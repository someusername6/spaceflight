var ay=Object.defineProperty;var cy=(t,e,n)=>e in t?ay(t,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):t[e]=n;var sc=(t,e,n)=>cy(t,typeof e!="symbol"?e+"":e,n);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function n(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(s){if(s.ep)return;s.ep=!0;const r=n(s);fetch(s.href,r)}})();function eo(t){return{seed:t>>>0}}function ft(t){t.seed+=1831565813;let e=t.seed;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function zr(t,e,n){return ft(t)*(n-e)+e}function Qp(t){let e,n,i,s;do e=zr(t,-1,1),n=zr(t,-1,1),i=zr(t,-1,1),s=e*e+n*n+i*i;while(s>1||s===0);const r=Math.sqrt(s);return{x:e/r,y:n/r,z:i/r}}/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const $u="170",ly=0,rf=1,uy=2,em=1,dy=2,ei=3,Ni=0,Gt=1,Dt=2,Pi=0,Vs=1,ot=2,of=3,af=4,fy=5,ji=100,hy=101,py=102,my=103,gy=104,vy=200,yy=201,Sy=202,_y=203,Dl=204,Il=205,xy=206,by=207,My=208,Ey=209,wy=210,Ty=211,Ay=212,Ry=213,Cy=214,Nl=0,Ul=1,kl=2,Zs=3,Fl=4,Ol=5,Bl=6,zl=7,Xu=0,Py=1,Ly=2,Li=0,Dy=1,Iy=2,Ny=3,Uy=4,ky=5,Fy=6,Oy=7,tm=300,Js=301,Qs=302,Hl=303,Gl=304,Oa=306,Wl=1e3,Ji=1001,Vl=1002,Ln=1003,By=1004,So=1005,qt=1006,rc=1007,Qi=1008,ri=1009,nm=1010,im=1011,qr=1012,qu=1013,ns=1014,ti=1015,to=1016,Yu=1017,ju=1018,er=1020,sm=35902,rm=1021,om=1022,nn=1023,am=1024,cm=1025,$s=1026,tr=1027,lm=1028,Ku=1029,um=1030,Zu=1031,Ju=1033,ua=33776,da=33777,fa=33778,ha=33779,$l=35840,Xl=35841,ql=35842,Yl=35843,jl=36196,Kl=37492,Zl=37496,Jl=37808,Ql=37809,eu=37810,tu=37811,nu=37812,iu=37813,su=37814,ru=37815,ou=37816,au=37817,cu=37818,lu=37819,uu=37820,du=37821,pa=36492,fu=36494,hu=36495,dm=36283,pu=36284,mu=36285,gu=36286,zy=3200,Hy=3201,fm=0,Gy=1,Ei="",hn="srgb",ur="srgb-linear",Ba="linear",nt="srgb",hs=7680,cf=519,Wy=512,Vy=513,$y=514,hm=515,Xy=516,qy=517,Yy=518,jy=519,vu=35044,lf="300 es",ni=2e3,Ea=2001;class dr{addEventListener(e,n){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(n)===-1&&i[e].push(n)}hasEventListener(e,n){if(this._listeners===void 0)return!1;const i=this._listeners;return i[e]!==void 0&&i[e].indexOf(n)!==-1}removeEventListener(e,n){if(this._listeners===void 0)return;const s=this._listeners[e];if(s!==void 0){const r=s.indexOf(n);r!==-1&&s.splice(r,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const i=this._listeners[e.type];if(i!==void 0){e.target=this;const s=i.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}}const Ot=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let uf=1234567;const Hr=Math.PI/180,Yr=180/Math.PI;function ii(){const t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(Ot[t&255]+Ot[t>>8&255]+Ot[t>>16&255]+Ot[t>>24&255]+"-"+Ot[e&255]+Ot[e>>8&255]+"-"+Ot[e>>16&15|64]+Ot[e>>24&255]+"-"+Ot[n&63|128]+Ot[n>>8&255]+"-"+Ot[n>>16&255]+Ot[n>>24&255]+Ot[i&255]+Ot[i>>8&255]+Ot[i>>16&255]+Ot[i>>24&255]).toLowerCase()}function Mt(t,e,n){return Math.max(e,Math.min(n,t))}function Qu(t,e){return(t%e+e)%e}function Ky(t,e,n,i,s){return i+(t-e)*(s-i)/(n-e)}function Zy(t,e,n){return t!==e?(n-t)/(e-t):0}function Gr(t,e,n){return(1-n)*t+n*e}function Jy(t,e,n,i){return Gr(t,e,1-Math.exp(-n*i))}function Qy(t,e=1){return e-Math.abs(Qu(t,e*2)-e)}function eS(t,e,n){return t<=e?0:t>=n?1:(t=(t-e)/(n-e),t*t*(3-2*t))}function tS(t,e,n){return t<=e?0:t>=n?1:(t=(t-e)/(n-e),t*t*t*(t*(t*6-15)+10))}function nS(t,e){return t+Math.floor(Math.random()*(e-t+1))}function iS(t,e){return t+Math.random()*(e-t)}function sS(t){return t*(.5-Math.random())}function rS(t){t!==void 0&&(uf=t);let e=uf+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function oS(t){return t*Hr}function aS(t){return t*Yr}function cS(t){return(t&t-1)===0&&t!==0}function lS(t){return Math.pow(2,Math.ceil(Math.log(t)/Math.LN2))}function uS(t){return Math.pow(2,Math.floor(Math.log(t)/Math.LN2))}function dS(t,e,n,i,s){const r=Math.cos,o=Math.sin,a=r(n/2),c=o(n/2),l=r((e+i)/2),u=o((e+i)/2),d=r((e-i)/2),f=o((e-i)/2),h=r((i-e)/2),p=o((i-e)/2);switch(s){case"XYX":t.set(a*u,c*d,c*f,a*l);break;case"YZY":t.set(c*f,a*u,c*d,a*l);break;case"ZXZ":t.set(c*d,c*f,a*u,a*l);break;case"XZX":t.set(a*u,c*p,c*h,a*l);break;case"YXY":t.set(c*h,a*u,c*p,a*l);break;case"ZYZ":t.set(c*p,c*h,a*u,a*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function An(t,e){switch(e.constructor){case Float32Array:return t;case Uint32Array:return t/4294967295;case Uint16Array:return t/65535;case Uint8Array:return t/255;case Int32Array:return Math.max(t/2147483647,-1);case Int16Array:return Math.max(t/32767,-1);case Int8Array:return Math.max(t/127,-1);default:throw new Error("Invalid component type.")}}function tt(t,e){switch(e.constructor){case Float32Array:return t;case Uint32Array:return Math.round(t*4294967295);case Uint16Array:return Math.round(t*65535);case Uint8Array:return Math.round(t*255);case Int32Array:return Math.round(t*2147483647);case Int16Array:return Math.round(t*32767);case Int8Array:return Math.round(t*127);default:throw new Error("Invalid component type.")}}const fS={DEG2RAD:Hr,RAD2DEG:Yr,generateUUID:ii,clamp:Mt,euclideanModulo:Qu,mapLinear:Ky,inverseLerp:Zy,lerp:Gr,damp:Jy,pingpong:Qy,smoothstep:eS,smootherstep:tS,randInt:nS,randFloat:iS,randFloatSpread:sS,seededRandom:rS,degToRad:oS,radToDeg:aS,isPowerOfTwo:cS,ceilPowerOfTwo:lS,floorPowerOfTwo:uS,setQuaternionFromProperEuler:dS,normalize:tt,denormalize:An};class fe{constructor(e=0,n=0){fe.prototype.isVector2=!0,this.x=e,this.y=n}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,n){return this.x=e,this.y=n,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const n=this.x,i=this.y,s=e.elements;return this.x=s[0]*n+s[3]*i+s[6],this.y=s[1]*n+s[4]*i+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,n){return this.x=Math.max(e.x,Math.min(n.x,this.x)),this.y=Math.max(e.y,Math.min(n.y,this.y)),this}clampScalar(e,n){return this.x=Math.max(e,Math.min(n,this.x)),this.y=Math.max(e,Math.min(n,this.y)),this}clampLength(e,n){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(n,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const i=this.dot(e)/n;return Math.acos(Mt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,i=this.y-e.y;return n*n+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this}lerpVectors(e,n,i){return this.x=e.x+(n.x-e.x)*i,this.y=e.y+(n.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this}rotateAround(e,n){const i=Math.cos(n),s=Math.sin(n),r=this.x-e.x,o=this.y-e.y;return this.x=r*i-o*s+e.x,this.y=r*s+o*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Ne{constructor(e,n,i,s,r,o,a,c,l){Ne.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,n,i,s,r,o,a,c,l)}set(e,n,i,s,r,o,a,c,l){const u=this.elements;return u[0]=e,u[1]=s,u[2]=a,u[3]=n,u[4]=r,u[5]=c,u[6]=i,u[7]=o,u[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const n=this.elements,i=e.elements;return n[0]=i[0],n[1]=i[1],n[2]=i[2],n[3]=i[3],n[4]=i[4],n[5]=i[5],n[6]=i[6],n[7]=i[7],n[8]=i[8],this}extractBasis(e,n,i){return e.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const n=e.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const i=e.elements,s=n.elements,r=this.elements,o=i[0],a=i[3],c=i[6],l=i[1],u=i[4],d=i[7],f=i[2],h=i[5],p=i[8],v=s[0],g=s[3],m=s[6],S=s[1],_=s[4],y=s[7],D=s[2],E=s[5],A=s[8];return r[0]=o*v+a*S+c*D,r[3]=o*g+a*_+c*E,r[6]=o*m+a*y+c*A,r[1]=l*v+u*S+d*D,r[4]=l*g+u*_+d*E,r[7]=l*m+u*y+d*A,r[2]=f*v+h*S+p*D,r[5]=f*g+h*_+p*E,r[8]=f*m+h*y+p*A,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[3]*=e,n[6]*=e,n[1]*=e,n[4]*=e,n[7]*=e,n[2]*=e,n[5]*=e,n[8]*=e,this}determinant(){const e=this.elements,n=e[0],i=e[1],s=e[2],r=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8];return n*o*u-n*a*l-i*r*u+i*a*c+s*r*l-s*o*c}invert(){const e=this.elements,n=e[0],i=e[1],s=e[2],r=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8],d=u*o-a*l,f=a*c-u*r,h=l*r-o*c,p=n*d+i*f+s*h;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/p;return e[0]=d*v,e[1]=(s*l-u*i)*v,e[2]=(a*i-s*o)*v,e[3]=f*v,e[4]=(u*n-s*c)*v,e[5]=(s*r-a*n)*v,e[6]=h*v,e[7]=(i*c-l*n)*v,e[8]=(o*n-i*r)*v,this}transpose(){let e;const n=this.elements;return e=n[1],n[1]=n[3],n[3]=e,e=n[2],n[2]=n[6],n[6]=e,e=n[5],n[5]=n[7],n[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const n=this.elements;return e[0]=n[0],e[1]=n[3],e[2]=n[6],e[3]=n[1],e[4]=n[4],e[5]=n[7],e[6]=n[2],e[7]=n[5],e[8]=n[8],this}setUvTransform(e,n,i,s,r,o,a){const c=Math.cos(r),l=Math.sin(r);return this.set(i*c,i*l,-i*(c*o+l*a)+o+e,-s*l,s*c,-s*(-l*o+c*a)+a+n,0,0,1),this}scale(e,n){return this.premultiply(oc.makeScale(e,n)),this}rotate(e){return this.premultiply(oc.makeRotation(-e)),this}translate(e,n){return this.premultiply(oc.makeTranslation(e,n)),this}makeTranslation(e,n){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,n,0,0,1),this}makeRotation(e){const n=Math.cos(e),i=Math.sin(e);return this.set(n,-i,0,i,n,0,0,0,1),this}makeScale(e,n){return this.set(e,0,0,0,n,0,0,0,1),this}equals(e){const n=this.elements,i=e.elements;for(let s=0;s<9;s++)if(n[s]!==i[s])return!1;return!0}fromArray(e,n=0){for(let i=0;i<9;i++)this.elements[i]=e[i+n];return this}toArray(e=[],n=0){const i=this.elements;return e[n]=i[0],e[n+1]=i[1],e[n+2]=i[2],e[n+3]=i[3],e[n+4]=i[4],e[n+5]=i[5],e[n+6]=i[6],e[n+7]=i[7],e[n+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const oc=new Ne;function pm(t){for(let e=t.length-1;e>=0;--e)if(t[e]>=65535)return!0;return!1}function wa(t){return document.createElementNS("http://www.w3.org/1999/xhtml",t)}function hS(){const t=wa("canvas");return t.style.display="block",t}const df={};function Nr(t){t in df||(df[t]=!0,console.warn(t))}function pS(t,e,n){return new Promise(function(i,s){function r(){switch(t.clientWaitSync(e,t.SYNC_FLUSH_COMMANDS_BIT,0)){case t.WAIT_FAILED:s();break;case t.TIMEOUT_EXPIRED:setTimeout(r,n);break;default:i()}}setTimeout(r,n)})}function mS(t){const e=t.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function gS(t){const e=t.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const Xe={enabled:!0,workingColorSpace:ur,spaces:{},convert:function(t,e,n){return this.enabled===!1||e===n||!e||!n||(this.spaces[e].transfer===nt&&(t.r=si(t.r),t.g=si(t.g),t.b=si(t.b)),this.spaces[e].primaries!==this.spaces[n].primaries&&(t.applyMatrix3(this.spaces[e].toXYZ),t.applyMatrix3(this.spaces[n].fromXYZ)),this.spaces[n].transfer===nt&&(t.r=Xs(t.r),t.g=Xs(t.g),t.b=Xs(t.b))),t},fromWorkingColorSpace:function(t,e){return this.convert(t,this.workingColorSpace,e)},toWorkingColorSpace:function(t,e){return this.convert(t,e,this.workingColorSpace)},getPrimaries:function(t){return this.spaces[t].primaries},getTransfer:function(t){return t===Ei?Ba:this.spaces[t].transfer},getLuminanceCoefficients:function(t,e=this.workingColorSpace){return t.fromArray(this.spaces[e].luminanceCoefficients)},define:function(t){Object.assign(this.spaces,t)},_getMatrix:function(t,e,n){return t.copy(this.spaces[e].toXYZ).multiply(this.spaces[n].fromXYZ)},_getDrawingBufferColorSpace:function(t){return this.spaces[t].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(t=this.workingColorSpace){return this.spaces[t].workingColorSpaceConfig.unpackColorSpace}};function si(t){return t<.04045?t*.0773993808:Math.pow(t*.9478672986+.0521327014,2.4)}function Xs(t){return t<.0031308?t*12.92:1.055*Math.pow(t,.41666)-.055}const ff=[.64,.33,.3,.6,.15,.06],hf=[.2126,.7152,.0722],pf=[.3127,.329],mf=new Ne().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),gf=new Ne().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);Xe.define({[ur]:{primaries:ff,whitePoint:pf,transfer:Ba,toXYZ:mf,fromXYZ:gf,luminanceCoefficients:hf,workingColorSpaceConfig:{unpackColorSpace:hn},outputColorSpaceConfig:{drawingBufferColorSpace:hn}},[hn]:{primaries:ff,whitePoint:pf,transfer:nt,toXYZ:mf,fromXYZ:gf,luminanceCoefficients:hf,outputColorSpaceConfig:{drawingBufferColorSpace:hn}}});let ps;class vS{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{ps===void 0&&(ps=wa("canvas")),ps.width=e.width,ps.height=e.height;const i=ps.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),n=ps}return n.width>2048||n.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),n.toDataURL("image/jpeg",.6)):n.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const n=wa("canvas");n.width=e.width,n.height=e.height;const i=n.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const s=i.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=si(r[o]/255)*255;return i.putImageData(s,0,0),n}else if(e.data){const n=e.data.slice(0);for(let i=0;i<n.length;i++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[i]=Math.floor(si(n[i]/255)*255):n[i]=si(n[i]);return{data:n,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let yS=0;class mm{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:yS++}),this.uuid=ii(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(ac(s[o].image)):r.push(ac(s[o]))}else r=ac(s);i.url=r}return n||(e.images[this.uuid]=i),i}}function ac(t){return typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap?vS.getDataURL(t):t.data?{data:Array.from(t.data),width:t.width,height:t.height,type:t.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let SS=0;class Yt extends dr{constructor(e=Yt.DEFAULT_IMAGE,n=Yt.DEFAULT_MAPPING,i=Ji,s=Ji,r=qt,o=Qi,a=nn,c=ri,l=Yt.DEFAULT_ANISOTROPY,u=Ei){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:SS++}),this.uuid=ii(),this.name="",this.source=new mm(e),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new fe(0,0),this.repeat=new fe(1,1),this.center=new fe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ne,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),n||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==tm)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Wl:e.x=e.x-Math.floor(e.x);break;case Ji:e.x=e.x<0?0:1;break;case Vl:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Wl:e.y=e.y-Math.floor(e.y);break;case Ji:e.y=e.y<0?0:1;break;case Vl:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Yt.DEFAULT_IMAGE=null;Yt.DEFAULT_MAPPING=tm;Yt.DEFAULT_ANISOTROPY=1;class qe{constructor(e=0,n=0,i=0,s=1){qe.prototype.isVector4=!0,this.x=e,this.y=n,this.z=i,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,n,i,s){return this.x=e,this.y=n,this.z=i,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this.w=e.w+n.w,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this.w+=e.w*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this.w=e.w-n.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const n=this.x,i=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*n+o[4]*i+o[8]*s+o[12]*r,this.y=o[1]*n+o[5]*i+o[9]*s+o[13]*r,this.z=o[2]*n+o[6]*i+o[10]*s+o[14]*r,this.w=o[3]*n+o[7]*i+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const n=Math.sqrt(1-e.w*e.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/n,this.y=e.y/n,this.z=e.z/n),this}setAxisAngleFromRotationMatrix(e){let n,i,s,r;const c=e.elements,l=c[0],u=c[4],d=c[8],f=c[1],h=c[5],p=c[9],v=c[2],g=c[6],m=c[10];if(Math.abs(u-f)<.01&&Math.abs(d-v)<.01&&Math.abs(p-g)<.01){if(Math.abs(u+f)<.1&&Math.abs(d+v)<.1&&Math.abs(p+g)<.1&&Math.abs(l+h+m-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const _=(l+1)/2,y=(h+1)/2,D=(m+1)/2,E=(u+f)/4,A=(d+v)/4,P=(p+g)/4;return _>y&&_>D?_<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(_),s=E/i,r=A/i):y>D?y<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),i=E/s,r=P/s):D<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(D),i=A/r,s=P/r),this.set(i,s,r,n),this}let S=Math.sqrt((g-p)*(g-p)+(d-v)*(d-v)+(f-u)*(f-u));return Math.abs(S)<.001&&(S=1),this.x=(g-p)/S,this.y=(d-v)/S,this.z=(f-u)/S,this.w=Math.acos((l+h+m-1)/2),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,n){return this.x=Math.max(e.x,Math.min(n.x,this.x)),this.y=Math.max(e.y,Math.min(n.y,this.y)),this.z=Math.max(e.z,Math.min(n.z,this.z)),this.w=Math.max(e.w,Math.min(n.w,this.w)),this}clampScalar(e,n){return this.x=Math.max(e,Math.min(n,this.x)),this.y=Math.max(e,Math.min(n,this.y)),this.z=Math.max(e,Math.min(n,this.z)),this.w=Math.max(e,Math.min(n,this.w)),this}clampLength(e,n){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(n,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this.w+=(e.w-this.w)*n,this}lerpVectors(e,n,i){return this.x=e.x+(n.x-e.x)*i,this.y=e.y+(n.y-e.y)*i,this.z=e.z+(n.z-e.z)*i,this.w=e.w+(n.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this.w=e[n+3],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e[n+3]=this.w,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this.w=e.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class _S extends dr{constructor(e=1,n=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=n,this.depth=1,this.scissor=new qe(0,0,e,n),this.scissorTest=!1,this.viewport=new qe(0,0,e,n);const s={width:e,height:n,depth:1};i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:qt,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},i);const r=new Yt(s,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace);r.flipY=!1,r.generateMipmaps=i.generateMipmaps,r.internalFormat=i.internalFormat,this.textures=[];const o=i.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,n,i=1){if(this.width!==e||this.height!==n||this.depth!==i){this.width=e,this.height=n,this.depth=i;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=n,this.textures[s].image.depth=i;this.dispose()}this.viewport.set(0,0,e,n),this.scissor.set(0,0,e,n)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let i=0,s=e.textures.length;i<s;i++)this.textures[i]=e.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0;const n=Object.assign({},e.texture.image);return this.texture.source=new mm(n),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ui extends _S{constructor(e=1,n=1,i={}){super(e,n,i),this.isWebGLRenderTarget=!0}}class gm extends Yt{constructor(e=null,n=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:n,height:i,depth:s},this.magFilter=Ln,this.minFilter=Ln,this.wrapR=Ji,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class xS extends Yt{constructor(e=null,n=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:n,height:i,depth:s},this.magFilter=Ln,this.minFilter=Ln,this.wrapR=Ji,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class at{constructor(e=0,n=0,i=0,s=1){this.isQuaternion=!0,this._x=e,this._y=n,this._z=i,this._w=s}static slerpFlat(e,n,i,s,r,o,a){let c=i[s+0],l=i[s+1],u=i[s+2],d=i[s+3];const f=r[o+0],h=r[o+1],p=r[o+2],v=r[o+3];if(a===0){e[n+0]=c,e[n+1]=l,e[n+2]=u,e[n+3]=d;return}if(a===1){e[n+0]=f,e[n+1]=h,e[n+2]=p,e[n+3]=v;return}if(d!==v||c!==f||l!==h||u!==p){let g=1-a;const m=c*f+l*h+u*p+d*v,S=m>=0?1:-1,_=1-m*m;if(_>Number.EPSILON){const D=Math.sqrt(_),E=Math.atan2(D,m*S);g=Math.sin(g*E)/D,a=Math.sin(a*E)/D}const y=a*S;if(c=c*g+f*y,l=l*g+h*y,u=u*g+p*y,d=d*g+v*y,g===1-a){const D=1/Math.sqrt(c*c+l*l+u*u+d*d);c*=D,l*=D,u*=D,d*=D}}e[n]=c,e[n+1]=l,e[n+2]=u,e[n+3]=d}static multiplyQuaternionsFlat(e,n,i,s,r,o){const a=i[s],c=i[s+1],l=i[s+2],u=i[s+3],d=r[o],f=r[o+1],h=r[o+2],p=r[o+3];return e[n]=a*p+u*d+c*h-l*f,e[n+1]=c*p+u*f+l*d-a*h,e[n+2]=l*p+u*h+a*f-c*d,e[n+3]=u*p-a*d-c*f-l*h,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,n,i,s){return this._x=e,this._y=n,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,n=!0){const i=e._x,s=e._y,r=e._z,o=e._order,a=Math.cos,c=Math.sin,l=a(i/2),u=a(s/2),d=a(r/2),f=c(i/2),h=c(s/2),p=c(r/2);switch(o){case"XYZ":this._x=f*u*d+l*h*p,this._y=l*h*d-f*u*p,this._z=l*u*p+f*h*d,this._w=l*u*d-f*h*p;break;case"YXZ":this._x=f*u*d+l*h*p,this._y=l*h*d-f*u*p,this._z=l*u*p-f*h*d,this._w=l*u*d+f*h*p;break;case"ZXY":this._x=f*u*d-l*h*p,this._y=l*h*d+f*u*p,this._z=l*u*p+f*h*d,this._w=l*u*d-f*h*p;break;case"ZYX":this._x=f*u*d-l*h*p,this._y=l*h*d+f*u*p,this._z=l*u*p-f*h*d,this._w=l*u*d+f*h*p;break;case"YZX":this._x=f*u*d+l*h*p,this._y=l*h*d+f*u*p,this._z=l*u*p-f*h*d,this._w=l*u*d-f*h*p;break;case"XZY":this._x=f*u*d-l*h*p,this._y=l*h*d-f*u*p,this._z=l*u*p+f*h*d,this._w=l*u*d+f*h*p;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,n){const i=n/2,s=Math.sin(i);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const n=e.elements,i=n[0],s=n[4],r=n[8],o=n[1],a=n[5],c=n[9],l=n[2],u=n[6],d=n[10],f=i+a+d;if(f>0){const h=.5/Math.sqrt(f+1);this._w=.25/h,this._x=(u-c)*h,this._y=(r-l)*h,this._z=(o-s)*h}else if(i>a&&i>d){const h=2*Math.sqrt(1+i-a-d);this._w=(u-c)/h,this._x=.25*h,this._y=(s+o)/h,this._z=(r+l)/h}else if(a>d){const h=2*Math.sqrt(1+a-i-d);this._w=(r-l)/h,this._x=(s+o)/h,this._y=.25*h,this._z=(c+u)/h}else{const h=2*Math.sqrt(1+d-i-a);this._w=(o-s)/h,this._x=(r+l)/h,this._y=(c+u)/h,this._z=.25*h}return this._onChangeCallback(),this}setFromUnitVectors(e,n){let i=e.dot(n)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*n.z-e.z*n.y,this._y=e.z*n.x-e.x*n.z,this._z=e.x*n.y-e.y*n.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Mt(this.dot(e),-1,1)))}rotateTowards(e,n){const i=this.angleTo(e);if(i===0)return this;const s=Math.min(1,n/i);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,n){const i=e._x,s=e._y,r=e._z,o=e._w,a=n._x,c=n._y,l=n._z,u=n._w;return this._x=i*u+o*a+s*l-r*c,this._y=s*u+o*c+r*a-i*l,this._z=r*u+o*l+i*c-s*a,this._w=o*u-i*a-s*c-r*l,this._onChangeCallback(),this}slerp(e,n){if(n===0)return this;if(n===1)return this.copy(e);const i=this._x,s=this._y,r=this._z,o=this._w;let a=o*e._w+i*e._x+s*e._y+r*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=i,this._y=s,this._z=r,this;const c=1-a*a;if(c<=Number.EPSILON){const h=1-n;return this._w=h*o+n*this._w,this._x=h*i+n*this._x,this._y=h*s+n*this._y,this._z=h*r+n*this._z,this.normalize(),this}const l=Math.sqrt(c),u=Math.atan2(l,a),d=Math.sin((1-n)*u)/l,f=Math.sin(n*u)/l;return this._w=o*d+this._w*f,this._x=i*d+this._x*f,this._y=s*d+this._y*f,this._z=r*d+this._z*f,this._onChangeCallback(),this}slerpQuaternions(e,n,i){return this.copy(e).slerp(n,i)}random(){const e=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),i=Math.random(),s=Math.sqrt(1-i),r=Math.sqrt(i);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(n),r*Math.cos(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,n=0){return this._x=e[n],this._y=e[n+1],this._z=e[n+2],this._w=e[n+3],this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._w,e}fromBufferAttribute(e,n){return this._x=e.getX(n),this._y=e.getY(n),this._z=e.getZ(n),this._w=e.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class T{constructor(e=0,n=0,i=0){T.prototype.isVector3=!0,this.x=e,this.y=n,this.z=i}set(e,n,i){return i===void 0&&(i=this.z),this.x=e,this.y=n,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,n){return this.x=e.x*n.x,this.y=e.y*n.y,this.z=e.z*n.z,this}applyEuler(e){return this.applyQuaternion(vf.setFromEuler(e))}applyAxisAngle(e,n){return this.applyQuaternion(vf.setFromAxisAngle(e,n))}applyMatrix3(e){const n=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*n+r[3]*i+r[6]*s,this.y=r[1]*n+r[4]*i+r[7]*s,this.z=r[2]*n+r[5]*i+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const n=this.x,i=this.y,s=this.z,r=e.elements,o=1/(r[3]*n+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*n+r[4]*i+r[8]*s+r[12])*o,this.y=(r[1]*n+r[5]*i+r[9]*s+r[13])*o,this.z=(r[2]*n+r[6]*i+r[10]*s+r[14])*o,this}applyQuaternion(e){const n=this.x,i=this.y,s=this.z,r=e.x,o=e.y,a=e.z,c=e.w,l=2*(o*s-a*i),u=2*(a*n-r*s),d=2*(r*i-o*n);return this.x=n+c*l+o*d-a*u,this.y=i+c*u+a*l-r*d,this.z=s+c*d+r*u-o*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const n=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*n+r[4]*i+r[8]*s,this.y=r[1]*n+r[5]*i+r[9]*s,this.z=r[2]*n+r[6]*i+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,n){return this.x=Math.max(e.x,Math.min(n.x,this.x)),this.y=Math.max(e.y,Math.min(n.y,this.y)),this.z=Math.max(e.z,Math.min(n.z,this.z)),this}clampScalar(e,n){return this.x=Math.max(e,Math.min(n,this.x)),this.y=Math.max(e,Math.min(n,this.y)),this.z=Math.max(e,Math.min(n,this.z)),this}clampLength(e,n){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(n,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this}lerpVectors(e,n,i){return this.x=e.x+(n.x-e.x)*i,this.y=e.y+(n.y-e.y)*i,this.z=e.z+(n.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,n){const i=e.x,s=e.y,r=e.z,o=n.x,a=n.y,c=n.z;return this.x=s*c-r*a,this.y=r*o-i*c,this.z=i*a-s*o,this}projectOnVector(e){const n=e.lengthSq();if(n===0)return this.set(0,0,0);const i=e.dot(this)/n;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return cc.copy(this).projectOnVector(e),this.sub(cc)}reflect(e){return this.sub(cc.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const i=this.dot(e)/n;return Math.acos(Mt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,i=this.y-e.y,s=this.z-e.z;return n*n+i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,n,i){const s=Math.sin(n)*e;return this.x=s*Math.sin(i),this.y=Math.cos(n)*e,this.z=s*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,n,i){return this.x=e*Math.sin(n),this.y=i,this.z=e*Math.cos(n),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(e){const n=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=n,this.y=i,this.z=s,this}setFromMatrixColumn(e,n){return this.fromArray(e.elements,n*4)}setFromMatrix3Column(e,n){return this.fromArray(e.elements,n*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,n=Math.random()*2-1,i=Math.sqrt(1-n*n);return this.x=i*Math.cos(e),this.y=n,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const cc=new T,vf=new at;class oi{constructor(e=new T(1/0,1/0,1/0),n=new T(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=n}set(e,n){return this.min.copy(e),this.max.copy(n),this}setFromArray(e){this.makeEmpty();for(let n=0,i=e.length;n<i;n+=3)this.expandByPoint(bn.fromArray(e,n));return this}setFromBufferAttribute(e){this.makeEmpty();for(let n=0,i=e.count;n<i;n++)this.expandByPoint(bn.fromBufferAttribute(e,n));return this}setFromPoints(e){this.makeEmpty();for(let n=0,i=e.length;n<i;n++)this.expandByPoint(e[n]);return this}setFromCenterAndSize(e,n){const i=bn.copy(n).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,n=!1){return this.makeEmpty(),this.expandByObject(e,n)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,n=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const r=i.getAttribute("position");if(n===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,bn):bn.fromBufferAttribute(r,o),bn.applyMatrix4(e.matrixWorld),this.expandByPoint(bn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),_o.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),_o.copy(i.boundingBox)),_o.applyMatrix4(e.matrixWorld),this.union(_o)}const s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],n);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,n){return n.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,bn),bn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let n,i;return e.normal.x>0?(n=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(n=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(n+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(n+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(n+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(n+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),n<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(br),xo.subVectors(this.max,br),ms.subVectors(e.a,br),gs.subVectors(e.b,br),vs.subVectors(e.c,br),fi.subVectors(gs,ms),hi.subVectors(vs,gs),Bi.subVectors(ms,vs);let n=[0,-fi.z,fi.y,0,-hi.z,hi.y,0,-Bi.z,Bi.y,fi.z,0,-fi.x,hi.z,0,-hi.x,Bi.z,0,-Bi.x,-fi.y,fi.x,0,-hi.y,hi.x,0,-Bi.y,Bi.x,0];return!lc(n,ms,gs,vs,xo)||(n=[1,0,0,0,1,0,0,0,1],!lc(n,ms,gs,vs,xo))?!1:(bo.crossVectors(fi,hi),n=[bo.x,bo.y,bo.z],lc(n,ms,gs,vs,xo))}clampPoint(e,n){return n.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,bn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(bn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(qn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),qn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),qn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),qn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),qn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),qn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),qn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),qn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(qn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const qn=[new T,new T,new T,new T,new T,new T,new T,new T],bn=new T,_o=new oi,ms=new T,gs=new T,vs=new T,fi=new T,hi=new T,Bi=new T,br=new T,xo=new T,bo=new T,zi=new T;function lc(t,e,n,i,s){for(let r=0,o=t.length-3;r<=o;r+=3){zi.fromArray(t,r);const a=s.x*Math.abs(zi.x)+s.y*Math.abs(zi.y)+s.z*Math.abs(zi.z),c=e.dot(zi),l=n.dot(zi),u=i.dot(zi);if(Math.max(-Math.max(c,l,u),Math.min(c,l,u))>a)return!1}return!0}const bS=new oi,Mr=new T,uc=new T;class fr{constructor(e=new T,n=-1){this.isSphere=!0,this.center=e,this.radius=n}set(e,n){return this.center.copy(e),this.radius=n,this}setFromPoints(e,n){const i=this.center;n!==void 0?i.copy(n):bS.setFromPoints(e).getCenter(i);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,i.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const n=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=n*n}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,n){const i=this.center.distanceToSquared(e);return n.copy(e),i>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Mr.subVectors(e,this.center);const n=Mr.lengthSq();if(n>this.radius*this.radius){const i=Math.sqrt(n),s=(i-this.radius)*.5;this.center.addScaledVector(Mr,s/i),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(uc.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Mr.copy(e.center).add(uc)),this.expandByPoint(Mr.copy(e.center).sub(uc))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const Yn=new T,dc=new T,Mo=new T,pi=new T,fc=new T,Eo=new T,hc=new T;class vm{constructor(e=new T,n=new T(0,0,-1)){this.origin=e,this.direction=n}set(e,n){return this.origin.copy(e),this.direction.copy(n),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,n){return n.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Yn)),this}closestPointToPoint(e,n){n.subVectors(e,this.origin);const i=n.dot(this.direction);return i<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const n=Yn.subVectors(e,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(e):(Yn.copy(this.origin).addScaledVector(this.direction,n),Yn.distanceToSquared(e))}distanceSqToSegment(e,n,i,s){dc.copy(e).add(n).multiplyScalar(.5),Mo.copy(n).sub(e).normalize(),pi.copy(this.origin).sub(dc);const r=e.distanceTo(n)*.5,o=-this.direction.dot(Mo),a=pi.dot(this.direction),c=-pi.dot(Mo),l=pi.lengthSq(),u=Math.abs(1-o*o);let d,f,h,p;if(u>0)if(d=o*c-a,f=o*a-c,p=r*u,d>=0)if(f>=-p)if(f<=p){const v=1/u;d*=v,f*=v,h=d*(d+o*f+2*a)+f*(o*d+f+2*c)+l}else f=r,d=Math.max(0,-(o*f+a)),h=-d*d+f*(f+2*c)+l;else f=-r,d=Math.max(0,-(o*f+a)),h=-d*d+f*(f+2*c)+l;else f<=-p?(d=Math.max(0,-(-o*r+a)),f=d>0?-r:Math.min(Math.max(-r,-c),r),h=-d*d+f*(f+2*c)+l):f<=p?(d=0,f=Math.min(Math.max(-r,-c),r),h=f*(f+2*c)+l):(d=Math.max(0,-(o*r+a)),f=d>0?r:Math.min(Math.max(-r,-c),r),h=-d*d+f*(f+2*c)+l);else f=o>0?-r:r,d=Math.max(0,-(o*f+a)),h=-d*d+f*(f+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,d),s&&s.copy(dc).addScaledVector(Mo,f),h}intersectSphere(e,n){Yn.subVectors(e.center,this.origin);const i=Yn.dot(this.direction),s=Yn.dot(Yn)-i*i,r=e.radius*e.radius;if(s>r)return null;const o=Math.sqrt(r-s),a=i-o,c=i+o;return c<0?null:a<0?this.at(c,n):this.at(a,n)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const n=e.normal.dot(this.direction);if(n===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/n;return i>=0?i:null}intersectPlane(e,n){const i=this.distanceToPlane(e);return i===null?null:this.at(i,n)}intersectsPlane(e){const n=e.distanceToPoint(this.origin);return n===0||e.normal.dot(this.direction)*n<0}intersectBox(e,n){let i,s,r,o,a,c;const l=1/this.direction.x,u=1/this.direction.y,d=1/this.direction.z,f=this.origin;return l>=0?(i=(e.min.x-f.x)*l,s=(e.max.x-f.x)*l):(i=(e.max.x-f.x)*l,s=(e.min.x-f.x)*l),u>=0?(r=(e.min.y-f.y)*u,o=(e.max.y-f.y)*u):(r=(e.max.y-f.y)*u,o=(e.min.y-f.y)*u),i>o||r>s||((r>i||isNaN(i))&&(i=r),(o<s||isNaN(s))&&(s=o),d>=0?(a=(e.min.z-f.z)*d,c=(e.max.z-f.z)*d):(a=(e.max.z-f.z)*d,c=(e.min.z-f.z)*d),i>c||a>s)||((a>i||i!==i)&&(i=a),(c<s||s!==s)&&(s=c),s<0)?null:this.at(i>=0?i:s,n)}intersectsBox(e){return this.intersectBox(e,Yn)!==null}intersectTriangle(e,n,i,s,r){fc.subVectors(n,e),Eo.subVectors(i,e),hc.crossVectors(fc,Eo);let o=this.direction.dot(hc),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;pi.subVectors(this.origin,e);const c=a*this.direction.dot(Eo.crossVectors(pi,Eo));if(c<0)return null;const l=a*this.direction.dot(fc.cross(pi));if(l<0||c+l>o)return null;const u=-a*pi.dot(hc);return u<0?null:this.at(u/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Qe{constructor(e,n,i,s,r,o,a,c,l,u,d,f,h,p,v,g){Qe.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,n,i,s,r,o,a,c,l,u,d,f,h,p,v,g)}set(e,n,i,s,r,o,a,c,l,u,d,f,h,p,v,g){const m=this.elements;return m[0]=e,m[4]=n,m[8]=i,m[12]=s,m[1]=r,m[5]=o,m[9]=a,m[13]=c,m[2]=l,m[6]=u,m[10]=d,m[14]=f,m[3]=h,m[7]=p,m[11]=v,m[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Qe().fromArray(this.elements)}copy(e){const n=this.elements,i=e.elements;return n[0]=i[0],n[1]=i[1],n[2]=i[2],n[3]=i[3],n[4]=i[4],n[5]=i[5],n[6]=i[6],n[7]=i[7],n[8]=i[8],n[9]=i[9],n[10]=i[10],n[11]=i[11],n[12]=i[12],n[13]=i[13],n[14]=i[14],n[15]=i[15],this}copyPosition(e){const n=this.elements,i=e.elements;return n[12]=i[12],n[13]=i[13],n[14]=i[14],this}setFromMatrix3(e){const n=e.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(e,n,i){return e.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,n,i){return this.set(e.x,n.x,i.x,0,e.y,n.y,i.y,0,e.z,n.z,i.z,0,0,0,0,1),this}extractRotation(e){const n=this.elements,i=e.elements,s=1/ys.setFromMatrixColumn(e,0).length(),r=1/ys.setFromMatrixColumn(e,1).length(),o=1/ys.setFromMatrixColumn(e,2).length();return n[0]=i[0]*s,n[1]=i[1]*s,n[2]=i[2]*s,n[3]=0,n[4]=i[4]*r,n[5]=i[5]*r,n[6]=i[6]*r,n[7]=0,n[8]=i[8]*o,n[9]=i[9]*o,n[10]=i[10]*o,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(e){const n=this.elements,i=e.x,s=e.y,r=e.z,o=Math.cos(i),a=Math.sin(i),c=Math.cos(s),l=Math.sin(s),u=Math.cos(r),d=Math.sin(r);if(e.order==="XYZ"){const f=o*u,h=o*d,p=a*u,v=a*d;n[0]=c*u,n[4]=-c*d,n[8]=l,n[1]=h+p*l,n[5]=f-v*l,n[9]=-a*c,n[2]=v-f*l,n[6]=p+h*l,n[10]=o*c}else if(e.order==="YXZ"){const f=c*u,h=c*d,p=l*u,v=l*d;n[0]=f+v*a,n[4]=p*a-h,n[8]=o*l,n[1]=o*d,n[5]=o*u,n[9]=-a,n[2]=h*a-p,n[6]=v+f*a,n[10]=o*c}else if(e.order==="ZXY"){const f=c*u,h=c*d,p=l*u,v=l*d;n[0]=f-v*a,n[4]=-o*d,n[8]=p+h*a,n[1]=h+p*a,n[5]=o*u,n[9]=v-f*a,n[2]=-o*l,n[6]=a,n[10]=o*c}else if(e.order==="ZYX"){const f=o*u,h=o*d,p=a*u,v=a*d;n[0]=c*u,n[4]=p*l-h,n[8]=f*l+v,n[1]=c*d,n[5]=v*l+f,n[9]=h*l-p,n[2]=-l,n[6]=a*c,n[10]=o*c}else if(e.order==="YZX"){const f=o*c,h=o*l,p=a*c,v=a*l;n[0]=c*u,n[4]=v-f*d,n[8]=p*d+h,n[1]=d,n[5]=o*u,n[9]=-a*u,n[2]=-l*u,n[6]=h*d+p,n[10]=f-v*d}else if(e.order==="XZY"){const f=o*c,h=o*l,p=a*c,v=a*l;n[0]=c*u,n[4]=-d,n[8]=l*u,n[1]=f*d+v,n[5]=o*u,n[9]=h*d-p,n[2]=p*d-h,n[6]=a*u,n[10]=v*d+f}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(e){return this.compose(MS,e,ES)}lookAt(e,n,i){const s=this.elements;return Kt.subVectors(e,n),Kt.lengthSq()===0&&(Kt.z=1),Kt.normalize(),mi.crossVectors(i,Kt),mi.lengthSq()===0&&(Math.abs(i.z)===1?Kt.x+=1e-4:Kt.z+=1e-4,Kt.normalize(),mi.crossVectors(i,Kt)),mi.normalize(),wo.crossVectors(Kt,mi),s[0]=mi.x,s[4]=wo.x,s[8]=Kt.x,s[1]=mi.y,s[5]=wo.y,s[9]=Kt.y,s[2]=mi.z,s[6]=wo.z,s[10]=Kt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const i=e.elements,s=n.elements,r=this.elements,o=i[0],a=i[4],c=i[8],l=i[12],u=i[1],d=i[5],f=i[9],h=i[13],p=i[2],v=i[6],g=i[10],m=i[14],S=i[3],_=i[7],y=i[11],D=i[15],E=s[0],A=s[4],P=s[8],b=s[12],x=s[1],L=s[5],B=s[9],F=s[13],G=s[2],$=s[6],X=s[10],Q=s[14],V=s[3],re=s[7],he=s[11],Me=s[15];return r[0]=o*E+a*x+c*G+l*V,r[4]=o*A+a*L+c*$+l*re,r[8]=o*P+a*B+c*X+l*he,r[12]=o*b+a*F+c*Q+l*Me,r[1]=u*E+d*x+f*G+h*V,r[5]=u*A+d*L+f*$+h*re,r[9]=u*P+d*B+f*X+h*he,r[13]=u*b+d*F+f*Q+h*Me,r[2]=p*E+v*x+g*G+m*V,r[6]=p*A+v*L+g*$+m*re,r[10]=p*P+v*B+g*X+m*he,r[14]=p*b+v*F+g*Q+m*Me,r[3]=S*E+_*x+y*G+D*V,r[7]=S*A+_*L+y*$+D*re,r[11]=S*P+_*B+y*X+D*he,r[15]=S*b+_*F+y*Q+D*Me,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[4]*=e,n[8]*=e,n[12]*=e,n[1]*=e,n[5]*=e,n[9]*=e,n[13]*=e,n[2]*=e,n[6]*=e,n[10]*=e,n[14]*=e,n[3]*=e,n[7]*=e,n[11]*=e,n[15]*=e,this}determinant(){const e=this.elements,n=e[0],i=e[4],s=e[8],r=e[12],o=e[1],a=e[5],c=e[9],l=e[13],u=e[2],d=e[6],f=e[10],h=e[14],p=e[3],v=e[7],g=e[11],m=e[15];return p*(+r*c*d-s*l*d-r*a*f+i*l*f+s*a*h-i*c*h)+v*(+n*c*h-n*l*f+r*o*f-s*o*h+s*l*u-r*c*u)+g*(+n*l*d-n*a*h-r*o*d+i*o*h+r*a*u-i*l*u)+m*(-s*a*u-n*c*d+n*a*f+s*o*d-i*o*f+i*c*u)}transpose(){const e=this.elements;let n;return n=e[1],e[1]=e[4],e[4]=n,n=e[2],e[2]=e[8],e[8]=n,n=e[6],e[6]=e[9],e[9]=n,n=e[3],e[3]=e[12],e[12]=n,n=e[7],e[7]=e[13],e[13]=n,n=e[11],e[11]=e[14],e[14]=n,this}setPosition(e,n,i){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=n,s[14]=i),this}invert(){const e=this.elements,n=e[0],i=e[1],s=e[2],r=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8],d=e[9],f=e[10],h=e[11],p=e[12],v=e[13],g=e[14],m=e[15],S=d*g*l-v*f*l+v*c*h-a*g*h-d*c*m+a*f*m,_=p*f*l-u*g*l-p*c*h+o*g*h+u*c*m-o*f*m,y=u*v*l-p*d*l+p*a*h-o*v*h-u*a*m+o*d*m,D=p*d*c-u*v*c-p*a*f+o*v*f+u*a*g-o*d*g,E=n*S+i*_+s*y+r*D;if(E===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/E;return e[0]=S*A,e[1]=(v*f*r-d*g*r-v*s*h+i*g*h+d*s*m-i*f*m)*A,e[2]=(a*g*r-v*c*r+v*s*l-i*g*l-a*s*m+i*c*m)*A,e[3]=(d*c*r-a*f*r-d*s*l+i*f*l+a*s*h-i*c*h)*A,e[4]=_*A,e[5]=(u*g*r-p*f*r+p*s*h-n*g*h-u*s*m+n*f*m)*A,e[6]=(p*c*r-o*g*r-p*s*l+n*g*l+o*s*m-n*c*m)*A,e[7]=(o*f*r-u*c*r+u*s*l-n*f*l-o*s*h+n*c*h)*A,e[8]=y*A,e[9]=(p*d*r-u*v*r-p*i*h+n*v*h+u*i*m-n*d*m)*A,e[10]=(o*v*r-p*a*r+p*i*l-n*v*l-o*i*m+n*a*m)*A,e[11]=(u*a*r-o*d*r-u*i*l+n*d*l+o*i*h-n*a*h)*A,e[12]=D*A,e[13]=(u*v*s-p*d*s+p*i*f-n*v*f-u*i*g+n*d*g)*A,e[14]=(p*a*s-o*v*s-p*i*c+n*v*c+o*i*g-n*a*g)*A,e[15]=(o*d*s-u*a*s+u*i*c-n*d*c-o*i*f+n*a*f)*A,this}scale(e){const n=this.elements,i=e.x,s=e.y,r=e.z;return n[0]*=i,n[4]*=s,n[8]*=r,n[1]*=i,n[5]*=s,n[9]*=r,n[2]*=i,n[6]*=s,n[10]*=r,n[3]*=i,n[7]*=s,n[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,n=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(n,i,s))}makeTranslation(e,n,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,n,0,0,1,i,0,0,0,1),this}makeRotationX(e){const n=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,n,-i,0,0,i,n,0,0,0,0,1),this}makeRotationY(e){const n=Math.cos(e),i=Math.sin(e);return this.set(n,0,i,0,0,1,0,0,-i,0,n,0,0,0,0,1),this}makeRotationZ(e){const n=Math.cos(e),i=Math.sin(e);return this.set(n,-i,0,0,i,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,n){const i=Math.cos(n),s=Math.sin(n),r=1-i,o=e.x,a=e.y,c=e.z,l=r*o,u=r*a;return this.set(l*o+i,l*a-s*c,l*c+s*a,0,l*a+s*c,u*a+i,u*c-s*o,0,l*c-s*a,u*c+s*o,r*c*c+i,0,0,0,0,1),this}makeScale(e,n,i){return this.set(e,0,0,0,0,n,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,n,i,s,r,o){return this.set(1,i,r,0,e,1,o,0,n,s,1,0,0,0,0,1),this}compose(e,n,i){const s=this.elements,r=n._x,o=n._y,a=n._z,c=n._w,l=r+r,u=o+o,d=a+a,f=r*l,h=r*u,p=r*d,v=o*u,g=o*d,m=a*d,S=c*l,_=c*u,y=c*d,D=i.x,E=i.y,A=i.z;return s[0]=(1-(v+m))*D,s[1]=(h+y)*D,s[2]=(p-_)*D,s[3]=0,s[4]=(h-y)*E,s[5]=(1-(f+m))*E,s[6]=(g+S)*E,s[7]=0,s[8]=(p+_)*A,s[9]=(g-S)*A,s[10]=(1-(f+v))*A,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,n,i){const s=this.elements;let r=ys.set(s[0],s[1],s[2]).length();const o=ys.set(s[4],s[5],s[6]).length(),a=ys.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],Mn.copy(this);const l=1/r,u=1/o,d=1/a;return Mn.elements[0]*=l,Mn.elements[1]*=l,Mn.elements[2]*=l,Mn.elements[4]*=u,Mn.elements[5]*=u,Mn.elements[6]*=u,Mn.elements[8]*=d,Mn.elements[9]*=d,Mn.elements[10]*=d,n.setFromRotationMatrix(Mn),i.x=r,i.y=o,i.z=a,this}makePerspective(e,n,i,s,r,o,a=ni){const c=this.elements,l=2*r/(n-e),u=2*r/(i-s),d=(n+e)/(n-e),f=(i+s)/(i-s);let h,p;if(a===ni)h=-(o+r)/(o-r),p=-2*o*r/(o-r);else if(a===Ea)h=-o/(o-r),p=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=h,c[14]=p,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,n,i,s,r,o,a=ni){const c=this.elements,l=1/(n-e),u=1/(i-s),d=1/(o-r),f=(n+e)*l,h=(i+s)*u;let p,v;if(a===ni)p=(o+r)*d,v=-2*d;else if(a===Ea)p=r*d,v=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-f,c[1]=0,c[5]=2*u,c[9]=0,c[13]=-h,c[2]=0,c[6]=0,c[10]=v,c[14]=-p,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const n=this.elements,i=e.elements;for(let s=0;s<16;s++)if(n[s]!==i[s])return!1;return!0}fromArray(e,n=0){for(let i=0;i<16;i++)this.elements[i]=e[i+n];return this}toArray(e=[],n=0){const i=this.elements;return e[n]=i[0],e[n+1]=i[1],e[n+2]=i[2],e[n+3]=i[3],e[n+4]=i[4],e[n+5]=i[5],e[n+6]=i[6],e[n+7]=i[7],e[n+8]=i[8],e[n+9]=i[9],e[n+10]=i[10],e[n+11]=i[11],e[n+12]=i[12],e[n+13]=i[13],e[n+14]=i[14],e[n+15]=i[15],e}}const ys=new T,Mn=new Qe,MS=new T(0,0,0),ES=new T(1,1,1),mi=new T,wo=new T,Kt=new T,yf=new Qe,Sf=new at;class Dn{constructor(e=0,n=0,i=0,s=Dn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=n,this._z=i,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,n,i,s=this._order){return this._x=e,this._y=n,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,n=this._order,i=!0){const s=e.elements,r=s[0],o=s[4],a=s[8],c=s[1],l=s[5],u=s[9],d=s[2],f=s[6],h=s[10];switch(n){case"XYZ":this._y=Math.asin(Mt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,h),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(f,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Mt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,h),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(Mt(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-d,h),this._z=Math.atan2(-o,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Mt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(f,h),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-o,l));break;case"YZX":this._z=Math.asin(Mt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-u,l),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(a,h));break;case"XZY":this._z=Math.asin(-Mt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(f,l),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-u,h),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,n,i){return yf.makeRotationFromQuaternion(e),this.setFromRotationMatrix(yf,n,i)}setFromVector3(e,n=this._order){return this.set(e.x,e.y,e.z,n)}reorder(e){return Sf.setFromEuler(this),this.setFromQuaternion(Sf,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Dn.DEFAULT_ORDER="XYZ";class ym{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let wS=0;const _f=new T,Ss=new at,jn=new Qe,To=new T,Er=new T,TS=new T,AS=new at,xf=new T(1,0,0),bf=new T(0,1,0),Mf=new T(0,0,1),Ef={type:"added"},RS={type:"removed"},_s={type:"childadded",child:null},pc={type:"childremoved",child:null};class Nt extends dr{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:wS++}),this.uuid=ii(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Nt.DEFAULT_UP.clone();const e=new T,n=new Dn,i=new at,s=new T(1,1,1);function r(){i.setFromEuler(n,!1)}function o(){n.setFromQuaternion(i,void 0,!1)}n._onChange(r),i._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Qe},normalMatrix:{value:new Ne}}),this.matrix=new Qe,this.matrixWorld=new Qe,this.matrixAutoUpdate=Nt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Nt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ym,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,n){this.quaternion.setFromAxisAngle(e,n)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,n){return Ss.setFromAxisAngle(e,n),this.quaternion.multiply(Ss),this}rotateOnWorldAxis(e,n){return Ss.setFromAxisAngle(e,n),this.quaternion.premultiply(Ss),this}rotateX(e){return this.rotateOnAxis(xf,e)}rotateY(e){return this.rotateOnAxis(bf,e)}rotateZ(e){return this.rotateOnAxis(Mf,e)}translateOnAxis(e,n){return _f.copy(e).applyQuaternion(this.quaternion),this.position.add(_f.multiplyScalar(n)),this}translateX(e){return this.translateOnAxis(xf,e)}translateY(e){return this.translateOnAxis(bf,e)}translateZ(e){return this.translateOnAxis(Mf,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(jn.copy(this.matrixWorld).invert())}lookAt(e,n,i){e.isVector3?To.copy(e):To.set(e,n,i);const s=this.parent;this.updateWorldMatrix(!0,!1),Er.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?jn.lookAt(Er,To,this.up):jn.lookAt(To,Er,this.up),this.quaternion.setFromRotationMatrix(jn),s&&(jn.extractRotation(s.matrixWorld),Ss.setFromRotationMatrix(jn),this.quaternion.premultiply(Ss.invert()))}add(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Ef),_s.child=e,this.dispatchEvent(_s),_s.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const n=this.children.indexOf(e);return n!==-1&&(e.parent=null,this.children.splice(n,1),e.dispatchEvent(RS),pc.child=e,this.dispatchEvent(pc),pc.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),jn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),jn.multiply(e.parent.matrixWorld)),e.applyMatrix4(jn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Ef),_s.child=e,this.dispatchEvent(_s),_s.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,n){if(this[e]===n)return this;for(let i=0,s=this.children.length;i<s;i++){const o=this.children[i].getObjectByProperty(e,n);if(o!==void 0)return o}}getObjectsByProperty(e,n,i=[]){this[e]===n&&i.push(this);const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,n,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Er,e,TS),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Er,AS,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return e.set(n[8],n[9],n[10]).normalize()}raycast(){}traverse(e){e(this);const n=this.children;for(let i=0,s=n.length;i<s;i++)n[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const n=this.children;for(let i=0,s=n.length;i<s;i++)n[i].traverseVisible(e)}traverseAncestors(e){const n=this.parent;n!==null&&(e(n),n.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const n=this.children;for(let i=0,s=n.length;i<s;i++)n[i].updateMatrixWorld(e)}updateWorldMatrix(e,n){const i=this.parent;if(e===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),n===!0){const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const n=e===void 0||typeof e=="string",i={};n&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const c=a.shapes;if(Array.isArray(c))for(let l=0,u=c.length;l<u;l++){const d=c[l];r(e.shapes,d)}else r(e.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(r(e.materials,this.material[c]));s.material=a}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){const c=this.animations[a];s.animations.push(r(e.animations,c))}}if(n){const a=o(e.geometries),c=o(e.materials),l=o(e.textures),u=o(e.images),d=o(e.shapes),f=o(e.skeletons),h=o(e.animations),p=o(e.nodes);a.length>0&&(i.geometries=a),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),u.length>0&&(i.images=u),d.length>0&&(i.shapes=d),f.length>0&&(i.skeletons=f),h.length>0&&(i.animations=h),p.length>0&&(i.nodes=p)}return i.object=s,i;function o(a){const c=[];for(const l in a){const u=a[l];delete u.metadata,c.push(u)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,n=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),n===!0)for(let i=0;i<e.children.length;i++){const s=e.children[i];this.add(s.clone())}return this}}Nt.DEFAULT_UP=new T(0,1,0);Nt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Nt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const En=new T,Kn=new T,mc=new T,Zn=new T,xs=new T,bs=new T,wf=new T,gc=new T,vc=new T,yc=new T,Sc=new qe,_c=new qe,xc=new qe;class Rn{constructor(e=new T,n=new T,i=new T){this.a=e,this.b=n,this.c=i}static getNormal(e,n,i,s){s.subVectors(i,n),En.subVectors(e,n),s.cross(En);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,n,i,s,r){En.subVectors(s,n),Kn.subVectors(i,n),mc.subVectors(e,n);const o=En.dot(En),a=En.dot(Kn),c=En.dot(mc),l=Kn.dot(Kn),u=Kn.dot(mc),d=o*l-a*a;if(d===0)return r.set(0,0,0),null;const f=1/d,h=(l*c-a*u)*f,p=(o*u-a*c)*f;return r.set(1-h-p,p,h)}static containsPoint(e,n,i,s){return this.getBarycoord(e,n,i,s,Zn)===null?!1:Zn.x>=0&&Zn.y>=0&&Zn.x+Zn.y<=1}static getInterpolation(e,n,i,s,r,o,a,c){return this.getBarycoord(e,n,i,s,Zn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,Zn.x),c.addScaledVector(o,Zn.y),c.addScaledVector(a,Zn.z),c)}static getInterpolatedAttribute(e,n,i,s,r,o){return Sc.setScalar(0),_c.setScalar(0),xc.setScalar(0),Sc.fromBufferAttribute(e,n),_c.fromBufferAttribute(e,i),xc.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(Sc,r.x),o.addScaledVector(_c,r.y),o.addScaledVector(xc,r.z),o}static isFrontFacing(e,n,i,s){return En.subVectors(i,n),Kn.subVectors(e,n),En.cross(Kn).dot(s)<0}set(e,n,i){return this.a.copy(e),this.b.copy(n),this.c.copy(i),this}setFromPointsAndIndices(e,n,i,s){return this.a.copy(e[n]),this.b.copy(e[i]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,n,i,s){return this.a.fromBufferAttribute(e,n),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return En.subVectors(this.c,this.b),Kn.subVectors(this.a,this.b),En.cross(Kn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Rn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,n){return Rn.getBarycoord(e,this.a,this.b,this.c,n)}getInterpolation(e,n,i,s,r){return Rn.getInterpolation(e,this.a,this.b,this.c,n,i,s,r)}containsPoint(e){return Rn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Rn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,n){const i=this.a,s=this.b,r=this.c;let o,a;xs.subVectors(s,i),bs.subVectors(r,i),gc.subVectors(e,i);const c=xs.dot(gc),l=bs.dot(gc);if(c<=0&&l<=0)return n.copy(i);vc.subVectors(e,s);const u=xs.dot(vc),d=bs.dot(vc);if(u>=0&&d<=u)return n.copy(s);const f=c*d-u*l;if(f<=0&&c>=0&&u<=0)return o=c/(c-u),n.copy(i).addScaledVector(xs,o);yc.subVectors(e,r);const h=xs.dot(yc),p=bs.dot(yc);if(p>=0&&h<=p)return n.copy(r);const v=h*l-c*p;if(v<=0&&l>=0&&p<=0)return a=l/(l-p),n.copy(i).addScaledVector(bs,a);const g=u*p-h*d;if(g<=0&&d-u>=0&&h-p>=0)return wf.subVectors(r,s),a=(d-u)/(d-u+(h-p)),n.copy(s).addScaledVector(wf,a);const m=1/(g+v+f);return o=v*m,a=f*m,n.copy(i).addScaledVector(xs,o).addScaledVector(bs,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Sm={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},gi={h:0,s:0,l:0},Ao={h:0,s:0,l:0};function bc(t,e,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?t+(e-t)*6*n:n<1/2?e:n<2/3?t+(e-t)*6*(2/3-n):t}class J{constructor(e,n,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,n,i)}set(e,n,i){if(n===void 0&&i===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,n,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,n=hn){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Xe.toWorkingColorSpace(this,n),this}setRGB(e,n,i,s=Xe.workingColorSpace){return this.r=e,this.g=n,this.b=i,Xe.toWorkingColorSpace(this,s),this}setHSL(e,n,i,s=Xe.workingColorSpace){if(e=Qu(e,1),n=Mt(n,0,1),i=Mt(i,0,1),n===0)this.r=this.g=this.b=i;else{const r=i<=.5?i*(1+n):i+n-i*n,o=2*i-r;this.r=bc(o,r,e+1/3),this.g=bc(o,r,e),this.b=bc(o,r,e-1/3)}return Xe.toWorkingColorSpace(this,s),this}setStyle(e,n=hn){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,n);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,n);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,n);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,n);if(o===6)return this.setHex(parseInt(r,16),n);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,n);return this}setColorName(e,n=hn){const i=Sm[e.toLowerCase()];return i!==void 0?this.setHex(i,n):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=si(e.r),this.g=si(e.g),this.b=si(e.b),this}copyLinearToSRGB(e){return this.r=Xs(e.r),this.g=Xs(e.g),this.b=Xs(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=hn){return Xe.fromWorkingColorSpace(Bt.copy(this),e),Math.round(Mt(Bt.r*255,0,255))*65536+Math.round(Mt(Bt.g*255,0,255))*256+Math.round(Mt(Bt.b*255,0,255))}getHexString(e=hn){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,n=Xe.workingColorSpace){Xe.fromWorkingColorSpace(Bt.copy(this),n);const i=Bt.r,s=Bt.g,r=Bt.b,o=Math.max(i,s,r),a=Math.min(i,s,r);let c,l;const u=(a+o)/2;if(a===o)c=0,l=0;else{const d=o-a;switch(l=u<=.5?d/(o+a):d/(2-o-a),o){case i:c=(s-r)/d+(s<r?6:0);break;case s:c=(r-i)/d+2;break;case r:c=(i-s)/d+4;break}c/=6}return e.h=c,e.s=l,e.l=u,e}getRGB(e,n=Xe.workingColorSpace){return Xe.fromWorkingColorSpace(Bt.copy(this),n),e.r=Bt.r,e.g=Bt.g,e.b=Bt.b,e}getStyle(e=hn){Xe.fromWorkingColorSpace(Bt.copy(this),e);const n=Bt.r,i=Bt.g,s=Bt.b;return e!==hn?`color(${e} ${n.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(e,n,i){return this.getHSL(gi),this.setHSL(gi.h+e,gi.s+n,gi.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,n){return this.r=e.r+n.r,this.g=e.g+n.g,this.b=e.b+n.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,n){return this.r+=(e.r-this.r)*n,this.g+=(e.g-this.g)*n,this.b+=(e.b-this.b)*n,this}lerpColors(e,n,i){return this.r=e.r+(n.r-e.r)*i,this.g=e.g+(n.g-e.g)*i,this.b=e.b+(n.b-e.b)*i,this}lerpHSL(e,n){this.getHSL(gi),e.getHSL(Ao);const i=Gr(gi.h,Ao.h,n),s=Gr(gi.s,Ao.s,n),r=Gr(gi.l,Ao.l,n);return this.setHSL(i,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const n=this.r,i=this.g,s=this.b,r=e.elements;return this.r=r[0]*n+r[3]*i+r[6]*s,this.g=r[1]*n+r[4]*i+r[7]*s,this.b=r[2]*n+r[5]*i+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,n=0){return this.r=e[n],this.g=e[n+1],this.b=e[n+2],this}toArray(e=[],n=0){return e[n]=this.r,e[n+1]=this.g,e[n+2]=this.b,e}fromBufferAttribute(e,n){return this.r=e.getX(n),this.g=e.getY(n),this.b=e.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Bt=new J;J.NAMES=Sm;let CS=0;class hr extends dr{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:CS++}),this.uuid=ii(),this.name="",this.blending=Vs,this.side=Ni,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Dl,this.blendDst=Il,this.blendEquation=ji,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new J(0,0,0),this.blendAlpha=0,this.depthFunc=Zs,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=cf,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=hs,this.stencilZFail=hs,this.stencilZPass=hs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const n in e){const i=e[n];if(i===void 0){console.warn(`THREE.Material: parameter '${n}' has value of undefined.`);continue}const s=this[n];if(s===void 0){console.warn(`THREE.Material: '${n}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[n]=i}}toJSON(e){const n=e===void 0||typeof e=="string";n&&(e={textures:{},images:{}});const i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Vs&&(i.blending=this.blending),this.side!==Ni&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Dl&&(i.blendSrc=this.blendSrc),this.blendDst!==Il&&(i.blendDst=this.blendDst),this.blendEquation!==ji&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==Zs&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==cf&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==hs&&(i.stencilFail=this.stencilFail),this.stencilZFail!==hs&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==hs&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){const o=[];for(const a in r){const c=r[a];delete c.metadata,o.push(c)}return o}if(n){const r=s(e.textures),o=s(e.images);r.length>0&&(i.textures=r),o.length>0&&(i.images=o)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const n=e.clippingPlanes;let i=null;if(n!==null){const s=n.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=n[r].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class mt extends hr{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new J(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Dn,this.combine=Xu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const _t=new T,Ro=new fe;class Ut{constructor(e,n,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=n,this.count=e!==void 0?e.length/n:0,this.normalized=i,this.usage=vu,this.updateRanges=[],this.gpuType=ti,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,n,i){e*=this.itemSize,i*=n.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=n.array[i+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let n=0,i=this.count;n<i;n++)Ro.fromBufferAttribute(this,n),Ro.applyMatrix3(e),this.setXY(n,Ro.x,Ro.y);else if(this.itemSize===3)for(let n=0,i=this.count;n<i;n++)_t.fromBufferAttribute(this,n),_t.applyMatrix3(e),this.setXYZ(n,_t.x,_t.y,_t.z);return this}applyMatrix4(e){for(let n=0,i=this.count;n<i;n++)_t.fromBufferAttribute(this,n),_t.applyMatrix4(e),this.setXYZ(n,_t.x,_t.y,_t.z);return this}applyNormalMatrix(e){for(let n=0,i=this.count;n<i;n++)_t.fromBufferAttribute(this,n),_t.applyNormalMatrix(e),this.setXYZ(n,_t.x,_t.y,_t.z);return this}transformDirection(e){for(let n=0,i=this.count;n<i;n++)_t.fromBufferAttribute(this,n),_t.transformDirection(e),this.setXYZ(n,_t.x,_t.y,_t.z);return this}set(e,n=0){return this.array.set(e,n),this}getComponent(e,n){let i=this.array[e*this.itemSize+n];return this.normalized&&(i=An(i,this.array)),i}setComponent(e,n,i){return this.normalized&&(i=tt(i,this.array)),this.array[e*this.itemSize+n]=i,this}getX(e){let n=this.array[e*this.itemSize];return this.normalized&&(n=An(n,this.array)),n}setX(e,n){return this.normalized&&(n=tt(n,this.array)),this.array[e*this.itemSize]=n,this}getY(e){let n=this.array[e*this.itemSize+1];return this.normalized&&(n=An(n,this.array)),n}setY(e,n){return this.normalized&&(n=tt(n,this.array)),this.array[e*this.itemSize+1]=n,this}getZ(e){let n=this.array[e*this.itemSize+2];return this.normalized&&(n=An(n,this.array)),n}setZ(e,n){return this.normalized&&(n=tt(n,this.array)),this.array[e*this.itemSize+2]=n,this}getW(e){let n=this.array[e*this.itemSize+3];return this.normalized&&(n=An(n,this.array)),n}setW(e,n){return this.normalized&&(n=tt(n,this.array)),this.array[e*this.itemSize+3]=n,this}setXY(e,n,i){return e*=this.itemSize,this.normalized&&(n=tt(n,this.array),i=tt(i,this.array)),this.array[e+0]=n,this.array[e+1]=i,this}setXYZ(e,n,i,s){return e*=this.itemSize,this.normalized&&(n=tt(n,this.array),i=tt(i,this.array),s=tt(s,this.array)),this.array[e+0]=n,this.array[e+1]=i,this.array[e+2]=s,this}setXYZW(e,n,i,s,r){return e*=this.itemSize,this.normalized&&(n=tt(n,this.array),i=tt(i,this.array),s=tt(s,this.array),r=tt(r,this.array)),this.array[e+0]=n,this.array[e+1]=i,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==vu&&(e.usage=this.usage),e}}class _m extends Ut{constructor(e,n,i){super(new Uint16Array(e),n,i)}}class xm extends Ut{constructor(e,n,i){super(new Uint32Array(e),n,i)}}class vt extends Ut{constructor(e,n,i){super(new Float32Array(e),n,i)}}let PS=0;const ln=new Qe,Mc=new Nt,Ms=new T,Zt=new oi,wr=new oi,At=new T;class Tt extends dr{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:PS++}),this.uuid=ii(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(pm(e)?xm:_m)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,n){return this.attributes[e]=n,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,n,i=0){this.groups.push({start:e,count:n,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,n){this.drawRange.start=e,this.drawRange.count=n}applyMatrix4(e){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(e),n.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const r=new Ne().getNormalMatrix(e);i.applyNormalMatrix(r),i.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return ln.makeRotationFromQuaternion(e),this.applyMatrix4(ln),this}rotateX(e){return ln.makeRotationX(e),this.applyMatrix4(ln),this}rotateY(e){return ln.makeRotationY(e),this.applyMatrix4(ln),this}rotateZ(e){return ln.makeRotationZ(e),this.applyMatrix4(ln),this}translate(e,n,i){return ln.makeTranslation(e,n,i),this.applyMatrix4(ln),this}scale(e,n,i){return ln.makeScale(e,n,i),this.applyMatrix4(ln),this}lookAt(e){return Mc.lookAt(e),Mc.updateMatrix(),this.applyMatrix4(Mc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ms).negate(),this.translate(Ms.x,Ms.y,Ms.z),this}setFromPoints(e){const n=this.getAttribute("position");if(n===void 0){const i=[];for(let s=0,r=e.length;s<r;s++){const o=e[s];i.push(o.x,o.y,o.z||0)}this.setAttribute("position",new vt(i,3))}else{for(let i=0,s=n.count;i<s;i++){const r=e[i];n.setXYZ(i,r.x,r.y,r.z||0)}e.length>n.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new oi);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new T(-1/0,-1/0,-1/0),new T(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),n)for(let i=0,s=n.length;i<s;i++){const r=n[i];Zt.setFromBufferAttribute(r),this.morphTargetsRelative?(At.addVectors(this.boundingBox.min,Zt.min),this.boundingBox.expandByPoint(At),At.addVectors(this.boundingBox.max,Zt.max),this.boundingBox.expandByPoint(At)):(this.boundingBox.expandByPoint(Zt.min),this.boundingBox.expandByPoint(Zt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new fr);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new T,1/0);return}if(e){const i=this.boundingSphere.center;if(Zt.setFromBufferAttribute(e),n)for(let r=0,o=n.length;r<o;r++){const a=n[r];wr.setFromBufferAttribute(a),this.morphTargetsRelative?(At.addVectors(Zt.min,wr.min),Zt.expandByPoint(At),At.addVectors(Zt.max,wr.max),Zt.expandByPoint(At)):(Zt.expandByPoint(wr.min),Zt.expandByPoint(wr.max))}Zt.getCenter(i);let s=0;for(let r=0,o=e.count;r<o;r++)At.fromBufferAttribute(e,r),s=Math.max(s,i.distanceToSquared(At));if(n)for(let r=0,o=n.length;r<o;r++){const a=n[r],c=this.morphTargetsRelative;for(let l=0,u=a.count;l<u;l++)At.fromBufferAttribute(a,l),c&&(Ms.fromBufferAttribute(e,l),At.add(Ms)),s=Math.max(s,i.distanceToSquared(At))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,n=this.attributes;if(e===null||n.position===void 0||n.normal===void 0||n.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=n.position,s=n.normal,r=n.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Ut(new Float32Array(4*i.count),4));const o=this.getAttribute("tangent"),a=[],c=[];for(let P=0;P<i.count;P++)a[P]=new T,c[P]=new T;const l=new T,u=new T,d=new T,f=new fe,h=new fe,p=new fe,v=new T,g=new T;function m(P,b,x){l.fromBufferAttribute(i,P),u.fromBufferAttribute(i,b),d.fromBufferAttribute(i,x),f.fromBufferAttribute(r,P),h.fromBufferAttribute(r,b),p.fromBufferAttribute(r,x),u.sub(l),d.sub(l),h.sub(f),p.sub(f);const L=1/(h.x*p.y-p.x*h.y);isFinite(L)&&(v.copy(u).multiplyScalar(p.y).addScaledVector(d,-h.y).multiplyScalar(L),g.copy(d).multiplyScalar(h.x).addScaledVector(u,-p.x).multiplyScalar(L),a[P].add(v),a[b].add(v),a[x].add(v),c[P].add(g),c[b].add(g),c[x].add(g))}let S=this.groups;S.length===0&&(S=[{start:0,count:e.count}]);for(let P=0,b=S.length;P<b;++P){const x=S[P],L=x.start,B=x.count;for(let F=L,G=L+B;F<G;F+=3)m(e.getX(F+0),e.getX(F+1),e.getX(F+2))}const _=new T,y=new T,D=new T,E=new T;function A(P){D.fromBufferAttribute(s,P),E.copy(D);const b=a[P];_.copy(b),_.sub(D.multiplyScalar(D.dot(b))).normalize(),y.crossVectors(E,b);const L=y.dot(c[P])<0?-1:1;o.setXYZW(P,_.x,_.y,_.z,L)}for(let P=0,b=S.length;P<b;++P){const x=S[P],L=x.start,B=x.count;for(let F=L,G=L+B;F<G;F+=3)A(e.getX(F+0)),A(e.getX(F+1)),A(e.getX(F+2))}}computeVertexNormals(){const e=this.index,n=this.getAttribute("position");if(n!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new Ut(new Float32Array(n.count*3),3),this.setAttribute("normal",i);else for(let f=0,h=i.count;f<h;f++)i.setXYZ(f,0,0,0);const s=new T,r=new T,o=new T,a=new T,c=new T,l=new T,u=new T,d=new T;if(e)for(let f=0,h=e.count;f<h;f+=3){const p=e.getX(f+0),v=e.getX(f+1),g=e.getX(f+2);s.fromBufferAttribute(n,p),r.fromBufferAttribute(n,v),o.fromBufferAttribute(n,g),u.subVectors(o,r),d.subVectors(s,r),u.cross(d),a.fromBufferAttribute(i,p),c.fromBufferAttribute(i,v),l.fromBufferAttribute(i,g),a.add(u),c.add(u),l.add(u),i.setXYZ(p,a.x,a.y,a.z),i.setXYZ(v,c.x,c.y,c.z),i.setXYZ(g,l.x,l.y,l.z)}else for(let f=0,h=n.count;f<h;f+=3)s.fromBufferAttribute(n,f+0),r.fromBufferAttribute(n,f+1),o.fromBufferAttribute(n,f+2),u.subVectors(o,r),d.subVectors(s,r),u.cross(d),i.setXYZ(f+0,u.x,u.y,u.z),i.setXYZ(f+1,u.x,u.y,u.z),i.setXYZ(f+2,u.x,u.y,u.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let n=0,i=e.count;n<i;n++)At.fromBufferAttribute(e,n),At.normalize(),e.setXYZ(n,At.x,At.y,At.z)}toNonIndexed(){function e(a,c){const l=a.array,u=a.itemSize,d=a.normalized,f=new l.constructor(c.length*u);let h=0,p=0;for(let v=0,g=c.length;v<g;v++){a.isInterleavedBufferAttribute?h=c[v]*a.data.stride+a.offset:h=c[v]*u;for(let m=0;m<u;m++)f[p++]=l[h++]}return new Ut(f,u,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new Tt,i=this.index.array,s=this.attributes;for(const a in s){const c=s[a],l=e(c,i);n.setAttribute(a,l)}const r=this.morphAttributes;for(const a in r){const c=[],l=r[a];for(let u=0,d=l.length;u<d;u++){const f=l[u],h=e(f,i);c.push(h)}n.morphAttributes[a]=c}n.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,c=o.length;a<c;a++){const l=o[a];n.addGroup(l.start,l.count,l.materialIndex)}return n}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const n=this.index;n!==null&&(e.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const i=this.attributes;for(const c in i){const l=i[c];e.data.attributes[c]=l.toJSON(e.data)}const s={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],u=[];for(let d=0,f=l.length;d<f;d++){const h=l[d];u.push(h.toJSON(e.data))}u.length>0&&(s[c]=u,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone(n));const s=e.attributes;for(const l in s){const u=s[l];this.setAttribute(l,u.clone(n))}const r=e.morphAttributes;for(const l in r){const u=[],d=r[l];for(let f=0,h=d.length;f<h;f++)u.push(d[f].clone(n));this.morphAttributes[l]=u}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let l=0,u=o.length;l<u;l++){const d=o[l];this.addGroup(d.start,d.count,d.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Tf=new Qe,Hi=new vm,Co=new fr,Af=new T,Po=new T,Lo=new T,Do=new T,Ec=new T,Io=new T,Rf=new T,No=new T;class Ye extends Nt{constructor(e=new Tt,n=new mt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=n,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,i=Object.keys(n);if(i.length>0){const s=n[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(e,n){const i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,o=i.morphTargetsRelative;n.fromBufferAttribute(s,e);const a=this.morphTargetInfluences;if(r&&a){Io.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const u=a[c],d=r[c];u!==0&&(Ec.fromBufferAttribute(d,e),o?Io.addScaledVector(Ec,u):Io.addScaledVector(Ec.sub(n),u))}n.add(Io)}return n}raycast(e,n){const i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Co.copy(i.boundingSphere),Co.applyMatrix4(r),Hi.copy(e.ray).recast(e.near),!(Co.containsPoint(Hi.origin)===!1&&(Hi.intersectSphere(Co,Af)===null||Hi.origin.distanceToSquared(Af)>(e.far-e.near)**2))&&(Tf.copy(r).invert(),Hi.copy(e.ray).applyMatrix4(Tf),!(i.boundingBox!==null&&Hi.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,n,Hi)))}_computeIntersections(e,n,i){let s;const r=this.geometry,o=this.material,a=r.index,c=r.attributes.position,l=r.attributes.uv,u=r.attributes.uv1,d=r.attributes.normal,f=r.groups,h=r.drawRange;if(a!==null)if(Array.isArray(o))for(let p=0,v=f.length;p<v;p++){const g=f[p],m=o[g.materialIndex],S=Math.max(g.start,h.start),_=Math.min(a.count,Math.min(g.start+g.count,h.start+h.count));for(let y=S,D=_;y<D;y+=3){const E=a.getX(y),A=a.getX(y+1),P=a.getX(y+2);s=Uo(this,m,e,i,l,u,d,E,A,P),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=g.materialIndex,n.push(s))}}else{const p=Math.max(0,h.start),v=Math.min(a.count,h.start+h.count);for(let g=p,m=v;g<m;g+=3){const S=a.getX(g),_=a.getX(g+1),y=a.getX(g+2);s=Uo(this,o,e,i,l,u,d,S,_,y),s&&(s.faceIndex=Math.floor(g/3),n.push(s))}}else if(c!==void 0)if(Array.isArray(o))for(let p=0,v=f.length;p<v;p++){const g=f[p],m=o[g.materialIndex],S=Math.max(g.start,h.start),_=Math.min(c.count,Math.min(g.start+g.count,h.start+h.count));for(let y=S,D=_;y<D;y+=3){const E=y,A=y+1,P=y+2;s=Uo(this,m,e,i,l,u,d,E,A,P),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=g.materialIndex,n.push(s))}}else{const p=Math.max(0,h.start),v=Math.min(c.count,h.start+h.count);for(let g=p,m=v;g<m;g+=3){const S=g,_=g+1,y=g+2;s=Uo(this,o,e,i,l,u,d,S,_,y),s&&(s.faceIndex=Math.floor(g/3),n.push(s))}}}}function LS(t,e,n,i,s,r,o,a){let c;if(e.side===Gt?c=i.intersectTriangle(o,r,s,!0,a):c=i.intersectTriangle(s,r,o,e.side===Ni,a),c===null)return null;No.copy(a),No.applyMatrix4(t.matrixWorld);const l=n.ray.origin.distanceTo(No);return l<n.near||l>n.far?null:{distance:l,point:No.clone(),object:t}}function Uo(t,e,n,i,s,r,o,a,c,l){t.getVertexPosition(a,Po),t.getVertexPosition(c,Lo),t.getVertexPosition(l,Do);const u=LS(t,e,n,i,Po,Lo,Do,Rf);if(u){const d=new T;Rn.getBarycoord(Rf,Po,Lo,Do,d),s&&(u.uv=Rn.getInterpolatedAttribute(s,a,c,l,d,new fe)),r&&(u.uv1=Rn.getInterpolatedAttribute(r,a,c,l,d,new fe)),o&&(u.normal=Rn.getInterpolatedAttribute(o,a,c,l,d,new T),u.normal.dot(i.direction)>0&&u.normal.multiplyScalar(-1));const f={a,b:c,c:l,normal:new T,materialIndex:0};Rn.getNormal(Po,Lo,Do,f.normal),u.face=f,u.barycoord=d}return u}class os extends Tt{constructor(e=1,n=1,i=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:n,depth:i,widthSegments:s,heightSegments:r,depthSegments:o};const a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);const c=[],l=[],u=[],d=[];let f=0,h=0;p("z","y","x",-1,-1,i,n,e,o,r,0),p("z","y","x",1,-1,i,n,-e,o,r,1),p("x","z","y",1,1,e,i,n,s,o,2),p("x","z","y",1,-1,e,i,-n,s,o,3),p("x","y","z",1,-1,e,n,i,s,r,4),p("x","y","z",-1,-1,e,n,-i,s,r,5),this.setIndex(c),this.setAttribute("position",new vt(l,3)),this.setAttribute("normal",new vt(u,3)),this.setAttribute("uv",new vt(d,2));function p(v,g,m,S,_,y,D,E,A,P,b){const x=y/A,L=D/P,B=y/2,F=D/2,G=E/2,$=A+1,X=P+1;let Q=0,V=0;const re=new T;for(let he=0;he<X;he++){const Me=he*L-F;for(let Fe=0;Fe<$;Fe++){const it=Fe*x-B;re[v]=it*S,re[g]=Me*_,re[m]=G,l.push(re.x,re.y,re.z),re[v]=0,re[g]=0,re[m]=E>0?1:-1,u.push(re.x,re.y,re.z),d.push(Fe/A),d.push(1-he/P),Q+=1}}for(let he=0;he<P;he++)for(let Me=0;Me<A;Me++){const Fe=f+Me+$*he,it=f+Me+$*(he+1),Y=f+(Me+1)+$*(he+1),ne=f+(Me+1)+$*he;c.push(Fe,it,ne),c.push(it,Y,ne),V+=6}a.addGroup(h,V,b),h+=V,f+=Q}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new os(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function nr(t){const e={};for(const n in t){e[n]={};for(const i in t[n]){const s=t[n][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[n][i]=null):e[n][i]=s.clone():Array.isArray(s)?e[n][i]=s.slice():e[n][i]=s}}return e}function Ht(t){const e={};for(let n=0;n<t.length;n++){const i=nr(t[n]);for(const s in i)e[s]=i[s]}return e}function DS(t){const e=[];for(let n=0;n<t.length;n++)e.push(t[n].clone());return e}function bm(t){const e=t.getRenderTarget();return e===null?t.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Xe.workingColorSpace}const ed={clone:nr,merge:Ht};var IS=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,NS=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class vn extends hr{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=IS,this.fragmentShader=NS,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=nr(e.uniforms),this.uniformsGroups=DS(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const n=super.toJSON(e);n.glslVersion=this.glslVersion,n.uniforms={};for(const s in this.uniforms){const o=this.uniforms[s].value;o&&o.isTexture?n.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?n.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?n.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?n.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?n.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?n.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?n.uniforms[s]={type:"m4",value:o.toArray()}:n.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const i={};for(const s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(n.extensions=i),n}}class Mm extends Nt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Qe,this.projectionMatrix=new Qe,this.projectionMatrixInverse=new Qe,this.coordinateSystem=ni}copy(e,n){return super.copy(e,n),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,n){super.updateWorldMatrix(e,n),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const vi=new T,Cf=new fe,Pf=new fe;class $t extends Mm{constructor(e=50,n=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const n=.5*this.getFilmHeight()/e;this.fov=Yr*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Hr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Yr*2*Math.atan(Math.tan(Hr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,n,i){vi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(vi.x,vi.y).multiplyScalar(-e/vi.z),vi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(vi.x,vi.y).multiplyScalar(-e/vi.z)}getViewSize(e,n){return this.getViewBounds(e,Cf,Pf),n.subVectors(Pf,Cf)}setViewOffset(e,n,i,s,r,o){this.aspect=e/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let n=e*Math.tan(Hr*.5*this.fov)/this.zoom,i=2*n,s=this.aspect*i,r=-.5*s;const o=this.view;if(this.view!==null&&this.view.enabled){const c=o.fullWidth,l=o.fullHeight;r+=o.offsetX*s/c,n-=o.offsetY*i/l,s*=o.width/c,i*=o.height/l}const a=this.filmOffset;a!==0&&(r+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,n,n-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}const Es=-90,ws=1;class Em extends Nt{constructor(e,n,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new $t(Es,ws,e,n);s.layers=this.layers,this.add(s);const r=new $t(Es,ws,e,n);r.layers=this.layers,this.add(r);const o=new $t(Es,ws,e,n);o.layers=this.layers,this.add(o);const a=new $t(Es,ws,e,n);a.layers=this.layers,this.add(a);const c=new $t(Es,ws,e,n);c.layers=this.layers,this.add(c);const l=new $t(Es,ws,e,n);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,n=this.children.concat(),[i,s,r,o,a,c]=n;for(const l of n)this.remove(l);if(e===ni)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===Ea)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of n)this.add(l),l.updateMatrixWorld()}update(e,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,o,a,c,l,u]=this.children,d=e.getRenderTarget(),f=e.getActiveCubeFace(),h=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;const v=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,s),e.render(n,r),e.setRenderTarget(i,1,s),e.render(n,o),e.setRenderTarget(i,2,s),e.render(n,a),e.setRenderTarget(i,3,s),e.render(n,c),e.setRenderTarget(i,4,s),e.render(n,l),i.texture.generateMipmaps=v,e.setRenderTarget(i,5,s),e.render(n,u),e.setRenderTarget(d,f,h),e.xr.enabled=p,i.texture.needsPMREMUpdate=!0}}class wm extends Yt{constructor(e,n,i,s,r,o,a,c,l,u){e=e!==void 0?e:[],n=n!==void 0?n:Js,super(e,n,i,s,r,o,a,c,l,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Tm extends Ui{constructor(e=1,n={}){super(e,e,n),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},s=[i,i,i,i,i,i];this.texture=new wm(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=n.generateMipmaps!==void 0?n.generateMipmaps:!1,this.texture.minFilter=n.minFilter!==void 0?n.minFilter:qt}fromEquirectangularTexture(e,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new os(5,5,5),r=new vn({name:"CubemapFromEquirect",uniforms:nr(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Gt,blending:Pi});r.uniforms.tEquirect.value=n;const o=new Ye(s,r),a=n.minFilter;return n.minFilter===Qi&&(n.minFilter=qt),new Em(1,10,this).update(e,o),n.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,n,i,s){const r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(n,i,s);e.setRenderTarget(r)}}const wc=new T,US=new T,kS=new Ne;class qi{constructor(e=new T(1,0,0),n=0){this.isPlane=!0,this.normal=e,this.constant=n}set(e,n){return this.normal.copy(e),this.constant=n,this}setComponents(e,n,i,s){return this.normal.set(e,n,i),this.constant=s,this}setFromNormalAndCoplanarPoint(e,n){return this.normal.copy(e),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(e,n,i){const s=wc.subVectors(i,n).cross(US.subVectors(e,n)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,n){return n.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,n){const i=e.delta(wc),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(e.start)===0?n.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:n.copy(e.start).addScaledVector(i,r)}intersectsLine(e){const n=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return n<0&&i>0||i<0&&n>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,n){const i=n||kS.getNormalMatrix(e),s=this.coplanarPoint(wc).applyMatrix4(e),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Gi=new fr,ko=new T;class td{constructor(e=new qi,n=new qi,i=new qi,s=new qi,r=new qi,o=new qi){this.planes=[e,n,i,s,r,o]}set(e,n,i,s,r,o){const a=this.planes;return a[0].copy(e),a[1].copy(n),a[2].copy(i),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(e){const n=this.planes;for(let i=0;i<6;i++)n[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,n=ni){const i=this.planes,s=e.elements,r=s[0],o=s[1],a=s[2],c=s[3],l=s[4],u=s[5],d=s[6],f=s[7],h=s[8],p=s[9],v=s[10],g=s[11],m=s[12],S=s[13],_=s[14],y=s[15];if(i[0].setComponents(c-r,f-l,g-h,y-m).normalize(),i[1].setComponents(c+r,f+l,g+h,y+m).normalize(),i[2].setComponents(c+o,f+u,g+p,y+S).normalize(),i[3].setComponents(c-o,f-u,g-p,y-S).normalize(),i[4].setComponents(c-a,f-d,g-v,y-_).normalize(),n===ni)i[5].setComponents(c+a,f+d,g+v,y+_).normalize();else if(n===Ea)i[5].setComponents(a,d,v,_).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Gi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const n=e.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),Gi.copy(n.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Gi)}intersectsSprite(e){return Gi.center.set(0,0,0),Gi.radius=.7071067811865476,Gi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Gi)}intersectsSphere(e){const n=this.planes,i=e.center,s=-e.radius;for(let r=0;r<6;r++)if(n[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(e){const n=this.planes;for(let i=0;i<6;i++){const s=n[i];if(ko.x=s.normal.x>0?e.max.x:e.min.x,ko.y=s.normal.y>0?e.max.y:e.min.y,ko.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(ko)<0)return!1}return!0}containsPoint(e){const n=this.planes;for(let i=0;i<6;i++)if(n[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Am(){let t=null,e=!1,n=null,i=null;function s(r,o){n(r,o),i=t.requestAnimationFrame(s)}return{start:function(){e!==!0&&n!==null&&(i=t.requestAnimationFrame(s),e=!0)},stop:function(){t.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(r){n=r},setContext:function(r){t=r}}}function FS(t){const e=new WeakMap;function n(a,c){const l=a.array,u=a.usage,d=l.byteLength,f=t.createBuffer();t.bindBuffer(c,f),t.bufferData(c,l,u),a.onUploadCallback();let h;if(l instanceof Float32Array)h=t.FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?h=t.HALF_FLOAT:h=t.UNSIGNED_SHORT;else if(l instanceof Int16Array)h=t.SHORT;else if(l instanceof Uint32Array)h=t.UNSIGNED_INT;else if(l instanceof Int32Array)h=t.INT;else if(l instanceof Int8Array)h=t.BYTE;else if(l instanceof Uint8Array)h=t.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)h=t.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:f,type:h,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:d}}function i(a,c,l){const u=c.array,d=c.updateRanges;if(t.bindBuffer(l,a),d.length===0)t.bufferSubData(l,0,u);else{d.sort((h,p)=>h.start-p.start);let f=0;for(let h=1;h<d.length;h++){const p=d[f],v=d[h];v.start<=p.start+p.count+1?p.count=Math.max(p.count,v.start+v.count-p.start):(++f,d[f]=v)}d.length=f+1;for(let h=0,p=d.length;h<p;h++){const v=d[h];t.bufferSubData(l,v.start*u.BYTES_PER_ELEMENT,u,v.start,v.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);const c=e.get(a);c&&(t.deleteBuffer(c.buffer),e.delete(a))}function o(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const u=e.get(a);(!u||u.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const l=e.get(a);if(l===void 0)e.set(a,n(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(l.buffer,a,c),l.version=a.version}}return{get:s,remove:r,update:o}}class za extends Tt{constructor(e=1,n=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:n,widthSegments:i,heightSegments:s};const r=e/2,o=n/2,a=Math.floor(i),c=Math.floor(s),l=a+1,u=c+1,d=e/a,f=n/c,h=[],p=[],v=[],g=[];for(let m=0;m<u;m++){const S=m*f-o;for(let _=0;_<l;_++){const y=_*d-r;p.push(y,-S,0),v.push(0,0,1),g.push(_/a),g.push(1-m/c)}}for(let m=0;m<c;m++)for(let S=0;S<a;S++){const _=S+l*m,y=S+l*(m+1),D=S+1+l*(m+1),E=S+1+l*m;h.push(_,y,E),h.push(y,D,E)}this.setIndex(h),this.setAttribute("position",new vt(p,3)),this.setAttribute("normal",new vt(v,3)),this.setAttribute("uv",new vt(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new za(e.width,e.height,e.widthSegments,e.heightSegments)}}var OS=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,BS=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,zS=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,HS=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,GS=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,WS=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,VS=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,$S=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,XS=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,qS=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,YS=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,jS=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,KS=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,ZS=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,JS=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,QS=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,e_=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,t_=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,n_=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,i_=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,s_=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,r_=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,o_=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,a_=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,c_=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,l_=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,u_=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,d_=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,f_=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,h_=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,p_="gl_FragColor = linearToOutputTexel( gl_FragColor );",m_=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,g_=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,v_=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,y_=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,S_=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,__=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,x_=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,b_=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,M_=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,E_=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,w_=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,T_=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,A_=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,R_=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,C_=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,P_=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,L_=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,D_=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,I_=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,N_=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,U_=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,k_=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,F_=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,O_=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,B_=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,z_=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,H_=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,G_=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,W_=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,V_=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,$_=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,X_=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,q_=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Y_=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,j_=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,K_=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Z_=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,J_=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Q_=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,ex=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,tx=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,nx=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,ix=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,sx=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,rx=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,ox=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,ax=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,cx=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,lx=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,ux=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,dx=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,fx=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,hx=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,px=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,mx=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,gx=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,vx=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,yx=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Sx=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,_x=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,xx=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,bx=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Mx=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Ex=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,wx=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Tx=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Ax=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Rx=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Cx=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Px=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Lx=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Dx=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Ix=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Nx=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Ux=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,kx=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Fx=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Ox=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,zx=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Hx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Gx=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Wx=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Vx=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,$x=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Xx=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,qx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Yx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,jx=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Kx=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Zx=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Jx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,eb=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tb=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,nb=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ib=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,sb=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,rb=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ob=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ab=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,cb=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,lb=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ub=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,db=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,fb=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,hb=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,pb=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,mb=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,gb=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ke={alphahash_fragment:OS,alphahash_pars_fragment:BS,alphamap_fragment:zS,alphamap_pars_fragment:HS,alphatest_fragment:GS,alphatest_pars_fragment:WS,aomap_fragment:VS,aomap_pars_fragment:$S,batching_pars_vertex:XS,batching_vertex:qS,begin_vertex:YS,beginnormal_vertex:jS,bsdfs:KS,iridescence_fragment:ZS,bumpmap_pars_fragment:JS,clipping_planes_fragment:QS,clipping_planes_pars_fragment:e_,clipping_planes_pars_vertex:t_,clipping_planes_vertex:n_,color_fragment:i_,color_pars_fragment:s_,color_pars_vertex:r_,color_vertex:o_,common:a_,cube_uv_reflection_fragment:c_,defaultnormal_vertex:l_,displacementmap_pars_vertex:u_,displacementmap_vertex:d_,emissivemap_fragment:f_,emissivemap_pars_fragment:h_,colorspace_fragment:p_,colorspace_pars_fragment:m_,envmap_fragment:g_,envmap_common_pars_fragment:v_,envmap_pars_fragment:y_,envmap_pars_vertex:S_,envmap_physical_pars_fragment:P_,envmap_vertex:__,fog_vertex:x_,fog_pars_vertex:b_,fog_fragment:M_,fog_pars_fragment:E_,gradientmap_pars_fragment:w_,lightmap_pars_fragment:T_,lights_lambert_fragment:A_,lights_lambert_pars_fragment:R_,lights_pars_begin:C_,lights_toon_fragment:L_,lights_toon_pars_fragment:D_,lights_phong_fragment:I_,lights_phong_pars_fragment:N_,lights_physical_fragment:U_,lights_physical_pars_fragment:k_,lights_fragment_begin:F_,lights_fragment_maps:O_,lights_fragment_end:B_,logdepthbuf_fragment:z_,logdepthbuf_pars_fragment:H_,logdepthbuf_pars_vertex:G_,logdepthbuf_vertex:W_,map_fragment:V_,map_pars_fragment:$_,map_particle_fragment:X_,map_particle_pars_fragment:q_,metalnessmap_fragment:Y_,metalnessmap_pars_fragment:j_,morphinstance_vertex:K_,morphcolor_vertex:Z_,morphnormal_vertex:J_,morphtarget_pars_vertex:Q_,morphtarget_vertex:ex,normal_fragment_begin:tx,normal_fragment_maps:nx,normal_pars_fragment:ix,normal_pars_vertex:sx,normal_vertex:rx,normalmap_pars_fragment:ox,clearcoat_normal_fragment_begin:ax,clearcoat_normal_fragment_maps:cx,clearcoat_pars_fragment:lx,iridescence_pars_fragment:ux,opaque_fragment:dx,packing:fx,premultiplied_alpha_fragment:hx,project_vertex:px,dithering_fragment:mx,dithering_pars_fragment:gx,roughnessmap_fragment:vx,roughnessmap_pars_fragment:yx,shadowmap_pars_fragment:Sx,shadowmap_pars_vertex:_x,shadowmap_vertex:xx,shadowmask_pars_fragment:bx,skinbase_vertex:Mx,skinning_pars_vertex:Ex,skinning_vertex:wx,skinnormal_vertex:Tx,specularmap_fragment:Ax,specularmap_pars_fragment:Rx,tonemapping_fragment:Cx,tonemapping_pars_fragment:Px,transmission_fragment:Lx,transmission_pars_fragment:Dx,uv_pars_fragment:Ix,uv_pars_vertex:Nx,uv_vertex:Ux,worldpos_vertex:kx,background_vert:Fx,background_frag:Ox,backgroundCube_vert:Bx,backgroundCube_frag:zx,cube_vert:Hx,cube_frag:Gx,depth_vert:Wx,depth_frag:Vx,distanceRGBA_vert:$x,distanceRGBA_frag:Xx,equirect_vert:qx,equirect_frag:Yx,linedashed_vert:jx,linedashed_frag:Kx,meshbasic_vert:Zx,meshbasic_frag:Jx,meshlambert_vert:Qx,meshlambert_frag:eb,meshmatcap_vert:tb,meshmatcap_frag:nb,meshnormal_vert:ib,meshnormal_frag:sb,meshphong_vert:rb,meshphong_frag:ob,meshphysical_vert:ab,meshphysical_frag:cb,meshtoon_vert:lb,meshtoon_frag:ub,points_vert:db,points_frag:fb,shadow_vert:hb,shadow_frag:pb,sprite_vert:mb,sprite_frag:gb},ie={common:{diffuse:{value:new J(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ne},alphaMap:{value:null},alphaMapTransform:{value:new Ne},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ne}},envmap:{envMap:{value:null},envMapRotation:{value:new Ne},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ne}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ne}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ne},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ne},normalScale:{value:new fe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ne},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ne}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ne}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ne}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new J(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new J(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ne},alphaTest:{value:0},uvTransform:{value:new Ne}},sprite:{diffuse:{value:new J(16777215)},opacity:{value:1},center:{value:new fe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ne},alphaMap:{value:null},alphaMapTransform:{value:new Ne},alphaTest:{value:0}}},Xt={basic:{uniforms:Ht([ie.common,ie.specularmap,ie.envmap,ie.aomap,ie.lightmap,ie.fog]),vertexShader:ke.meshbasic_vert,fragmentShader:ke.meshbasic_frag},lambert:{uniforms:Ht([ie.common,ie.specularmap,ie.envmap,ie.aomap,ie.lightmap,ie.emissivemap,ie.bumpmap,ie.normalmap,ie.displacementmap,ie.fog,ie.lights,{emissive:{value:new J(0)}}]),vertexShader:ke.meshlambert_vert,fragmentShader:ke.meshlambert_frag},phong:{uniforms:Ht([ie.common,ie.specularmap,ie.envmap,ie.aomap,ie.lightmap,ie.emissivemap,ie.bumpmap,ie.normalmap,ie.displacementmap,ie.fog,ie.lights,{emissive:{value:new J(0)},specular:{value:new J(1118481)},shininess:{value:30}}]),vertexShader:ke.meshphong_vert,fragmentShader:ke.meshphong_frag},standard:{uniforms:Ht([ie.common,ie.envmap,ie.aomap,ie.lightmap,ie.emissivemap,ie.bumpmap,ie.normalmap,ie.displacementmap,ie.roughnessmap,ie.metalnessmap,ie.fog,ie.lights,{emissive:{value:new J(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag},toon:{uniforms:Ht([ie.common,ie.aomap,ie.lightmap,ie.emissivemap,ie.bumpmap,ie.normalmap,ie.displacementmap,ie.gradientmap,ie.fog,ie.lights,{emissive:{value:new J(0)}}]),vertexShader:ke.meshtoon_vert,fragmentShader:ke.meshtoon_frag},matcap:{uniforms:Ht([ie.common,ie.bumpmap,ie.normalmap,ie.displacementmap,ie.fog,{matcap:{value:null}}]),vertexShader:ke.meshmatcap_vert,fragmentShader:ke.meshmatcap_frag},points:{uniforms:Ht([ie.points,ie.fog]),vertexShader:ke.points_vert,fragmentShader:ke.points_frag},dashed:{uniforms:Ht([ie.common,ie.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ke.linedashed_vert,fragmentShader:ke.linedashed_frag},depth:{uniforms:Ht([ie.common,ie.displacementmap]),vertexShader:ke.depth_vert,fragmentShader:ke.depth_frag},normal:{uniforms:Ht([ie.common,ie.bumpmap,ie.normalmap,ie.displacementmap,{opacity:{value:1}}]),vertexShader:ke.meshnormal_vert,fragmentShader:ke.meshnormal_frag},sprite:{uniforms:Ht([ie.sprite,ie.fog]),vertexShader:ke.sprite_vert,fragmentShader:ke.sprite_frag},background:{uniforms:{uvTransform:{value:new Ne},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ke.background_vert,fragmentShader:ke.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ne}},vertexShader:ke.backgroundCube_vert,fragmentShader:ke.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ke.cube_vert,fragmentShader:ke.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ke.equirect_vert,fragmentShader:ke.equirect_frag},distanceRGBA:{uniforms:Ht([ie.common,ie.displacementmap,{referencePosition:{value:new T},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ke.distanceRGBA_vert,fragmentShader:ke.distanceRGBA_frag},shadow:{uniforms:Ht([ie.lights,ie.fog,{color:{value:new J(0)},opacity:{value:1}}]),vertexShader:ke.shadow_vert,fragmentShader:ke.shadow_frag}};Xt.physical={uniforms:Ht([Xt.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ne},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ne},clearcoatNormalScale:{value:new fe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ne},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ne},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ne},sheen:{value:0},sheenColor:{value:new J(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ne},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ne},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ne},transmissionSamplerSize:{value:new fe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ne},attenuationDistance:{value:0},attenuationColor:{value:new J(0)},specularColor:{value:new J(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ne},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ne},anisotropyVector:{value:new fe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ne}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag};const Fo={r:0,b:0,g:0},Wi=new Dn,vb=new Qe;function yb(t,e,n,i,s,r,o){const a=new J(0);let c=r===!0?0:1,l,u,d=null,f=0,h=null;function p(S){let _=S.isScene===!0?S.background:null;return _&&_.isTexture&&(_=(S.backgroundBlurriness>0?n:e).get(_)),_}function v(S){let _=!1;const y=p(S);y===null?m(a,c):y&&y.isColor&&(m(y,1),_=!0);const D=t.xr.getEnvironmentBlendMode();D==="additive"?i.buffers.color.setClear(0,0,0,1,o):D==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,o),(t.autoClear||_)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil))}function g(S,_){const y=p(_);y&&(y.isCubeTexture||y.mapping===Oa)?(u===void 0&&(u=new Ye(new os(1,1,1),new vn({name:"BackgroundCubeMaterial",uniforms:nr(Xt.backgroundCube.uniforms),vertexShader:Xt.backgroundCube.vertexShader,fragmentShader:Xt.backgroundCube.fragmentShader,side:Gt,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(D,E,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(u)),Wi.copy(_.backgroundRotation),Wi.x*=-1,Wi.y*=-1,Wi.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(Wi.y*=-1,Wi.z*=-1),u.material.uniforms.envMap.value=y,u.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=_.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=_.backgroundIntensity,u.material.uniforms.backgroundRotation.value.setFromMatrix4(vb.makeRotationFromEuler(Wi)),u.material.toneMapped=Xe.getTransfer(y.colorSpace)!==nt,(d!==y||f!==y.version||h!==t.toneMapping)&&(u.material.needsUpdate=!0,d=y,f=y.version,h=t.toneMapping),u.layers.enableAll(),S.unshift(u,u.geometry,u.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new Ye(new za(2,2),new vn({name:"BackgroundMaterial",uniforms:nr(Xt.background.uniforms),vertexShader:Xt.background.vertexShader,fragmentShader:Xt.background.fragmentShader,side:Ni,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=_.backgroundIntensity,l.material.toneMapped=Xe.getTransfer(y.colorSpace)!==nt,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(d!==y||f!==y.version||h!==t.toneMapping)&&(l.material.needsUpdate=!0,d=y,f=y.version,h=t.toneMapping),l.layers.enableAll(),S.unshift(l,l.geometry,l.material,0,0,null))}function m(S,_){S.getRGB(Fo,bm(t)),i.buffers.color.setClear(Fo.r,Fo.g,Fo.b,_,o)}return{getClearColor:function(){return a},setClearColor:function(S,_=1){a.set(S),c=_,m(a,c)},getClearAlpha:function(){return c},setClearAlpha:function(S){c=S,m(a,c)},render:v,addToRenderList:g}}function Sb(t,e){const n=t.getParameter(t.MAX_VERTEX_ATTRIBS),i={},s=f(null);let r=s,o=!1;function a(x,L,B,F,G){let $=!1;const X=d(F,B,L);r!==X&&(r=X,l(r.object)),$=h(x,F,B,G),$&&p(x,F,B,G),G!==null&&e.update(G,t.ELEMENT_ARRAY_BUFFER),($||o)&&(o=!1,y(x,L,B,F),G!==null&&t.bindBuffer(t.ELEMENT_ARRAY_BUFFER,e.get(G).buffer))}function c(){return t.createVertexArray()}function l(x){return t.bindVertexArray(x)}function u(x){return t.deleteVertexArray(x)}function d(x,L,B){const F=B.wireframe===!0;let G=i[x.id];G===void 0&&(G={},i[x.id]=G);let $=G[L.id];$===void 0&&($={},G[L.id]=$);let X=$[F];return X===void 0&&(X=f(c()),$[F]=X),X}function f(x){const L=[],B=[],F=[];for(let G=0;G<n;G++)L[G]=0,B[G]=0,F[G]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:L,enabledAttributes:B,attributeDivisors:F,object:x,attributes:{},index:null}}function h(x,L,B,F){const G=r.attributes,$=L.attributes;let X=0;const Q=B.getAttributes();for(const V in Q)if(Q[V].location>=0){const he=G[V];let Me=$[V];if(Me===void 0&&(V==="instanceMatrix"&&x.instanceMatrix&&(Me=x.instanceMatrix),V==="instanceColor"&&x.instanceColor&&(Me=x.instanceColor)),he===void 0||he.attribute!==Me||Me&&he.data!==Me.data)return!0;X++}return r.attributesNum!==X||r.index!==F}function p(x,L,B,F){const G={},$=L.attributes;let X=0;const Q=B.getAttributes();for(const V in Q)if(Q[V].location>=0){let he=$[V];he===void 0&&(V==="instanceMatrix"&&x.instanceMatrix&&(he=x.instanceMatrix),V==="instanceColor"&&x.instanceColor&&(he=x.instanceColor));const Me={};Me.attribute=he,he&&he.data&&(Me.data=he.data),G[V]=Me,X++}r.attributes=G,r.attributesNum=X,r.index=F}function v(){const x=r.newAttributes;for(let L=0,B=x.length;L<B;L++)x[L]=0}function g(x){m(x,0)}function m(x,L){const B=r.newAttributes,F=r.enabledAttributes,G=r.attributeDivisors;B[x]=1,F[x]===0&&(t.enableVertexAttribArray(x),F[x]=1),G[x]!==L&&(t.vertexAttribDivisor(x,L),G[x]=L)}function S(){const x=r.newAttributes,L=r.enabledAttributes;for(let B=0,F=L.length;B<F;B++)L[B]!==x[B]&&(t.disableVertexAttribArray(B),L[B]=0)}function _(x,L,B,F,G,$,X){X===!0?t.vertexAttribIPointer(x,L,B,G,$):t.vertexAttribPointer(x,L,B,F,G,$)}function y(x,L,B,F){v();const G=F.attributes,$=B.getAttributes(),X=L.defaultAttributeValues;for(const Q in $){const V=$[Q];if(V.location>=0){let re=G[Q];if(re===void 0&&(Q==="instanceMatrix"&&x.instanceMatrix&&(re=x.instanceMatrix),Q==="instanceColor"&&x.instanceColor&&(re=x.instanceColor)),re!==void 0){const he=re.normalized,Me=re.itemSize,Fe=e.get(re);if(Fe===void 0)continue;const it=Fe.buffer,Y=Fe.type,ne=Fe.bytesPerElement,_e=Y===t.INT||Y===t.UNSIGNED_INT||re.gpuType===qu;if(re.isInterleavedBufferAttribute){const oe=re.data,Re=oe.stride,Le=re.offset;if(oe.isInstancedInterleavedBuffer){for(let Oe=0;Oe<V.locationSize;Oe++)m(V.location+Oe,oe.meshPerAttribute);x.isInstancedMesh!==!0&&F._maxInstanceCount===void 0&&(F._maxInstanceCount=oe.meshPerAttribute*oe.count)}else for(let Oe=0;Oe<V.locationSize;Oe++)g(V.location+Oe);t.bindBuffer(t.ARRAY_BUFFER,it);for(let Oe=0;Oe<V.locationSize;Oe++)_(V.location+Oe,Me/V.locationSize,Y,he,Re*ne,(Le+Me/V.locationSize*Oe)*ne,_e)}else{if(re.isInstancedBufferAttribute){for(let oe=0;oe<V.locationSize;oe++)m(V.location+oe,re.meshPerAttribute);x.isInstancedMesh!==!0&&F._maxInstanceCount===void 0&&(F._maxInstanceCount=re.meshPerAttribute*re.count)}else for(let oe=0;oe<V.locationSize;oe++)g(V.location+oe);t.bindBuffer(t.ARRAY_BUFFER,it);for(let oe=0;oe<V.locationSize;oe++)_(V.location+oe,Me/V.locationSize,Y,he,Me*ne,Me/V.locationSize*oe*ne,_e)}}else if(X!==void 0){const he=X[Q];if(he!==void 0)switch(he.length){case 2:t.vertexAttrib2fv(V.location,he);break;case 3:t.vertexAttrib3fv(V.location,he);break;case 4:t.vertexAttrib4fv(V.location,he);break;default:t.vertexAttrib1fv(V.location,he)}}}}S()}function D(){P();for(const x in i){const L=i[x];for(const B in L){const F=L[B];for(const G in F)u(F[G].object),delete F[G];delete L[B]}delete i[x]}}function E(x){if(i[x.id]===void 0)return;const L=i[x.id];for(const B in L){const F=L[B];for(const G in F)u(F[G].object),delete F[G];delete L[B]}delete i[x.id]}function A(x){for(const L in i){const B=i[L];if(B[x.id]===void 0)continue;const F=B[x.id];for(const G in F)u(F[G].object),delete F[G];delete B[x.id]}}function P(){b(),o=!0,r!==s&&(r=s,l(r.object))}function b(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:P,resetDefaultState:b,dispose:D,releaseStatesOfGeometry:E,releaseStatesOfProgram:A,initAttributes:v,enableAttribute:g,disableUnusedAttributes:S}}function _b(t,e,n){let i;function s(l){i=l}function r(l,u){t.drawArrays(i,l,u),n.update(u,i,1)}function o(l,u,d){d!==0&&(t.drawArraysInstanced(i,l,u,d),n.update(u,i,d))}function a(l,u,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,l,0,u,0,d);let h=0;for(let p=0;p<d;p++)h+=u[p];n.update(h,i,1)}function c(l,u,d,f){if(d===0)return;const h=e.get("WEBGL_multi_draw");if(h===null)for(let p=0;p<l.length;p++)o(l[p],u[p],f[p]);else{h.multiDrawArraysInstancedWEBGL(i,l,0,u,0,f,0,d);let p=0;for(let v=0;v<d;v++)p+=u[v]*f[v];n.update(p,i,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=c}function xb(t,e,n,i){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const A=e.get("EXT_texture_filter_anisotropic");s=t.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(A){return!(A!==nn&&i.convert(A)!==t.getParameter(t.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(A){const P=A===to&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(A!==ri&&i.convert(A)!==t.getParameter(t.IMPLEMENTATION_COLOR_READ_TYPE)&&A!==ti&&!P)}function c(A){if(A==="highp"){if(t.getShaderPrecisionFormat(t.VERTEX_SHADER,t.HIGH_FLOAT).precision>0&&t.getShaderPrecisionFormat(t.FRAGMENT_SHADER,t.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&t.getShaderPrecisionFormat(t.VERTEX_SHADER,t.MEDIUM_FLOAT).precision>0&&t.getShaderPrecisionFormat(t.FRAGMENT_SHADER,t.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=n.precision!==void 0?n.precision:"highp";const u=c(l);u!==l&&(console.warn("THREE.WebGLRenderer:",l,"not supported, using",u,"instead."),l=u);const d=n.logarithmicDepthBuffer===!0,f=n.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),h=t.getParameter(t.MAX_TEXTURE_IMAGE_UNITS),p=t.getParameter(t.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=t.getParameter(t.MAX_TEXTURE_SIZE),g=t.getParameter(t.MAX_CUBE_MAP_TEXTURE_SIZE),m=t.getParameter(t.MAX_VERTEX_ATTRIBS),S=t.getParameter(t.MAX_VERTEX_UNIFORM_VECTORS),_=t.getParameter(t.MAX_VARYING_VECTORS),y=t.getParameter(t.MAX_FRAGMENT_UNIFORM_VECTORS),D=p>0,E=t.getParameter(t.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:d,reverseDepthBuffer:f,maxTextures:h,maxVertexTextures:p,maxTextureSize:v,maxCubemapSize:g,maxAttributes:m,maxVertexUniforms:S,maxVaryings:_,maxFragmentUniforms:y,vertexTextures:D,maxSamples:E}}function bb(t){const e=this;let n=null,i=0,s=!1,r=!1;const o=new qi,a=new Ne,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,f){const h=d.length!==0||f||i!==0||s;return s=f,i=d.length,h},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(d,f){n=u(d,f,0)},this.setState=function(d,f,h){const p=d.clippingPlanes,v=d.clipIntersection,g=d.clipShadows,m=t.get(d);if(!s||p===null||p.length===0||r&&!g)r?u(null):l();else{const S=r?0:i,_=S*4;let y=m.clippingState||null;c.value=y,y=u(p,f,_,h);for(let D=0;D!==_;++D)y[D]=n[D];m.clippingState=y,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=S}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function u(d,f,h,p){const v=d!==null?d.length:0;let g=null;if(v!==0){if(g=c.value,p!==!0||g===null){const m=h+v*4,S=f.matrixWorldInverse;a.getNormalMatrix(S),(g===null||g.length<m)&&(g=new Float32Array(m));for(let _=0,y=h;_!==v;++_,y+=4)o.copy(d[_]).applyMatrix4(S,a),o.normal.toArray(g,y),g[y+3]=o.constant}c.value=g,c.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,g}}function Mb(t){let e=new WeakMap;function n(o,a){return a===Hl?o.mapping=Js:a===Gl&&(o.mapping=Qs),o}function i(o){if(o&&o.isTexture){const a=o.mapping;if(a===Hl||a===Gl)if(e.has(o)){const c=e.get(o).texture;return n(c,o.mapping)}else{const c=o.image;if(c&&c.height>0){const l=new Tm(c.height);return l.fromEquirectangularTexture(t,o),e.set(o,l),o.addEventListener("dispose",s),n(l.texture,o.mapping)}else return null}}return o}function s(o){const a=o.target;a.removeEventListener("dispose",s);const c=e.get(a);c!==void 0&&(e.delete(a),c.dispose())}function r(){e=new WeakMap}return{get:i,dispose:r}}class Rm extends Mm{constructor(e=-1,n=1,i=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=n,this.top=i,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,n,i,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=i-e,o=i+e,a=s+n,c=s-n;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,o=r+l*this.view.width,a-=u*this.view.offsetY,c=a-u*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}const Bs=4,Lf=[.125,.215,.35,.446,.526,.582],Ki=20,Tc=new Rm,Df=new J;let Ac=null,Rc=0,Cc=0,Pc=!1;const Yi=(1+Math.sqrt(5))/2,Ts=1/Yi,If=[new T(-Yi,Ts,0),new T(Yi,Ts,0),new T(-Ts,0,Yi),new T(Ts,0,Yi),new T(0,Yi,-Ts),new T(0,Yi,Ts),new T(-1,1,-1),new T(1,1,-1),new T(-1,1,1),new T(1,1,1)];class Nf{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,n=0,i=.1,s=100){Ac=this._renderer.getRenderTarget(),Rc=this._renderer.getActiveCubeFace(),Cc=this._renderer.getActiveMipmapLevel(),Pc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(e,i,s,r),n>0&&this._blur(r,0,0,n),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(e,n=null){return this._fromTexture(e,n)}fromCubemap(e,n=null){return this._fromTexture(e,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Ff(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=kf(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Ac,Rc,Cc),this._renderer.xr.enabled=Pc,e.scissorTest=!1,Oo(e,0,0,e.width,e.height)}_fromTexture(e,n){e.mapping===Js||e.mapping===Qs?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Ac=this._renderer.getRenderTarget(),Rc=this._renderer.getActiveCubeFace(),Cc=this._renderer.getActiveMipmapLevel(),Pc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=n||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,i={magFilter:qt,minFilter:qt,generateMipmaps:!1,type:to,format:nn,colorSpace:ur,depthBuffer:!1},s=Uf(e,n,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Uf(e,n,i);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Eb(r)),this._blurMaterial=wb(r,e,n)}return s}_compileMaterial(e){const n=new Ye(this._lodPlanes[0],e);this._renderer.compile(n,Tc)}_sceneToCubeUV(e,n,i,s){const a=new $t(90,1,n,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(Df),u.toneMapping=Li,u.autoClear=!1;const h=new mt({name:"PMREM.Background",side:Gt,depthWrite:!1,depthTest:!1}),p=new Ye(new os,h);let v=!1;const g=e.background;g?g.isColor&&(h.color.copy(g),e.background=null,v=!0):(h.color.copy(Df),v=!0);for(let m=0;m<6;m++){const S=m%3;S===0?(a.up.set(0,c[m],0),a.lookAt(l[m],0,0)):S===1?(a.up.set(0,0,c[m]),a.lookAt(0,l[m],0)):(a.up.set(0,c[m],0),a.lookAt(0,0,l[m]));const _=this._cubeSize;Oo(s,S*_,m>2?_:0,_,_),u.setRenderTarget(s),v&&u.render(p,a),u.render(e,a)}p.geometry.dispose(),p.material.dispose(),u.toneMapping=f,u.autoClear=d,e.background=g}_textureToCubeUV(e,n){const i=this._renderer,s=e.mapping===Js||e.mapping===Qs;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Ff()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=kf());const r=s?this._cubemapMaterial:this._equirectMaterial,o=new Ye(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=e;const c=this._cubeSize;Oo(n,0,0,3*c,2*c),i.setRenderTarget(n),i.render(o,Tc)}_applyPMREM(e){const n=this._renderer,i=n.autoClear;n.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=If[(s-r-1)%If.length];this._blur(e,r-1,r,o,a)}n.autoClear=i}_blur(e,n,i,s,r){const o=this._pingPongRenderTarget;this._halfBlur(e,o,n,i,s,"latitudinal",r),this._halfBlur(o,e,i,i,s,"longitudinal",r)}_halfBlur(e,n,i,s,r,o,a){const c=this._renderer,l=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const u=3,d=new Ye(this._lodPlanes[s],l),f=l.uniforms,h=this._sizeLods[i]-1,p=isFinite(r)?Math.PI/(2*h):2*Math.PI/(2*Ki-1),v=r/p,g=isFinite(r)?1+Math.floor(u*v):Ki;g>Ki&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${Ki}`);const m=[];let S=0;for(let A=0;A<Ki;++A){const P=A/v,b=Math.exp(-P*P/2);m.push(b),A===0?S+=b:A<g&&(S+=2*b)}for(let A=0;A<m.length;A++)m[A]=m[A]/S;f.envMap.value=e.texture,f.samples.value=g,f.weights.value=m,f.latitudinal.value=o==="latitudinal",a&&(f.poleAxis.value=a);const{_lodMax:_}=this;f.dTheta.value=p,f.mipInt.value=_-i;const y=this._sizeLods[s],D=3*y*(s>_-Bs?s-_+Bs:0),E=4*(this._cubeSize-y);Oo(n,D,E,3*y,2*y),c.setRenderTarget(n),c.render(d,Tc)}}function Eb(t){const e=[],n=[],i=[];let s=t;const r=t-Bs+1+Lf.length;for(let o=0;o<r;o++){const a=Math.pow(2,s);n.push(a);let c=1/a;o>t-Bs?c=Lf[o-t+Bs-1]:o===0&&(c=0),i.push(c);const l=1/(a-2),u=-l,d=1+l,f=[u,u,d,u,d,d,u,u,d,d,u,d],h=6,p=6,v=3,g=2,m=1,S=new Float32Array(v*p*h),_=new Float32Array(g*p*h),y=new Float32Array(m*p*h);for(let E=0;E<h;E++){const A=E%3*2/3-1,P=E>2?0:-1,b=[A,P,0,A+2/3,P,0,A+2/3,P+1,0,A,P,0,A+2/3,P+1,0,A,P+1,0];S.set(b,v*p*E),_.set(f,g*p*E);const x=[E,E,E,E,E,E];y.set(x,m*p*E)}const D=new Tt;D.setAttribute("position",new Ut(S,v)),D.setAttribute("uv",new Ut(_,g)),D.setAttribute("faceIndex",new Ut(y,m)),e.push(D),s>Bs&&s--}return{lodPlanes:e,sizeLods:n,sigmas:i}}function Uf(t,e,n){const i=new Ui(t,e,n);return i.texture.mapping=Oa,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Oo(t,e,n,i,s){t.viewport.set(e,n,i,s),t.scissor.set(e,n,i,s)}function wb(t,e,n){const i=new Float32Array(Ki),s=new T(0,1,0);return new vn({name:"SphericalGaussianBlur",defines:{n:Ki,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${t}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:nd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Pi,depthTest:!1,depthWrite:!1})}function kf(){return new vn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:nd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Pi,depthTest:!1,depthWrite:!1})}function Ff(){return new vn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:nd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Pi,depthTest:!1,depthWrite:!1})}function nd(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Tb(t){let e=new WeakMap,n=null;function i(a){if(a&&a.isTexture){const c=a.mapping,l=c===Hl||c===Gl,u=c===Js||c===Qs;if(l||u){let d=e.get(a);const f=d!==void 0?d.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==f)return n===null&&(n=new Nf(t)),d=l?n.fromEquirectangular(a,d):n.fromCubemap(a,d),d.texture.pmremVersion=a.pmremVersion,e.set(a,d),d.texture;if(d!==void 0)return d.texture;{const h=a.image;return l&&h&&h.height>0||u&&h&&s(h)?(n===null&&(n=new Nf(t)),d=l?n.fromEquirectangular(a):n.fromCubemap(a),d.texture.pmremVersion=a.pmremVersion,e.set(a,d),a.addEventListener("dispose",r),d.texture):null}}}return a}function s(a){let c=0;const l=6;for(let u=0;u<l;u++)a[u]!==void 0&&c++;return c===l}function r(a){const c=a.target;c.removeEventListener("dispose",r);const l=e.get(c);l!==void 0&&(e.delete(c),l.dispose())}function o(){e=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:i,dispose:o}}function Ab(t){const e={};function n(i){if(e[i]!==void 0)return e[i];let s;switch(i){case"WEBGL_depth_texture":s=t.getExtension("WEBGL_depth_texture")||t.getExtension("MOZ_WEBGL_depth_texture")||t.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=t.getExtension("EXT_texture_filter_anisotropic")||t.getExtension("MOZ_EXT_texture_filter_anisotropic")||t.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=t.getExtension("WEBGL_compressed_texture_s3tc")||t.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||t.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=t.getExtension("WEBGL_compressed_texture_pvrtc")||t.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=t.getExtension(i)}return e[i]=s,s}return{has:function(i){return n(i)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(i){const s=n(i);return s===null&&Nr("THREE.WebGLRenderer: "+i+" extension not supported."),s}}}function Rb(t,e,n,i){const s={},r=new WeakMap;function o(d){const f=d.target;f.index!==null&&e.remove(f.index);for(const p in f.attributes)e.remove(f.attributes[p]);for(const p in f.morphAttributes){const v=f.morphAttributes[p];for(let g=0,m=v.length;g<m;g++)e.remove(v[g])}f.removeEventListener("dispose",o),delete s[f.id];const h=r.get(f);h&&(e.remove(h),r.delete(f)),i.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,n.memory.geometries--}function a(d,f){return s[f.id]===!0||(f.addEventListener("dispose",o),s[f.id]=!0,n.memory.geometries++),f}function c(d){const f=d.attributes;for(const p in f)e.update(f[p],t.ARRAY_BUFFER);const h=d.morphAttributes;for(const p in h){const v=h[p];for(let g=0,m=v.length;g<m;g++)e.update(v[g],t.ARRAY_BUFFER)}}function l(d){const f=[],h=d.index,p=d.attributes.position;let v=0;if(h!==null){const S=h.array;v=h.version;for(let _=0,y=S.length;_<y;_+=3){const D=S[_+0],E=S[_+1],A=S[_+2];f.push(D,E,E,A,A,D)}}else if(p!==void 0){const S=p.array;v=p.version;for(let _=0,y=S.length/3-1;_<y;_+=3){const D=_+0,E=_+1,A=_+2;f.push(D,E,E,A,A,D)}}else return;const g=new(pm(f)?xm:_m)(f,1);g.version=v;const m=r.get(d);m&&e.remove(m),r.set(d,g)}function u(d){const f=r.get(d);if(f){const h=d.index;h!==null&&f.version<h.version&&l(d)}else l(d);return r.get(d)}return{get:a,update:c,getWireframeAttribute:u}}function Cb(t,e,n){let i;function s(f){i=f}let r,o;function a(f){r=f.type,o=f.bytesPerElement}function c(f,h){t.drawElements(i,h,r,f*o),n.update(h,i,1)}function l(f,h,p){p!==0&&(t.drawElementsInstanced(i,h,r,f*o,p),n.update(h,i,p))}function u(f,h,p){if(p===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,h,0,r,f,0,p);let g=0;for(let m=0;m<p;m++)g+=h[m];n.update(g,i,1)}function d(f,h,p,v){if(p===0)return;const g=e.get("WEBGL_multi_draw");if(g===null)for(let m=0;m<f.length;m++)l(f[m]/o,h[m],v[m]);else{g.multiDrawElementsInstancedWEBGL(i,h,0,r,f,0,v,0,p);let m=0;for(let S=0;S<p;S++)m+=h[S]*v[S];n.update(m,i,1)}}this.setMode=s,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=u,this.renderMultiDrawInstances=d}function Pb(t){const e={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,o,a){switch(n.calls++,o){case t.TRIANGLES:n.triangles+=a*(r/3);break;case t.LINES:n.lines+=a*(r/2);break;case t.LINE_STRIP:n.lines+=a*(r-1);break;case t.LINE_LOOP:n.lines+=a*r;break;case t.POINTS:n.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:e,render:n,programs:null,autoReset:!0,reset:s,update:i}}function Lb(t,e,n){const i=new WeakMap,s=new qe;function r(o,a,c){const l=o.morphTargetInfluences,u=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,d=u!==void 0?u.length:0;let f=i.get(a);if(f===void 0||f.count!==d){let x=function(){P.dispose(),i.delete(a),a.removeEventListener("dispose",x)};var h=x;f!==void 0&&f.texture.dispose();const p=a.morphAttributes.position!==void 0,v=a.morphAttributes.normal!==void 0,g=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],S=a.morphAttributes.normal||[],_=a.morphAttributes.color||[];let y=0;p===!0&&(y=1),v===!0&&(y=2),g===!0&&(y=3);let D=a.attributes.position.count*y,E=1;D>e.maxTextureSize&&(E=Math.ceil(D/e.maxTextureSize),D=e.maxTextureSize);const A=new Float32Array(D*E*4*d),P=new gm(A,D,E,d);P.type=ti,P.needsUpdate=!0;const b=y*4;for(let L=0;L<d;L++){const B=m[L],F=S[L],G=_[L],$=D*E*4*L;for(let X=0;X<B.count;X++){const Q=X*b;p===!0&&(s.fromBufferAttribute(B,X),A[$+Q+0]=s.x,A[$+Q+1]=s.y,A[$+Q+2]=s.z,A[$+Q+3]=0),v===!0&&(s.fromBufferAttribute(F,X),A[$+Q+4]=s.x,A[$+Q+5]=s.y,A[$+Q+6]=s.z,A[$+Q+7]=0),g===!0&&(s.fromBufferAttribute(G,X),A[$+Q+8]=s.x,A[$+Q+9]=s.y,A[$+Q+10]=s.z,A[$+Q+11]=G.itemSize===4?s.w:1)}}f={count:d,texture:P,size:new fe(D,E)},i.set(a,f),a.addEventListener("dispose",x)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(t,"morphTexture",o.morphTexture,n);else{let p=0;for(let g=0;g<l.length;g++)p+=l[g];const v=a.morphTargetsRelative?1:1-p;c.getUniforms().setValue(t,"morphTargetBaseInfluence",v),c.getUniforms().setValue(t,"morphTargetInfluences",l)}c.getUniforms().setValue(t,"morphTargetsTexture",f.texture,n),c.getUniforms().setValue(t,"morphTargetsTextureSize",f.size)}return{update:r}}function Db(t,e,n,i){let s=new WeakMap;function r(c){const l=i.render.frame,u=c.geometry,d=e.get(c,u);if(s.get(d)!==l&&(e.update(d),s.set(d,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",a)===!1&&c.addEventListener("dispose",a),s.get(c)!==l&&(n.update(c.instanceMatrix,t.ARRAY_BUFFER),c.instanceColor!==null&&n.update(c.instanceColor,t.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){const f=c.skeleton;s.get(f)!==l&&(f.update(),s.set(f,l))}return d}function o(){s=new WeakMap}function a(c){const l=c.target;l.removeEventListener("dispose",a),n.remove(l.instanceMatrix),l.instanceColor!==null&&n.remove(l.instanceColor)}return{update:r,dispose:o}}class Cm extends Yt{constructor(e,n,i,s,r,o,a,c,l,u=$s){if(u!==$s&&u!==tr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&u===$s&&(i=ns),i===void 0&&u===tr&&(i=er),super(null,s,r,o,a,c,u,i,l),this.isDepthTexture=!0,this.image={width:e,height:n},this.magFilter=a!==void 0?a:Ln,this.minFilter=c!==void 0?c:Ln,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const n=super.toJSON(e);return this.compareFunction!==null&&(n.compareFunction=this.compareFunction),n}}const Pm=new Yt,Of=new Cm(1,1),Lm=new gm,Dm=new xS,Im=new wm,Bf=[],zf=[],Hf=new Float32Array(16),Gf=new Float32Array(9),Wf=new Float32Array(4);function pr(t,e,n){const i=t[0];if(i<=0||i>0)return t;const s=e*n;let r=Bf[s];if(r===void 0&&(r=new Float32Array(s),Bf[s]=r),e!==0){i.toArray(r,0);for(let o=1,a=0;o!==e;++o)a+=n,t[o].toArray(r,a)}return r}function Et(t,e){if(t.length!==e.length)return!1;for(let n=0,i=t.length;n<i;n++)if(t[n]!==e[n])return!1;return!0}function wt(t,e){for(let n=0,i=e.length;n<i;n++)t[n]=e[n]}function Ha(t,e){let n=zf[e];n===void 0&&(n=new Int32Array(e),zf[e]=n);for(let i=0;i!==e;++i)n[i]=t.allocateTextureUnit();return n}function Ib(t,e){const n=this.cache;n[0]!==e&&(t.uniform1f(this.addr,e),n[0]=e)}function Nb(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(t.uniform2f(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Et(n,e))return;t.uniform2fv(this.addr,e),wt(n,e)}}function Ub(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(t.uniform3f(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else if(e.r!==void 0)(n[0]!==e.r||n[1]!==e.g||n[2]!==e.b)&&(t.uniform3f(this.addr,e.r,e.g,e.b),n[0]=e.r,n[1]=e.g,n[2]=e.b);else{if(Et(n,e))return;t.uniform3fv(this.addr,e),wt(n,e)}}function kb(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(t.uniform4f(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Et(n,e))return;t.uniform4fv(this.addr,e),wt(n,e)}}function Fb(t,e){const n=this.cache,i=e.elements;if(i===void 0){if(Et(n,e))return;t.uniformMatrix2fv(this.addr,!1,e),wt(n,e)}else{if(Et(n,i))return;Wf.set(i),t.uniformMatrix2fv(this.addr,!1,Wf),wt(n,i)}}function Ob(t,e){const n=this.cache,i=e.elements;if(i===void 0){if(Et(n,e))return;t.uniformMatrix3fv(this.addr,!1,e),wt(n,e)}else{if(Et(n,i))return;Gf.set(i),t.uniformMatrix3fv(this.addr,!1,Gf),wt(n,i)}}function Bb(t,e){const n=this.cache,i=e.elements;if(i===void 0){if(Et(n,e))return;t.uniformMatrix4fv(this.addr,!1,e),wt(n,e)}else{if(Et(n,i))return;Hf.set(i),t.uniformMatrix4fv(this.addr,!1,Hf),wt(n,i)}}function zb(t,e){const n=this.cache;n[0]!==e&&(t.uniform1i(this.addr,e),n[0]=e)}function Hb(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(t.uniform2i(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Et(n,e))return;t.uniform2iv(this.addr,e),wt(n,e)}}function Gb(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(t.uniform3i(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(Et(n,e))return;t.uniform3iv(this.addr,e),wt(n,e)}}function Wb(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(t.uniform4i(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Et(n,e))return;t.uniform4iv(this.addr,e),wt(n,e)}}function Vb(t,e){const n=this.cache;n[0]!==e&&(t.uniform1ui(this.addr,e),n[0]=e)}function $b(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(t.uniform2ui(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Et(n,e))return;t.uniform2uiv(this.addr,e),wt(n,e)}}function Xb(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(t.uniform3ui(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(Et(n,e))return;t.uniform3uiv(this.addr,e),wt(n,e)}}function qb(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(t.uniform4ui(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Et(n,e))return;t.uniform4uiv(this.addr,e),wt(n,e)}}function Yb(t,e,n){const i=this.cache,s=n.allocateTextureUnit();i[0]!==s&&(t.uniform1i(this.addr,s),i[0]=s);let r;this.type===t.SAMPLER_2D_SHADOW?(Of.compareFunction=hm,r=Of):r=Pm,n.setTexture2D(e||r,s)}function jb(t,e,n){const i=this.cache,s=n.allocateTextureUnit();i[0]!==s&&(t.uniform1i(this.addr,s),i[0]=s),n.setTexture3D(e||Dm,s)}function Kb(t,e,n){const i=this.cache,s=n.allocateTextureUnit();i[0]!==s&&(t.uniform1i(this.addr,s),i[0]=s),n.setTextureCube(e||Im,s)}function Zb(t,e,n){const i=this.cache,s=n.allocateTextureUnit();i[0]!==s&&(t.uniform1i(this.addr,s),i[0]=s),n.setTexture2DArray(e||Lm,s)}function Jb(t){switch(t){case 5126:return Ib;case 35664:return Nb;case 35665:return Ub;case 35666:return kb;case 35674:return Fb;case 35675:return Ob;case 35676:return Bb;case 5124:case 35670:return zb;case 35667:case 35671:return Hb;case 35668:case 35672:return Gb;case 35669:case 35673:return Wb;case 5125:return Vb;case 36294:return $b;case 36295:return Xb;case 36296:return qb;case 35678:case 36198:case 36298:case 36306:case 35682:return Yb;case 35679:case 36299:case 36307:return jb;case 35680:case 36300:case 36308:case 36293:return Kb;case 36289:case 36303:case 36311:case 36292:return Zb}}function Qb(t,e){t.uniform1fv(this.addr,e)}function eM(t,e){const n=pr(e,this.size,2);t.uniform2fv(this.addr,n)}function tM(t,e){const n=pr(e,this.size,3);t.uniform3fv(this.addr,n)}function nM(t,e){const n=pr(e,this.size,4);t.uniform4fv(this.addr,n)}function iM(t,e){const n=pr(e,this.size,4);t.uniformMatrix2fv(this.addr,!1,n)}function sM(t,e){const n=pr(e,this.size,9);t.uniformMatrix3fv(this.addr,!1,n)}function rM(t,e){const n=pr(e,this.size,16);t.uniformMatrix4fv(this.addr,!1,n)}function oM(t,e){t.uniform1iv(this.addr,e)}function aM(t,e){t.uniform2iv(this.addr,e)}function cM(t,e){t.uniform3iv(this.addr,e)}function lM(t,e){t.uniform4iv(this.addr,e)}function uM(t,e){t.uniform1uiv(this.addr,e)}function dM(t,e){t.uniform2uiv(this.addr,e)}function fM(t,e){t.uniform3uiv(this.addr,e)}function hM(t,e){t.uniform4uiv(this.addr,e)}function pM(t,e,n){const i=this.cache,s=e.length,r=Ha(n,s);Et(i,r)||(t.uniform1iv(this.addr,r),wt(i,r));for(let o=0;o!==s;++o)n.setTexture2D(e[o]||Pm,r[o])}function mM(t,e,n){const i=this.cache,s=e.length,r=Ha(n,s);Et(i,r)||(t.uniform1iv(this.addr,r),wt(i,r));for(let o=0;o!==s;++o)n.setTexture3D(e[o]||Dm,r[o])}function gM(t,e,n){const i=this.cache,s=e.length,r=Ha(n,s);Et(i,r)||(t.uniform1iv(this.addr,r),wt(i,r));for(let o=0;o!==s;++o)n.setTextureCube(e[o]||Im,r[o])}function vM(t,e,n){const i=this.cache,s=e.length,r=Ha(n,s);Et(i,r)||(t.uniform1iv(this.addr,r),wt(i,r));for(let o=0;o!==s;++o)n.setTexture2DArray(e[o]||Lm,r[o])}function yM(t){switch(t){case 5126:return Qb;case 35664:return eM;case 35665:return tM;case 35666:return nM;case 35674:return iM;case 35675:return sM;case 35676:return rM;case 5124:case 35670:return oM;case 35667:case 35671:return aM;case 35668:case 35672:return cM;case 35669:case 35673:return lM;case 5125:return uM;case 36294:return dM;case 36295:return fM;case 36296:return hM;case 35678:case 36198:case 36298:case 36306:case 35682:return pM;case 35679:case 36299:case 36307:return mM;case 35680:case 36300:case 36308:case 36293:return gM;case 36289:case 36303:case 36311:case 36292:return vM}}class SM{constructor(e,n,i){this.id=e,this.addr=i,this.cache=[],this.type=n.type,this.setValue=Jb(n.type)}}class _M{constructor(e,n,i){this.id=e,this.addr=i,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=yM(n.type)}}class xM{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,n,i){const s=this.seq;for(let r=0,o=s.length;r!==o;++r){const a=s[r];a.setValue(e,n[a.id],i)}}}const Lc=/(\w+)(\])?(\[|\.)?/g;function Vf(t,e){t.seq.push(e),t.map[e.id]=e}function bM(t,e,n){const i=t.name,s=i.length;for(Lc.lastIndex=0;;){const r=Lc.exec(i),o=Lc.lastIndex;let a=r[1];const c=r[2]==="]",l=r[3];if(c&&(a=a|0),l===void 0||l==="["&&o+2===s){Vf(n,l===void 0?new SM(a,t,e):new _M(a,t,e));break}else{let d=n.map[a];d===void 0&&(d=new xM(a),Vf(n,d)),n=d}}}class ma{constructor(e,n){this.seq=[],this.map={};const i=e.getProgramParameter(n,e.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){const r=e.getActiveUniform(n,s),o=e.getUniformLocation(n,r.name);bM(r,o,this)}}setValue(e,n,i,s){const r=this.map[n];r!==void 0&&r.setValue(e,i,s)}setOptional(e,n,i){const s=n[i];s!==void 0&&this.setValue(e,i,s)}static upload(e,n,i,s){for(let r=0,o=n.length;r!==o;++r){const a=n[r],c=i[a.id];c.needsUpdate!==!1&&a.setValue(e,c.value,s)}}static seqWithValue(e,n){const i=[];for(let s=0,r=e.length;s!==r;++s){const o=e[s];o.id in n&&i.push(o)}return i}}function $f(t,e,n){const i=t.createShader(e);return t.shaderSource(i,n),t.compileShader(i),i}const MM=37297;let EM=0;function wM(t,e){const n=t.split(`
`),i=[],s=Math.max(e-6,0),r=Math.min(e+6,n.length);for(let o=s;o<r;o++){const a=o+1;i.push(`${a===e?">":" "} ${a}: ${n[o]}`)}return i.join(`
`)}const Xf=new Ne;function TM(t){Xe._getMatrix(Xf,Xe.workingColorSpace,t);const e=`mat3( ${Xf.elements.map(n=>n.toFixed(4))} )`;switch(Xe.getTransfer(t)){case Ba:return[e,"LinearTransferOETF"];case nt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",t),[e,"LinearTransferOETF"]}}function qf(t,e,n){const i=t.getShaderParameter(e,t.COMPILE_STATUS),s=t.getShaderInfoLog(e).trim();if(i&&s==="")return"";const r=/ERROR: 0:(\d+)/.exec(s);if(r){const o=parseInt(r[1]);return n.toUpperCase()+`

`+s+`

`+wM(t.getShaderSource(e),o)}else return s}function AM(t,e){const n=TM(e);return[`vec4 ${t}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}function RM(t,e){let n;switch(e){case Dy:n="Linear";break;case Iy:n="Reinhard";break;case Ny:n="Cineon";break;case Uy:n="ACESFilmic";break;case Fy:n="AgX";break;case Oy:n="Neutral";break;case ky:n="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),n="Linear"}return"vec3 "+t+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const Bo=new T;function CM(){Xe.getLuminanceCoefficients(Bo);const t=Bo.x.toFixed(4),e=Bo.y.toFixed(4),n=Bo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${t}, ${e}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function PM(t){return[t.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",t.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ur).join(`
`)}function LM(t){const e=[];for(const n in t){const i=t[n];i!==!1&&e.push("#define "+n+" "+i)}return e.join(`
`)}function DM(t,e){const n={},i=t.getProgramParameter(e,t.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){const r=t.getActiveAttrib(e,s),o=r.name;let a=1;r.type===t.FLOAT_MAT2&&(a=2),r.type===t.FLOAT_MAT3&&(a=3),r.type===t.FLOAT_MAT4&&(a=4),n[o]={type:r.type,location:t.getAttribLocation(e,o),locationSize:a}}return n}function Ur(t){return t!==""}function Yf(t,e){const n=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return t.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function jf(t,e){return t.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const IM=/^[ \t]*#include +<([\w\d./]+)>/gm;function yu(t){return t.replace(IM,UM)}const NM=new Map;function UM(t,e){let n=ke[e];if(n===void 0){const i=NM.get(e);if(i!==void 0)n=ke[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return yu(n)}const kM=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Kf(t){return t.replace(kM,FM)}function FM(t,e,n,i){let s="";for(let r=parseInt(e);r<parseInt(n);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Zf(t){let e=`precision ${t.precision} float;
	precision ${t.precision} int;
	precision ${t.precision} sampler2D;
	precision ${t.precision} samplerCube;
	precision ${t.precision} sampler3D;
	precision ${t.precision} sampler2DArray;
	precision ${t.precision} sampler2DShadow;
	precision ${t.precision} samplerCubeShadow;
	precision ${t.precision} sampler2DArrayShadow;
	precision ${t.precision} isampler2D;
	precision ${t.precision} isampler3D;
	precision ${t.precision} isamplerCube;
	precision ${t.precision} isampler2DArray;
	precision ${t.precision} usampler2D;
	precision ${t.precision} usampler3D;
	precision ${t.precision} usamplerCube;
	precision ${t.precision} usampler2DArray;
	`;return t.precision==="highp"?e+=`
#define HIGH_PRECISION`:t.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:t.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function OM(t){let e="SHADOWMAP_TYPE_BASIC";return t.shadowMapType===em?e="SHADOWMAP_TYPE_PCF":t.shadowMapType===dy?e="SHADOWMAP_TYPE_PCF_SOFT":t.shadowMapType===ei&&(e="SHADOWMAP_TYPE_VSM"),e}function BM(t){let e="ENVMAP_TYPE_CUBE";if(t.envMap)switch(t.envMapMode){case Js:case Qs:e="ENVMAP_TYPE_CUBE";break;case Oa:e="ENVMAP_TYPE_CUBE_UV";break}return e}function zM(t){let e="ENVMAP_MODE_REFLECTION";if(t.envMap)switch(t.envMapMode){case Qs:e="ENVMAP_MODE_REFRACTION";break}return e}function HM(t){let e="ENVMAP_BLENDING_NONE";if(t.envMap)switch(t.combine){case Xu:e="ENVMAP_BLENDING_MULTIPLY";break;case Py:e="ENVMAP_BLENDING_MIX";break;case Ly:e="ENVMAP_BLENDING_ADD";break}return e}function GM(t){const e=t.envMapCubeUVHeight;if(e===null)return null;const n=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,n),112)),texelHeight:i,maxMip:n}}function WM(t,e,n,i){const s=t.getContext(),r=n.defines;let o=n.vertexShader,a=n.fragmentShader;const c=OM(n),l=BM(n),u=zM(n),d=HM(n),f=GM(n),h=PM(n),p=LM(r),v=s.createProgram();let g,m,S=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(g=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,p].filter(Ur).join(`
`),g.length>0&&(g+=`
`),m=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,p].filter(Ur).join(`
`),m.length>0&&(m+=`
`)):(g=[Zf(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,p,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+u:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+c:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",n.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ur).join(`
`),m=[Zf(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,p,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+l:"",n.envMap?"#define "+u:"",n.envMap?"#define "+d:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor||n.batchingColor?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+c:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",n.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==Li?"#define TONE_MAPPING":"",n.toneMapping!==Li?ke.tonemapping_pars_fragment:"",n.toneMapping!==Li?RM("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",ke.colorspace_pars_fragment,AM("linearToOutputTexel",n.outputColorSpace),CM(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(Ur).join(`
`)),o=yu(o),o=Yf(o,n),o=jf(o,n),a=yu(a),a=Yf(a,n),a=jf(a,n),o=Kf(o),a=Kf(a),n.isRawShaderMaterial!==!0&&(S=`#version 300 es
`,g=[h,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,m=["#define varying in",n.glslVersion===lf?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===lf?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const _=S+g+o,y=S+m+a,D=$f(s,s.VERTEX_SHADER,_),E=$f(s,s.FRAGMENT_SHADER,y);s.attachShader(v,D),s.attachShader(v,E),n.index0AttributeName!==void 0?s.bindAttribLocation(v,0,n.index0AttributeName):n.morphTargets===!0&&s.bindAttribLocation(v,0,"position"),s.linkProgram(v);function A(L){if(t.debug.checkShaderErrors){const B=s.getProgramInfoLog(v).trim(),F=s.getShaderInfoLog(D).trim(),G=s.getShaderInfoLog(E).trim();let $=!0,X=!0;if(s.getProgramParameter(v,s.LINK_STATUS)===!1)if($=!1,typeof t.debug.onShaderError=="function")t.debug.onShaderError(s,v,D,E);else{const Q=qf(s,D,"vertex"),V=qf(s,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(v,s.VALIDATE_STATUS)+`

Material Name: `+L.name+`
Material Type: `+L.type+`

Program Info Log: `+B+`
`+Q+`
`+V)}else B!==""?console.warn("THREE.WebGLProgram: Program Info Log:",B):(F===""||G==="")&&(X=!1);X&&(L.diagnostics={runnable:$,programLog:B,vertexShader:{log:F,prefix:g},fragmentShader:{log:G,prefix:m}})}s.deleteShader(D),s.deleteShader(E),P=new ma(s,v),b=DM(s,v)}let P;this.getUniforms=function(){return P===void 0&&A(this),P};let b;this.getAttributes=function(){return b===void 0&&A(this),b};let x=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return x===!1&&(x=s.getProgramParameter(v,MM)),x},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(v),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=EM++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=D,this.fragmentShader=E,this}let VM=0;class $M{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const n=e.vertexShader,i=e.fragmentShader,s=this._getShaderStage(n),r=this._getShaderStage(i),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){const n=this.materialCache.get(e);for(const i of n)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const n=this.materialCache;let i=n.get(e);return i===void 0&&(i=new Set,n.set(e,i)),i}_getShaderStage(e){const n=this.shaderCache;let i=n.get(e);return i===void 0&&(i=new XM(e),n.set(e,i)),i}}class XM{constructor(e){this.id=VM++,this.code=e,this.usedTimes=0}}function qM(t,e,n,i,s,r,o){const a=new ym,c=new $M,l=new Set,u=[],d=s.logarithmicDepthBuffer,f=s.vertexTextures;let h=s.precision;const p={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(b){return l.add(b),b===0?"uv":`uv${b}`}function g(b,x,L,B,F){const G=B.fog,$=F.geometry,X=b.isMeshStandardMaterial?B.environment:null,Q=(b.isMeshStandardMaterial?n:e).get(b.envMap||X),V=Q&&Q.mapping===Oa?Q.image.height:null,re=p[b.type];b.precision!==null&&(h=s.getMaxPrecision(b.precision),h!==b.precision&&console.warn("THREE.WebGLProgram.getParameters:",b.precision,"not supported, using",h,"instead."));const he=$.morphAttributes.position||$.morphAttributes.normal||$.morphAttributes.color,Me=he!==void 0?he.length:0;let Fe=0;$.morphAttributes.position!==void 0&&(Fe=1),$.morphAttributes.normal!==void 0&&(Fe=2),$.morphAttributes.color!==void 0&&(Fe=3);let it,Y,ne,_e;if(re){const et=Xt[re];it=et.vertexShader,Y=et.fragmentShader}else it=b.vertexShader,Y=b.fragmentShader,c.update(b),ne=c.getVertexShaderID(b),_e=c.getFragmentShaderID(b);const oe=t.getRenderTarget(),Re=t.state.buffers.depth.getReversed(),Le=F.isInstancedMesh===!0,Oe=F.isBatchedMesh===!0,ht=!!b.map,Ve=!!b.matcap,yt=!!Q,k=!!b.aoMap,an=!!b.lightMap,He=!!b.bumpMap,Ge=!!b.normalMap,we=!!b.displacementMap,ct=!!b.emissiveMap,Ee=!!b.metalnessMap,R=!!b.roughnessMap,M=b.anisotropy>0,O=b.clearcoat>0,j=b.dispersion>0,Z=b.iridescence>0,q=b.sheen>0,xe=b.transmission>0,ae=M&&!!b.anisotropyMap,pe=O&&!!b.clearcoatMap,$e=O&&!!b.clearcoatNormalMap,ee=O&&!!b.clearcoatRoughnessMap,me=Z&&!!b.iridescenceMap,Ae=Z&&!!b.iridescenceThicknessMap,Ce=q&&!!b.sheenColorMap,ge=q&&!!b.sheenRoughnessMap,We=!!b.specularMap,Ue=!!b.specularColorMap,st=!!b.specularIntensityMap,I=xe&&!!b.transmissionMap,se=xe&&!!b.thicknessMap,W=!!b.gradientMap,K=!!b.alphaMap,ue=b.alphaTest>0,ce=!!b.alphaHash,De=!!b.extensions;let gt=Li;b.toneMapped&&(oe===null||oe.isXRRenderTarget===!0)&&(gt=t.toneMapping);const Ft={shaderID:re,shaderType:b.type,shaderName:b.name,vertexShader:it,fragmentShader:Y,defines:b.defines,customVertexShaderID:ne,customFragmentShaderID:_e,isRawShaderMaterial:b.isRawShaderMaterial===!0,glslVersion:b.glslVersion,precision:h,batching:Oe,batchingColor:Oe&&F._colorsTexture!==null,instancing:Le,instancingColor:Le&&F.instanceColor!==null,instancingMorph:Le&&F.morphTexture!==null,supportsVertexTextures:f,outputColorSpace:oe===null?t.outputColorSpace:oe.isXRRenderTarget===!0?oe.texture.colorSpace:ur,alphaToCoverage:!!b.alphaToCoverage,map:ht,matcap:Ve,envMap:yt,envMapMode:yt&&Q.mapping,envMapCubeUVHeight:V,aoMap:k,lightMap:an,bumpMap:He,normalMap:Ge,displacementMap:f&&we,emissiveMap:ct,normalMapObjectSpace:Ge&&b.normalMapType===Gy,normalMapTangentSpace:Ge&&b.normalMapType===fm,metalnessMap:Ee,roughnessMap:R,anisotropy:M,anisotropyMap:ae,clearcoat:O,clearcoatMap:pe,clearcoatNormalMap:$e,clearcoatRoughnessMap:ee,dispersion:j,iridescence:Z,iridescenceMap:me,iridescenceThicknessMap:Ae,sheen:q,sheenColorMap:Ce,sheenRoughnessMap:ge,specularMap:We,specularColorMap:Ue,specularIntensityMap:st,transmission:xe,transmissionMap:I,thicknessMap:se,gradientMap:W,opaque:b.transparent===!1&&b.blending===Vs&&b.alphaToCoverage===!1,alphaMap:K,alphaTest:ue,alphaHash:ce,combine:b.combine,mapUv:ht&&v(b.map.channel),aoMapUv:k&&v(b.aoMap.channel),lightMapUv:an&&v(b.lightMap.channel),bumpMapUv:He&&v(b.bumpMap.channel),normalMapUv:Ge&&v(b.normalMap.channel),displacementMapUv:we&&v(b.displacementMap.channel),emissiveMapUv:ct&&v(b.emissiveMap.channel),metalnessMapUv:Ee&&v(b.metalnessMap.channel),roughnessMapUv:R&&v(b.roughnessMap.channel),anisotropyMapUv:ae&&v(b.anisotropyMap.channel),clearcoatMapUv:pe&&v(b.clearcoatMap.channel),clearcoatNormalMapUv:$e&&v(b.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ee&&v(b.clearcoatRoughnessMap.channel),iridescenceMapUv:me&&v(b.iridescenceMap.channel),iridescenceThicknessMapUv:Ae&&v(b.iridescenceThicknessMap.channel),sheenColorMapUv:Ce&&v(b.sheenColorMap.channel),sheenRoughnessMapUv:ge&&v(b.sheenRoughnessMap.channel),specularMapUv:We&&v(b.specularMap.channel),specularColorMapUv:Ue&&v(b.specularColorMap.channel),specularIntensityMapUv:st&&v(b.specularIntensityMap.channel),transmissionMapUv:I&&v(b.transmissionMap.channel),thicknessMapUv:se&&v(b.thicknessMap.channel),alphaMapUv:K&&v(b.alphaMap.channel),vertexTangents:!!$.attributes.tangent&&(Ge||M),vertexColors:b.vertexColors,vertexAlphas:b.vertexColors===!0&&!!$.attributes.color&&$.attributes.color.itemSize===4,pointsUvs:F.isPoints===!0&&!!$.attributes.uv&&(ht||K),fog:!!G,useFog:b.fog===!0,fogExp2:!!G&&G.isFogExp2,flatShading:b.flatShading===!0,sizeAttenuation:b.sizeAttenuation===!0,logarithmicDepthBuffer:d,reverseDepthBuffer:Re,skinning:F.isSkinnedMesh===!0,morphTargets:$.morphAttributes.position!==void 0,morphNormals:$.morphAttributes.normal!==void 0,morphColors:$.morphAttributes.color!==void 0,morphTargetsCount:Me,morphTextureStride:Fe,numDirLights:x.directional.length,numPointLights:x.point.length,numSpotLights:x.spot.length,numSpotLightMaps:x.spotLightMap.length,numRectAreaLights:x.rectArea.length,numHemiLights:x.hemi.length,numDirLightShadows:x.directionalShadowMap.length,numPointLightShadows:x.pointShadowMap.length,numSpotLightShadows:x.spotShadowMap.length,numSpotLightShadowsWithMaps:x.numSpotLightShadowsWithMaps,numLightProbes:x.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:b.dithering,shadowMapEnabled:t.shadowMap.enabled&&L.length>0,shadowMapType:t.shadowMap.type,toneMapping:gt,decodeVideoTexture:ht&&b.map.isVideoTexture===!0&&Xe.getTransfer(b.map.colorSpace)===nt,decodeVideoTextureEmissive:ct&&b.emissiveMap.isVideoTexture===!0&&Xe.getTransfer(b.emissiveMap.colorSpace)===nt,premultipliedAlpha:b.premultipliedAlpha,doubleSided:b.side===Dt,flipSided:b.side===Gt,useDepthPacking:b.depthPacking>=0,depthPacking:b.depthPacking||0,index0AttributeName:b.index0AttributeName,extensionClipCullDistance:De&&b.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(De&&b.extensions.multiDraw===!0||Oe)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:b.customProgramCacheKey()};return Ft.vertexUv1s=l.has(1),Ft.vertexUv2s=l.has(2),Ft.vertexUv3s=l.has(3),l.clear(),Ft}function m(b){const x=[];if(b.shaderID?x.push(b.shaderID):(x.push(b.customVertexShaderID),x.push(b.customFragmentShaderID)),b.defines!==void 0)for(const L in b.defines)x.push(L),x.push(b.defines[L]);return b.isRawShaderMaterial===!1&&(S(x,b),_(x,b),x.push(t.outputColorSpace)),x.push(b.customProgramCacheKey),x.join()}function S(b,x){b.push(x.precision),b.push(x.outputColorSpace),b.push(x.envMapMode),b.push(x.envMapCubeUVHeight),b.push(x.mapUv),b.push(x.alphaMapUv),b.push(x.lightMapUv),b.push(x.aoMapUv),b.push(x.bumpMapUv),b.push(x.normalMapUv),b.push(x.displacementMapUv),b.push(x.emissiveMapUv),b.push(x.metalnessMapUv),b.push(x.roughnessMapUv),b.push(x.anisotropyMapUv),b.push(x.clearcoatMapUv),b.push(x.clearcoatNormalMapUv),b.push(x.clearcoatRoughnessMapUv),b.push(x.iridescenceMapUv),b.push(x.iridescenceThicknessMapUv),b.push(x.sheenColorMapUv),b.push(x.sheenRoughnessMapUv),b.push(x.specularMapUv),b.push(x.specularColorMapUv),b.push(x.specularIntensityMapUv),b.push(x.transmissionMapUv),b.push(x.thicknessMapUv),b.push(x.combine),b.push(x.fogExp2),b.push(x.sizeAttenuation),b.push(x.morphTargetsCount),b.push(x.morphAttributeCount),b.push(x.numDirLights),b.push(x.numPointLights),b.push(x.numSpotLights),b.push(x.numSpotLightMaps),b.push(x.numHemiLights),b.push(x.numRectAreaLights),b.push(x.numDirLightShadows),b.push(x.numPointLightShadows),b.push(x.numSpotLightShadows),b.push(x.numSpotLightShadowsWithMaps),b.push(x.numLightProbes),b.push(x.shadowMapType),b.push(x.toneMapping),b.push(x.numClippingPlanes),b.push(x.numClipIntersection),b.push(x.depthPacking)}function _(b,x){a.disableAll(),x.supportsVertexTextures&&a.enable(0),x.instancing&&a.enable(1),x.instancingColor&&a.enable(2),x.instancingMorph&&a.enable(3),x.matcap&&a.enable(4),x.envMap&&a.enable(5),x.normalMapObjectSpace&&a.enable(6),x.normalMapTangentSpace&&a.enable(7),x.clearcoat&&a.enable(8),x.iridescence&&a.enable(9),x.alphaTest&&a.enable(10),x.vertexColors&&a.enable(11),x.vertexAlphas&&a.enable(12),x.vertexUv1s&&a.enable(13),x.vertexUv2s&&a.enable(14),x.vertexUv3s&&a.enable(15),x.vertexTangents&&a.enable(16),x.anisotropy&&a.enable(17),x.alphaHash&&a.enable(18),x.batching&&a.enable(19),x.dispersion&&a.enable(20),x.batchingColor&&a.enable(21),b.push(a.mask),a.disableAll(),x.fog&&a.enable(0),x.useFog&&a.enable(1),x.flatShading&&a.enable(2),x.logarithmicDepthBuffer&&a.enable(3),x.reverseDepthBuffer&&a.enable(4),x.skinning&&a.enable(5),x.morphTargets&&a.enable(6),x.morphNormals&&a.enable(7),x.morphColors&&a.enable(8),x.premultipliedAlpha&&a.enable(9),x.shadowMapEnabled&&a.enable(10),x.doubleSided&&a.enable(11),x.flipSided&&a.enable(12),x.useDepthPacking&&a.enable(13),x.dithering&&a.enable(14),x.transmission&&a.enable(15),x.sheen&&a.enable(16),x.opaque&&a.enable(17),x.pointsUvs&&a.enable(18),x.decodeVideoTexture&&a.enable(19),x.decodeVideoTextureEmissive&&a.enable(20),x.alphaToCoverage&&a.enable(21),b.push(a.mask)}function y(b){const x=p[b.type];let L;if(x){const B=Xt[x];L=ed.clone(B.uniforms)}else L=b.uniforms;return L}function D(b,x){let L;for(let B=0,F=u.length;B<F;B++){const G=u[B];if(G.cacheKey===x){L=G,++L.usedTimes;break}}return L===void 0&&(L=new WM(t,x,b,r),u.push(L)),L}function E(b){if(--b.usedTimes===0){const x=u.indexOf(b);u[x]=u[u.length-1],u.pop(),b.destroy()}}function A(b){c.remove(b)}function P(){c.dispose()}return{getParameters:g,getProgramCacheKey:m,getUniforms:y,acquireProgram:D,releaseProgram:E,releaseShaderCache:A,programs:u,dispose:P}}function YM(){let t=new WeakMap;function e(o){return t.has(o)}function n(o){let a=t.get(o);return a===void 0&&(a={},t.set(o,a)),a}function i(o){t.delete(o)}function s(o,a,c){t.get(o)[a]=c}function r(){t=new WeakMap}return{has:e,get:n,remove:i,update:s,dispose:r}}function jM(t,e){return t.groupOrder!==e.groupOrder?t.groupOrder-e.groupOrder:t.renderOrder!==e.renderOrder?t.renderOrder-e.renderOrder:t.material.id!==e.material.id?t.material.id-e.material.id:t.z!==e.z?t.z-e.z:t.id-e.id}function Jf(t,e){return t.groupOrder!==e.groupOrder?t.groupOrder-e.groupOrder:t.renderOrder!==e.renderOrder?t.renderOrder-e.renderOrder:t.z!==e.z?e.z-t.z:t.id-e.id}function Qf(){const t=[];let e=0;const n=[],i=[],s=[];function r(){e=0,n.length=0,i.length=0,s.length=0}function o(d,f,h,p,v,g){let m=t[e];return m===void 0?(m={id:d.id,object:d,geometry:f,material:h,groupOrder:p,renderOrder:d.renderOrder,z:v,group:g},t[e]=m):(m.id=d.id,m.object=d,m.geometry=f,m.material=h,m.groupOrder=p,m.renderOrder=d.renderOrder,m.z=v,m.group=g),e++,m}function a(d,f,h,p,v,g){const m=o(d,f,h,p,v,g);h.transmission>0?i.push(m):h.transparent===!0?s.push(m):n.push(m)}function c(d,f,h,p,v,g){const m=o(d,f,h,p,v,g);h.transmission>0?i.unshift(m):h.transparent===!0?s.unshift(m):n.unshift(m)}function l(d,f){n.length>1&&n.sort(d||jM),i.length>1&&i.sort(f||Jf),s.length>1&&s.sort(f||Jf)}function u(){for(let d=e,f=t.length;d<f;d++){const h=t[d];if(h.id===null)break;h.id=null,h.object=null,h.geometry=null,h.material=null,h.group=null}}return{opaque:n,transmissive:i,transparent:s,init:r,push:a,unshift:c,finish:u,sort:l}}function KM(){let t=new WeakMap;function e(i,s){const r=t.get(i);let o;return r===void 0?(o=new Qf,t.set(i,[o])):s>=r.length?(o=new Qf,r.push(o)):o=r[s],o}function n(){t=new WeakMap}return{get:e,dispose:n}}function ZM(){const t={};return{get:function(e){if(t[e.id]!==void 0)return t[e.id];let n;switch(e.type){case"DirectionalLight":n={direction:new T,color:new J};break;case"SpotLight":n={position:new T,direction:new T,color:new J,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new T,color:new J,distance:0,decay:0};break;case"HemisphereLight":n={direction:new T,skyColor:new J,groundColor:new J};break;case"RectAreaLight":n={color:new J,position:new T,halfWidth:new T,halfHeight:new T};break}return t[e.id]=n,n}}}function JM(){const t={};return{get:function(e){if(t[e.id]!==void 0)return t[e.id];let n;switch(e.type){case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fe};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fe};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fe,shadowCameraNear:1,shadowCameraFar:1e3};break}return t[e.id]=n,n}}}let QM=0;function e1(t,e){return(e.castShadow?2:0)-(t.castShadow?2:0)+(e.map?1:0)-(t.map?1:0)}function t1(t){const e=new ZM,n=JM(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)i.probe.push(new T);const s=new T,r=new Qe,o=new Qe;function a(l){let u=0,d=0,f=0;for(let b=0;b<9;b++)i.probe[b].set(0,0,0);let h=0,p=0,v=0,g=0,m=0,S=0,_=0,y=0,D=0,E=0,A=0;l.sort(e1);for(let b=0,x=l.length;b<x;b++){const L=l[b],B=L.color,F=L.intensity,G=L.distance,$=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)u+=B.r*F,d+=B.g*F,f+=B.b*F;else if(L.isLightProbe){for(let X=0;X<9;X++)i.probe[X].addScaledVector(L.sh.coefficients[X],F);A++}else if(L.isDirectionalLight){const X=e.get(L);if(X.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const Q=L.shadow,V=n.get(L);V.shadowIntensity=Q.intensity,V.shadowBias=Q.bias,V.shadowNormalBias=Q.normalBias,V.shadowRadius=Q.radius,V.shadowMapSize=Q.mapSize,i.directionalShadow[h]=V,i.directionalShadowMap[h]=$,i.directionalShadowMatrix[h]=L.shadow.matrix,S++}i.directional[h]=X,h++}else if(L.isSpotLight){const X=e.get(L);X.position.setFromMatrixPosition(L.matrixWorld),X.color.copy(B).multiplyScalar(F),X.distance=G,X.coneCos=Math.cos(L.angle),X.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),X.decay=L.decay,i.spot[v]=X;const Q=L.shadow;if(L.map&&(i.spotLightMap[D]=L.map,D++,Q.updateMatrices(L),L.castShadow&&E++),i.spotLightMatrix[v]=Q.matrix,L.castShadow){const V=n.get(L);V.shadowIntensity=Q.intensity,V.shadowBias=Q.bias,V.shadowNormalBias=Q.normalBias,V.shadowRadius=Q.radius,V.shadowMapSize=Q.mapSize,i.spotShadow[v]=V,i.spotShadowMap[v]=$,y++}v++}else if(L.isRectAreaLight){const X=e.get(L);X.color.copy(B).multiplyScalar(F),X.halfWidth.set(L.width*.5,0,0),X.halfHeight.set(0,L.height*.5,0),i.rectArea[g]=X,g++}else if(L.isPointLight){const X=e.get(L);if(X.color.copy(L.color).multiplyScalar(L.intensity),X.distance=L.distance,X.decay=L.decay,L.castShadow){const Q=L.shadow,V=n.get(L);V.shadowIntensity=Q.intensity,V.shadowBias=Q.bias,V.shadowNormalBias=Q.normalBias,V.shadowRadius=Q.radius,V.shadowMapSize=Q.mapSize,V.shadowCameraNear=Q.camera.near,V.shadowCameraFar=Q.camera.far,i.pointShadow[p]=V,i.pointShadowMap[p]=$,i.pointShadowMatrix[p]=L.shadow.matrix,_++}i.point[p]=X,p++}else if(L.isHemisphereLight){const X=e.get(L);X.skyColor.copy(L.color).multiplyScalar(F),X.groundColor.copy(L.groundColor).multiplyScalar(F),i.hemi[m]=X,m++}}g>0&&(t.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ie.LTC_FLOAT_1,i.rectAreaLTC2=ie.LTC_FLOAT_2):(i.rectAreaLTC1=ie.LTC_HALF_1,i.rectAreaLTC2=ie.LTC_HALF_2)),i.ambient[0]=u,i.ambient[1]=d,i.ambient[2]=f;const P=i.hash;(P.directionalLength!==h||P.pointLength!==p||P.spotLength!==v||P.rectAreaLength!==g||P.hemiLength!==m||P.numDirectionalShadows!==S||P.numPointShadows!==_||P.numSpotShadows!==y||P.numSpotMaps!==D||P.numLightProbes!==A)&&(i.directional.length=h,i.spot.length=v,i.rectArea.length=g,i.point.length=p,i.hemi.length=m,i.directionalShadow.length=S,i.directionalShadowMap.length=S,i.pointShadow.length=_,i.pointShadowMap.length=_,i.spotShadow.length=y,i.spotShadowMap.length=y,i.directionalShadowMatrix.length=S,i.pointShadowMatrix.length=_,i.spotLightMatrix.length=y+D-E,i.spotLightMap.length=D,i.numSpotLightShadowsWithMaps=E,i.numLightProbes=A,P.directionalLength=h,P.pointLength=p,P.spotLength=v,P.rectAreaLength=g,P.hemiLength=m,P.numDirectionalShadows=S,P.numPointShadows=_,P.numSpotShadows=y,P.numSpotMaps=D,P.numLightProbes=A,i.version=QM++)}function c(l,u){let d=0,f=0,h=0,p=0,v=0;const g=u.matrixWorldInverse;for(let m=0,S=l.length;m<S;m++){const _=l[m];if(_.isDirectionalLight){const y=i.directional[d];y.direction.setFromMatrixPosition(_.matrixWorld),s.setFromMatrixPosition(_.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(g),d++}else if(_.isSpotLight){const y=i.spot[h];y.position.setFromMatrixPosition(_.matrixWorld),y.position.applyMatrix4(g),y.direction.setFromMatrixPosition(_.matrixWorld),s.setFromMatrixPosition(_.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(g),h++}else if(_.isRectAreaLight){const y=i.rectArea[p];y.position.setFromMatrixPosition(_.matrixWorld),y.position.applyMatrix4(g),o.identity(),r.copy(_.matrixWorld),r.premultiply(g),o.extractRotation(r),y.halfWidth.set(_.width*.5,0,0),y.halfHeight.set(0,_.height*.5,0),y.halfWidth.applyMatrix4(o),y.halfHeight.applyMatrix4(o),p++}else if(_.isPointLight){const y=i.point[f];y.position.setFromMatrixPosition(_.matrixWorld),y.position.applyMatrix4(g),f++}else if(_.isHemisphereLight){const y=i.hemi[v];y.direction.setFromMatrixPosition(_.matrixWorld),y.direction.transformDirection(g),v++}}}return{setup:a,setupView:c,state:i}}function eh(t){const e=new t1(t),n=[],i=[];function s(u){l.camera=u,n.length=0,i.length=0}function r(u){n.push(u)}function o(u){i.push(u)}function a(){e.setup(n)}function c(u){e.setupView(n,u)}const l={lightsArray:n,shadowsArray:i,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:l,setupLights:a,setupLightsView:c,pushLight:r,pushShadow:o}}function n1(t){let e=new WeakMap;function n(s,r=0){const o=e.get(s);let a;return o===void 0?(a=new eh(t),e.set(s,[a])):r>=o.length?(a=new eh(t),o.push(a)):a=o[r],a}function i(){e=new WeakMap}return{get:n,dispose:i}}class i1 extends hr{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=zy,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class s1 extends hr{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const r1=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,o1=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function a1(t,e,n){let i=new td;const s=new fe,r=new fe,o=new qe,a=new i1({depthPacking:Hy}),c=new s1,l={},u=n.maxTextureSize,d={[Ni]:Gt,[Gt]:Ni,[Dt]:Dt},f=new vn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new fe},radius:{value:4}},vertexShader:r1,fragmentShader:o1}),h=f.clone();h.defines.HORIZONTAL_PASS=1;const p=new Tt;p.setAttribute("position",new Ut(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new Ye(p,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=em;let m=this.type;this.render=function(E,A,P){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||E.length===0)return;const b=t.getRenderTarget(),x=t.getActiveCubeFace(),L=t.getActiveMipmapLevel(),B=t.state;B.setBlending(Pi),B.buffers.color.setClear(1,1,1,1),B.buffers.depth.setTest(!0),B.setScissorTest(!1);const F=m!==ei&&this.type===ei,G=m===ei&&this.type!==ei;for(let $=0,X=E.length;$<X;$++){const Q=E[$],V=Q.shadow;if(V===void 0){console.warn("THREE.WebGLShadowMap:",Q,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;s.copy(V.mapSize);const re=V.getFrameExtents();if(s.multiply(re),r.copy(V.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/re.x),s.x=r.x*re.x,V.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/re.y),s.y=r.y*re.y,V.mapSize.y=r.y)),V.map===null||F===!0||G===!0){const Me=this.type!==ei?{minFilter:Ln,magFilter:Ln}:{};V.map!==null&&V.map.dispose(),V.map=new Ui(s.x,s.y,Me),V.map.texture.name=Q.name+".shadowMap",V.camera.updateProjectionMatrix()}t.setRenderTarget(V.map),t.clear();const he=V.getViewportCount();for(let Me=0;Me<he;Me++){const Fe=V.getViewport(Me);o.set(r.x*Fe.x,r.y*Fe.y,r.x*Fe.z,r.y*Fe.w),B.viewport(o),V.updateMatrices(Q,Me),i=V.getFrustum(),y(A,P,V.camera,Q,this.type)}V.isPointLightShadow!==!0&&this.type===ei&&S(V,P),V.needsUpdate=!1}m=this.type,g.needsUpdate=!1,t.setRenderTarget(b,x,L)};function S(E,A){const P=e.update(v);f.defines.VSM_SAMPLES!==E.blurSamples&&(f.defines.VSM_SAMPLES=E.blurSamples,h.defines.VSM_SAMPLES=E.blurSamples,f.needsUpdate=!0,h.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new Ui(s.x,s.y)),f.uniforms.shadow_pass.value=E.map.texture,f.uniforms.resolution.value=E.mapSize,f.uniforms.radius.value=E.radius,t.setRenderTarget(E.mapPass),t.clear(),t.renderBufferDirect(A,null,P,f,v,null),h.uniforms.shadow_pass.value=E.mapPass.texture,h.uniforms.resolution.value=E.mapSize,h.uniforms.radius.value=E.radius,t.setRenderTarget(E.map),t.clear(),t.renderBufferDirect(A,null,P,h,v,null)}function _(E,A,P,b){let x=null;const L=P.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(L!==void 0)x=L;else if(x=P.isPointLight===!0?c:a,t.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){const B=x.uuid,F=A.uuid;let G=l[B];G===void 0&&(G={},l[B]=G);let $=G[F];$===void 0&&($=x.clone(),G[F]=$,A.addEventListener("dispose",D)),x=$}if(x.visible=A.visible,x.wireframe=A.wireframe,b===ei?x.side=A.shadowSide!==null?A.shadowSide:A.side:x.side=A.shadowSide!==null?A.shadowSide:d[A.side],x.alphaMap=A.alphaMap,x.alphaTest=A.alphaTest,x.map=A.map,x.clipShadows=A.clipShadows,x.clippingPlanes=A.clippingPlanes,x.clipIntersection=A.clipIntersection,x.displacementMap=A.displacementMap,x.displacementScale=A.displacementScale,x.displacementBias=A.displacementBias,x.wireframeLinewidth=A.wireframeLinewidth,x.linewidth=A.linewidth,P.isPointLight===!0&&x.isMeshDistanceMaterial===!0){const B=t.properties.get(x);B.light=P}return x}function y(E,A,P,b,x){if(E.visible===!1)return;if(E.layers.test(A.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&x===ei)&&(!E.frustumCulled||i.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,E.matrixWorld);const F=e.update(E),G=E.material;if(Array.isArray(G)){const $=F.groups;for(let X=0,Q=$.length;X<Q;X++){const V=$[X],re=G[V.materialIndex];if(re&&re.visible){const he=_(E,re,b,x);E.onBeforeShadow(t,E,A,P,F,he,V),t.renderBufferDirect(P,null,F,he,E,V),E.onAfterShadow(t,E,A,P,F,he,V)}}}else if(G.visible){const $=_(E,G,b,x);E.onBeforeShadow(t,E,A,P,F,$,null),t.renderBufferDirect(P,null,F,$,E,null),E.onAfterShadow(t,E,A,P,F,$,null)}}const B=E.children;for(let F=0,G=B.length;F<G;F++)y(B[F],A,P,b,x)}function D(E){E.target.removeEventListener("dispose",D);for(const P in l){const b=l[P],x=E.target.uuid;x in b&&(b[x].dispose(),delete b[x])}}}const c1={[Nl]:Ul,[kl]:Bl,[Fl]:zl,[Zs]:Ol,[Ul]:Nl,[Bl]:kl,[zl]:Fl,[Ol]:Zs};function l1(t,e){function n(){let I=!1;const se=new qe;let W=null;const K=new qe(0,0,0,0);return{setMask:function(ue){W!==ue&&!I&&(t.colorMask(ue,ue,ue,ue),W=ue)},setLocked:function(ue){I=ue},setClear:function(ue,ce,De,gt,Ft){Ft===!0&&(ue*=gt,ce*=gt,De*=gt),se.set(ue,ce,De,gt),K.equals(se)===!1&&(t.clearColor(ue,ce,De,gt),K.copy(se))},reset:function(){I=!1,W=null,K.set(-1,0,0,0)}}}function i(){let I=!1,se=!1,W=null,K=null,ue=null;return{setReversed:function(ce){if(se!==ce){const De=e.get("EXT_clip_control");se?De.clipControlEXT(De.LOWER_LEFT_EXT,De.ZERO_TO_ONE_EXT):De.clipControlEXT(De.LOWER_LEFT_EXT,De.NEGATIVE_ONE_TO_ONE_EXT);const gt=ue;ue=null,this.setClear(gt)}se=ce},getReversed:function(){return se},setTest:function(ce){ce?oe(t.DEPTH_TEST):Re(t.DEPTH_TEST)},setMask:function(ce){W!==ce&&!I&&(t.depthMask(ce),W=ce)},setFunc:function(ce){if(se&&(ce=c1[ce]),K!==ce){switch(ce){case Nl:t.depthFunc(t.NEVER);break;case Ul:t.depthFunc(t.ALWAYS);break;case kl:t.depthFunc(t.LESS);break;case Zs:t.depthFunc(t.LEQUAL);break;case Fl:t.depthFunc(t.EQUAL);break;case Ol:t.depthFunc(t.GEQUAL);break;case Bl:t.depthFunc(t.GREATER);break;case zl:t.depthFunc(t.NOTEQUAL);break;default:t.depthFunc(t.LEQUAL)}K=ce}},setLocked:function(ce){I=ce},setClear:function(ce){ue!==ce&&(se&&(ce=1-ce),t.clearDepth(ce),ue=ce)},reset:function(){I=!1,W=null,K=null,ue=null,se=!1}}}function s(){let I=!1,se=null,W=null,K=null,ue=null,ce=null,De=null,gt=null,Ft=null;return{setTest:function(et){I||(et?oe(t.STENCIL_TEST):Re(t.STENCIL_TEST))},setMask:function(et){se!==et&&!I&&(t.stencilMask(et),se=et)},setFunc:function(et,_n,$n){(W!==et||K!==_n||ue!==$n)&&(t.stencilFunc(et,_n,$n),W=et,K=_n,ue=$n)},setOp:function(et,_n,$n){(ce!==et||De!==_n||gt!==$n)&&(t.stencilOp(et,_n,$n),ce=et,De=_n,gt=$n)},setLocked:function(et){I=et},setClear:function(et){Ft!==et&&(t.clearStencil(et),Ft=et)},reset:function(){I=!1,se=null,W=null,K=null,ue=null,ce=null,De=null,gt=null,Ft=null}}}const r=new n,o=new i,a=new s,c=new WeakMap,l=new WeakMap;let u={},d={},f=new WeakMap,h=[],p=null,v=!1,g=null,m=null,S=null,_=null,y=null,D=null,E=null,A=new J(0,0,0),P=0,b=!1,x=null,L=null,B=null,F=null,G=null;const $=t.getParameter(t.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let X=!1,Q=0;const V=t.getParameter(t.VERSION);V.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(V)[1]),X=Q>=1):V.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),X=Q>=2);let re=null,he={};const Me=t.getParameter(t.SCISSOR_BOX),Fe=t.getParameter(t.VIEWPORT),it=new qe().fromArray(Me),Y=new qe().fromArray(Fe);function ne(I,se,W,K){const ue=new Uint8Array(4),ce=t.createTexture();t.bindTexture(I,ce),t.texParameteri(I,t.TEXTURE_MIN_FILTER,t.NEAREST),t.texParameteri(I,t.TEXTURE_MAG_FILTER,t.NEAREST);for(let De=0;De<W;De++)I===t.TEXTURE_3D||I===t.TEXTURE_2D_ARRAY?t.texImage3D(se,0,t.RGBA,1,1,K,0,t.RGBA,t.UNSIGNED_BYTE,ue):t.texImage2D(se+De,0,t.RGBA,1,1,0,t.RGBA,t.UNSIGNED_BYTE,ue);return ce}const _e={};_e[t.TEXTURE_2D]=ne(t.TEXTURE_2D,t.TEXTURE_2D,1),_e[t.TEXTURE_CUBE_MAP]=ne(t.TEXTURE_CUBE_MAP,t.TEXTURE_CUBE_MAP_POSITIVE_X,6),_e[t.TEXTURE_2D_ARRAY]=ne(t.TEXTURE_2D_ARRAY,t.TEXTURE_2D_ARRAY,1,1),_e[t.TEXTURE_3D]=ne(t.TEXTURE_3D,t.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),oe(t.DEPTH_TEST),o.setFunc(Zs),He(!1),Ge(rf),oe(t.CULL_FACE),k(Pi);function oe(I){u[I]!==!0&&(t.enable(I),u[I]=!0)}function Re(I){u[I]!==!1&&(t.disable(I),u[I]=!1)}function Le(I,se){return d[I]!==se?(t.bindFramebuffer(I,se),d[I]=se,I===t.DRAW_FRAMEBUFFER&&(d[t.FRAMEBUFFER]=se),I===t.FRAMEBUFFER&&(d[t.DRAW_FRAMEBUFFER]=se),!0):!1}function Oe(I,se){let W=h,K=!1;if(I){W=f.get(se),W===void 0&&(W=[],f.set(se,W));const ue=I.textures;if(W.length!==ue.length||W[0]!==t.COLOR_ATTACHMENT0){for(let ce=0,De=ue.length;ce<De;ce++)W[ce]=t.COLOR_ATTACHMENT0+ce;W.length=ue.length,K=!0}}else W[0]!==t.BACK&&(W[0]=t.BACK,K=!0);K&&t.drawBuffers(W)}function ht(I){return p!==I?(t.useProgram(I),p=I,!0):!1}const Ve={[ji]:t.FUNC_ADD,[hy]:t.FUNC_SUBTRACT,[py]:t.FUNC_REVERSE_SUBTRACT};Ve[my]=t.MIN,Ve[gy]=t.MAX;const yt={[vy]:t.ZERO,[yy]:t.ONE,[Sy]:t.SRC_COLOR,[Dl]:t.SRC_ALPHA,[wy]:t.SRC_ALPHA_SATURATE,[My]:t.DST_COLOR,[xy]:t.DST_ALPHA,[_y]:t.ONE_MINUS_SRC_COLOR,[Il]:t.ONE_MINUS_SRC_ALPHA,[Ey]:t.ONE_MINUS_DST_COLOR,[by]:t.ONE_MINUS_DST_ALPHA,[Ty]:t.CONSTANT_COLOR,[Ay]:t.ONE_MINUS_CONSTANT_COLOR,[Ry]:t.CONSTANT_ALPHA,[Cy]:t.ONE_MINUS_CONSTANT_ALPHA};function k(I,se,W,K,ue,ce,De,gt,Ft,et){if(I===Pi){v===!0&&(Re(t.BLEND),v=!1);return}if(v===!1&&(oe(t.BLEND),v=!0),I!==fy){if(I!==g||et!==b){if((m!==ji||y!==ji)&&(t.blendEquation(t.FUNC_ADD),m=ji,y=ji),et)switch(I){case Vs:t.blendFuncSeparate(t.ONE,t.ONE_MINUS_SRC_ALPHA,t.ONE,t.ONE_MINUS_SRC_ALPHA);break;case ot:t.blendFunc(t.ONE,t.ONE);break;case of:t.blendFuncSeparate(t.ZERO,t.ONE_MINUS_SRC_COLOR,t.ZERO,t.ONE);break;case af:t.blendFuncSeparate(t.ZERO,t.SRC_COLOR,t.ZERO,t.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}else switch(I){case Vs:t.blendFuncSeparate(t.SRC_ALPHA,t.ONE_MINUS_SRC_ALPHA,t.ONE,t.ONE_MINUS_SRC_ALPHA);break;case ot:t.blendFunc(t.SRC_ALPHA,t.ONE);break;case of:t.blendFuncSeparate(t.ZERO,t.ONE_MINUS_SRC_COLOR,t.ZERO,t.ONE);break;case af:t.blendFunc(t.ZERO,t.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}S=null,_=null,D=null,E=null,A.set(0,0,0),P=0,g=I,b=et}return}ue=ue||se,ce=ce||W,De=De||K,(se!==m||ue!==y)&&(t.blendEquationSeparate(Ve[se],Ve[ue]),m=se,y=ue),(W!==S||K!==_||ce!==D||De!==E)&&(t.blendFuncSeparate(yt[W],yt[K],yt[ce],yt[De]),S=W,_=K,D=ce,E=De),(gt.equals(A)===!1||Ft!==P)&&(t.blendColor(gt.r,gt.g,gt.b,Ft),A.copy(gt),P=Ft),g=I,b=!1}function an(I,se){I.side===Dt?Re(t.CULL_FACE):oe(t.CULL_FACE);let W=I.side===Gt;se&&(W=!W),He(W),I.blending===Vs&&I.transparent===!1?k(Pi):k(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),o.setFunc(I.depthFunc),o.setTest(I.depthTest),o.setMask(I.depthWrite),r.setMask(I.colorWrite);const K=I.stencilWrite;a.setTest(K),K&&(a.setMask(I.stencilWriteMask),a.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),a.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),ct(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?oe(t.SAMPLE_ALPHA_TO_COVERAGE):Re(t.SAMPLE_ALPHA_TO_COVERAGE)}function He(I){x!==I&&(I?t.frontFace(t.CW):t.frontFace(t.CCW),x=I)}function Ge(I){I!==ly?(oe(t.CULL_FACE),I!==L&&(I===rf?t.cullFace(t.BACK):I===uy?t.cullFace(t.FRONT):t.cullFace(t.FRONT_AND_BACK))):Re(t.CULL_FACE),L=I}function we(I){I!==B&&(X&&t.lineWidth(I),B=I)}function ct(I,se,W){I?(oe(t.POLYGON_OFFSET_FILL),(F!==se||G!==W)&&(t.polygonOffset(se,W),F=se,G=W)):Re(t.POLYGON_OFFSET_FILL)}function Ee(I){I?oe(t.SCISSOR_TEST):Re(t.SCISSOR_TEST)}function R(I){I===void 0&&(I=t.TEXTURE0+$-1),re!==I&&(t.activeTexture(I),re=I)}function M(I,se,W){W===void 0&&(re===null?W=t.TEXTURE0+$-1:W=re);let K=he[W];K===void 0&&(K={type:void 0,texture:void 0},he[W]=K),(K.type!==I||K.texture!==se)&&(re!==W&&(t.activeTexture(W),re=W),t.bindTexture(I,se||_e[I]),K.type=I,K.texture=se)}function O(){const I=he[re];I!==void 0&&I.type!==void 0&&(t.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function j(){try{t.compressedTexImage2D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Z(){try{t.compressedTexImage3D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function q(){try{t.texSubImage2D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function xe(){try{t.texSubImage3D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function ae(){try{t.compressedTexSubImage2D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function pe(){try{t.compressedTexSubImage3D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function $e(){try{t.texStorage2D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function ee(){try{t.texStorage3D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function me(){try{t.texImage2D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Ae(){try{t.texImage3D.apply(t,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Ce(I){it.equals(I)===!1&&(t.scissor(I.x,I.y,I.z,I.w),it.copy(I))}function ge(I){Y.equals(I)===!1&&(t.viewport(I.x,I.y,I.z,I.w),Y.copy(I))}function We(I,se){let W=l.get(se);W===void 0&&(W=new WeakMap,l.set(se,W));let K=W.get(I);K===void 0&&(K=t.getUniformBlockIndex(se,I.name),W.set(I,K))}function Ue(I,se){const K=l.get(se).get(I);c.get(se)!==K&&(t.uniformBlockBinding(se,K,I.__bindingPointIndex),c.set(se,K))}function st(){t.disable(t.BLEND),t.disable(t.CULL_FACE),t.disable(t.DEPTH_TEST),t.disable(t.POLYGON_OFFSET_FILL),t.disable(t.SCISSOR_TEST),t.disable(t.STENCIL_TEST),t.disable(t.SAMPLE_ALPHA_TO_COVERAGE),t.blendEquation(t.FUNC_ADD),t.blendFunc(t.ONE,t.ZERO),t.blendFuncSeparate(t.ONE,t.ZERO,t.ONE,t.ZERO),t.blendColor(0,0,0,0),t.colorMask(!0,!0,!0,!0),t.clearColor(0,0,0,0),t.depthMask(!0),t.depthFunc(t.LESS),o.setReversed(!1),t.clearDepth(1),t.stencilMask(4294967295),t.stencilFunc(t.ALWAYS,0,4294967295),t.stencilOp(t.KEEP,t.KEEP,t.KEEP),t.clearStencil(0),t.cullFace(t.BACK),t.frontFace(t.CCW),t.polygonOffset(0,0),t.activeTexture(t.TEXTURE0),t.bindFramebuffer(t.FRAMEBUFFER,null),t.bindFramebuffer(t.DRAW_FRAMEBUFFER,null),t.bindFramebuffer(t.READ_FRAMEBUFFER,null),t.useProgram(null),t.lineWidth(1),t.scissor(0,0,t.canvas.width,t.canvas.height),t.viewport(0,0,t.canvas.width,t.canvas.height),u={},re=null,he={},d={},f=new WeakMap,h=[],p=null,v=!1,g=null,m=null,S=null,_=null,y=null,D=null,E=null,A=new J(0,0,0),P=0,b=!1,x=null,L=null,B=null,F=null,G=null,it.set(0,0,t.canvas.width,t.canvas.height),Y.set(0,0,t.canvas.width,t.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:oe,disable:Re,bindFramebuffer:Le,drawBuffers:Oe,useProgram:ht,setBlending:k,setMaterial:an,setFlipSided:He,setCullFace:Ge,setLineWidth:we,setPolygonOffset:ct,setScissorTest:Ee,activeTexture:R,bindTexture:M,unbindTexture:O,compressedTexImage2D:j,compressedTexImage3D:Z,texImage2D:me,texImage3D:Ae,updateUBOMapping:We,uniformBlockBinding:Ue,texStorage2D:$e,texStorage3D:ee,texSubImage2D:q,texSubImage3D:xe,compressedTexSubImage2D:ae,compressedTexSubImage3D:pe,scissor:Ce,viewport:ge,reset:st}}function th(t,e,n,i){const s=u1(i);switch(n){case rm:return t*e;case am:return t*e;case cm:return t*e*2;case lm:return t*e/s.components*s.byteLength;case Ku:return t*e/s.components*s.byteLength;case um:return t*e*2/s.components*s.byteLength;case Zu:return t*e*2/s.components*s.byteLength;case om:return t*e*3/s.components*s.byteLength;case nn:return t*e*4/s.components*s.byteLength;case Ju:return t*e*4/s.components*s.byteLength;case ua:case da:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*8;case fa:case ha:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*16;case Xl:case Yl:return Math.max(t,16)*Math.max(e,8)/4;case $l:case ql:return Math.max(t,8)*Math.max(e,8)/2;case jl:case Kl:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*8;case Zl:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*16;case Jl:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*16;case Ql:return Math.floor((t+4)/5)*Math.floor((e+3)/4)*16;case eu:return Math.floor((t+4)/5)*Math.floor((e+4)/5)*16;case tu:return Math.floor((t+5)/6)*Math.floor((e+4)/5)*16;case nu:return Math.floor((t+5)/6)*Math.floor((e+5)/6)*16;case iu:return Math.floor((t+7)/8)*Math.floor((e+4)/5)*16;case su:return Math.floor((t+7)/8)*Math.floor((e+5)/6)*16;case ru:return Math.floor((t+7)/8)*Math.floor((e+7)/8)*16;case ou:return Math.floor((t+9)/10)*Math.floor((e+4)/5)*16;case au:return Math.floor((t+9)/10)*Math.floor((e+5)/6)*16;case cu:return Math.floor((t+9)/10)*Math.floor((e+7)/8)*16;case lu:return Math.floor((t+9)/10)*Math.floor((e+9)/10)*16;case uu:return Math.floor((t+11)/12)*Math.floor((e+9)/10)*16;case du:return Math.floor((t+11)/12)*Math.floor((e+11)/12)*16;case pa:case fu:case hu:return Math.ceil(t/4)*Math.ceil(e/4)*16;case dm:case pu:return Math.ceil(t/4)*Math.ceil(e/4)*8;case mu:case gu:return Math.ceil(t/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function u1(t){switch(t){case ri:case nm:return{byteLength:1,components:1};case qr:case im:case to:return{byteLength:2,components:1};case Yu:case ju:return{byteLength:2,components:4};case ns:case qu:case ti:return{byteLength:4,components:1};case sm:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${t}.`)}function d1(t,e,n,i,s,r,o){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new fe,u=new WeakMap;let d;const f=new WeakMap;let h=!1;try{h=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(R,M){return h?new OffscreenCanvas(R,M):wa("canvas")}function v(R,M,O){let j=1;const Z=Ee(R);if((Z.width>O||Z.height>O)&&(j=O/Math.max(Z.width,Z.height)),j<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){const q=Math.floor(j*Z.width),xe=Math.floor(j*Z.height);d===void 0&&(d=p(q,xe));const ae=M?p(q,xe):d;return ae.width=q,ae.height=xe,ae.getContext("2d").drawImage(R,0,0,q,xe),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+Z.width+"x"+Z.height+") to ("+q+"x"+xe+")."),ae}else return"data"in R&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+Z.width+"x"+Z.height+")."),R;return R}function g(R){return R.generateMipmaps}function m(R){t.generateMipmap(R)}function S(R){return R.isWebGLCubeRenderTarget?t.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?t.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?t.TEXTURE_2D_ARRAY:t.TEXTURE_2D}function _(R,M,O,j,Z=!1){if(R!==null){if(t[R]!==void 0)return t[R];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let q=M;if(M===t.RED&&(O===t.FLOAT&&(q=t.R32F),O===t.HALF_FLOAT&&(q=t.R16F),O===t.UNSIGNED_BYTE&&(q=t.R8)),M===t.RED_INTEGER&&(O===t.UNSIGNED_BYTE&&(q=t.R8UI),O===t.UNSIGNED_SHORT&&(q=t.R16UI),O===t.UNSIGNED_INT&&(q=t.R32UI),O===t.BYTE&&(q=t.R8I),O===t.SHORT&&(q=t.R16I),O===t.INT&&(q=t.R32I)),M===t.RG&&(O===t.FLOAT&&(q=t.RG32F),O===t.HALF_FLOAT&&(q=t.RG16F),O===t.UNSIGNED_BYTE&&(q=t.RG8)),M===t.RG_INTEGER&&(O===t.UNSIGNED_BYTE&&(q=t.RG8UI),O===t.UNSIGNED_SHORT&&(q=t.RG16UI),O===t.UNSIGNED_INT&&(q=t.RG32UI),O===t.BYTE&&(q=t.RG8I),O===t.SHORT&&(q=t.RG16I),O===t.INT&&(q=t.RG32I)),M===t.RGB_INTEGER&&(O===t.UNSIGNED_BYTE&&(q=t.RGB8UI),O===t.UNSIGNED_SHORT&&(q=t.RGB16UI),O===t.UNSIGNED_INT&&(q=t.RGB32UI),O===t.BYTE&&(q=t.RGB8I),O===t.SHORT&&(q=t.RGB16I),O===t.INT&&(q=t.RGB32I)),M===t.RGBA_INTEGER&&(O===t.UNSIGNED_BYTE&&(q=t.RGBA8UI),O===t.UNSIGNED_SHORT&&(q=t.RGBA16UI),O===t.UNSIGNED_INT&&(q=t.RGBA32UI),O===t.BYTE&&(q=t.RGBA8I),O===t.SHORT&&(q=t.RGBA16I),O===t.INT&&(q=t.RGBA32I)),M===t.RGB&&O===t.UNSIGNED_INT_5_9_9_9_REV&&(q=t.RGB9_E5),M===t.RGBA){const xe=Z?Ba:Xe.getTransfer(j);O===t.FLOAT&&(q=t.RGBA32F),O===t.HALF_FLOAT&&(q=t.RGBA16F),O===t.UNSIGNED_BYTE&&(q=xe===nt?t.SRGB8_ALPHA8:t.RGBA8),O===t.UNSIGNED_SHORT_4_4_4_4&&(q=t.RGBA4),O===t.UNSIGNED_SHORT_5_5_5_1&&(q=t.RGB5_A1)}return(q===t.R16F||q===t.R32F||q===t.RG16F||q===t.RG32F||q===t.RGBA16F||q===t.RGBA32F)&&e.get("EXT_color_buffer_float"),q}function y(R,M){let O;return R?M===null||M===ns||M===er?O=t.DEPTH24_STENCIL8:M===ti?O=t.DEPTH32F_STENCIL8:M===qr&&(O=t.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):M===null||M===ns||M===er?O=t.DEPTH_COMPONENT24:M===ti?O=t.DEPTH_COMPONENT32F:M===qr&&(O=t.DEPTH_COMPONENT16),O}function D(R,M){return g(R)===!0||R.isFramebufferTexture&&R.minFilter!==Ln&&R.minFilter!==qt?Math.log2(Math.max(M.width,M.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?M.mipmaps.length:1}function E(R){const M=R.target;M.removeEventListener("dispose",E),P(M),M.isVideoTexture&&u.delete(M)}function A(R){const M=R.target;M.removeEventListener("dispose",A),x(M)}function P(R){const M=i.get(R);if(M.__webglInit===void 0)return;const O=R.source,j=f.get(O);if(j){const Z=j[M.__cacheKey];Z.usedTimes--,Z.usedTimes===0&&b(R),Object.keys(j).length===0&&f.delete(O)}i.remove(R)}function b(R){const M=i.get(R);t.deleteTexture(M.__webglTexture);const O=R.source,j=f.get(O);delete j[M.__cacheKey],o.memory.textures--}function x(R){const M=i.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),i.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(M.__webglFramebuffer[j]))for(let Z=0;Z<M.__webglFramebuffer[j].length;Z++)t.deleteFramebuffer(M.__webglFramebuffer[j][Z]);else t.deleteFramebuffer(M.__webglFramebuffer[j]);M.__webglDepthbuffer&&t.deleteRenderbuffer(M.__webglDepthbuffer[j])}else{if(Array.isArray(M.__webglFramebuffer))for(let j=0;j<M.__webglFramebuffer.length;j++)t.deleteFramebuffer(M.__webglFramebuffer[j]);else t.deleteFramebuffer(M.__webglFramebuffer);if(M.__webglDepthbuffer&&t.deleteRenderbuffer(M.__webglDepthbuffer),M.__webglMultisampledFramebuffer&&t.deleteFramebuffer(M.__webglMultisampledFramebuffer),M.__webglColorRenderbuffer)for(let j=0;j<M.__webglColorRenderbuffer.length;j++)M.__webglColorRenderbuffer[j]&&t.deleteRenderbuffer(M.__webglColorRenderbuffer[j]);M.__webglDepthRenderbuffer&&t.deleteRenderbuffer(M.__webglDepthRenderbuffer)}const O=R.textures;for(let j=0,Z=O.length;j<Z;j++){const q=i.get(O[j]);q.__webglTexture&&(t.deleteTexture(q.__webglTexture),o.memory.textures--),i.remove(O[j])}i.remove(R)}let L=0;function B(){L=0}function F(){const R=L;return R>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+s.maxTextures),L+=1,R}function G(R){const M=[];return M.push(R.wrapS),M.push(R.wrapT),M.push(R.wrapR||0),M.push(R.magFilter),M.push(R.minFilter),M.push(R.anisotropy),M.push(R.internalFormat),M.push(R.format),M.push(R.type),M.push(R.generateMipmaps),M.push(R.premultiplyAlpha),M.push(R.flipY),M.push(R.unpackAlignment),M.push(R.colorSpace),M.join()}function $(R,M){const O=i.get(R);if(R.isVideoTexture&&we(R),R.isRenderTargetTexture===!1&&R.version>0&&O.__version!==R.version){const j=R.image;if(j===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(j.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Y(O,R,M);return}}n.bindTexture(t.TEXTURE_2D,O.__webglTexture,t.TEXTURE0+M)}function X(R,M){const O=i.get(R);if(R.version>0&&O.__version!==R.version){Y(O,R,M);return}n.bindTexture(t.TEXTURE_2D_ARRAY,O.__webglTexture,t.TEXTURE0+M)}function Q(R,M){const O=i.get(R);if(R.version>0&&O.__version!==R.version){Y(O,R,M);return}n.bindTexture(t.TEXTURE_3D,O.__webglTexture,t.TEXTURE0+M)}function V(R,M){const O=i.get(R);if(R.version>0&&O.__version!==R.version){ne(O,R,M);return}n.bindTexture(t.TEXTURE_CUBE_MAP,O.__webglTexture,t.TEXTURE0+M)}const re={[Wl]:t.REPEAT,[Ji]:t.CLAMP_TO_EDGE,[Vl]:t.MIRRORED_REPEAT},he={[Ln]:t.NEAREST,[By]:t.NEAREST_MIPMAP_NEAREST,[So]:t.NEAREST_MIPMAP_LINEAR,[qt]:t.LINEAR,[rc]:t.LINEAR_MIPMAP_NEAREST,[Qi]:t.LINEAR_MIPMAP_LINEAR},Me={[Wy]:t.NEVER,[jy]:t.ALWAYS,[Vy]:t.LESS,[hm]:t.LEQUAL,[$y]:t.EQUAL,[Yy]:t.GEQUAL,[Xy]:t.GREATER,[qy]:t.NOTEQUAL};function Fe(R,M){if(M.type===ti&&e.has("OES_texture_float_linear")===!1&&(M.magFilter===qt||M.magFilter===rc||M.magFilter===So||M.magFilter===Qi||M.minFilter===qt||M.minFilter===rc||M.minFilter===So||M.minFilter===Qi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),t.texParameteri(R,t.TEXTURE_WRAP_S,re[M.wrapS]),t.texParameteri(R,t.TEXTURE_WRAP_T,re[M.wrapT]),(R===t.TEXTURE_3D||R===t.TEXTURE_2D_ARRAY)&&t.texParameteri(R,t.TEXTURE_WRAP_R,re[M.wrapR]),t.texParameteri(R,t.TEXTURE_MAG_FILTER,he[M.magFilter]),t.texParameteri(R,t.TEXTURE_MIN_FILTER,he[M.minFilter]),M.compareFunction&&(t.texParameteri(R,t.TEXTURE_COMPARE_MODE,t.COMPARE_REF_TO_TEXTURE),t.texParameteri(R,t.TEXTURE_COMPARE_FUNC,Me[M.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(M.magFilter===Ln||M.minFilter!==So&&M.minFilter!==Qi||M.type===ti&&e.has("OES_texture_float_linear")===!1)return;if(M.anisotropy>1||i.get(M).__currentAnisotropy){const O=e.get("EXT_texture_filter_anisotropic");t.texParameterf(R,O.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,s.getMaxAnisotropy())),i.get(M).__currentAnisotropy=M.anisotropy}}}function it(R,M){let O=!1;R.__webglInit===void 0&&(R.__webglInit=!0,M.addEventListener("dispose",E));const j=M.source;let Z=f.get(j);Z===void 0&&(Z={},f.set(j,Z));const q=G(M);if(q!==R.__cacheKey){Z[q]===void 0&&(Z[q]={texture:t.createTexture(),usedTimes:0},o.memory.textures++,O=!0),Z[q].usedTimes++;const xe=Z[R.__cacheKey];xe!==void 0&&(Z[R.__cacheKey].usedTimes--,xe.usedTimes===0&&b(M)),R.__cacheKey=q,R.__webglTexture=Z[q].texture}return O}function Y(R,M,O){let j=t.TEXTURE_2D;(M.isDataArrayTexture||M.isCompressedArrayTexture)&&(j=t.TEXTURE_2D_ARRAY),M.isData3DTexture&&(j=t.TEXTURE_3D);const Z=it(R,M),q=M.source;n.bindTexture(j,R.__webglTexture,t.TEXTURE0+O);const xe=i.get(q);if(q.version!==xe.__version||Z===!0){n.activeTexture(t.TEXTURE0+O);const ae=Xe.getPrimaries(Xe.workingColorSpace),pe=M.colorSpace===Ei?null:Xe.getPrimaries(M.colorSpace),$e=M.colorSpace===Ei||ae===pe?t.NONE:t.BROWSER_DEFAULT_WEBGL;t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL,M.flipY),t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),t.pixelStorei(t.UNPACK_ALIGNMENT,M.unpackAlignment),t.pixelStorei(t.UNPACK_COLORSPACE_CONVERSION_WEBGL,$e);let ee=v(M.image,!1,s.maxTextureSize);ee=ct(M,ee);const me=r.convert(M.format,M.colorSpace),Ae=r.convert(M.type);let Ce=_(M.internalFormat,me,Ae,M.colorSpace,M.isVideoTexture);Fe(j,M);let ge;const We=M.mipmaps,Ue=M.isVideoTexture!==!0,st=xe.__version===void 0||Z===!0,I=q.dataReady,se=D(M,ee);if(M.isDepthTexture)Ce=y(M.format===tr,M.type),st&&(Ue?n.texStorage2D(t.TEXTURE_2D,1,Ce,ee.width,ee.height):n.texImage2D(t.TEXTURE_2D,0,Ce,ee.width,ee.height,0,me,Ae,null));else if(M.isDataTexture)if(We.length>0){Ue&&st&&n.texStorage2D(t.TEXTURE_2D,se,Ce,We[0].width,We[0].height);for(let W=0,K=We.length;W<K;W++)ge=We[W],Ue?I&&n.texSubImage2D(t.TEXTURE_2D,W,0,0,ge.width,ge.height,me,Ae,ge.data):n.texImage2D(t.TEXTURE_2D,W,Ce,ge.width,ge.height,0,me,Ae,ge.data);M.generateMipmaps=!1}else Ue?(st&&n.texStorage2D(t.TEXTURE_2D,se,Ce,ee.width,ee.height),I&&n.texSubImage2D(t.TEXTURE_2D,0,0,0,ee.width,ee.height,me,Ae,ee.data)):n.texImage2D(t.TEXTURE_2D,0,Ce,ee.width,ee.height,0,me,Ae,ee.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){Ue&&st&&n.texStorage3D(t.TEXTURE_2D_ARRAY,se,Ce,We[0].width,We[0].height,ee.depth);for(let W=0,K=We.length;W<K;W++)if(ge=We[W],M.format!==nn)if(me!==null)if(Ue){if(I)if(M.layerUpdates.size>0){const ue=th(ge.width,ge.height,M.format,M.type);for(const ce of M.layerUpdates){const De=ge.data.subarray(ce*ue/ge.data.BYTES_PER_ELEMENT,(ce+1)*ue/ge.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(t.TEXTURE_2D_ARRAY,W,0,0,ce,ge.width,ge.height,1,me,De)}M.clearLayerUpdates()}else n.compressedTexSubImage3D(t.TEXTURE_2D_ARRAY,W,0,0,0,ge.width,ge.height,ee.depth,me,ge.data)}else n.compressedTexImage3D(t.TEXTURE_2D_ARRAY,W,Ce,ge.width,ge.height,ee.depth,0,ge.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Ue?I&&n.texSubImage3D(t.TEXTURE_2D_ARRAY,W,0,0,0,ge.width,ge.height,ee.depth,me,Ae,ge.data):n.texImage3D(t.TEXTURE_2D_ARRAY,W,Ce,ge.width,ge.height,ee.depth,0,me,Ae,ge.data)}else{Ue&&st&&n.texStorage2D(t.TEXTURE_2D,se,Ce,We[0].width,We[0].height);for(let W=0,K=We.length;W<K;W++)ge=We[W],M.format!==nn?me!==null?Ue?I&&n.compressedTexSubImage2D(t.TEXTURE_2D,W,0,0,ge.width,ge.height,me,ge.data):n.compressedTexImage2D(t.TEXTURE_2D,W,Ce,ge.width,ge.height,0,ge.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Ue?I&&n.texSubImage2D(t.TEXTURE_2D,W,0,0,ge.width,ge.height,me,Ae,ge.data):n.texImage2D(t.TEXTURE_2D,W,Ce,ge.width,ge.height,0,me,Ae,ge.data)}else if(M.isDataArrayTexture)if(Ue){if(st&&n.texStorage3D(t.TEXTURE_2D_ARRAY,se,Ce,ee.width,ee.height,ee.depth),I)if(M.layerUpdates.size>0){const W=th(ee.width,ee.height,M.format,M.type);for(const K of M.layerUpdates){const ue=ee.data.subarray(K*W/ee.data.BYTES_PER_ELEMENT,(K+1)*W/ee.data.BYTES_PER_ELEMENT);n.texSubImage3D(t.TEXTURE_2D_ARRAY,0,0,0,K,ee.width,ee.height,1,me,Ae,ue)}M.clearLayerUpdates()}else n.texSubImage3D(t.TEXTURE_2D_ARRAY,0,0,0,0,ee.width,ee.height,ee.depth,me,Ae,ee.data)}else n.texImage3D(t.TEXTURE_2D_ARRAY,0,Ce,ee.width,ee.height,ee.depth,0,me,Ae,ee.data);else if(M.isData3DTexture)Ue?(st&&n.texStorage3D(t.TEXTURE_3D,se,Ce,ee.width,ee.height,ee.depth),I&&n.texSubImage3D(t.TEXTURE_3D,0,0,0,0,ee.width,ee.height,ee.depth,me,Ae,ee.data)):n.texImage3D(t.TEXTURE_3D,0,Ce,ee.width,ee.height,ee.depth,0,me,Ae,ee.data);else if(M.isFramebufferTexture){if(st)if(Ue)n.texStorage2D(t.TEXTURE_2D,se,Ce,ee.width,ee.height);else{let W=ee.width,K=ee.height;for(let ue=0;ue<se;ue++)n.texImage2D(t.TEXTURE_2D,ue,Ce,W,K,0,me,Ae,null),W>>=1,K>>=1}}else if(We.length>0){if(Ue&&st){const W=Ee(We[0]);n.texStorage2D(t.TEXTURE_2D,se,Ce,W.width,W.height)}for(let W=0,K=We.length;W<K;W++)ge=We[W],Ue?I&&n.texSubImage2D(t.TEXTURE_2D,W,0,0,me,Ae,ge):n.texImage2D(t.TEXTURE_2D,W,Ce,me,Ae,ge);M.generateMipmaps=!1}else if(Ue){if(st){const W=Ee(ee);n.texStorage2D(t.TEXTURE_2D,se,Ce,W.width,W.height)}I&&n.texSubImage2D(t.TEXTURE_2D,0,0,0,me,Ae,ee)}else n.texImage2D(t.TEXTURE_2D,0,Ce,me,Ae,ee);g(M)&&m(j),xe.__version=q.version,M.onUpdate&&M.onUpdate(M)}R.__version=M.version}function ne(R,M,O){if(M.image.length!==6)return;const j=it(R,M),Z=M.source;n.bindTexture(t.TEXTURE_CUBE_MAP,R.__webglTexture,t.TEXTURE0+O);const q=i.get(Z);if(Z.version!==q.__version||j===!0){n.activeTexture(t.TEXTURE0+O);const xe=Xe.getPrimaries(Xe.workingColorSpace),ae=M.colorSpace===Ei?null:Xe.getPrimaries(M.colorSpace),pe=M.colorSpace===Ei||xe===ae?t.NONE:t.BROWSER_DEFAULT_WEBGL;t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL,M.flipY),t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),t.pixelStorei(t.UNPACK_ALIGNMENT,M.unpackAlignment),t.pixelStorei(t.UNPACK_COLORSPACE_CONVERSION_WEBGL,pe);const $e=M.isCompressedTexture||M.image[0].isCompressedTexture,ee=M.image[0]&&M.image[0].isDataTexture,me=[];for(let K=0;K<6;K++)!$e&&!ee?me[K]=v(M.image[K],!0,s.maxCubemapSize):me[K]=ee?M.image[K].image:M.image[K],me[K]=ct(M,me[K]);const Ae=me[0],Ce=r.convert(M.format,M.colorSpace),ge=r.convert(M.type),We=_(M.internalFormat,Ce,ge,M.colorSpace),Ue=M.isVideoTexture!==!0,st=q.__version===void 0||j===!0,I=Z.dataReady;let se=D(M,Ae);Fe(t.TEXTURE_CUBE_MAP,M);let W;if($e){Ue&&st&&n.texStorage2D(t.TEXTURE_CUBE_MAP,se,We,Ae.width,Ae.height);for(let K=0;K<6;K++){W=me[K].mipmaps;for(let ue=0;ue<W.length;ue++){const ce=W[ue];M.format!==nn?Ce!==null?Ue?I&&n.compressedTexSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue,0,0,ce.width,ce.height,Ce,ce.data):n.compressedTexImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue,We,ce.width,ce.height,0,ce.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ue?I&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue,0,0,ce.width,ce.height,Ce,ge,ce.data):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue,We,ce.width,ce.height,0,Ce,ge,ce.data)}}}else{if(W=M.mipmaps,Ue&&st){W.length>0&&se++;const K=Ee(me[0]);n.texStorage2D(t.TEXTURE_CUBE_MAP,se,We,K.width,K.height)}for(let K=0;K<6;K++)if(ee){Ue?I&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,0,0,me[K].width,me[K].height,Ce,ge,me[K].data):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,We,me[K].width,me[K].height,0,Ce,ge,me[K].data);for(let ue=0;ue<W.length;ue++){const De=W[ue].image[K].image;Ue?I&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue+1,0,0,De.width,De.height,Ce,ge,De.data):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue+1,We,De.width,De.height,0,Ce,ge,De.data)}}else{Ue?I&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,0,0,Ce,ge,me[K]):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,We,Ce,ge,me[K]);for(let ue=0;ue<W.length;ue++){const ce=W[ue];Ue?I&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue+1,0,0,Ce,ge,ce.image[K]):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+K,ue+1,We,Ce,ge,ce.image[K])}}}g(M)&&m(t.TEXTURE_CUBE_MAP),q.__version=Z.version,M.onUpdate&&M.onUpdate(M)}R.__version=M.version}function _e(R,M,O,j,Z,q){const xe=r.convert(O.format,O.colorSpace),ae=r.convert(O.type),pe=_(O.internalFormat,xe,ae,O.colorSpace),$e=i.get(M),ee=i.get(O);if(ee.__renderTarget=M,!$e.__hasExternalTextures){const me=Math.max(1,M.width>>q),Ae=Math.max(1,M.height>>q);Z===t.TEXTURE_3D||Z===t.TEXTURE_2D_ARRAY?n.texImage3D(Z,q,pe,me,Ae,M.depth,0,xe,ae,null):n.texImage2D(Z,q,pe,me,Ae,0,xe,ae,null)}n.bindFramebuffer(t.FRAMEBUFFER,R),Ge(M)?a.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER,j,Z,ee.__webglTexture,0,He(M)):(Z===t.TEXTURE_2D||Z>=t.TEXTURE_CUBE_MAP_POSITIVE_X&&Z<=t.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&t.framebufferTexture2D(t.FRAMEBUFFER,j,Z,ee.__webglTexture,q),n.bindFramebuffer(t.FRAMEBUFFER,null)}function oe(R,M,O){if(t.bindRenderbuffer(t.RENDERBUFFER,R),M.depthBuffer){const j=M.depthTexture,Z=j&&j.isDepthTexture?j.type:null,q=y(M.stencilBuffer,Z),xe=M.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT,ae=He(M);Ge(M)?a.renderbufferStorageMultisampleEXT(t.RENDERBUFFER,ae,q,M.width,M.height):O?t.renderbufferStorageMultisample(t.RENDERBUFFER,ae,q,M.width,M.height):t.renderbufferStorage(t.RENDERBUFFER,q,M.width,M.height),t.framebufferRenderbuffer(t.FRAMEBUFFER,xe,t.RENDERBUFFER,R)}else{const j=M.textures;for(let Z=0;Z<j.length;Z++){const q=j[Z],xe=r.convert(q.format,q.colorSpace),ae=r.convert(q.type),pe=_(q.internalFormat,xe,ae,q.colorSpace),$e=He(M);O&&Ge(M)===!1?t.renderbufferStorageMultisample(t.RENDERBUFFER,$e,pe,M.width,M.height):Ge(M)?a.renderbufferStorageMultisampleEXT(t.RENDERBUFFER,$e,pe,M.width,M.height):t.renderbufferStorage(t.RENDERBUFFER,pe,M.width,M.height)}}t.bindRenderbuffer(t.RENDERBUFFER,null)}function Re(R,M){if(M&&M.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(n.bindFramebuffer(t.FRAMEBUFFER,R),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const j=i.get(M.depthTexture);j.__renderTarget=M,(!j.__webglTexture||M.depthTexture.image.width!==M.width||M.depthTexture.image.height!==M.height)&&(M.depthTexture.image.width=M.width,M.depthTexture.image.height=M.height,M.depthTexture.needsUpdate=!0),$(M.depthTexture,0);const Z=j.__webglTexture,q=He(M);if(M.depthTexture.format===$s)Ge(M)?a.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER,t.DEPTH_ATTACHMENT,t.TEXTURE_2D,Z,0,q):t.framebufferTexture2D(t.FRAMEBUFFER,t.DEPTH_ATTACHMENT,t.TEXTURE_2D,Z,0);else if(M.depthTexture.format===tr)Ge(M)?a.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER,t.DEPTH_STENCIL_ATTACHMENT,t.TEXTURE_2D,Z,0,q):t.framebufferTexture2D(t.FRAMEBUFFER,t.DEPTH_STENCIL_ATTACHMENT,t.TEXTURE_2D,Z,0);else throw new Error("Unknown depthTexture format")}function Le(R){const M=i.get(R),O=R.isWebGLCubeRenderTarget===!0;if(M.__boundDepthTexture!==R.depthTexture){const j=R.depthTexture;if(M.__depthDisposeCallback&&M.__depthDisposeCallback(),j){const Z=()=>{delete M.__boundDepthTexture,delete M.__depthDisposeCallback,j.removeEventListener("dispose",Z)};j.addEventListener("dispose",Z),M.__depthDisposeCallback=Z}M.__boundDepthTexture=j}if(R.depthTexture&&!M.__autoAllocateDepthBuffer){if(O)throw new Error("target.depthTexture not supported in Cube render targets");Re(M.__webglFramebuffer,R)}else if(O){M.__webglDepthbuffer=[];for(let j=0;j<6;j++)if(n.bindFramebuffer(t.FRAMEBUFFER,M.__webglFramebuffer[j]),M.__webglDepthbuffer[j]===void 0)M.__webglDepthbuffer[j]=t.createRenderbuffer(),oe(M.__webglDepthbuffer[j],R,!1);else{const Z=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT,q=M.__webglDepthbuffer[j];t.bindRenderbuffer(t.RENDERBUFFER,q),t.framebufferRenderbuffer(t.FRAMEBUFFER,Z,t.RENDERBUFFER,q)}}else if(n.bindFramebuffer(t.FRAMEBUFFER,M.__webglFramebuffer),M.__webglDepthbuffer===void 0)M.__webglDepthbuffer=t.createRenderbuffer(),oe(M.__webglDepthbuffer,R,!1);else{const j=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT,Z=M.__webglDepthbuffer;t.bindRenderbuffer(t.RENDERBUFFER,Z),t.framebufferRenderbuffer(t.FRAMEBUFFER,j,t.RENDERBUFFER,Z)}n.bindFramebuffer(t.FRAMEBUFFER,null)}function Oe(R,M,O){const j=i.get(R);M!==void 0&&_e(j.__webglFramebuffer,R,R.texture,t.COLOR_ATTACHMENT0,t.TEXTURE_2D,0),O!==void 0&&Le(R)}function ht(R){const M=R.texture,O=i.get(R),j=i.get(M);R.addEventListener("dispose",A);const Z=R.textures,q=R.isWebGLCubeRenderTarget===!0,xe=Z.length>1;if(xe||(j.__webglTexture===void 0&&(j.__webglTexture=t.createTexture()),j.__version=M.version,o.memory.textures++),q){O.__webglFramebuffer=[];for(let ae=0;ae<6;ae++)if(M.mipmaps&&M.mipmaps.length>0){O.__webglFramebuffer[ae]=[];for(let pe=0;pe<M.mipmaps.length;pe++)O.__webglFramebuffer[ae][pe]=t.createFramebuffer()}else O.__webglFramebuffer[ae]=t.createFramebuffer()}else{if(M.mipmaps&&M.mipmaps.length>0){O.__webglFramebuffer=[];for(let ae=0;ae<M.mipmaps.length;ae++)O.__webglFramebuffer[ae]=t.createFramebuffer()}else O.__webglFramebuffer=t.createFramebuffer();if(xe)for(let ae=0,pe=Z.length;ae<pe;ae++){const $e=i.get(Z[ae]);$e.__webglTexture===void 0&&($e.__webglTexture=t.createTexture(),o.memory.textures++)}if(R.samples>0&&Ge(R)===!1){O.__webglMultisampledFramebuffer=t.createFramebuffer(),O.__webglColorRenderbuffer=[],n.bindFramebuffer(t.FRAMEBUFFER,O.__webglMultisampledFramebuffer);for(let ae=0;ae<Z.length;ae++){const pe=Z[ae];O.__webglColorRenderbuffer[ae]=t.createRenderbuffer(),t.bindRenderbuffer(t.RENDERBUFFER,O.__webglColorRenderbuffer[ae]);const $e=r.convert(pe.format,pe.colorSpace),ee=r.convert(pe.type),me=_(pe.internalFormat,$e,ee,pe.colorSpace,R.isXRRenderTarget===!0),Ae=He(R);t.renderbufferStorageMultisample(t.RENDERBUFFER,Ae,me,R.width,R.height),t.framebufferRenderbuffer(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0+ae,t.RENDERBUFFER,O.__webglColorRenderbuffer[ae])}t.bindRenderbuffer(t.RENDERBUFFER,null),R.depthBuffer&&(O.__webglDepthRenderbuffer=t.createRenderbuffer(),oe(O.__webglDepthRenderbuffer,R,!0)),n.bindFramebuffer(t.FRAMEBUFFER,null)}}if(q){n.bindTexture(t.TEXTURE_CUBE_MAP,j.__webglTexture),Fe(t.TEXTURE_CUBE_MAP,M);for(let ae=0;ae<6;ae++)if(M.mipmaps&&M.mipmaps.length>0)for(let pe=0;pe<M.mipmaps.length;pe++)_e(O.__webglFramebuffer[ae][pe],R,M,t.COLOR_ATTACHMENT0,t.TEXTURE_CUBE_MAP_POSITIVE_X+ae,pe);else _e(O.__webglFramebuffer[ae],R,M,t.COLOR_ATTACHMENT0,t.TEXTURE_CUBE_MAP_POSITIVE_X+ae,0);g(M)&&m(t.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(xe){for(let ae=0,pe=Z.length;ae<pe;ae++){const $e=Z[ae],ee=i.get($e);n.bindTexture(t.TEXTURE_2D,ee.__webglTexture),Fe(t.TEXTURE_2D,$e),_e(O.__webglFramebuffer,R,$e,t.COLOR_ATTACHMENT0+ae,t.TEXTURE_2D,0),g($e)&&m(t.TEXTURE_2D)}n.unbindTexture()}else{let ae=t.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(ae=R.isWebGL3DRenderTarget?t.TEXTURE_3D:t.TEXTURE_2D_ARRAY),n.bindTexture(ae,j.__webglTexture),Fe(ae,M),M.mipmaps&&M.mipmaps.length>0)for(let pe=0;pe<M.mipmaps.length;pe++)_e(O.__webglFramebuffer[pe],R,M,t.COLOR_ATTACHMENT0,ae,pe);else _e(O.__webglFramebuffer,R,M,t.COLOR_ATTACHMENT0,ae,0);g(M)&&m(ae),n.unbindTexture()}R.depthBuffer&&Le(R)}function Ve(R){const M=R.textures;for(let O=0,j=M.length;O<j;O++){const Z=M[O];if(g(Z)){const q=S(R),xe=i.get(Z).__webglTexture;n.bindTexture(q,xe),m(q),n.unbindTexture()}}}const yt=[],k=[];function an(R){if(R.samples>0){if(Ge(R)===!1){const M=R.textures,O=R.width,j=R.height;let Z=t.COLOR_BUFFER_BIT;const q=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT,xe=i.get(R),ae=M.length>1;if(ae)for(let pe=0;pe<M.length;pe++)n.bindFramebuffer(t.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),t.framebufferRenderbuffer(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0+pe,t.RENDERBUFFER,null),n.bindFramebuffer(t.FRAMEBUFFER,xe.__webglFramebuffer),t.framebufferTexture2D(t.DRAW_FRAMEBUFFER,t.COLOR_ATTACHMENT0+pe,t.TEXTURE_2D,null,0);n.bindFramebuffer(t.READ_FRAMEBUFFER,xe.__webglMultisampledFramebuffer),n.bindFramebuffer(t.DRAW_FRAMEBUFFER,xe.__webglFramebuffer);for(let pe=0;pe<M.length;pe++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(Z|=t.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(Z|=t.STENCIL_BUFFER_BIT)),ae){t.framebufferRenderbuffer(t.READ_FRAMEBUFFER,t.COLOR_ATTACHMENT0,t.RENDERBUFFER,xe.__webglColorRenderbuffer[pe]);const $e=i.get(M[pe]).__webglTexture;t.framebufferTexture2D(t.DRAW_FRAMEBUFFER,t.COLOR_ATTACHMENT0,t.TEXTURE_2D,$e,0)}t.blitFramebuffer(0,0,O,j,0,0,O,j,Z,t.NEAREST),c===!0&&(yt.length=0,k.length=0,yt.push(t.COLOR_ATTACHMENT0+pe),R.depthBuffer&&R.resolveDepthBuffer===!1&&(yt.push(q),k.push(q),t.invalidateFramebuffer(t.DRAW_FRAMEBUFFER,k)),t.invalidateFramebuffer(t.READ_FRAMEBUFFER,yt))}if(n.bindFramebuffer(t.READ_FRAMEBUFFER,null),n.bindFramebuffer(t.DRAW_FRAMEBUFFER,null),ae)for(let pe=0;pe<M.length;pe++){n.bindFramebuffer(t.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),t.framebufferRenderbuffer(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0+pe,t.RENDERBUFFER,xe.__webglColorRenderbuffer[pe]);const $e=i.get(M[pe]).__webglTexture;n.bindFramebuffer(t.FRAMEBUFFER,xe.__webglFramebuffer),t.framebufferTexture2D(t.DRAW_FRAMEBUFFER,t.COLOR_ATTACHMENT0+pe,t.TEXTURE_2D,$e,0)}n.bindFramebuffer(t.DRAW_FRAMEBUFFER,xe.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.resolveDepthBuffer===!1&&c){const M=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT;t.invalidateFramebuffer(t.DRAW_FRAMEBUFFER,[M])}}}function He(R){return Math.min(s.maxSamples,R.samples)}function Ge(R){const M=i.get(R);return R.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function we(R){const M=o.render.frame;u.get(R)!==M&&(u.set(R,M),R.update())}function ct(R,M){const O=R.colorSpace,j=R.format,Z=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||O!==ur&&O!==Ei&&(Xe.getTransfer(O)===nt?(j!==nn||Z!==ri)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",O)),M}function Ee(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(l.width=R.naturalWidth||R.width,l.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(l.width=R.displayWidth,l.height=R.displayHeight):(l.width=R.width,l.height=R.height),l}this.allocateTextureUnit=F,this.resetTextureUnits=B,this.setTexture2D=$,this.setTexture2DArray=X,this.setTexture3D=Q,this.setTextureCube=V,this.rebindTextures=Oe,this.setupRenderTarget=ht,this.updateRenderTargetMipmap=Ve,this.updateMultisampleRenderTarget=an,this.setupDepthRenderbuffer=Le,this.setupFrameBufferTexture=_e,this.useMultisampledRTT=Ge}function f1(t,e){function n(i,s=Ei){let r;const o=Xe.getTransfer(s);if(i===ri)return t.UNSIGNED_BYTE;if(i===Yu)return t.UNSIGNED_SHORT_4_4_4_4;if(i===ju)return t.UNSIGNED_SHORT_5_5_5_1;if(i===sm)return t.UNSIGNED_INT_5_9_9_9_REV;if(i===nm)return t.BYTE;if(i===im)return t.SHORT;if(i===qr)return t.UNSIGNED_SHORT;if(i===qu)return t.INT;if(i===ns)return t.UNSIGNED_INT;if(i===ti)return t.FLOAT;if(i===to)return t.HALF_FLOAT;if(i===rm)return t.ALPHA;if(i===om)return t.RGB;if(i===nn)return t.RGBA;if(i===am)return t.LUMINANCE;if(i===cm)return t.LUMINANCE_ALPHA;if(i===$s)return t.DEPTH_COMPONENT;if(i===tr)return t.DEPTH_STENCIL;if(i===lm)return t.RED;if(i===Ku)return t.RED_INTEGER;if(i===um)return t.RG;if(i===Zu)return t.RG_INTEGER;if(i===Ju)return t.RGBA_INTEGER;if(i===ua||i===da||i===fa||i===ha)if(o===nt)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(i===ua)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===da)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===fa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===ha)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(i===ua)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===da)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===fa)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===ha)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===$l||i===Xl||i===ql||i===Yl)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(i===$l)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===Xl)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===ql)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===Yl)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===jl||i===Kl||i===Zl)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(i===jl||i===Kl)return o===nt?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(i===Zl)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(i===Jl||i===Ql||i===eu||i===tu||i===nu||i===iu||i===su||i===ru||i===ou||i===au||i===cu||i===lu||i===uu||i===du)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(i===Jl)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===Ql)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===eu)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===tu)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===nu)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===iu)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===su)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===ru)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===ou)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===au)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===cu)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===lu)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===uu)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===du)return o===nt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===pa||i===fu||i===hu)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(i===pa)return o===nt?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===fu)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===hu)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===dm||i===pu||i===mu||i===gu)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(i===pa)return r.COMPRESSED_RED_RGTC1_EXT;if(i===pu)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===mu)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===gu)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===er?t.UNSIGNED_INT_24_8:t[i]!==void 0?t[i]:null}return{convert:n}}class h1 extends $t{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class zs extends Nt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const p1={type:"move"};class Dc{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new zs,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new zs,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new T,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new T),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new zs,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new T,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new T),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const n=this._hand;if(n)for(const i of e.hand.values())this._getHandJoint(n,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,n,i){let s=null,r=null,o=null;const a=this._targetRay,c=this._grip,l=this._hand;if(e&&n.session.visibilityState!=="visible-blurred"){if(l&&e.hand){o=!0;for(const v of e.hand.values()){const g=n.getJointPose(v,i),m=this._getHandJoint(l,v);g!==null&&(m.matrix.fromArray(g.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=g.radius),m.visible=g!==null}const u=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],f=u.position.distanceTo(d.position),h=.02,p=.005;l.inputState.pinching&&f>h+p?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&f<=h-p&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(r=n.getPose(e.gripSpace,i),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));a!==null&&(s=n.getPose(e.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(p1)))}return a!==null&&(a.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=o!==null),this}_getHandJoint(e,n){if(e.joints[n.jointName]===void 0){const i=new zs;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[n.jointName]=i,e.add(i)}return e.joints[n.jointName]}}const m1=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,g1=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class v1{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,n,i){if(this.texture===null){const s=new Yt,r=e.properties.get(s);r.__webglTexture=n.texture,(n.depthNear!=i.depthNear||n.depthFar!=i.depthFar)&&(this.depthNear=n.depthNear,this.depthFar=n.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){const n=e.cameras[0].viewport,i=new vn({vertexShader:m1,fragmentShader:g1,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new Ye(new za(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class y1 extends dr{constructor(e,n){super();const i=this;let s=null,r=1,o=null,a="local-floor",c=1,l=null,u=null,d=null,f=null,h=null,p=null;const v=new v1,g=n.getContextAttributes();let m=null,S=null;const _=[],y=[],D=new fe;let E=null;const A=new $t;A.viewport=new qe;const P=new $t;P.viewport=new qe;const b=[A,P],x=new h1;let L=null,B=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let ne=_[Y];return ne===void 0&&(ne=new Dc,_[Y]=ne),ne.getTargetRaySpace()},this.getControllerGrip=function(Y){let ne=_[Y];return ne===void 0&&(ne=new Dc,_[Y]=ne),ne.getGripSpace()},this.getHand=function(Y){let ne=_[Y];return ne===void 0&&(ne=new Dc,_[Y]=ne),ne.getHandSpace()};function F(Y){const ne=y.indexOf(Y.inputSource);if(ne===-1)return;const _e=_[ne];_e!==void 0&&(_e.update(Y.inputSource,Y.frame,l||o),_e.dispatchEvent({type:Y.type,data:Y.inputSource}))}function G(){s.removeEventListener("select",F),s.removeEventListener("selectstart",F),s.removeEventListener("selectend",F),s.removeEventListener("squeeze",F),s.removeEventListener("squeezestart",F),s.removeEventListener("squeezeend",F),s.removeEventListener("end",G),s.removeEventListener("inputsourceschange",$);for(let Y=0;Y<_.length;Y++){const ne=y[Y];ne!==null&&(y[Y]=null,_[Y].disconnect(ne))}L=null,B=null,v.reset(),e.setRenderTarget(m),h=null,f=null,d=null,s=null,S=null,it.stop(),i.isPresenting=!1,e.setPixelRatio(E),e.setSize(D.width,D.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){r=Y,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){a=Y,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||o},this.setReferenceSpace=function(Y){l=Y},this.getBaseLayer=function(){return f!==null?f:h},this.getBinding=function(){return d},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function(Y){if(s=Y,s!==null){if(m=e.getRenderTarget(),s.addEventListener("select",F),s.addEventListener("selectstart",F),s.addEventListener("selectend",F),s.addEventListener("squeeze",F),s.addEventListener("squeezestart",F),s.addEventListener("squeezeend",F),s.addEventListener("end",G),s.addEventListener("inputsourceschange",$),g.xrCompatible!==!0&&await n.makeXRCompatible(),E=e.getPixelRatio(),e.getSize(D),s.renderState.layers===void 0){const ne={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:r};h=new XRWebGLLayer(s,n,ne),s.updateRenderState({baseLayer:h}),e.setPixelRatio(1),e.setSize(h.framebufferWidth,h.framebufferHeight,!1),S=new Ui(h.framebufferWidth,h.framebufferHeight,{format:nn,type:ri,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil})}else{let ne=null,_e=null,oe=null;g.depth&&(oe=g.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,ne=g.stencil?tr:$s,_e=g.stencil?er:ns);const Re={colorFormat:n.RGBA8,depthFormat:oe,scaleFactor:r};d=new XRWebGLBinding(s,n),f=d.createProjectionLayer(Re),s.updateRenderState({layers:[f]}),e.setPixelRatio(1),e.setSize(f.textureWidth,f.textureHeight,!1),S=new Ui(f.textureWidth,f.textureHeight,{format:nn,type:ri,depthTexture:new Cm(f.textureWidth,f.textureHeight,_e,void 0,void 0,void 0,void 0,void 0,void 0,ne),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1})}S.isXRRenderTarget=!0,this.setFoveation(c),l=null,o=await s.requestReferenceSpace(a),it.setContext(s),it.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};function $(Y){for(let ne=0;ne<Y.removed.length;ne++){const _e=Y.removed[ne],oe=y.indexOf(_e);oe>=0&&(y[oe]=null,_[oe].disconnect(_e))}for(let ne=0;ne<Y.added.length;ne++){const _e=Y.added[ne];let oe=y.indexOf(_e);if(oe===-1){for(let Le=0;Le<_.length;Le++)if(Le>=y.length){y.push(_e),oe=Le;break}else if(y[Le]===null){y[Le]=_e,oe=Le;break}if(oe===-1)break}const Re=_[oe];Re&&Re.connect(_e)}}const X=new T,Q=new T;function V(Y,ne,_e){X.setFromMatrixPosition(ne.matrixWorld),Q.setFromMatrixPosition(_e.matrixWorld);const oe=X.distanceTo(Q),Re=ne.projectionMatrix.elements,Le=_e.projectionMatrix.elements,Oe=Re[14]/(Re[10]-1),ht=Re[14]/(Re[10]+1),Ve=(Re[9]+1)/Re[5],yt=(Re[9]-1)/Re[5],k=(Re[8]-1)/Re[0],an=(Le[8]+1)/Le[0],He=Oe*k,Ge=Oe*an,we=oe/(-k+an),ct=we*-k;if(ne.matrixWorld.decompose(Y.position,Y.quaternion,Y.scale),Y.translateX(ct),Y.translateZ(we),Y.matrixWorld.compose(Y.position,Y.quaternion,Y.scale),Y.matrixWorldInverse.copy(Y.matrixWorld).invert(),Re[10]===-1)Y.projectionMatrix.copy(ne.projectionMatrix),Y.projectionMatrixInverse.copy(ne.projectionMatrixInverse);else{const Ee=Oe+we,R=ht+we,M=He-ct,O=Ge+(oe-ct),j=Ve*ht/R*Ee,Z=yt*ht/R*Ee;Y.projectionMatrix.makePerspective(M,O,j,Z,Ee,R),Y.projectionMatrixInverse.copy(Y.projectionMatrix).invert()}}function re(Y,ne){ne===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(ne.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(s===null)return;let ne=Y.near,_e=Y.far;v.texture!==null&&(v.depthNear>0&&(ne=v.depthNear),v.depthFar>0&&(_e=v.depthFar)),x.near=P.near=A.near=ne,x.far=P.far=A.far=_e,(L!==x.near||B!==x.far)&&(s.updateRenderState({depthNear:x.near,depthFar:x.far}),L=x.near,B=x.far),A.layers.mask=Y.layers.mask|2,P.layers.mask=Y.layers.mask|4,x.layers.mask=A.layers.mask|P.layers.mask;const oe=Y.parent,Re=x.cameras;re(x,oe);for(let Le=0;Le<Re.length;Le++)re(Re[Le],oe);Re.length===2?V(x,A,P):x.projectionMatrix.copy(A.projectionMatrix),he(Y,x,oe)};function he(Y,ne,_e){_e===null?Y.matrix.copy(ne.matrixWorld):(Y.matrix.copy(_e.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(ne.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(ne.projectionMatrix),Y.projectionMatrixInverse.copy(ne.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=Yr*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return x},this.getFoveation=function(){if(!(f===null&&h===null))return c},this.setFoveation=function(Y){c=Y,f!==null&&(f.fixedFoveation=Y),h!==null&&h.fixedFoveation!==void 0&&(h.fixedFoveation=Y)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(x)};let Me=null;function Fe(Y,ne){if(u=ne.getViewerPose(l||o),p=ne,u!==null){const _e=u.views;h!==null&&(e.setRenderTargetFramebuffer(S,h.framebuffer),e.setRenderTarget(S));let oe=!1;_e.length!==x.cameras.length&&(x.cameras.length=0,oe=!0);for(let Le=0;Le<_e.length;Le++){const Oe=_e[Le];let ht=null;if(h!==null)ht=h.getViewport(Oe);else{const yt=d.getViewSubImage(f,Oe);ht=yt.viewport,Le===0&&(e.setRenderTargetTextures(S,yt.colorTexture,f.ignoreDepthValues?void 0:yt.depthStencilTexture),e.setRenderTarget(S))}let Ve=b[Le];Ve===void 0&&(Ve=new $t,Ve.layers.enable(Le),Ve.viewport=new qe,b[Le]=Ve),Ve.matrix.fromArray(Oe.transform.matrix),Ve.matrix.decompose(Ve.position,Ve.quaternion,Ve.scale),Ve.projectionMatrix.fromArray(Oe.projectionMatrix),Ve.projectionMatrixInverse.copy(Ve.projectionMatrix).invert(),Ve.viewport.set(ht.x,ht.y,ht.width,ht.height),Le===0&&(x.matrix.copy(Ve.matrix),x.matrix.decompose(x.position,x.quaternion,x.scale)),oe===!0&&x.cameras.push(Ve)}const Re=s.enabledFeatures;if(Re&&Re.includes("depth-sensing")){const Le=d.getDepthInformation(_e[0]);Le&&Le.isValid&&Le.texture&&v.init(e,Le,s.renderState)}}for(let _e=0;_e<_.length;_e++){const oe=y[_e],Re=_[_e];oe!==null&&Re!==void 0&&Re.update(oe,ne,l||o)}Me&&Me(Y,ne),ne.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:ne}),p=null}const it=new Am;it.setAnimationLoop(Fe),this.setAnimationLoop=function(Y){Me=Y},this.dispose=function(){}}}const Vi=new Dn,S1=new Qe;function _1(t,e){function n(g,m){g.matrixAutoUpdate===!0&&g.updateMatrix(),m.value.copy(g.matrix)}function i(g,m){m.color.getRGB(g.fogColor.value,bm(t)),m.isFog?(g.fogNear.value=m.near,g.fogFar.value=m.far):m.isFogExp2&&(g.fogDensity.value=m.density)}function s(g,m,S,_,y){m.isMeshBasicMaterial||m.isMeshLambertMaterial?r(g,m):m.isMeshToonMaterial?(r(g,m),d(g,m)):m.isMeshPhongMaterial?(r(g,m),u(g,m)):m.isMeshStandardMaterial?(r(g,m),f(g,m),m.isMeshPhysicalMaterial&&h(g,m,y)):m.isMeshMatcapMaterial?(r(g,m),p(g,m)):m.isMeshDepthMaterial?r(g,m):m.isMeshDistanceMaterial?(r(g,m),v(g,m)):m.isMeshNormalMaterial?r(g,m):m.isLineBasicMaterial?(o(g,m),m.isLineDashedMaterial&&a(g,m)):m.isPointsMaterial?c(g,m,S,_):m.isSpriteMaterial?l(g,m):m.isShadowMaterial?(g.color.value.copy(m.color),g.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(g,m){g.opacity.value=m.opacity,m.color&&g.diffuse.value.copy(m.color),m.emissive&&g.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(g.map.value=m.map,n(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,n(m.alphaMap,g.alphaMapTransform)),m.bumpMap&&(g.bumpMap.value=m.bumpMap,n(m.bumpMap,g.bumpMapTransform),g.bumpScale.value=m.bumpScale,m.side===Gt&&(g.bumpScale.value*=-1)),m.normalMap&&(g.normalMap.value=m.normalMap,n(m.normalMap,g.normalMapTransform),g.normalScale.value.copy(m.normalScale),m.side===Gt&&g.normalScale.value.negate()),m.displacementMap&&(g.displacementMap.value=m.displacementMap,n(m.displacementMap,g.displacementMapTransform),g.displacementScale.value=m.displacementScale,g.displacementBias.value=m.displacementBias),m.emissiveMap&&(g.emissiveMap.value=m.emissiveMap,n(m.emissiveMap,g.emissiveMapTransform)),m.specularMap&&(g.specularMap.value=m.specularMap,n(m.specularMap,g.specularMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest);const S=e.get(m),_=S.envMap,y=S.envMapRotation;_&&(g.envMap.value=_,Vi.copy(y),Vi.x*=-1,Vi.y*=-1,Vi.z*=-1,_.isCubeTexture&&_.isRenderTargetTexture===!1&&(Vi.y*=-1,Vi.z*=-1),g.envMapRotation.value.setFromMatrix4(S1.makeRotationFromEuler(Vi)),g.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=m.reflectivity,g.ior.value=m.ior,g.refractionRatio.value=m.refractionRatio),m.lightMap&&(g.lightMap.value=m.lightMap,g.lightMapIntensity.value=m.lightMapIntensity,n(m.lightMap,g.lightMapTransform)),m.aoMap&&(g.aoMap.value=m.aoMap,g.aoMapIntensity.value=m.aoMapIntensity,n(m.aoMap,g.aoMapTransform))}function o(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,m.map&&(g.map.value=m.map,n(m.map,g.mapTransform))}function a(g,m){g.dashSize.value=m.dashSize,g.totalSize.value=m.dashSize+m.gapSize,g.scale.value=m.scale}function c(g,m,S,_){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.size.value=m.size*S,g.scale.value=_*.5,m.map&&(g.map.value=m.map,n(m.map,g.uvTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,n(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function l(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.rotation.value=m.rotation,m.map&&(g.map.value=m.map,n(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,n(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function u(g,m){g.specular.value.copy(m.specular),g.shininess.value=Math.max(m.shininess,1e-4)}function d(g,m){m.gradientMap&&(g.gradientMap.value=m.gradientMap)}function f(g,m){g.metalness.value=m.metalness,m.metalnessMap&&(g.metalnessMap.value=m.metalnessMap,n(m.metalnessMap,g.metalnessMapTransform)),g.roughness.value=m.roughness,m.roughnessMap&&(g.roughnessMap.value=m.roughnessMap,n(m.roughnessMap,g.roughnessMapTransform)),m.envMap&&(g.envMapIntensity.value=m.envMapIntensity)}function h(g,m,S){g.ior.value=m.ior,m.sheen>0&&(g.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),g.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(g.sheenColorMap.value=m.sheenColorMap,n(m.sheenColorMap,g.sheenColorMapTransform)),m.sheenRoughnessMap&&(g.sheenRoughnessMap.value=m.sheenRoughnessMap,n(m.sheenRoughnessMap,g.sheenRoughnessMapTransform))),m.clearcoat>0&&(g.clearcoat.value=m.clearcoat,g.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(g.clearcoatMap.value=m.clearcoatMap,n(m.clearcoatMap,g.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,n(m.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(g.clearcoatNormalMap.value=m.clearcoatNormalMap,n(m.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===Gt&&g.clearcoatNormalScale.value.negate())),m.dispersion>0&&(g.dispersion.value=m.dispersion),m.iridescence>0&&(g.iridescence.value=m.iridescence,g.iridescenceIOR.value=m.iridescenceIOR,g.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(g.iridescenceMap.value=m.iridescenceMap,n(m.iridescenceMap,g.iridescenceMapTransform)),m.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=m.iridescenceThicknessMap,n(m.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),m.transmission>0&&(g.transmission.value=m.transmission,g.transmissionSamplerMap.value=S.texture,g.transmissionSamplerSize.value.set(S.width,S.height),m.transmissionMap&&(g.transmissionMap.value=m.transmissionMap,n(m.transmissionMap,g.transmissionMapTransform)),g.thickness.value=m.thickness,m.thicknessMap&&(g.thicknessMap.value=m.thicknessMap,n(m.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=m.attenuationDistance,g.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(g.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(g.anisotropyMap.value=m.anisotropyMap,n(m.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=m.specularIntensity,g.specularColor.value.copy(m.specularColor),m.specularColorMap&&(g.specularColorMap.value=m.specularColorMap,n(m.specularColorMap,g.specularColorMapTransform)),m.specularIntensityMap&&(g.specularIntensityMap.value=m.specularIntensityMap,n(m.specularIntensityMap,g.specularIntensityMapTransform))}function p(g,m){m.matcap&&(g.matcap.value=m.matcap)}function v(g,m){const S=e.get(m).light;g.referencePosition.value.setFromMatrixPosition(S.matrixWorld),g.nearDistance.value=S.shadow.camera.near,g.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function x1(t,e,n,i){let s={},r={},o=[];const a=t.getParameter(t.MAX_UNIFORM_BUFFER_BINDINGS);function c(S,_){const y=_.program;i.uniformBlockBinding(S,y)}function l(S,_){let y=s[S.id];y===void 0&&(p(S),y=u(S),s[S.id]=y,S.addEventListener("dispose",g));const D=_.program;i.updateUBOMapping(S,D);const E=e.render.frame;r[S.id]!==E&&(f(S),r[S.id]=E)}function u(S){const _=d();S.__bindingPointIndex=_;const y=t.createBuffer(),D=S.__size,E=S.usage;return t.bindBuffer(t.UNIFORM_BUFFER,y),t.bufferData(t.UNIFORM_BUFFER,D,E),t.bindBuffer(t.UNIFORM_BUFFER,null),t.bindBufferBase(t.UNIFORM_BUFFER,_,y),y}function d(){for(let S=0;S<a;S++)if(o.indexOf(S)===-1)return o.push(S),S;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(S){const _=s[S.id],y=S.uniforms,D=S.__cache;t.bindBuffer(t.UNIFORM_BUFFER,_);for(let E=0,A=y.length;E<A;E++){const P=Array.isArray(y[E])?y[E]:[y[E]];for(let b=0,x=P.length;b<x;b++){const L=P[b];if(h(L,E,b,D)===!0){const B=L.__offset,F=Array.isArray(L.value)?L.value:[L.value];let G=0;for(let $=0;$<F.length;$++){const X=F[$],Q=v(X);typeof X=="number"||typeof X=="boolean"?(L.__data[0]=X,t.bufferSubData(t.UNIFORM_BUFFER,B+G,L.__data)):X.isMatrix3?(L.__data[0]=X.elements[0],L.__data[1]=X.elements[1],L.__data[2]=X.elements[2],L.__data[3]=0,L.__data[4]=X.elements[3],L.__data[5]=X.elements[4],L.__data[6]=X.elements[5],L.__data[7]=0,L.__data[8]=X.elements[6],L.__data[9]=X.elements[7],L.__data[10]=X.elements[8],L.__data[11]=0):(X.toArray(L.__data,G),G+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}t.bufferSubData(t.UNIFORM_BUFFER,B,L.__data)}}}t.bindBuffer(t.UNIFORM_BUFFER,null)}function h(S,_,y,D){const E=S.value,A=_+"_"+y;if(D[A]===void 0)return typeof E=="number"||typeof E=="boolean"?D[A]=E:D[A]=E.clone(),!0;{const P=D[A];if(typeof E=="number"||typeof E=="boolean"){if(P!==E)return D[A]=E,!0}else if(P.equals(E)===!1)return P.copy(E),!0}return!1}function p(S){const _=S.uniforms;let y=0;const D=16;for(let A=0,P=_.length;A<P;A++){const b=Array.isArray(_[A])?_[A]:[_[A]];for(let x=0,L=b.length;x<L;x++){const B=b[x],F=Array.isArray(B.value)?B.value:[B.value];for(let G=0,$=F.length;G<$;G++){const X=F[G],Q=v(X),V=y%D,re=V%Q.boundary,he=V+re;y+=re,he!==0&&D-he<Q.storage&&(y+=D-he),B.__data=new Float32Array(Q.storage/Float32Array.BYTES_PER_ELEMENT),B.__offset=y,y+=Q.storage}}}const E=y%D;return E>0&&(y+=D-E),S.__size=y,S.__cache={},this}function v(S){const _={boundary:0,storage:0};return typeof S=="number"||typeof S=="boolean"?(_.boundary=4,_.storage=4):S.isVector2?(_.boundary=8,_.storage=8):S.isVector3||S.isColor?(_.boundary=16,_.storage=12):S.isVector4?(_.boundary=16,_.storage=16):S.isMatrix3?(_.boundary=48,_.storage=48):S.isMatrix4?(_.boundary=64,_.storage=64):S.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",S),_}function g(S){const _=S.target;_.removeEventListener("dispose",g);const y=o.indexOf(_.__bindingPointIndex);o.splice(y,1),t.deleteBuffer(s[_.id]),delete s[_.id],delete r[_.id]}function m(){for(const S in s)t.deleteBuffer(s[S]);o=[],s={},r={}}return{bind:c,update:l,dispose:m}}class b1{constructor(e={}){const{canvas:n=hS(),context:i=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:d=!1,reverseDepthBuffer:f=!1}=e;this.isWebGLRenderer=!0;let h;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");h=i.getContextAttributes().alpha}else h=o;const p=new Uint32Array(4),v=new Int32Array(4);let g=null,m=null;const S=[],_=[];this.domElement=n,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=hn,this.toneMapping=Li,this.toneMappingExposure=1;const y=this;let D=!1,E=0,A=0,P=null,b=-1,x=null;const L=new qe,B=new qe;let F=null;const G=new J(0);let $=0,X=n.width,Q=n.height,V=1,re=null,he=null;const Me=new qe(0,0,X,Q),Fe=new qe(0,0,X,Q);let it=!1;const Y=new td;let ne=!1,_e=!1;const oe=new Qe,Re=new Qe,Le=new T,Oe=new qe,ht={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Ve=!1;function yt(){return P===null?V:1}let k=i;function an(w,N){return n.getContext(w,N)}try{const w={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:d};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${$u}`),n.addEventListener("webglcontextlost",K,!1),n.addEventListener("webglcontextrestored",ue,!1),n.addEventListener("webglcontextcreationerror",ce,!1),k===null){const N="webgl2";if(k=an(N,w),k===null)throw an(N)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(w){throw console.error("THREE.WebGLRenderer: "+w.message),w}let He,Ge,we,ct,Ee,R,M,O,j,Z,q,xe,ae,pe,$e,ee,me,Ae,Ce,ge,We,Ue,st,I;function se(){He=new Ab(k),He.init(),Ue=new f1(k,He),Ge=new xb(k,He,e,Ue),we=new l1(k,He),Ge.reverseDepthBuffer&&f&&we.buffers.depth.setReversed(!0),ct=new Pb(k),Ee=new YM,R=new d1(k,He,we,Ee,Ge,Ue,ct),M=new Mb(y),O=new Tb(y),j=new FS(k),st=new Sb(k,j),Z=new Rb(k,j,ct,st),q=new Db(k,Z,j,ct),Ce=new Lb(k,Ge,R),ee=new bb(Ee),xe=new qM(y,M,O,He,Ge,st,ee),ae=new _1(y,Ee),pe=new KM,$e=new n1(He),Ae=new yb(y,M,O,we,q,h,c),me=new a1(y,q,Ge),I=new x1(k,ct,Ge,we),ge=new _b(k,He,ct),We=new Cb(k,He,ct),ct.programs=xe.programs,y.capabilities=Ge,y.extensions=He,y.properties=Ee,y.renderLists=pe,y.shadowMap=me,y.state=we,y.info=ct}se();const W=new y1(y,k);this.xr=W,this.getContext=function(){return k},this.getContextAttributes=function(){return k.getContextAttributes()},this.forceContextLoss=function(){const w=He.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=He.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return V},this.setPixelRatio=function(w){w!==void 0&&(V=w,this.setSize(X,Q,!1))},this.getSize=function(w){return w.set(X,Q)},this.setSize=function(w,N,z=!0){if(W.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}X=w,Q=N,n.width=Math.floor(w*V),n.height=Math.floor(N*V),z===!0&&(n.style.width=w+"px",n.style.height=N+"px"),this.setViewport(0,0,w,N)},this.getDrawingBufferSize=function(w){return w.set(X*V,Q*V).floor()},this.setDrawingBufferSize=function(w,N,z){X=w,Q=N,V=z,n.width=Math.floor(w*z),n.height=Math.floor(N*z),this.setViewport(0,0,w,N)},this.getCurrentViewport=function(w){return w.copy(L)},this.getViewport=function(w){return w.copy(Me)},this.setViewport=function(w,N,z,H){w.isVector4?Me.set(w.x,w.y,w.z,w.w):Me.set(w,N,z,H),we.viewport(L.copy(Me).multiplyScalar(V).round())},this.getScissor=function(w){return w.copy(Fe)},this.setScissor=function(w,N,z,H){w.isVector4?Fe.set(w.x,w.y,w.z,w.w):Fe.set(w,N,z,H),we.scissor(B.copy(Fe).multiplyScalar(V).round())},this.getScissorTest=function(){return it},this.setScissorTest=function(w){we.setScissorTest(it=w)},this.setOpaqueSort=function(w){re=w},this.setTransparentSort=function(w){he=w},this.getClearColor=function(w){return w.copy(Ae.getClearColor())},this.setClearColor=function(){Ae.setClearColor.apply(Ae,arguments)},this.getClearAlpha=function(){return Ae.getClearAlpha()},this.setClearAlpha=function(){Ae.setClearAlpha.apply(Ae,arguments)},this.clear=function(w=!0,N=!0,z=!0){let H=0;if(w){let U=!1;if(P!==null){const te=P.texture.format;U=te===Ju||te===Zu||te===Ku}if(U){const te=P.texture.type,le=te===ri||te===ns||te===qr||te===er||te===Yu||te===ju,ve=Ae.getClearColor(),ye=Ae.getClearAlpha(),Pe=ve.r,Ie=ve.g,Se=ve.b;le?(p[0]=Pe,p[1]=Ie,p[2]=Se,p[3]=ye,k.clearBufferuiv(k.COLOR,0,p)):(v[0]=Pe,v[1]=Ie,v[2]=Se,v[3]=ye,k.clearBufferiv(k.COLOR,0,v))}else H|=k.COLOR_BUFFER_BIT}N&&(H|=k.DEPTH_BUFFER_BIT),z&&(H|=k.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),k.clear(H)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){n.removeEventListener("webglcontextlost",K,!1),n.removeEventListener("webglcontextrestored",ue,!1),n.removeEventListener("webglcontextcreationerror",ce,!1),pe.dispose(),$e.dispose(),Ee.dispose(),M.dispose(),O.dispose(),q.dispose(),st.dispose(),I.dispose(),xe.dispose(),W.dispose(),W.removeEventListener("sessionstart",Kd),W.removeEventListener("sessionend",Zd),Oi.stop()};function K(w){w.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),D=!0}function ue(){console.log("THREE.WebGLRenderer: Context Restored."),D=!1;const w=ct.autoReset,N=me.enabled,z=me.autoUpdate,H=me.needsUpdate,U=me.type;se(),ct.autoReset=w,me.enabled=N,me.autoUpdate=z,me.needsUpdate=H,me.type=U}function ce(w){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function De(w){const N=w.target;N.removeEventListener("dispose",De),gt(N)}function gt(w){Ft(w),Ee.remove(w)}function Ft(w){const N=Ee.get(w).programs;N!==void 0&&(N.forEach(function(z){xe.releaseProgram(z)}),w.isShaderMaterial&&xe.releaseShaderCache(w))}this.renderBufferDirect=function(w,N,z,H,U,te){N===null&&(N=ht);const le=U.isMesh&&U.matrixWorld.determinant()<0,ve=sy(w,N,z,H,U);we.setMaterial(H,le);let ye=z.index,Pe=1;if(H.wireframe===!0){if(ye=Z.getWireframeAttribute(z),ye===void 0)return;Pe=2}const Ie=z.drawRange,Se=z.attributes.position;let je=Ie.start*Pe,rt=(Ie.start+Ie.count)*Pe;te!==null&&(je=Math.max(je,te.start*Pe),rt=Math.min(rt,(te.start+te.count)*Pe)),ye!==null?(je=Math.max(je,0),rt=Math.min(rt,ye.count)):Se!=null&&(je=Math.max(je,0),rt=Math.min(rt,Se.count));const lt=rt-je;if(lt<0||lt===1/0)return;st.setup(U,H,ve,z,ye);let Vt,Ze=ge;if(ye!==null&&(Vt=j.get(ye),Ze=We,Ze.setIndex(Vt)),U.isMesh)H.wireframe===!0?(we.setLineWidth(H.wireframeLinewidth*yt()),Ze.setMode(k.LINES)):Ze.setMode(k.TRIANGLES);else if(U.isLine){let be=H.linewidth;be===void 0&&(be=1),we.setLineWidth(be*yt()),U.isLineSegments?Ze.setMode(k.LINES):U.isLineLoop?Ze.setMode(k.LINE_LOOP):Ze.setMode(k.LINE_STRIP)}else U.isPoints?Ze.setMode(k.POINTS):U.isSprite&&Ze.setMode(k.TRIANGLES);if(U.isBatchedMesh)if(U._multiDrawInstances!==null)Ze.renderMultiDrawInstances(U._multiDrawStarts,U._multiDrawCounts,U._multiDrawCount,U._multiDrawInstances);else if(He.get("WEBGL_multi_draw"))Ze.renderMultiDraw(U._multiDrawStarts,U._multiDrawCounts,U._multiDrawCount);else{const be=U._multiDrawStarts,Xn=U._multiDrawCounts,Je=U._multiDrawCount,xn=ye?j.get(ye).bytesPerElement:1,fs=Ee.get(H).currentProgram.getUniforms();for(let jt=0;jt<Je;jt++)fs.setValue(k,"_gl_DrawID",jt),Ze.render(be[jt]/xn,Xn[jt])}else if(U.isInstancedMesh)Ze.renderInstances(je,lt,U.count);else if(z.isInstancedBufferGeometry){const be=z._maxInstanceCount!==void 0?z._maxInstanceCount:1/0,Xn=Math.min(z.instanceCount,be);Ze.renderInstances(je,lt,Xn)}else Ze.render(je,lt)};function et(w,N,z){w.transparent===!0&&w.side===Dt&&w.forceSinglePass===!1?(w.side=Gt,w.needsUpdate=!0,yo(w,N,z),w.side=Ni,w.needsUpdate=!0,yo(w,N,z),w.side=Dt):yo(w,N,z)}this.compile=function(w,N,z=null){z===null&&(z=w),m=$e.get(z),m.init(N),_.push(m),z.traverseVisible(function(U){U.isLight&&U.layers.test(N.layers)&&(m.pushLight(U),U.castShadow&&m.pushShadow(U))}),w!==z&&w.traverseVisible(function(U){U.isLight&&U.layers.test(N.layers)&&(m.pushLight(U),U.castShadow&&m.pushShadow(U))}),m.setupLights();const H=new Set;return w.traverse(function(U){if(!(U.isMesh||U.isPoints||U.isLine||U.isSprite))return;const te=U.material;if(te)if(Array.isArray(te))for(let le=0;le<te.length;le++){const ve=te[le];et(ve,z,U),H.add(ve)}else et(te,z,U),H.add(te)}),_.pop(),m=null,H},this.compileAsync=function(w,N,z=null){const H=this.compile(w,N,z);return new Promise(U=>{function te(){if(H.forEach(function(le){Ee.get(le).currentProgram.isReady()&&H.delete(le)}),H.size===0){U(w);return}setTimeout(te,10)}He.get("KHR_parallel_shader_compile")!==null?te():setTimeout(te,10)})};let _n=null;function $n(w){_n&&_n(w)}function Kd(){Oi.stop()}function Zd(){Oi.start()}const Oi=new Am;Oi.setAnimationLoop($n),typeof self<"u"&&Oi.setContext(self),this.setAnimationLoop=function(w){_n=w,W.setAnimationLoop(w),w===null?Oi.stop():Oi.start()},W.addEventListener("sessionstart",Kd),W.addEventListener("sessionend",Zd),this.render=function(w,N){if(N!==void 0&&N.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(D===!0)return;if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),W.enabled===!0&&W.isPresenting===!0&&(W.cameraAutoUpdate===!0&&W.updateCamera(N),N=W.getCamera()),w.isScene===!0&&w.onBeforeRender(y,w,N,P),m=$e.get(w,_.length),m.init(N),_.push(m),Re.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),Y.setFromProjectionMatrix(Re),_e=this.localClippingEnabled,ne=ee.init(this.clippingPlanes,_e),g=pe.get(w,S.length),g.init(),S.push(g),W.enabled===!0&&W.isPresenting===!0){const te=y.xr.getDepthSensingMesh();te!==null&&ic(te,N,-1/0,y.sortObjects)}ic(w,N,0,y.sortObjects),g.finish(),y.sortObjects===!0&&g.sort(re,he),Ve=W.enabled===!1||W.isPresenting===!1||W.hasDepthSensing()===!1,Ve&&Ae.addToRenderList(g,w),this.info.render.frame++,ne===!0&&ee.beginShadows();const z=m.state.shadowsArray;me.render(z,w,N),ne===!0&&ee.endShadows(),this.info.autoReset===!0&&this.info.reset();const H=g.opaque,U=g.transmissive;if(m.setupLights(),N.isArrayCamera){const te=N.cameras;if(U.length>0)for(let le=0,ve=te.length;le<ve;le++){const ye=te[le];Qd(H,U,w,ye)}Ve&&Ae.render(w);for(let le=0,ve=te.length;le<ve;le++){const ye=te[le];Jd(g,w,ye,ye.viewport)}}else U.length>0&&Qd(H,U,w,N),Ve&&Ae.render(w),Jd(g,w,N);P!==null&&(R.updateMultisampleRenderTarget(P),R.updateRenderTargetMipmap(P)),w.isScene===!0&&w.onAfterRender(y,w,N),st.resetDefaultState(),b=-1,x=null,_.pop(),_.length>0?(m=_[_.length-1],ne===!0&&ee.setGlobalState(y.clippingPlanes,m.state.camera)):m=null,S.pop(),S.length>0?g=S[S.length-1]:g=null};function ic(w,N,z,H){if(w.visible===!1)return;if(w.layers.test(N.layers)){if(w.isGroup)z=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(N);else if(w.isLight)m.pushLight(w),w.castShadow&&m.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||Y.intersectsSprite(w)){H&&Oe.setFromMatrixPosition(w.matrixWorld).applyMatrix4(Re);const le=q.update(w),ve=w.material;ve.visible&&g.push(w,le,ve,z,Oe.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||Y.intersectsObject(w))){const le=q.update(w),ve=w.material;if(H&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),Oe.copy(w.boundingSphere.center)):(le.boundingSphere===null&&le.computeBoundingSphere(),Oe.copy(le.boundingSphere.center)),Oe.applyMatrix4(w.matrixWorld).applyMatrix4(Re)),Array.isArray(ve)){const ye=le.groups;for(let Pe=0,Ie=ye.length;Pe<Ie;Pe++){const Se=ye[Pe],je=ve[Se.materialIndex];je&&je.visible&&g.push(w,le,je,z,Oe.z,Se)}}else ve.visible&&g.push(w,le,ve,z,Oe.z,null)}}const te=w.children;for(let le=0,ve=te.length;le<ve;le++)ic(te[le],N,z,H)}function Jd(w,N,z,H){const U=w.opaque,te=w.transmissive,le=w.transparent;m.setupLightsView(z),ne===!0&&ee.setGlobalState(y.clippingPlanes,z),H&&we.viewport(L.copy(H)),U.length>0&&vo(U,N,z),te.length>0&&vo(te,N,z),le.length>0&&vo(le,N,z),we.buffers.depth.setTest(!0),we.buffers.depth.setMask(!0),we.buffers.color.setMask(!0),we.setPolygonOffset(!1)}function Qd(w,N,z,H){if((z.isScene===!0?z.overrideMaterial:null)!==null)return;m.state.transmissionRenderTarget[H.id]===void 0&&(m.state.transmissionRenderTarget[H.id]=new Ui(1,1,{generateMipmaps:!0,type:He.has("EXT_color_buffer_half_float")||He.has("EXT_color_buffer_float")?to:ri,minFilter:Qi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Xe.workingColorSpace}));const te=m.state.transmissionRenderTarget[H.id],le=H.viewport||L;te.setSize(le.z,le.w);const ve=y.getRenderTarget();y.setRenderTarget(te),y.getClearColor(G),$=y.getClearAlpha(),$<1&&y.setClearColor(16777215,.5),y.clear(),Ve&&Ae.render(z);const ye=y.toneMapping;y.toneMapping=Li;const Pe=H.viewport;if(H.viewport!==void 0&&(H.viewport=void 0),m.setupLightsView(H),ne===!0&&ee.setGlobalState(y.clippingPlanes,H),vo(w,z,H),R.updateMultisampleRenderTarget(te),R.updateRenderTargetMipmap(te),He.has("WEBGL_multisampled_render_to_texture")===!1){let Ie=!1;for(let Se=0,je=N.length;Se<je;Se++){const rt=N[Se],lt=rt.object,Vt=rt.geometry,Ze=rt.material,be=rt.group;if(Ze.side===Dt&&lt.layers.test(H.layers)){const Xn=Ze.side;Ze.side=Gt,Ze.needsUpdate=!0,ef(lt,z,H,Vt,Ze,be),Ze.side=Xn,Ze.needsUpdate=!0,Ie=!0}}Ie===!0&&(R.updateMultisampleRenderTarget(te),R.updateRenderTargetMipmap(te))}y.setRenderTarget(ve),y.setClearColor(G,$),Pe!==void 0&&(H.viewport=Pe),y.toneMapping=ye}function vo(w,N,z){const H=N.isScene===!0?N.overrideMaterial:null;for(let U=0,te=w.length;U<te;U++){const le=w[U],ve=le.object,ye=le.geometry,Pe=H===null?le.material:H,Ie=le.group;ve.layers.test(z.layers)&&ef(ve,N,z,ye,Pe,Ie)}}function ef(w,N,z,H,U,te){w.onBeforeRender(y,N,z,H,U,te),w.modelViewMatrix.multiplyMatrices(z.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),U.onBeforeRender(y,N,z,H,w,te),U.transparent===!0&&U.side===Dt&&U.forceSinglePass===!1?(U.side=Gt,U.needsUpdate=!0,y.renderBufferDirect(z,N,H,U,w,te),U.side=Ni,U.needsUpdate=!0,y.renderBufferDirect(z,N,H,U,w,te),U.side=Dt):y.renderBufferDirect(z,N,H,U,w,te),w.onAfterRender(y,N,z,H,U,te)}function yo(w,N,z){N.isScene!==!0&&(N=ht);const H=Ee.get(w),U=m.state.lights,te=m.state.shadowsArray,le=U.state.version,ve=xe.getParameters(w,U.state,te,N,z),ye=xe.getProgramCacheKey(ve);let Pe=H.programs;H.environment=w.isMeshStandardMaterial?N.environment:null,H.fog=N.fog,H.envMap=(w.isMeshStandardMaterial?O:M).get(w.envMap||H.environment),H.envMapRotation=H.environment!==null&&w.envMap===null?N.environmentRotation:w.envMapRotation,Pe===void 0&&(w.addEventListener("dispose",De),Pe=new Map,H.programs=Pe);let Ie=Pe.get(ye);if(Ie!==void 0){if(H.currentProgram===Ie&&H.lightsStateVersion===le)return nf(w,ve),Ie}else ve.uniforms=xe.getUniforms(w),w.onBeforeCompile(ve,y),Ie=xe.acquireProgram(ve,ye),Pe.set(ye,Ie),H.uniforms=ve.uniforms;const Se=H.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(Se.clippingPlanes=ee.uniform),nf(w,ve),H.needsLights=oy(w),H.lightsStateVersion=le,H.needsLights&&(Se.ambientLightColor.value=U.state.ambient,Se.lightProbe.value=U.state.probe,Se.directionalLights.value=U.state.directional,Se.directionalLightShadows.value=U.state.directionalShadow,Se.spotLights.value=U.state.spot,Se.spotLightShadows.value=U.state.spotShadow,Se.rectAreaLights.value=U.state.rectArea,Se.ltc_1.value=U.state.rectAreaLTC1,Se.ltc_2.value=U.state.rectAreaLTC2,Se.pointLights.value=U.state.point,Se.pointLightShadows.value=U.state.pointShadow,Se.hemisphereLights.value=U.state.hemi,Se.directionalShadowMap.value=U.state.directionalShadowMap,Se.directionalShadowMatrix.value=U.state.directionalShadowMatrix,Se.spotShadowMap.value=U.state.spotShadowMap,Se.spotLightMatrix.value=U.state.spotLightMatrix,Se.spotLightMap.value=U.state.spotLightMap,Se.pointShadowMap.value=U.state.pointShadowMap,Se.pointShadowMatrix.value=U.state.pointShadowMatrix),H.currentProgram=Ie,H.uniformsList=null,Ie}function tf(w){if(w.uniformsList===null){const N=w.currentProgram.getUniforms();w.uniformsList=ma.seqWithValue(N.seq,w.uniforms)}return w.uniformsList}function nf(w,N){const z=Ee.get(w);z.outputColorSpace=N.outputColorSpace,z.batching=N.batching,z.batchingColor=N.batchingColor,z.instancing=N.instancing,z.instancingColor=N.instancingColor,z.instancingMorph=N.instancingMorph,z.skinning=N.skinning,z.morphTargets=N.morphTargets,z.morphNormals=N.morphNormals,z.morphColors=N.morphColors,z.morphTargetsCount=N.morphTargetsCount,z.numClippingPlanes=N.numClippingPlanes,z.numIntersection=N.numClipIntersection,z.vertexAlphas=N.vertexAlphas,z.vertexTangents=N.vertexTangents,z.toneMapping=N.toneMapping}function sy(w,N,z,H,U){N.isScene!==!0&&(N=ht),R.resetTextureUnits();const te=N.fog,le=H.isMeshStandardMaterial?N.environment:null,ve=P===null?y.outputColorSpace:P.isXRRenderTarget===!0?P.texture.colorSpace:ur,ye=(H.isMeshStandardMaterial?O:M).get(H.envMap||le),Pe=H.vertexColors===!0&&!!z.attributes.color&&z.attributes.color.itemSize===4,Ie=!!z.attributes.tangent&&(!!H.normalMap||H.anisotropy>0),Se=!!z.morphAttributes.position,je=!!z.morphAttributes.normal,rt=!!z.morphAttributes.color;let lt=Li;H.toneMapped&&(P===null||P.isXRRenderTarget===!0)&&(lt=y.toneMapping);const Vt=z.morphAttributes.position||z.morphAttributes.normal||z.morphAttributes.color,Ze=Vt!==void 0?Vt.length:0,be=Ee.get(H),Xn=m.state.lights;if(ne===!0&&(_e===!0||w!==x)){const cn=w===x&&H.id===b;ee.setState(H,w,cn)}let Je=!1;H.version===be.__version?(be.needsLights&&be.lightsStateVersion!==Xn.state.version||be.outputColorSpace!==ve||U.isBatchedMesh&&be.batching===!1||!U.isBatchedMesh&&be.batching===!0||U.isBatchedMesh&&be.batchingColor===!0&&U.colorTexture===null||U.isBatchedMesh&&be.batchingColor===!1&&U.colorTexture!==null||U.isInstancedMesh&&be.instancing===!1||!U.isInstancedMesh&&be.instancing===!0||U.isSkinnedMesh&&be.skinning===!1||!U.isSkinnedMesh&&be.skinning===!0||U.isInstancedMesh&&be.instancingColor===!0&&U.instanceColor===null||U.isInstancedMesh&&be.instancingColor===!1&&U.instanceColor!==null||U.isInstancedMesh&&be.instancingMorph===!0&&U.morphTexture===null||U.isInstancedMesh&&be.instancingMorph===!1&&U.morphTexture!==null||be.envMap!==ye||H.fog===!0&&be.fog!==te||be.numClippingPlanes!==void 0&&(be.numClippingPlanes!==ee.numPlanes||be.numIntersection!==ee.numIntersection)||be.vertexAlphas!==Pe||be.vertexTangents!==Ie||be.morphTargets!==Se||be.morphNormals!==je||be.morphColors!==rt||be.toneMapping!==lt||be.morphTargetsCount!==Ze)&&(Je=!0):(Je=!0,be.__version=H.version);let xn=be.currentProgram;Je===!0&&(xn=yo(H,N,U));let fs=!1,jt=!1,_r=!1;const ut=xn.getUniforms(),In=be.uniforms;if(we.useProgram(xn.program)&&(fs=!0,jt=!0,_r=!0),H.id!==b&&(b=H.id,jt=!0),fs||x!==w){we.buffers.depth.getReversed()?(oe.copy(w.projectionMatrix),mS(oe),gS(oe),ut.setValue(k,"projectionMatrix",oe)):ut.setValue(k,"projectionMatrix",w.projectionMatrix),ut.setValue(k,"viewMatrix",w.matrixWorldInverse);const ui=ut.map.cameraPosition;ui!==void 0&&ui.setValue(k,Le.setFromMatrixPosition(w.matrixWorld)),Ge.logarithmicDepthBuffer&&ut.setValue(k,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(H.isMeshPhongMaterial||H.isMeshToonMaterial||H.isMeshLambertMaterial||H.isMeshBasicMaterial||H.isMeshStandardMaterial||H.isShaderMaterial)&&ut.setValue(k,"isOrthographic",w.isOrthographicCamera===!0),x!==w&&(x=w,jt=!0,_r=!0)}if(U.isSkinnedMesh){ut.setOptional(k,U,"bindMatrix"),ut.setOptional(k,U,"bindMatrixInverse");const cn=U.skeleton;cn&&(cn.boneTexture===null&&cn.computeBoneTexture(),ut.setValue(k,"boneTexture",cn.boneTexture,R))}U.isBatchedMesh&&(ut.setOptional(k,U,"batchingTexture"),ut.setValue(k,"batchingTexture",U._matricesTexture,R),ut.setOptional(k,U,"batchingIdTexture"),ut.setValue(k,"batchingIdTexture",U._indirectTexture,R),ut.setOptional(k,U,"batchingColorTexture"),U._colorsTexture!==null&&ut.setValue(k,"batchingColorTexture",U._colorsTexture,R));const xr=z.morphAttributes;if((xr.position!==void 0||xr.normal!==void 0||xr.color!==void 0)&&Ce.update(U,z,xn),(jt||be.receiveShadow!==U.receiveShadow)&&(be.receiveShadow=U.receiveShadow,ut.setValue(k,"receiveShadow",U.receiveShadow)),H.isMeshGouraudMaterial&&H.envMap!==null&&(In.envMap.value=ye,In.flipEnvMap.value=ye.isCubeTexture&&ye.isRenderTargetTexture===!1?-1:1),H.isMeshStandardMaterial&&H.envMap===null&&N.environment!==null&&(In.envMapIntensity.value=N.environmentIntensity),jt&&(ut.setValue(k,"toneMappingExposure",y.toneMappingExposure),be.needsLights&&ry(In,_r),te&&H.fog===!0&&ae.refreshFogUniforms(In,te),ae.refreshMaterialUniforms(In,H,V,Q,m.state.transmissionRenderTarget[w.id]),ma.upload(k,tf(be),In,R)),H.isShaderMaterial&&H.uniformsNeedUpdate===!0&&(ma.upload(k,tf(be),In,R),H.uniformsNeedUpdate=!1),H.isSpriteMaterial&&ut.setValue(k,"center",U.center),ut.setValue(k,"modelViewMatrix",U.modelViewMatrix),ut.setValue(k,"normalMatrix",U.normalMatrix),ut.setValue(k,"modelMatrix",U.matrixWorld),H.isShaderMaterial||H.isRawShaderMaterial){const cn=H.uniformsGroups;for(let ui=0,di=cn.length;ui<di;ui++){const sf=cn[ui];I.update(sf,xn),I.bind(sf,xn)}}return xn}function ry(w,N){w.ambientLightColor.needsUpdate=N,w.lightProbe.needsUpdate=N,w.directionalLights.needsUpdate=N,w.directionalLightShadows.needsUpdate=N,w.pointLights.needsUpdate=N,w.pointLightShadows.needsUpdate=N,w.spotLights.needsUpdate=N,w.spotLightShadows.needsUpdate=N,w.rectAreaLights.needsUpdate=N,w.hemisphereLights.needsUpdate=N}function oy(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return P},this.setRenderTargetTextures=function(w,N,z){Ee.get(w.texture).__webglTexture=N,Ee.get(w.depthTexture).__webglTexture=z;const H=Ee.get(w);H.__hasExternalTextures=!0,H.__autoAllocateDepthBuffer=z===void 0,H.__autoAllocateDepthBuffer||He.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),H.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(w,N){const z=Ee.get(w);z.__webglFramebuffer=N,z.__useDefaultFramebuffer=N===void 0},this.setRenderTarget=function(w,N=0,z=0){P=w,E=N,A=z;let H=!0,U=null,te=!1,le=!1;if(w){const ye=Ee.get(w);if(ye.__useDefaultFramebuffer!==void 0)we.bindFramebuffer(k.FRAMEBUFFER,null),H=!1;else if(ye.__webglFramebuffer===void 0)R.setupRenderTarget(w);else if(ye.__hasExternalTextures)R.rebindTextures(w,Ee.get(w.texture).__webglTexture,Ee.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const Se=w.depthTexture;if(ye.__boundDepthTexture!==Se){if(Se!==null&&Ee.has(Se)&&(w.width!==Se.image.width||w.height!==Se.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");R.setupDepthRenderbuffer(w)}}const Pe=w.texture;(Pe.isData3DTexture||Pe.isDataArrayTexture||Pe.isCompressedArrayTexture)&&(le=!0);const Ie=Ee.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(Ie[N])?U=Ie[N][z]:U=Ie[N],te=!0):w.samples>0&&R.useMultisampledRTT(w)===!1?U=Ee.get(w).__webglMultisampledFramebuffer:Array.isArray(Ie)?U=Ie[z]:U=Ie,L.copy(w.viewport),B.copy(w.scissor),F=w.scissorTest}else L.copy(Me).multiplyScalar(V).floor(),B.copy(Fe).multiplyScalar(V).floor(),F=it;if(we.bindFramebuffer(k.FRAMEBUFFER,U)&&H&&we.drawBuffers(w,U),we.viewport(L),we.scissor(B),we.setScissorTest(F),te){const ye=Ee.get(w.texture);k.framebufferTexture2D(k.FRAMEBUFFER,k.COLOR_ATTACHMENT0,k.TEXTURE_CUBE_MAP_POSITIVE_X+N,ye.__webglTexture,z)}else if(le){const ye=Ee.get(w.texture),Pe=N||0;k.framebufferTextureLayer(k.FRAMEBUFFER,k.COLOR_ATTACHMENT0,ye.__webglTexture,z||0,Pe)}b=-1},this.readRenderTargetPixels=function(w,N,z,H,U,te,le){if(!(w&&w.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ve=Ee.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&le!==void 0&&(ve=ve[le]),ve){we.bindFramebuffer(k.FRAMEBUFFER,ve);try{const ye=w.texture,Pe=ye.format,Ie=ye.type;if(!Ge.textureFormatReadable(Pe)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Ge.textureTypeReadable(Ie)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=w.width-H&&z>=0&&z<=w.height-U&&k.readPixels(N,z,H,U,Ue.convert(Pe),Ue.convert(Ie),te)}finally{const ye=P!==null?Ee.get(P).__webglFramebuffer:null;we.bindFramebuffer(k.FRAMEBUFFER,ye)}}},this.readRenderTargetPixelsAsync=async function(w,N,z,H,U,te,le){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let ve=Ee.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&le!==void 0&&(ve=ve[le]),ve){const ye=w.texture,Pe=ye.format,Ie=ye.type;if(!Ge.textureFormatReadable(Pe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Ge.textureTypeReadable(Ie))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(N>=0&&N<=w.width-H&&z>=0&&z<=w.height-U){we.bindFramebuffer(k.FRAMEBUFFER,ve);const Se=k.createBuffer();k.bindBuffer(k.PIXEL_PACK_BUFFER,Se),k.bufferData(k.PIXEL_PACK_BUFFER,te.byteLength,k.STREAM_READ),k.readPixels(N,z,H,U,Ue.convert(Pe),Ue.convert(Ie),0);const je=P!==null?Ee.get(P).__webglFramebuffer:null;we.bindFramebuffer(k.FRAMEBUFFER,je);const rt=k.fenceSync(k.SYNC_GPU_COMMANDS_COMPLETE,0);return k.flush(),await pS(k,rt,4),k.bindBuffer(k.PIXEL_PACK_BUFFER,Se),k.getBufferSubData(k.PIXEL_PACK_BUFFER,0,te),k.deleteBuffer(Se),k.deleteSync(rt),te}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(w,N=null,z=0){w.isTexture!==!0&&(Nr("WebGLRenderer: copyFramebufferToTexture function signature has changed."),N=arguments[0]||null,w=arguments[1]);const H=Math.pow(2,-z),U=Math.floor(w.image.width*H),te=Math.floor(w.image.height*H),le=N!==null?N.x:0,ve=N!==null?N.y:0;R.setTexture2D(w,0),k.copyTexSubImage2D(k.TEXTURE_2D,z,0,0,le,ve,U,te),we.unbindTexture()},this.copyTextureToTexture=function(w,N,z=null,H=null,U=0){w.isTexture!==!0&&(Nr("WebGLRenderer: copyTextureToTexture function signature has changed."),H=arguments[0]||null,w=arguments[1],N=arguments[2],U=arguments[3]||0,z=null);let te,le,ve,ye,Pe,Ie,Se,je,rt;const lt=w.isCompressedTexture?w.mipmaps[U]:w.image;z!==null?(te=z.max.x-z.min.x,le=z.max.y-z.min.y,ve=z.isBox3?z.max.z-z.min.z:1,ye=z.min.x,Pe=z.min.y,Ie=z.isBox3?z.min.z:0):(te=lt.width,le=lt.height,ve=lt.depth||1,ye=0,Pe=0,Ie=0),H!==null?(Se=H.x,je=H.y,rt=H.z):(Se=0,je=0,rt=0);const Vt=Ue.convert(N.format),Ze=Ue.convert(N.type);let be;N.isData3DTexture?(R.setTexture3D(N,0),be=k.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(R.setTexture2DArray(N,0),be=k.TEXTURE_2D_ARRAY):(R.setTexture2D(N,0),be=k.TEXTURE_2D),k.pixelStorei(k.UNPACK_FLIP_Y_WEBGL,N.flipY),k.pixelStorei(k.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),k.pixelStorei(k.UNPACK_ALIGNMENT,N.unpackAlignment);const Xn=k.getParameter(k.UNPACK_ROW_LENGTH),Je=k.getParameter(k.UNPACK_IMAGE_HEIGHT),xn=k.getParameter(k.UNPACK_SKIP_PIXELS),fs=k.getParameter(k.UNPACK_SKIP_ROWS),jt=k.getParameter(k.UNPACK_SKIP_IMAGES);k.pixelStorei(k.UNPACK_ROW_LENGTH,lt.width),k.pixelStorei(k.UNPACK_IMAGE_HEIGHT,lt.height),k.pixelStorei(k.UNPACK_SKIP_PIXELS,ye),k.pixelStorei(k.UNPACK_SKIP_ROWS,Pe),k.pixelStorei(k.UNPACK_SKIP_IMAGES,Ie);const _r=w.isDataArrayTexture||w.isData3DTexture,ut=N.isDataArrayTexture||N.isData3DTexture;if(w.isRenderTargetTexture||w.isDepthTexture){const In=Ee.get(w),xr=Ee.get(N),cn=Ee.get(In.__renderTarget),ui=Ee.get(xr.__renderTarget);we.bindFramebuffer(k.READ_FRAMEBUFFER,cn.__webglFramebuffer),we.bindFramebuffer(k.DRAW_FRAMEBUFFER,ui.__webglFramebuffer);for(let di=0;di<ve;di++)_r&&k.framebufferTextureLayer(k.READ_FRAMEBUFFER,k.COLOR_ATTACHMENT0,Ee.get(w).__webglTexture,U,Ie+di),w.isDepthTexture?(ut&&k.framebufferTextureLayer(k.DRAW_FRAMEBUFFER,k.COLOR_ATTACHMENT0,Ee.get(N).__webglTexture,U,rt+di),k.blitFramebuffer(ye,Pe,te,le,Se,je,te,le,k.DEPTH_BUFFER_BIT,k.NEAREST)):ut?k.copyTexSubImage3D(be,U,Se,je,rt+di,ye,Pe,te,le):k.copyTexSubImage2D(be,U,Se,je,rt+di,ye,Pe,te,le);we.bindFramebuffer(k.READ_FRAMEBUFFER,null),we.bindFramebuffer(k.DRAW_FRAMEBUFFER,null)}else ut?w.isDataTexture||w.isData3DTexture?k.texSubImage3D(be,U,Se,je,rt,te,le,ve,Vt,Ze,lt.data):N.isCompressedArrayTexture?k.compressedTexSubImage3D(be,U,Se,je,rt,te,le,ve,Vt,lt.data):k.texSubImage3D(be,U,Se,je,rt,te,le,ve,Vt,Ze,lt):w.isDataTexture?k.texSubImage2D(k.TEXTURE_2D,U,Se,je,te,le,Vt,Ze,lt.data):w.isCompressedTexture?k.compressedTexSubImage2D(k.TEXTURE_2D,U,Se,je,lt.width,lt.height,Vt,lt.data):k.texSubImage2D(k.TEXTURE_2D,U,Se,je,te,le,Vt,Ze,lt);k.pixelStorei(k.UNPACK_ROW_LENGTH,Xn),k.pixelStorei(k.UNPACK_IMAGE_HEIGHT,Je),k.pixelStorei(k.UNPACK_SKIP_PIXELS,xn),k.pixelStorei(k.UNPACK_SKIP_ROWS,fs),k.pixelStorei(k.UNPACK_SKIP_IMAGES,jt),U===0&&N.generateMipmaps&&k.generateMipmap(be),we.unbindTexture()},this.copyTextureToTexture3D=function(w,N,z=null,H=null,U=0){return w.isTexture!==!0&&(Nr("WebGLRenderer: copyTextureToTexture3D function signature has changed."),z=arguments[0]||null,H=arguments[1]||null,w=arguments[2],N=arguments[3],U=arguments[4]||0),Nr('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(w,N,z,H,U)},this.initRenderTarget=function(w){Ee.get(w).__webglFramebuffer===void 0&&R.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?R.setTextureCube(w,0):w.isData3DTexture?R.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?R.setTexture2DArray(w,0):R.setTexture2D(w,0),we.unbindTexture()},this.resetState=function(){E=0,A=0,P=null,we.reset(),st.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ni}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const n=this.getContext();n.drawingBufferColorspace=Xe._getDrawingBufferColorSpace(e),n.unpackColorSpace=Xe._getUnpackColorSpace()}}class Nm extends Nt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Dn,this.environmentIntensity=1,this.environmentRotation=new Dn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,n){return super.copy(e,n),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const n=super.toJSON(e);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(n.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(n.object.backgroundIntensity=this.backgroundIntensity),n.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(n.object.environmentIntensity=this.environmentIntensity),n.object.environmentRotation=this.environmentRotation.toArray(),n}}class M1{constructor(e,n){this.isInterleavedBuffer=!0,this.array=e,this.stride=n,this.count=e!==void 0?e.length/n:0,this.usage=vu,this.updateRanges=[],this.version=0,this.uuid=ii()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,n,i){e*=this.stride,i*=n.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=n.array[i+s];return this}set(e,n=0){return this.array.set(e,n),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ii()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const n=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(n,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ii()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const zt=new T;class Ti{constructor(e,n,i,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=n,this.offset=i,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let n=0,i=this.data.count;n<i;n++)zt.fromBufferAttribute(this,n),zt.applyMatrix4(e),this.setXYZ(n,zt.x,zt.y,zt.z);return this}applyNormalMatrix(e){for(let n=0,i=this.count;n<i;n++)zt.fromBufferAttribute(this,n),zt.applyNormalMatrix(e),this.setXYZ(n,zt.x,zt.y,zt.z);return this}transformDirection(e){for(let n=0,i=this.count;n<i;n++)zt.fromBufferAttribute(this,n),zt.transformDirection(e),this.setXYZ(n,zt.x,zt.y,zt.z);return this}getComponent(e,n){let i=this.array[e*this.data.stride+this.offset+n];return this.normalized&&(i=An(i,this.array)),i}setComponent(e,n,i){return this.normalized&&(i=tt(i,this.array)),this.data.array[e*this.data.stride+this.offset+n]=i,this}setX(e,n){return this.normalized&&(n=tt(n,this.array)),this.data.array[e*this.data.stride+this.offset]=n,this}setY(e,n){return this.normalized&&(n=tt(n,this.array)),this.data.array[e*this.data.stride+this.offset+1]=n,this}setZ(e,n){return this.normalized&&(n=tt(n,this.array)),this.data.array[e*this.data.stride+this.offset+2]=n,this}setW(e,n){return this.normalized&&(n=tt(n,this.array)),this.data.array[e*this.data.stride+this.offset+3]=n,this}getX(e){let n=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(n=An(n,this.array)),n}getY(e){let n=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(n=An(n,this.array)),n}getZ(e){let n=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(n=An(n,this.array)),n}getW(e){let n=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(n=An(n,this.array)),n}setXY(e,n,i){return e=e*this.data.stride+this.offset,this.normalized&&(n=tt(n,this.array),i=tt(i,this.array)),this.data.array[e+0]=n,this.data.array[e+1]=i,this}setXYZ(e,n,i,s){return e=e*this.data.stride+this.offset,this.normalized&&(n=tt(n,this.array),i=tt(i,this.array),s=tt(s,this.array)),this.data.array[e+0]=n,this.data.array[e+1]=i,this.data.array[e+2]=s,this}setXYZW(e,n,i,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(n=tt(n,this.array),i=tt(i,this.array),s=tt(s,this.array),r=tt(r,this.array)),this.data.array[e+0]=n,this.data.array[e+1]=i,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const n=[];for(let i=0;i<this.count;i++){const s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)n.push(this.data.array[s+r])}return new Ut(new this.array.constructor(n),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new Ti(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const n=[];for(let i=0;i<this.count;i++){const s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)n.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:n,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Ga extends hr{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new J(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const nh=new Qe,Su=new vm,zo=new fr,Ho=new T;class Wa extends Nt{constructor(e=new Tt,n=new Ga){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=n,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,n){const i=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,o=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),zo.copy(i.boundingSphere),zo.applyMatrix4(s),zo.radius+=r,e.ray.intersectsSphere(zo)===!1)return;nh.copy(s).invert(),Su.copy(e.ray).applyMatrix4(nh);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=i.index,d=i.attributes.position;if(l!==null){const f=Math.max(0,o.start),h=Math.min(l.count,o.start+o.count);for(let p=f,v=h;p<v;p++){const g=l.getX(p);Ho.fromBufferAttribute(d,g),ih(Ho,g,c,s,e,n,this)}}else{const f=Math.max(0,o.start),h=Math.min(d.count,o.start+o.count);for(let p=f,v=h;p<v;p++)Ho.fromBufferAttribute(d,p),ih(Ho,p,c,s,e,n,this)}}updateMorphTargets(){const n=this.geometry.morphAttributes,i=Object.keys(n);if(i.length>0){const s=n[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function ih(t,e,n,i,s,r,o){const a=Su.distanceSqToPoint(t);if(a<n){const c=new T;Su.closestPointToPoint(t,c),c.applyMatrix4(i);const l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(a),point:c,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}class Vn{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,n){const i=this.getUtoTmapping(e);return this.getPoint(i,n)}getPoints(e=5){const n=[];for(let i=0;i<=e;i++)n.push(this.getPoint(i/e));return n}getSpacedPoints(e=5){const n=[];for(let i=0;i<=e;i++)n.push(this.getPointAt(i/e));return n}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const n=[];let i,s=this.getPoint(0),r=0;n.push(0);for(let o=1;o<=e;o++)i=this.getPoint(o/e),r+=i.distanceTo(s),n.push(r),s=i;return this.cacheArcLengths=n,n}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,n){const i=this.getLengths();let s=0;const r=i.length;let o;n?o=n:o=e*i[r-1];let a=0,c=r-1,l;for(;a<=c;)if(s=Math.floor(a+(c-a)/2),l=i[s]-o,l<0)a=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,i[s]===o)return s/(r-1);const u=i[s],f=i[s+1]-u,h=(o-u)/f;return(s+h)/(r-1)}getTangent(e,n){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const o=this.getPoint(s),a=this.getPoint(r),c=n||(o.isVector2?new fe:new T);return c.copy(a).sub(o).normalize(),c}getTangentAt(e,n){const i=this.getUtoTmapping(e);return this.getTangent(i,n)}computeFrenetFrames(e,n){const i=new T,s=[],r=[],o=[],a=new T,c=new Qe;for(let h=0;h<=e;h++){const p=h/e;s[h]=this.getTangentAt(p,new T)}r[0]=new T,o[0]=new T;let l=Number.MAX_VALUE;const u=Math.abs(s[0].x),d=Math.abs(s[0].y),f=Math.abs(s[0].z);u<=l&&(l=u,i.set(1,0,0)),d<=l&&(l=d,i.set(0,1,0)),f<=l&&i.set(0,0,1),a.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let h=1;h<=e;h++){if(r[h]=r[h-1].clone(),o[h]=o[h-1].clone(),a.crossVectors(s[h-1],s[h]),a.length()>Number.EPSILON){a.normalize();const p=Math.acos(Mt(s[h-1].dot(s[h]),-1,1));r[h].applyMatrix4(c.makeRotationAxis(a,p))}o[h].crossVectors(s[h],r[h])}if(n===!0){let h=Math.acos(Mt(r[0].dot(r[e]),-1,1));h/=e,s[0].dot(a.crossVectors(r[0],r[e]))>0&&(h=-h);for(let p=1;p<=e;p++)r[p].applyMatrix4(c.makeRotationAxis(s[p],h*p)),o[p].crossVectors(s[p],r[p])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class id extends Vn{constructor(e=0,n=0,i=1,s=1,r=0,o=Math.PI*2,a=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=n,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=c}getPoint(e,n=new fe){const i=n,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);const a=this.aStartAngle+e*r;let c=this.aX+this.xRadius*Math.cos(a),l=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){const u=Math.cos(this.aRotation),d=Math.sin(this.aRotation),f=c-this.aX,h=l-this.aY;c=f*u-h*d+this.aX,l=f*d+h*u+this.aY}return i.set(c,l)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class E1 extends id{constructor(e,n,i,s,r,o){super(e,n,i,i,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}}function sd(){let t=0,e=0,n=0,i=0;function s(r,o,a,c){t=r,e=a,n=-3*r+3*o-2*a-c,i=2*r-2*o+a+c}return{initCatmullRom:function(r,o,a,c,l){s(o,a,l*(a-r),l*(c-o))},initNonuniformCatmullRom:function(r,o,a,c,l,u,d){let f=(o-r)/l-(a-r)/(l+u)+(a-o)/u,h=(a-o)/u-(c-o)/(u+d)+(c-a)/d;f*=u,h*=u,s(o,a,f,h)},calc:function(r){const o=r*r,a=o*r;return t+e*r+n*o+i*a}}}const Go=new T,Ic=new sd,Nc=new sd,Uc=new sd;class w1 extends Vn{constructor(e=[],n=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=n,this.curveType=i,this.tension=s}getPoint(e,n=new T){const i=n,s=this.points,r=s.length,o=(r-(this.closed?0:1))*e;let a=Math.floor(o),c=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:c===0&&a===r-1&&(a=r-2,c=1);let l,u;this.closed||a>0?l=s[(a-1)%r]:(Go.subVectors(s[0],s[1]).add(s[0]),l=Go);const d=s[a%r],f=s[(a+1)%r];if(this.closed||a+2<r?u=s[(a+2)%r]:(Go.subVectors(s[r-1],s[r-2]).add(s[r-1]),u=Go),this.curveType==="centripetal"||this.curveType==="chordal"){const h=this.curveType==="chordal"?.5:.25;let p=Math.pow(l.distanceToSquared(d),h),v=Math.pow(d.distanceToSquared(f),h),g=Math.pow(f.distanceToSquared(u),h);v<1e-4&&(v=1),p<1e-4&&(p=v),g<1e-4&&(g=v),Ic.initNonuniformCatmullRom(l.x,d.x,f.x,u.x,p,v,g),Nc.initNonuniformCatmullRom(l.y,d.y,f.y,u.y,p,v,g),Uc.initNonuniformCatmullRom(l.z,d.z,f.z,u.z,p,v,g)}else this.curveType==="catmullrom"&&(Ic.initCatmullRom(l.x,d.x,f.x,u.x,this.tension),Nc.initCatmullRom(l.y,d.y,f.y,u.y,this.tension),Uc.initCatmullRom(l.z,d.z,f.z,u.z,this.tension));return i.set(Ic.calc(c),Nc.calc(c),Uc.calc(c)),i}copy(e){super.copy(e),this.points=[];for(let n=0,i=e.points.length;n<i;n++){const s=e.points[n];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let n=0,i=this.points.length;n<i;n++){const s=this.points[n];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let n=0,i=e.points.length;n<i;n++){const s=e.points[n];this.points.push(new T().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function sh(t,e,n,i,s){const r=(i-e)*.5,o=(s-n)*.5,a=t*t,c=t*a;return(2*n-2*i+r+o)*c+(-3*n+3*i-2*r-o)*a+r*t+n}function T1(t,e){const n=1-t;return n*n*e}function A1(t,e){return 2*(1-t)*t*e}function R1(t,e){return t*t*e}function Wr(t,e,n,i){return T1(t,e)+A1(t,n)+R1(t,i)}function C1(t,e){const n=1-t;return n*n*n*e}function P1(t,e){const n=1-t;return 3*n*n*t*e}function L1(t,e){return 3*(1-t)*t*t*e}function D1(t,e){return t*t*t*e}function Vr(t,e,n,i,s){return C1(t,e)+P1(t,n)+L1(t,i)+D1(t,s)}class Um extends Vn{constructor(e=new fe,n=new fe,i=new fe,s=new fe){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=n,this.v2=i,this.v3=s}getPoint(e,n=new fe){const i=n,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return i.set(Vr(e,s.x,r.x,o.x,a.x),Vr(e,s.y,r.y,o.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class I1 extends Vn{constructor(e=new T,n=new T,i=new T,s=new T){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=n,this.v2=i,this.v3=s}getPoint(e,n=new T){const i=n,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return i.set(Vr(e,s.x,r.x,o.x,a.x),Vr(e,s.y,r.y,o.y,a.y),Vr(e,s.z,r.z,o.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class km extends Vn{constructor(e=new fe,n=new fe){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=n}getPoint(e,n=new fe){const i=n;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,n){return this.getPoint(e,n)}getTangent(e,n=new fe){return n.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,n){return this.getTangent(e,n)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class N1 extends Vn{constructor(e=new T,n=new T){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=n}getPoint(e,n=new T){const i=n;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,n){return this.getPoint(e,n)}getTangent(e,n=new T){return n.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,n){return this.getTangent(e,n)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Fm extends Vn{constructor(e=new fe,n=new fe,i=new fe){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=n,this.v2=i}getPoint(e,n=new fe){const i=n,s=this.v0,r=this.v1,o=this.v2;return i.set(Wr(e,s.x,r.x,o.x),Wr(e,s.y,r.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class U1 extends Vn{constructor(e=new T,n=new T,i=new T){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=n,this.v2=i}getPoint(e,n=new T){const i=n,s=this.v0,r=this.v1,o=this.v2;return i.set(Wr(e,s.x,r.x,o.x),Wr(e,s.y,r.y,o.y),Wr(e,s.z,r.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Om extends Vn{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,n=new fe){const i=n,s=this.points,r=(s.length-1)*e,o=Math.floor(r),a=r-o,c=s[o===0?o:o-1],l=s[o],u=s[o>s.length-2?s.length-1:o+1],d=s[o>s.length-3?s.length-1:o+2];return i.set(sh(a,c.x,l.x,u.x,d.x),sh(a,c.y,l.y,u.y,d.y)),i}copy(e){super.copy(e),this.points=[];for(let n=0,i=e.points.length;n<i;n++){const s=e.points[n];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let n=0,i=this.points.length;n<i;n++){const s=this.points[n];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let n=0,i=e.points.length;n<i;n++){const s=e.points[n];this.points.push(new fe().fromArray(s))}return this}}var rh=Object.freeze({__proto__:null,ArcCurve:E1,CatmullRomCurve3:w1,CubicBezierCurve:Um,CubicBezierCurve3:I1,EllipseCurve:id,LineCurve:km,LineCurve3:N1,QuadraticBezierCurve:Fm,QuadraticBezierCurve3:U1,SplineCurve:Om});class k1 extends Vn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),n=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(n)){const i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new rh[i](n,e))}return this}getPoint(e,n){const i=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=i){const o=s[r]-i,a=this.curves[r],c=a.getLength(),l=c===0?0:1-o/c;return a.getPointAt(l,n)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let n=0;for(let i=0,s=this.curves.length;i<s;i++)n+=this.curves[i].getLength(),e.push(n);return this.cacheLengths=e,e}getSpacedPoints(e=40){const n=[];for(let i=0;i<=e;i++)n.push(this.getPoint(i/e));return this.autoClose&&n.push(n[0]),n}getPoints(e=12){const n=[];let i;for(let s=0,r=this.curves;s<r.length;s++){const o=r[s],a=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,c=o.getPoints(a);for(let l=0;l<c.length;l++){const u=c[l];i&&i.equals(u)||(n.push(u),i=u)}}return this.autoClose&&n.length>1&&!n[n.length-1].equals(n[0])&&n.push(n[0]),n}copy(e){super.copy(e),this.curves=[];for(let n=0,i=e.curves.length;n<i;n++){const s=e.curves[n];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let n=0,i=this.curves.length;n<i;n++){const s=this.curves[n];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let n=0,i=e.curves.length;n<i;n++){const s=e.curves[n];this.curves.push(new rh[s.type]().fromJSON(s))}return this}}class F1 extends k1{constructor(e){super(),this.type="Path",this.currentPoint=new fe,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let n=1,i=e.length;n<i;n++)this.lineTo(e[n].x,e[n].y);return this}moveTo(e,n){return this.currentPoint.set(e,n),this}lineTo(e,n){const i=new km(this.currentPoint.clone(),new fe(e,n));return this.curves.push(i),this.currentPoint.set(e,n),this}quadraticCurveTo(e,n,i,s){const r=new Fm(this.currentPoint.clone(),new fe(e,n),new fe(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(e,n,i,s,r,o){const a=new Um(this.currentPoint.clone(),new fe(e,n),new fe(i,s),new fe(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(e){const n=[this.currentPoint.clone()].concat(e),i=new Om(n);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,n,i,s,r,o){const a=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(e+a,n+c,i,s,r,o),this}absarc(e,n,i,s,r,o){return this.absellipse(e,n,i,i,s,r,o),this}ellipse(e,n,i,s,r,o,a,c){const l=this.currentPoint.x,u=this.currentPoint.y;return this.absellipse(e+l,n+u,i,s,r,o,a,c),this}absellipse(e,n,i,s,r,o,a,c){const l=new id(e,n,i,s,r,o,a,c);if(this.curves.length>0){const d=l.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(l);const u=l.getPoint(1);return this.currentPoint.copy(u),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class rd extends Tt{constructor(e=[new fe(0,-.5),new fe(.5,0),new fe(0,.5)],n=12,i=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:n,phiStart:i,phiLength:s},n=Math.floor(n),s=Mt(s,0,Math.PI*2);const r=[],o=[],a=[],c=[],l=[],u=1/n,d=new T,f=new fe,h=new T,p=new T,v=new T;let g=0,m=0;for(let S=0;S<=e.length-1;S++)switch(S){case 0:g=e[S+1].x-e[S].x,m=e[S+1].y-e[S].y,h.x=m*1,h.y=-g,h.z=m*0,v.copy(h),h.normalize(),c.push(h.x,h.y,h.z);break;case e.length-1:c.push(v.x,v.y,v.z);break;default:g=e[S+1].x-e[S].x,m=e[S+1].y-e[S].y,h.x=m*1,h.y=-g,h.z=m*0,p.copy(h),h.x+=v.x,h.y+=v.y,h.z+=v.z,h.normalize(),c.push(h.x,h.y,h.z),v.copy(p)}for(let S=0;S<=n;S++){const _=i+S*u*s,y=Math.sin(_),D=Math.cos(_);for(let E=0;E<=e.length-1;E++){d.x=e[E].x*y,d.y=e[E].y,d.z=e[E].x*D,o.push(d.x,d.y,d.z),f.x=S/n,f.y=E/(e.length-1),a.push(f.x,f.y);const A=c[3*E+0]*y,P=c[3*E+1],b=c[3*E+0]*D;l.push(A,P,b)}}for(let S=0;S<n;S++)for(let _=0;_<e.length-1;_++){const y=_+S*e.length,D=y,E=y+e.length,A=y+e.length+1,P=y+1;r.push(D,E,P),r.push(A,P,E)}this.setIndex(r),this.setAttribute("position",new vt(o,3)),this.setAttribute("uv",new vt(a,2)),this.setAttribute("normal",new vt(l,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new rd(e.points,e.segments,e.phiStart,e.phiLength)}}class od extends rd{constructor(e=1,n=1,i=4,s=8){const r=new F1;r.absarc(0,-n/2,e,Math.PI*1.5,0),r.absarc(0,n/2,e,0,Math.PI*.5),super(r.getPoints(i),s),this.type="CapsuleGeometry",this.parameters={radius:e,length:n,capSegments:i,radialSegments:s}}static fromJSON(e){return new od(e.radius,e.length,e.capSegments,e.radialSegments)}}class is extends Tt{constructor(e=1,n=1,i=1,s=32,r=1,o=!1,a=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:n,height:i,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:c};const l=this;s=Math.floor(s),r=Math.floor(r);const u=[],d=[],f=[],h=[];let p=0;const v=[],g=i/2;let m=0;S(),o===!1&&(e>0&&_(!0),n>0&&_(!1)),this.setIndex(u),this.setAttribute("position",new vt(d,3)),this.setAttribute("normal",new vt(f,3)),this.setAttribute("uv",new vt(h,2));function S(){const y=new T,D=new T;let E=0;const A=(n-e)/i;for(let P=0;P<=r;P++){const b=[],x=P/r,L=x*(n-e)+e;for(let B=0;B<=s;B++){const F=B/s,G=F*c+a,$=Math.sin(G),X=Math.cos(G);D.x=L*$,D.y=-x*i+g,D.z=L*X,d.push(D.x,D.y,D.z),y.set($,A,X).normalize(),f.push(y.x,y.y,y.z),h.push(F,1-x),b.push(p++)}v.push(b)}for(let P=0;P<s;P++)for(let b=0;b<r;b++){const x=v[b][P],L=v[b+1][P],B=v[b+1][P+1],F=v[b][P+1];(e>0||b!==0)&&(u.push(x,L,F),E+=3),(n>0||b!==r-1)&&(u.push(L,B,F),E+=3)}l.addGroup(m,E,0),m+=E}function _(y){const D=p,E=new fe,A=new T;let P=0;const b=y===!0?e:n,x=y===!0?1:-1;for(let B=1;B<=s;B++)d.push(0,g*x,0),f.push(0,x,0),h.push(.5,.5),p++;const L=p;for(let B=0;B<=s;B++){const G=B/s*c+a,$=Math.cos(G),X=Math.sin(G);A.x=b*X,A.y=g*x,A.z=b*$,d.push(A.x,A.y,A.z),f.push(0,x,0),E.x=$*.5+.5,E.y=X*.5*x+.5,h.push(E.x,E.y),p++}for(let B=0;B<s;B++){const F=D+B,G=L+B;y===!0?u.push(G,G+1,F):u.push(G+1,G,F),P+=3}l.addGroup(m,P,y===!0?1:2),m+=P}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new is(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class no extends is{constructor(e=1,n=1,i=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,e,n,i,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:e,height:n,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(e){return new no(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class yn extends Tt{constructor(e=1,n=32,i=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:n,heightSegments:i,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},n=Math.max(3,Math.floor(n)),i=Math.max(2,Math.floor(i));const c=Math.min(o+a,Math.PI);let l=0;const u=[],d=new T,f=new T,h=[],p=[],v=[],g=[];for(let m=0;m<=i;m++){const S=[],_=m/i;let y=0;m===0&&o===0?y=.5/n:m===i&&c===Math.PI&&(y=-.5/n);for(let D=0;D<=n;D++){const E=D/n;d.x=-e*Math.cos(s+E*r)*Math.sin(o+_*a),d.y=e*Math.cos(o+_*a),d.z=e*Math.sin(s+E*r)*Math.sin(o+_*a),p.push(d.x,d.y,d.z),f.copy(d).normalize(),v.push(f.x,f.y,f.z),g.push(E+y,1-_),S.push(l++)}u.push(S)}for(let m=0;m<i;m++)for(let S=0;S<n;S++){const _=u[m][S+1],y=u[m][S],D=u[m+1][S],E=u[m+1][S+1];(m!==0||o>0)&&h.push(_,y,E),(m!==i-1||c<Math.PI)&&h.push(y,D,E)}this.setIndex(h),this.setAttribute("position",new vt(p,3)),this.setAttribute("normal",new vt(v,3)),this.setAttribute("uv",new vt(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new yn(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Va extends Tt{constructor(e=1,n=.4,i=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:n,radialSegments:i,tubularSegments:s,arc:r},i=Math.floor(i),s=Math.floor(s);const o=[],a=[],c=[],l=[],u=new T,d=new T,f=new T;for(let h=0;h<=i;h++)for(let p=0;p<=s;p++){const v=p/s*r,g=h/i*Math.PI*2;d.x=(e+n*Math.cos(g))*Math.cos(v),d.y=(e+n*Math.cos(g))*Math.sin(v),d.z=n*Math.sin(g),a.push(d.x,d.y,d.z),u.x=e*Math.cos(v),u.y=e*Math.sin(v),f.subVectors(d,u).normalize(),c.push(f.x,f.y,f.z),l.push(p/s),l.push(h/i)}for(let h=1;h<=i;h++)for(let p=1;p<=s;p++){const v=(s+1)*h+p-1,g=(s+1)*(h-1)+p-1,m=(s+1)*(h-1)+p,S=(s+1)*h+p;o.push(v,g,S),o.push(g,m,S)}this.setIndex(o),this.setAttribute("position",new vt(a,3)),this.setAttribute("normal",new vt(c,3)),this.setAttribute("uv",new vt(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Va(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class O1 extends Tt{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){const n=[],i=new Set,s=new T,r=new T;if(e.index!==null){const o=e.attributes.position,a=e.index;let c=e.groups;c.length===0&&(c=[{start:0,count:a.count,materialIndex:0}]);for(let l=0,u=c.length;l<u;++l){const d=c[l],f=d.start,h=d.count;for(let p=f,v=f+h;p<v;p+=3)for(let g=0;g<3;g++){const m=a.getX(p+g),S=a.getX(p+(g+1)%3);s.fromBufferAttribute(o,m),r.fromBufferAttribute(o,S),oh(s,r,i)===!0&&(n.push(s.x,s.y,s.z),n.push(r.x,r.y,r.z))}}}else{const o=e.attributes.position;for(let a=0,c=o.count/3;a<c;a++)for(let l=0;l<3;l++){const u=3*a+l,d=3*a+(l+1)%3;s.fromBufferAttribute(o,u),r.fromBufferAttribute(o,d),oh(s,r,i)===!0&&(n.push(s.x,s.y,s.z),n.push(r.x,r.y,r.z))}}this.setAttribute("position",new vt(n,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}function oh(t,e,n){const i=`${t.x},${t.y},${t.z}-${e.x},${e.y},${e.z}`,s=`${e.x},${e.y},${e.z}-${t.x},${t.y},${t.z}`;return n.has(i)===!0||n.has(s)===!0?!1:(n.add(i),n.add(s),!0)}class B1 extends hr{static get type(){return"MeshPhongMaterial"}constructor(e){super(),this.isMeshPhongMaterial=!0,this.color=new J(16777215),this.specular=new J(1118481),this.shininess=30,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new J(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=fm,this.normalScale=new fe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Dn,this.combine=Xu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.specular.copy(e.specular),this.shininess=e.shininess,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class $a extends Nt{constructor(e,n=1){super(),this.isLight=!0,this.type="Light",this.color=new J(e),this.intensity=n}dispose(){}copy(e,n){return super.copy(e,n),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const n=super.toJSON(e);return n.object.color=this.color.getHex(),n.object.intensity=this.intensity,this.groundColor!==void 0&&(n.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(n.object.distance=this.distance),this.angle!==void 0&&(n.object.angle=this.angle),this.decay!==void 0&&(n.object.decay=this.decay),this.penumbra!==void 0&&(n.object.penumbra=this.penumbra),this.shadow!==void 0&&(n.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(n.object.target=this.target.uuid),n}}const kc=new Qe,ah=new T,ch=new T;class Bm{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new fe(512,512),this.map=null,this.mapPass=null,this.matrix=new Qe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new td,this._frameExtents=new fe(1,1),this._viewportCount=1,this._viewports=[new qe(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const n=this.camera,i=this.matrix;ah.setFromMatrixPosition(e.matrixWorld),n.position.copy(ah),ch.setFromMatrixPosition(e.target.matrixWorld),n.lookAt(ch),n.updateMatrixWorld(),kc.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(kc),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(kc)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const lh=new Qe,Tr=new T,Fc=new T;class z1 extends Bm{constructor(){super(new $t(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new fe(4,2),this._viewportCount=6,this._viewports=[new qe(2,1,1,1),new qe(0,1,1,1),new qe(3,1,1,1),new qe(1,1,1,1),new qe(3,0,1,1),new qe(1,0,1,1)],this._cubeDirections=[new T(1,0,0),new T(-1,0,0),new T(0,0,1),new T(0,0,-1),new T(0,1,0),new T(0,-1,0)],this._cubeUps=[new T(0,1,0),new T(0,1,0),new T(0,1,0),new T(0,1,0),new T(0,0,1),new T(0,0,-1)]}updateMatrices(e,n=0){const i=this.camera,s=this.matrix,r=e.distance||i.far;r!==i.far&&(i.far=r,i.updateProjectionMatrix()),Tr.setFromMatrixPosition(e.matrixWorld),i.position.copy(Tr),Fc.copy(i.position),Fc.add(this._cubeDirections[n]),i.up.copy(this._cubeUps[n]),i.lookAt(Fc),i.updateMatrixWorld(),s.makeTranslation(-Tr.x,-Tr.y,-Tr.z),lh.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(lh)}}class io extends $a{constructor(e,n,i=0,s=2){super(e,n),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=s,this.shadow=new z1}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,n){return super.copy(e,n),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class H1 extends Bm{constructor(){super(new Rm(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class zm extends $a{constructor(e,n){super(e,n),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Nt.DEFAULT_UP),this.updateMatrix(),this.target=new Nt,this.shadow=new H1}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class G1 extends $a{constructor(e,n){super(e,n),this.isAmbientLight=!0,this.type="AmbientLight"}}class W1 extends Tt{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){const e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}}class _u extends M1{constructor(e,n,i=1){super(e,n),this.isInstancedInterleavedBuffer=!0,this.meshPerAttribute=i}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}clone(e){const n=super.clone(e);return n.meshPerAttribute=this.meshPerAttribute,n}toJSON(e){const n=super.toJSON(e);return n.isInstancedInterleavedBuffer=!0,n.meshPerAttribute=this.meshPerAttribute,n}}const uh=new T,Wo=new T;class V1{constructor(e=new T,n=new T){this.start=e,this.end=n}set(e,n){return this.start.copy(e),this.end.copy(n),this}copy(e){return this.start.copy(e.start),this.end.copy(e.end),this}getCenter(e){return e.addVectors(this.start,this.end).multiplyScalar(.5)}delta(e){return e.subVectors(this.end,this.start)}distanceSq(){return this.start.distanceToSquared(this.end)}distance(){return this.start.distanceTo(this.end)}at(e,n){return this.delta(n).multiplyScalar(e).add(this.start)}closestPointToPointParameter(e,n){uh.subVectors(e,this.start),Wo.subVectors(this.end,this.start);const i=Wo.dot(Wo);let r=Wo.dot(uh)/i;return n&&(r=Mt(r,0,1)),r}closestPointToPoint(e,n,i){const s=this.closestPointToPointParameter(e,n);return this.delta(i).multiplyScalar(s).add(this.start)}applyMatrix4(e){return this.start.applyMatrix4(e),this.end.applyMatrix4(e),this}equals(e){return e.start.equals(this.start)&&e.end.equals(this.end)}clone(){return new this.constructor().copy(this)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:$u}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=$u);var Wn=(t=>(t.InProgress="inProgress",t.Victory="victory",t.Defeat="defeat",t))(Wn||{}),ze=(t=>(t[t.Player=0]="Player",t[t.Enemy=1]="Enemy",t[t.Neutral=2]="Neutral",t))(ze||{});function $1(){return{pitchUp:!1,pitchDown:!1,yawLeft:!1,yawRight:!1,rollLeft:!1,rollRight:!1,accelerate:!1,decelerate:!1,afterburner:!1,firePrimary:!1,fireSecondary:!1,launchDecoy:!1,cyclePrimary:!1,cycleSecondary:!1,cycleTargetNext:!1,cycleTargetPrev:!1,targetNearest:!1,toggleMatchSpeed:!1}}function X1(t=0){return{entities:new Set,components:new Map,nextEntityId:1,toRemove:new Set,systemState:{gameTime:0,weapons:{prevInput:{cyclePrimary:!1,cycleSecondary:!1,fireSecondary:!1,launchDecoy:!1},lastDecoyFireTime:0},targeting:{prevInput:{cycleTargetNext:!1,cycleTargetPrev:!1,targetNearest:!1}},flightAssist:{prevInput:{toggleMatchSpeed:!1}},beams:{activeBeams:new Map,prevFireState:new Map},mission:{result:Wn.InProgress},shipIdentity:{callsignCounters:{}},projectileHits:{pending:[]},pools:{beamWeapon:0,collidable:0,targetCollector:0}},prng:eo(t)}}const q1=9007199254740991;function ai(t){if(t.nextEntityId>=q1)throw new Error("Entity ID overflow - too many entities created");const e=t.nextEntityId++;return t.entities.add(e),t.components.set(e,new Map),e}function ss(t,e){t.toRemove.add(e)}function kt(t,e){return t.entities.has(e)&&!t.toRemove.has(e)}function Hm(t){for(const e of t.toRemove)t.entities.delete(e),t.components.delete(e);t.toRemove.clear()}function de(t,e,n){const i=t.components.get(e);if(!i)throw new Error(`Entity ${e} does not exist`);i.set(n.type,n)}function C(t,e,n){const i=t.components.get(e);if(i)return i.get(n)}function Ke(t,e,n){const i=t.components.get(e);return i?i.has(n):!1}function ad(t,e,n){const i=t.components.get(e);if(!i)return!1;for(let s=0;s<n.length;s++)if(!i.has(n[s]))return!1;return!0}function*Te(t,e){for(const n of t.entities)ad(t,n,e)&&(yield n)}function Y1(t,e){let n=0;for(const i of t.entities)ad(t,i,e)&&n++;return n}function Gm(t,e){for(const n of t.entities)if(ad(t,n,e))return n}function mr(t,e){return Ke(t,e,"collision")&&!Ke(t,e,"projectile")&&!Ke(t,e,"missile")}const xu={frameRateCap:60},Wm=[{value:30,label:"30 FPS"},{value:60,label:"60 FPS"},{value:120,label:"120 FPS"},{value:0,label:"Uncapped"}],Vm="spaceflight_settings";let ir={...xu};function j1(){const t=eE();t?ir={...xu,...t}:ir={...xu}}function K1(){return ir.frameRateCap}function Z1(t){ir.frameRateCap=t,J1()}function J1(){try{localStorage.setItem(Vm,JSON.stringify(ir))}catch(t){console.error("Failed to save game settings:",t)}}function Q1(t){return t===30||t===60||t===120||t===0}function eE(){try{const t=localStorage.getItem(Vm);if(!t)return null;const e=JSON.parse(t);if(!e||typeof e!="object")return console.warn("Invalid game settings format in storage"),null;const n=e,i={};return"frameRateCap"in n&&Q1(n.frameRateCap)&&(i.frameRateCap=n.frameRateCap),Object.keys(i).length>0?i:null}catch{return console.warn("Failed to parse game settings from storage"),null}}function tE(){const t=ir.frameRateCap;return t===0?0:1e3/t}var Be=(t=>(t.Idle="idle",t.Pursue="pursue",t.Engage="engage",t.Evade="evade",t.Regroup="regroup",t.Reposition="reposition",t))(Be||{});function $m(t,e,n){const s={type:"aiControlled",state:"idle",target:null,stateTimer:0,lastStateChange:0,lastDecoyTime:0,lastRepositionTime:0,profile:t,input:{pitch:0,yaw:0,roll:0,accelerate:!1,decelerate:!1,afterburner:!1}};return e!==void 0&&(s.preferredCombatRange=e),n!==void 0&&(s.fleeDistance=n),s}function as(t){return{type:"faction",faction:t}}function gr(t,e){return t===ze.Neutral||e===ze.Neutral?!1:t!==e}function so(t,e){return{type:"health",hull:e??t,maxHull:t}}function xt(t){return t.hull<=0}function nE(t,e){const n=Math.min(t.hull,e);return t.hull-=n,n}const iE={rookie:0,regular:.33,veteran:.66,ace:1};function sE(t){return 4-t*3}function rE(t){return .7+t*.4}function Xm(t,e){const n=oE(t),i=iE[t.toLowerCase()]??.33;switch(e){case"escape":{const s=3-i*2;return{...n,aimErrorBase:n.aimErrorBase*s,aimErrorDriftSpeed:n.aimErrorDriftSpeed*s,evadeShieldThreshold:.25,regroupShieldThreshold:.12,heatSwitchThreshold:.8,linkedFireHeatThreshold:.7,minFiringAngle:35,combatRangeMultiplier:1,evadeCooldown:2.5,regroupMinTime:2}}case"kiting":{const s=sE(i),r=rE(i);return{...n,aimErrorBase:n.aimErrorBase*s,aimErrorDriftSpeed:n.aimErrorDriftSpeed*s,evadeShieldThreshold:.25,regroupShieldThreshold:.12,combatRangeMultiplier:r,fleeDistanceMultiplier:1,heatSwitchThreshold:.8,linkedFireHeatThreshold:.7,minFiringAngle:30,repositionCooldown:4,maxRepositionTime:4}}default:return n}}const dh={green:{name:"Green",aimErrorBase:.14,aimErrorDriftSpeed:.06,aimErrorAngularFactor:.9,beamTrackingSpeed:.5,engageRange:400,breakOffRange:800,combatRangeMultiplier:.6,heatSwitchThreshold:.98,minFiringAngle:60,linkedFireHeatThreshold:.9,evadeShieldThreshold:.45,regroupShieldThreshold:.25,recoverShieldThreshold:.8,evadeCooldown:2,regroupMinTime:1.5,decoyCooldown:5,burstDuration:4,repositionCooldown:8,maxRepositionTime:8,fleeDistanceMultiplier:.6},rookie:{name:"Rookie",aimErrorBase:.095,aimErrorDriftSpeed:.04,aimErrorAngularFactor:.68,beamTrackingSpeed:.8,engageRange:500,breakOffRange:1e3,combatRangeMultiplier:.8,heatSwitchThreshold:.95,minFiringAngle:45,linkedFireHeatThreshold:.8,evadeShieldThreshold:.31,regroupShieldThreshold:.17,recoverShieldThreshold:.7,evadeCooldown:3,regroupMinTime:2,decoyCooldown:3.5,burstDuration:3,repositionCooldown:6,maxRepositionTime:6,fleeDistanceMultiplier:.8},regular:{name:"Regular",aimErrorBase:.05,aimErrorDriftSpeed:.02,aimErrorAngularFactor:.5,beamTrackingSpeed:1.5,engageRange:600,breakOffRange:1200,combatRangeMultiplier:1,heatSwitchThreshold:.75,minFiringAngle:24,linkedFireHeatThreshold:.6,evadeShieldThreshold:.25,regroupShieldThreshold:.12,recoverShieldThreshold:.55,evadeCooldown:5,regroupMinTime:3,decoyCooldown:2,burstDuration:2.5,repositionCooldown:5,maxRepositionTime:5,fleeDistanceMultiplier:.9},veteran:{name:"Veteran",aimErrorBase:.032,aimErrorDriftSpeed:.016,aimErrorAngularFactor:.3,beamTrackingSpeed:2.5,engageRange:700,breakOffRange:1400,combatRangeMultiplier:1.15,heatSwitchThreshold:.65,minFiringAngle:18,linkedFireHeatThreshold:.5,evadeShieldThreshold:.2,regroupShieldThreshold:.09,recoverShieldThreshold:.45,evadeCooldown:6,regroupMinTime:3.5,decoyCooldown:1.4,burstDuration:2,repositionCooldown:4,maxRepositionTime:4,fleeDistanceMultiplier:1},ace:{name:"Ace",aimErrorBase:.008,aimErrorDriftSpeed:.008,aimErrorAngularFactor:.06,beamTrackingSpeed:4,engageRange:800,breakOffRange:1600,combatRangeMultiplier:1.3,heatSwitchThreshold:.5,minFiringAngle:14,linkedFireHeatThreshold:.35,evadeShieldThreshold:.12,regroupShieldThreshold:.05,recoverShieldThreshold:.3,evadeCooldown:7,regroupMinTime:4,decoyCooldown:.5,burstDuration:1.5,repositionCooldown:3,maxRepositionTime:3,fleeDistanceMultiplier:1.1}};function oE(t){const e=t.toLowerCase(),n=dh[e];return n||dh.regular}const aE={maxEngagingPlayer:3},qm=.9,cE=.95,Ym=.5,lE=.95;function cd(t,e){return{type:"heat",current:0,max:t,coolingRate:e,weaponsLocked:!1}}function ro(t){return t.current/t.max}function uE(t){return Math.min(1,t.current/t.max)}function dE(t){return ro(t)>=qm}function Xa(t,e){return t.weaponsLocked?!1:(t.current=Math.min(t.max,t.current+e),t.current>=t.max&&(t.weaponsLocked=!0),!0)}function fE(t,e){t.current+=e,t.current>=t.max&&(t.weaponsLocked=!0)}function hE(t,e){t.current=Math.max(0,t.current-t.coolingRate*e),t.weaponsLocked&&ro(t)<=lE&&(t.weaponsLocked=!1)}const Oc=new T,pE=new T(1,0,0),mE=new T(0,1,0),fh=new at,hh=new at;function gE(t){const e=ft(t)*Math.PI*2;return new fe(Math.cos(e),Math.sin(e))}function vE(t,e){const n=ft(e)*Math.PI*2;t.set(Math.cos(n),Math.sin(n))}function jm(t,e,n){let i,s,r;typeof e=="object"?(i=e.aimErrorBase,s=e.aimErrorDriftSpeed,r=e.aimErrorAngularFactor):(i=e??.05,s=.02,r=.5);const o=ft(t)*Math.PI*2,a=ft(t)*i;return{type:"aimError",offset:new fe(Math.cos(o)*a,Math.sin(o)*a),maxError:i,effectiveMaxError:i,angularFactor:r,driftSpeed:s,driftDirection:gE(t),driftTimer:Km(t),currentAngularVelocity:0}}function Km(t){return zr(t,.5,2)}function yE(t,e){t.currentAngularVelocity=e;const n=Math.min(t.angularFactor*e,.3);t.effectiveMaxError=t.maxError+n}function SE(t,e,n){t.driftTimer-=n,t.driftTimer<=0&&(vE(t.driftDirection,e),t.driftTimer=Km(e)),t.offset.x+=t.driftDirection.x*t.driftSpeed*n,t.offset.y+=t.driftDirection.y*t.driftSpeed*n;const i=t.offset.length();i>t.effectiveMaxError&&t.offset.multiplyScalar(t.effectiveMaxError/i)}function ld(t,e){return Oc.copy(t),fh.setFromAxisAngle(pE,e.offset.x),hh.setFromAxisAngle(mE,e.offset.y),Oc.applyQuaternion(fh).applyQuaternion(hh),Oc.normalize()}const cs={toTarget:new T,forward:new T,rotationAxis:new T,localUp:new T,escapeDir:new T,leadPoint:new T,localDir:new T,inverseRot:new at},_E=Math.PI/180,ph=10*_E,mh=5;function xE(t,e,n){const{localDir:i,inverseRot:s}=cs;s.copy(e.rotation).invert(),i.copy(n).applyQuaternion(s);const r=Math.atan2(-i.x,-i.z),o=Math.asin(Math.max(-1,Math.min(1,i.y)));t.input.yaw=gh(r),t.input.pitch=gh(o),t.input.roll=0}function gh(t){return Math.abs(t)<ph?t/ph:t>0?1:-1}const Zm=.95,bE=.9,ME=1.3,EE=1.1,wE=.7,TE=.3,AE=.6,RE=.4;function Hn(t){return t.fleeDistance!==void 0}function sr(t,e,n){xE(t,e,n)}function Jm(t,e,n,i,s,r,o){const a=r??C(t,e,"primaryWeapons"),c=o??C(t,e,"aimError");if(a!=null&&a.hasBeams&&c){const l=ld(s,c);sr(n,i,l)}else sr(n,i,s)}function Qm(t,e,n,i){const{localUp:s,escapeDir:r}=cs;return s.set(0,1,0),r.crossVectors(t,s),r.lengthSq()<.001?r.set(1,0,0):r.normalize(),e.dot(r)<0&&r.negate(),r.multiplyScalar(n).addScaledVector(t,i).normalize(),r}function jr(t,e,n,i=!1){e.currentSpeed<n-mh?(t.input.accelerate=!0,t.input.decelerate=!1,t.input.afterburner=i&&n>e.maxSpeed):e.currentSpeed>n+mh?(t.input.accelerate=!1,t.input.decelerate=!0,t.input.afterburner=!1):(t.input.accelerate=!1,t.input.decelerate=!1,t.input.afterburner=!1)}function CE(t){t.input.accelerate=!1,t.input.decelerate=!0,t.input.afterburner=!1}const PE=500;function LE(t,e){return t?t.current/t.max<e.evadeShieldThreshold:!1}function eg(t,e){return Hn(t)?e<t.fleeDistance:!1}function DE(t,e,n){const i=t&&t.current/t.max<n.regroupShieldThreshold,s=e&&dE(e);return!!(i||s)}function IE(t,e,n){const i=!t||t.current/t.max>=n.recoverShieldThreshold,s=!e||ro(e)<=Ym;return i&&s}function NE(t,e,n,i,s,r,o,a){const c=n.profile,{toTarget:l,forward:u}=cs;if(Hn(n)&&n.target&&kt(t,n.target)){const h=C(t,n.target,"transform");if(h){const p=i.position.distanceTo(h.position),v=n.preferredCombatRange??c.engageRange;if(p>=v*Zm){n.state=Be.Engage,n.stateTimer=0,s.isAfterburning=!1;return}}}if(!Hn(n)){const h=!r||r.current/r.max>=c.evadeShieldThreshold;if(n.stateTimer>=c.evadeCooldown&&h){n.state=n.target?Be.Pursue:Be.Idle,n.stateTimer=0,s.isAfterburning=!1;return}}if(n.target&&kt(t,n.target)){const h=C(t,n.target,"transform");if(h&&(l.copy(i.position).sub(h.position),l.lengthSq()>.001))if(l.normalize(),Hn(n))sr(n,i,l);else{u.set(0,0,-1).applyQuaternion(i.rotation);const p=Qm(l,u,wE,TE);sr(n,i,p)}}if(!Hn(n)){const h=Math.sin(n.stateTimer*8);n.input.roll=h}const d=!s.afterburnerLocked,f=s.maxSpeed*s.afterburnerMultiplier;d?jr(n,s,f,!0):jr(n,s,s.maxSpeed)}function UE(t,e,n,i,s,r,o,a){const c=n.profile,{toTarget:l,localUp:u}=cs;if(n.stateTimer>=c.regroupMinTime&&IE(r,o,c)){n.state=n.target?Be.Pursue:Be.Idle,n.stateTimer=0;return}if(n.target&&kt(t,n.target)){const d=C(t,n.target,"transform");d&&(l.copy(i.position).sub(d.position),l.lengthSq()>.001&&(l.normalize(),u.set(0,1,0).applyQuaternion(i.rotation),l.addScaledVector(u,.3),l.normalize(),sr(n,i,l)))}jr(n,s,s.maxSpeed*.7)}const Vo=new T,$o=new T,kE=new T;function vr(t,e,n,i,s){Vo.copy(n).sub(t),$o.copy(i).sub(e);const r=$o.dot($o)-s*s,o=2*Vo.dot($o),a=Vo.dot(Vo);let c;if(Math.abs(r)<1e-4){if(Math.abs(o)<1e-4||(c=-a/o,c<=0))return}else{const l=o*o-4*r*a;if(l<0)return;const u=Math.sqrt(l),d=(-o+u)/(2*r),f=(-o-u)/(2*r);if(d>0&&f>0)c=Math.min(d,f);else if(d>0)c=d;else if(f>0)c=f;else return}return c=Math.min(c,5),kE.copy(n).addScaledVector(i,c)}function tg(t,e){const n=C(t,e,"primaryWeapons");if(n){for(const i of n.weapons)if(i&&i.category!=="beam")return i.projectileSpeed}return PE}function ng(t,e,n,i,s,r,o=!1){const{toTarget:a,leadPoint:c}=cs,l=C(t,n.target,"transform");if(!l){n.target=null;return}const u=C(t,e,"primaryWeapons"),d=C(t,e,"aimError");let f=l.position;if(!o&&u&&!u.hasOnlyBeams){const p=C(t,n.target,"physics"),v=d&&d.currentAngularVelocity>.15;if(p&&!v){const g=tg(t,e),m=vr(i.position,s.velocity,l.position,p.velocity,g);m&&(c.copy(m),f=c)}}a.copy(f).sub(i.position),a.lengthSq()>.001&&(a.normalize(),Jm(t,e,n,i,a,u,d)),jr(n,s,s.maxSpeed)}function FE(t,e,n,i,s,r){const{toTarget:o,leadPoint:a}=cs,c=C(t,n.target,"transform");if(!c)return;const l=C(t,e,"primaryWeapons"),u=C(t,e,"aimError");let d=c.position;if(l&&!l.hasOnlyBeams){const f=C(t,n.target,"physics");if(f){const h=tg(t,e),p=vr(i.position,s.velocity,c.position,f.velocity,h);p&&(a.copy(p),d=a)}}o.copy(d).sub(i.position),o.lengthSq()>.001&&(o.normalize(),Jm(t,e,n,i,o,l,u)),CE(n)}function OE(t,e){if(t.preferredCombatRange===void 0||Hn(t))return!1;const n=t.profile;return!(t.preferredCombatRange<=n.engageRange*ME||t.stateTimer<n.burstDuration||e>=t.preferredCombatRange*bE)}function BE(t,e,n,i,s,r){const o=n.profile,{toTarget:a,forward:c}=cs;if(!n.target||!kt(t,n.target)){n.target=null,n.state=Be.Idle,n.stateTimer=0;return}const l=C(t,n.target,"transform");if(!l){n.target=null,n.state=Be.Idle,n.stateTimer=0;return}const u=i.position.distanceTo(l.position),d=n.preferredCombatRange??o.engageRange;if(u>=d*Zm||n.stateTimer>=o.maxRepositionTime){n.state=Be.Engage,n.stateTimer=0;return}if(u>o.breakOffRange){n.state=Be.Pursue,n.stateTimer=0;return}if(a.copy(i.position).sub(l.position),a.lengthSq()>.001){a.normalize(),c.set(0,0,-1).applyQuaternion(i.rotation);const h=Qm(a,c,AE,RE);sr(n,i,h)}const f=s.maxSpeed*s.afterburnerMultiplier;jr(n,s,f*.8,!0)}function zE(t,e){let n=0;for(const i of Te(t,["aiControlled"])){const s=C(t,i,"aiControlled");s.state===Be.Engage&&s.target===e&&n++}return n}function HE(t,e){return C(t,e,"playerControlled")!==void 0}function GE(t){for(const e of Te(t,["playerControlled","transform"]))return e;return null}function WE(t,e,n){const i=GE(t);if(!i)return null;const s=C(t,e,"transform");if(!s)return null;let r=null,o=1/0;for(const a of Te(t,["aiControlled","transform","faction","health"])){const c=C(t,a,"faction");if(!c||!gr(n,c.faction))continue;const l=C(t,a,"health");if(!l||xt(l))continue;const u=C(t,a,"aiControlled");if(u.target!==i||u.state!==Be.Pursue&&u.state!==Be.Engage)continue;const d=C(t,a,"transform"),f=s.position.distanceTo(d.position);f<o&&(o=f,r=a)}return r}function VE(t,e,n){let i=null,s=1/0;const r=C(t,e,"transform");if(!r)return null;for(const o of Te(t,["transform","faction","health"])){if(o===e)continue;const a=C(t,o,"health");if(a&&xt(a))continue;const c=C(t,o,"faction");if(!c||!gr(n,c.faction))continue;const l=C(t,o,"transform"),u=r.position.distanceTo(l.position);u<s&&(s=u,i=o)}return i}function $E(t,e){for(const n of Te(t,["aiControlled","transform","physics","faction"])){const i=C(t,n,"health");if(i&&xt(i))continue;const s=C(t,n,"aiControlled"),r=C(t,n,"transform"),o=C(t,n,"physics"),a=C(t,n,"faction");s.input.pitch=0,s.input.yaw=0,s.input.roll=0,s.input.accelerate=!1,s.input.decelerate=!1,s.input.afterburner=!1,s.stateTimer+=e;const c=C(t,n,"shields"),l=C(t,n,"heat");switch((s.state===Be.Pursue||s.state===Be.Engage)&&(DE(c,l,s.profile)?(s.state=Be.Regroup,s.stateTimer=0):LE(c,s.profile)&&(s.state=Be.Evade,s.stateTimer=0)),s.state){case Be.Idle:XE(t,n,s,a.faction);break;case Be.Pursue:qE(t,n,s,r,o);break;case Be.Engage:YE(t,n,s,r,o,e);break;case Be.Evade:NE(t,n,s,r,o,c);break;case Be.Regroup:UE(t,n,s,r,o,c,l);break;case Be.Reposition:BE(t,n,s,r,o);break}}}function XE(t,e,n,i){let s=null;i===ze.Player&&(s=WE(t,e,i)),s===null&&(s=VE(t,e,i)),s!==null&&(n.target=s,n.state=Be.Pursue,n.stateTimer=0)}function qE(t,e,n,i,s,r){if(n.target===null||!kt(t,n.target)){n.target=null,n.state=Be.Idle,n.stateTimer=0;return}const o=C(t,n.target,"transform");if(!o){n.target=null,n.state=Be.Idle,n.stateTimer=0;return}const a=i.position.distanceTo(o.position);if(eg(n,a)){n.state=Be.Evade,n.stateTimer=0;return}const c=Hn(n)?n.preferredCombatRange??n.profile.engageRange:n.profile.engageRange;a<=c&&(!HE(t,n.target)||zE(t,n.target)<aE.maxEngagingPlayer)&&(n.state=Be.Engage,n.stateTimer=0),ng(t,e,n,i,s)}function YE(t,e,n,i,s,r){if(n.target===null||!kt(t,n.target)){n.target=null,n.state=Be.Idle,n.stateTimer=0;return}const o=C(t,n.target,"transform");if(!o){n.target=null,n.state=Be.Idle,n.stateTimer=0;return}const a=i.position.distanceTo(o.position);if(!Hn(n)&&a>n.profile.breakOffRange){n.state=Be.Pursue,n.stateTimer=0;return}if(eg(n,a)){n.state=Be.Evade,n.stateTimer=0;return}if(OE(n,a)){n.state=Be.Reposition,n.stateTimer=0;return}const c=n.preferredCombatRange??n.profile.engageRange,l=!Hn(n)&&a>c*EE;Hn(n)?FE(t,e,n,i,s):ng(t,e,n,i,s,r,l)}const Ar=new T,vh=new T;function jE(t,e,n){Ar.copy(e).sub(t);const i=Ar.length();if(i<1)return 0;Ar.divideScalar(i);const s=n.dot(Ar);return vh.copy(n).addScaledVector(Ar,-s),vh.length()/i}function KE(t,e){for(const n of Te(t,["aimError"])){const i=C(t,n,"aimError"),s=C(t,n,"aiControlled"),r=C(t,n,"transform");let o=0;if(s!=null&&s.target&&kt(t,s.target)&&r){const a=C(t,s.target,"transform"),c=C(t,s.target,"physics");a&&c&&(o=jE(r.position,a.position,c.velocity))}yE(i,o),SE(i,t.prng,e)}}const ZE=.8,JE=2;function bu(t,e=new J(16737792),n,i="standard"){const s={type:"explosion",age:0,maxAge:i==="nuke"?JE:ZE,size:t,color:e,variant:i};return n!==void 0&&(s.sourceEntity=n),s}function QE(t){return Math.min(1,t.age/t.maxAge)}function ew(t){return t.age>=t.maxAge}function ci(t=0,e=0,n=0,i){return{type:"transform",position:new T(t,e,n),rotation:(i==null?void 0:i.clone())??new at}}function tw(t,e,n=!1){return{weaponName:t,category:e,shotsFired:0,shotsOnTarget:0,timeFired:0,timeOnTarget:0,isPulseBeam:n,ammoCarried:0,missilesLaunched:0,missilesHit:0,missilesSeduced:0,decoysCarried:0,decoysDeployed:0,missilesSeducedByDecoy:0,damageDealt:0}}function ud(){return{type:"combatStats",kills:0,assists:0,damageDealt:0,damageReceived:0,weaponStats:new Map}}function rn(t,e,n,i=!1){let s=t.weaponStats.get(e);return s?i&&!s.isPulseBeam&&(console.warn(`WeaponStats for "${e}" created with isPulseBeam=false but later called with isPulseBeam=true. Check call order.`),s.isPulseBeam=!0):(s=tw(e,n,i),t.weaponStats.set(e,s)),s}function ig(t){return{kills:t.kills,assists:t.assists,damageDealt:t.damageDealt,damageReceived:t.damageReceived,weaponStats:Array.from(t.weaponStats.values())}}const nw=5;function ls(t=nw){return{type:"collision",collidedWith:[],radius:t}}const Sn={rocket:{name:"Rocket",requiresLock:!1,speed:600,turnRate:0,range:1e3,damage:50,fireRate:.5,lockSpeed:0,lockConeAngle:60,capacity:12},cluster:{name:"Cluster",requiresLock:!1,speed:400,turnRate:60,range:1200,damage:25,fireRate:.8,lockSpeed:0,lockConeAngle:60,capacity:10},seeker:{name:"Seeker",requiresLock:!0,speed:400,turnRate:90,range:2e3,damage:60,fireRate:1,lockSpeed:.25,lockConeAngle:60,capacity:8},dart:{name:"Dart",requiresLock:!0,speed:600,turnRate:120,range:800,damage:30,fireRate:.5,lockSpeed:.5,lockConeAngle:60,capacity:10},swarm:{name:"Swarm",requiresLock:!0,speed:500,turnRate:100,range:600,damage:10,fireRate:.1,lockSpeed:.4,lockConeAngle:60,capacity:20},torpedo:{name:"Torpedo",requiresLock:!0,speed:200,turnRate:30,range:4e3,damage:150,fireRate:2,lockSpeed:.15,lockConeAngle:60,capacity:4},nuke:{name:"Nuke",requiresLock:!0,speed:150,turnRate:20,range:3e3,damage:300,fireRate:3,lockSpeed:.1,lockConeAngle:60,capacity:2,aoeRadius:100,isNuke:!0},decoy:{name:"Decoy",requiresLock:!1,speed:50,turnRate:0,range:0,damage:0,fireRate:.5,lockSpeed:0,lockConeAngle:60,capacity:6,isDecoy:!0}};function Di(t){const e=Sn[t.toLowerCase()];return(e==null?void 0:e.name)??t}function iw(t,e,n,i,s,r,o,a=0,c=!1,l="seeker"){return{type:"missile",owner:t,target:e,damage:n,speed:i,turnRate:s*Math.PI/180,range:r,distanceTraveled:0,direction:o.clone().normalize(),aoeRadius:a,isNuke:c,missileType:l,resistedDecoys:new Set}}function sw(t){return t.distanceTraveled>=t.range}const rw=Sn;function ow(t,e,n=1){const i=rw[t];if(!i)throw new Error(`Unknown missile: ${t}`);const s=e*n;return{...i,count:s,maxCount:s,bankSize:n}}function dd(t){return{type:"physics",velocity:new T,maxSpeed:t.maxSpeed??250,acceleration:t.acceleration??100,drag:t.drag??.5,turnRate:t.turnRate??100,rollRate:t.rollRate??150,currentSpeed:t.initialSpeed??0,afterburnerMultiplier:t.afterburnerMultiplier??1.5,afterburnerHeatRate:t.afterburnerHeatRate??50,isAfterburning:!1,afterburnerLocked:!1,angularVelocity:new T,angularAcceleration:t.angularAcceleration??800,prevPosition:new T,prevRotation:new at,prevVelocity:new T}}const rr=50;function fd(t,e,n){const i=new T(0,0,-1).applyQuaternion(e);t.velocity.copy(i).multiplyScalar(n),t.currentSpeed=n}function aw(){return{type:"playerControlled",input:$1(),matchSpeed:!1,prevTargetDistance:0,prevMatchSpeedTarget:void 0}}const yh=4,sg=.3;function hd(){return{type:"shieldHit",hits:[],writeIndex:0}}function cw(t,e,n,i,s){const r=Math.min(1,n/(i*.25));if(t.hits.length<yh)t.hits.push({position:e.clone(),intensity:r,time:s});else{const o=t.hits[t.writeIndex];o.position.copy(e),o.intensity=r,o.time=s,t.writeIndex=(t.writeIndex+1)%yh}}function lw(t,e){return t.hits.filter(n=>e-n.time<sg)}const uw=8;function pd(t,e,n){return{type:"shields",current:t,max:t,regenRate:e,regenDelay:n,lastDamageTime:-1/0,ionizedUntil:-1/0}}function dw(t,e,n){if(t.lastDamageTime=n,t.current>=e)return t.current-=e,0;const i=e-t.current;return t.current=0,i}function rg(t,e){return e<t.ionizedUntil}function og(t,e){t.ionizedUntil=e+uw}function fw(t,e,n){if(t.current>=t.max)return;const i=rg(t,e)?t.regenDelay*2:t.regenDelay;e-t.lastDamageTime<i||(t.current=Math.min(t.max,t.current+t.regenRate*n))}const Sh=["Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"];function hw(t){const e=t%Sh.length;return Sh[e]}function pw(t,e){const n=t.systemState.shipIdentity.callsignCounters,i=(n[e]??0)+1;return n[e]=i,`${e} ${i}`}function md(t,e,n){const i={type:"shipIdentity",archetype:t,callsign:e};return n!==void 0&&(i.campaignShipId=n),i}function mw(){return{type:"targeting",currentTarget:void 0,validTargets:[],targetIndex:-1}}const bt={plasma:{name:"Plasma",category:"energy",heatPerShot:5,projectileSpeed:600,fireRate:.125,range:800,damage:16},pulse:{name:"Pulse",category:"energy",heatPerShot:5,projectileSpeed:600,fireRate:.1,range:500,damage:12},ion:{name:"Ion",category:"energy",heatPerShot:6,projectileSpeed:600,fireRate:.18,range:700,damage:10,ionize:!0},autocannon:{name:"Autocannon",category:"ballistic",heatPerShot:1,projectileSpeed:500,fireRate:.065,range:400,damage:9,ammo:200,ammoName:"Autocannon Rounds"},railgun:{name:"Railgun",category:"ballistic",heatPerShot:3,projectileSpeed:2e3,fireRate:1,range:2e3,damage:80,ammo:20,ammoName:"Railgun Slugs",autoaimFov:2},flak:{name:"Flak",category:"ballistic",heatPerShot:4,projectileSpeed:350,fireRate:.25,range:600,damage:30,ammo:50,ammoName:"Flak Shells",flakRadius:100,shrapnelCount:8},redLaser:{name:"Red Laser",category:"beam",heatPerShot:15,projectileSpeed:0,fireRate:0,range:400,damage:120},greenLaser:{name:"Green Laser",category:"beam",heatPerShot:12,projectileSpeed:0,fireRate:0,range:800,damage:80},blueLaser:{name:"Blue Laser",category:"beam",heatPerShot:10,projectileSpeed:0,fireRate:0,range:1200,damage:50},lightning:{name:"Lightning",category:"beam",heatPerShot:2,projectileSpeed:0,fireRate:0,range:300,damage:5,isPulseBeam:!0,pulseInterval:.1,noFalloff:!0,autoaimFov:5},torch:{name:"Torch",listName:"Torch",category:"beam",heatPerShot:25,projectileSpeed:0,fireRate:0,range:200,damage:30,heatInjection:35,noFalloff:!0},nuclearLance:{name:"Nuclear Lance",listName:"Nuke Lance",category:"beam",heatPerShot:30,projectileSpeed:0,fireRate:.5,range:3e3,damage:500,ammo:1,ammoName:"Nuclear Lance Charges",noFalloff:!0,isInstantBeam:!0,autoaimFov:2}};function gw(t){return bt[t]}function gd(t){const e=bt[t];return(e==null?void 0:e.name)??t}function es(t){const e=bt[t];return e?e.ammoName??e.name:t}const vw=bt;function ag(t){var s;const e=t.map((r,o)=>String(o));let n=0;for(const r of t)r.isInstantBeam||n++;n>=2&&e.push("all");let i=e.indexOf("all");if(i===-1){for(let r=0;r<t.length;r++)if(!((s=t[r])!=null&&s.isInstantBeam)){i=r;break}i===-1&&(i=0)}return{linkModes:e,defaultLinkMode:i}}function yw(t){const e=t.map(r=>{const o=typeof r=="string"?r:r.name,a=typeof r=="string"?1:r.size,c=vw[o];if(!c)throw new Error(`Unknown weapon: ${o}`);const l="ammo"in c?c.ammo:void 0;if(l!==void 0){const u=l*a;return{...c,bankSize:a,ammo:u,maxAmmo:u}}return{...c,bankSize:a}});let n=0;for(const r of e)r.category==="beam"&&n++;const{linkModes:i,defaultLinkMode:s}=ag(e);return{type:"primaryWeapons",weapons:e,currentIndex:0,lastFireTime:0,linkMode:s,linkModes:i,hasBeams:n>0,hasOnlyBeams:n===e.length}}function us(t){return t.heatPerShot/t.bankSize}function Sw(t){return{type:"secondaryWeapons",weapons:t,currentIndex:0,lastFireTime:0,lockTarget:void 0,lockProgress:0,lockWeaponIndex:-1}}function vd(t){return t.weapons[t.currentIndex]}function cg(t){t.linkModes.length>0&&(t.linkMode=(t.linkMode+1)%t.linkModes.length)}function _w(t){t.weapons.length>1&&(t.currentIndex=(t.currentIndex+1)%t.weapons.length,t.lockProgress=0,t.lockWeaponIndex=-1)}function lg(t){return t.linkModes[t.linkMode]??"all"}function oo(t){var i;const e=lg(t);if(e==="all"){const s=[];for(let r=0;r<t.weapons.length;r++)(i=t.weapons[r])!=null&&i.isInstantBeam||s.push(r);return s}const n=Number.parseInt(e,10);return!Number.isNaN(n)&&n>=0&&n<t.weapons.length?[n]:[]}function _h(t,e){const n=t.linkModes.indexOf(e);n>=0&&(t.linkMode=n)}function ug(t){for(let e=0;e<t.weapons.length;e++){const n=t.weapons[e];if(n.isDecoy&&n.count>0)return{index:e,weapon:n}}}const Wt={patrol:{hull:45,shields:45,shieldRegen:5,shieldDelay:3,maxSpeed:90,acceleration:45,turnRate:80,rollRate:120,collisionRadius:5,maxHeat:90,coolingRate:18,afterburnerHeatRate:40,primaryBanks:[1,1],secondaryBanks:[1],primaryHardpoints:[{row:0,x:.3,svgX:12,svgY:32},{row:0,x:.7,svgX:52,svgY:32}],secondaryHardpoints:[{row:0,x:.5,svgX:32,svgY:46}]},scout:{hull:55,shields:35,shieldRegen:8,shieldDelay:2,maxSpeed:150,acceleration:75,turnRate:120,rollRate:180,collisionRadius:4,maxHeat:80,coolingRate:15,afterburnerHeatRate:25,primaryBanks:[1,1],secondaryBanks:[1],primaryHardpoints:[{row:0,x:.35,svgX:20,svgY:28},{row:0,x:.65,svgX:44,svgY:28}],secondaryHardpoints:[{row:0,x:.5,svgX:32,svgY:48}]},fighter:{hull:90,shields:65,shieldRegen:10,shieldDelay:3,maxSpeed:125,acceleration:50,turnRate:100,rollRate:150,collisionRadius:5,maxHeat:100,coolingRate:18,afterburnerHeatRate:40,primaryBanks:[1,1],secondaryBanks:[1,1],primaryHardpoints:[{row:0,x:.25,svgX:8,svgY:36},{row:0,x:.75,svgX:56,svgY:36}],secondaryHardpoints:[{row:0,x:.35,svgX:16,svgY:38},{row:0,x:.65,svgX:48,svgY:38}]},interceptor:{hull:75,shields:50,shieldRegen:9,shieldDelay:2.5,maxSpeed:138,acceleration:62,turnRate:110,rollRate:165,collisionRadius:5,maxHeat:90,coolingRate:16,afterburnerHeatRate:32,primaryBanks:[2,2],secondaryBanks:[1,2,1],primaryHardpoints:[{row:0,x:.2,svgX:6,svgY:44},{row:0,x:.8,svgX:58,svgY:44}],secondaryHardpoints:[{row:0,x:.25,svgX:18,svgY:44},{row:0,x:.5,svgX:32,svgY:50},{row:0,x:.75,svgX:46,svgY:44}]},striker:{hull:130,shields:90,shieldRegen:12,shieldDelay:3,maxSpeed:100,acceleration:40,turnRate:80,rollRate:120,collisionRadius:6,maxHeat:150,coolingRate:25,afterburnerHeatRate:60,primaryBanks:[2,2,2,1,1],secondaryBanks:[1],primaryHardpoints:[{row:2,x:.15,svgX:8,svgY:32},{row:0,x:.5,svgX:32,svgY:16},{row:2,x:.85,svgX:56,svgY:32},{row:1,x:.35,svgX:22,svgY:24},{row:1,x:.65,svgX:42,svgY:24}],secondaryHardpoints:[{row:0,x:.5,svgX:32,svgY:48}]},bomber:{hull:110,shields:80,shieldRegen:10,shieldDelay:3,maxSpeed:90,acceleration:35,turnRate:75,rollRate:110,collisionRadius:7,maxHeat:80,coolingRate:12,afterburnerHeatRate:55,primaryBanks:[2],secondaryBanks:[2,2,2,1,1,1,1],primaryHardpoints:[{row:1,x:.5,svgX:32,svgY:20}],secondaryHardpoints:[{row:0,x:.15,svgX:10,svgY:26},{row:2,x:.5,svgX:32,svgY:32},{row:0,x:.85,svgX:56,svgY:26},{row:2,x:.2,svgX:10,svgY:38},{row:1,x:.35,svgX:20,svgY:44},{row:1,x:.65,svgX:44,svgY:44},{row:2,x:.8,svgX:56,svgY:38}]},defender:{hull:165,shields:130,shieldRegen:18,shieldDelay:2.5,maxSpeed:90,acceleration:35,turnRate:70,rollRate:100,collisionRadius:7,maxHeat:100,coolingRate:18,afterburnerHeatRate:50,primaryBanks:[2,2],secondaryBanks:[2,2,1,1,1],primaryHardpoints:[{row:0,x:.3,svgX:16,svgY:14},{row:0,x:.7,svgX:48,svgY:14}],secondaryHardpoints:[{row:0,x:.2,svgX:10,svgY:32},{row:2,x:.5,svgX:32,svgY:48},{row:0,x:.8,svgX:54,svgY:32},{row:1,x:.35,svgX:16,svgY:50},{row:1,x:.65,svgX:48,svgY:50}]},raider:{hull:65,shields:45,shieldRegen:6,shieldDelay:4,maxSpeed:140,acceleration:60,turnRate:110,rollRate:160,collisionRadius:5,maxHeat:140,coolingRate:22,afterburnerHeatRate:35,primaryBanks:[3,3,1,1],secondaryBanks:[1,1,1],primaryHardpoints:[{row:0,x:.275,svgX:24,svgY:12},{row:0,x:.725,svgX:40,svgY:12},{row:1,x:.1,svgX:10,svgY:16},{row:1,x:.9,svgX:54,svgY:16}],secondaryHardpoints:[{row:0,x:.25,svgX:16,svgY:28},{row:1,x:.5,svgX:32,svgY:44},{row:0,x:.75,svgX:48,svgY:28}]},sentinel:{hull:110,shields:110,shieldRegen:15,shieldDelay:3,maxSpeed:100,acceleration:45,turnRate:90,rollRate:130,collisionRadius:6,maxHeat:130,coolingRate:22,afterburnerHeatRate:45,primaryBanks:[3,2,2],secondaryBanks:[2,2,1],primaryHardpoints:[{row:0,x:.25,svgX:16,svgY:32},{row:0,x:.5,svgX:32,svgY:12},{row:0,x:.75,svgX:48,svgY:32}],secondaryHardpoints:[{row:0,x:.3,svgX:16,svgY:36},{row:0,x:.5,svgX:32,svgY:52},{row:0,x:.7,svgX:48,svgY:36}]}};function xh(t,e){const n=Wt[t];if(!n)throw new Error(`Unknown ship class: ${t}`);return{...n,...e,shipClassName:t}}const dg={firefly:xh("patrol",{playstyle:"escape",primaryWeapons:[{name:"redLaser",size:1},{name:"redLaser",size:1}],secondaryWeapons:[{name:"dart",count:4,size:1}],preferredCombatRange:300}),dragonfly:xh("patrol",{playstyle:"escape",primaryWeapons:[{name:"pulse",size:1},{name:"pulse",size:1}],secondaryWeapons:[{name:"dart",count:4,size:1}]})};function un(t,e){const n=Wt[t];if(!n)throw new Error(`Unknown ship class: ${t}`);return{...n,...e,shipClassName:t}}const fg={fighter:un("fighter",{primaryWeapons:[{name:"plasma",size:1},{name:"plasma",size:1}],secondaryWeapons:[{name:"seeker",count:8,size:1},{name:"decoy",count:6,size:1}]}),scout:un("scout",{playstyle:"escape",primaryWeapons:[{name:"pulse",size:1},{name:"redLaser",size:1}],secondaryWeapons:[{name:"dart",count:6,size:1}]}),interceptor:un("interceptor",{primaryWeapons:[{name:"greenLaser",size:2},{name:"greenLaser",size:2}],secondaryWeapons:[{name:"seeker",count:8,size:1},{name:"rocket",count:6,size:2},{name:"decoy",count:4,size:1}]}),striker:un("striker",{primaryWeapons:[{name:"plasma",size:2},{name:"autocannon",size:2},{name:"greenLaser",size:2},{name:"pulse",size:1},{name:"pulse",size:1}],secondaryWeapons:[{name:"rocket",count:4,size:1}]}),bomber:un("bomber",{primaryWeapons:[{name:"plasma",size:2}],secondaryWeapons:[{name:"torpedo",count:4,size:2},{name:"seeker",count:8,size:2},{name:"seeker",count:8,size:2},{name:"rocket",count:6,size:1},{name:"rocket",count:6,size:1},{name:"dart",count:4,size:1},{name:"decoy",count:4,size:1}]}),defender:un("defender",{primaryWeapons:[{name:"plasma",size:2},{name:"greenLaser",size:2}],secondaryWeapons:[{name:"seeker",count:8,size:2},{name:"seeker",count:8,size:2},{name:"rocket",count:6,size:1},{name:"dart",count:4,size:1},{name:"decoy",count:4,size:1}]}),raider:un("raider",{primaryWeapons:[{name:"plasma",size:3},{name:"autocannon",size:3},{name:"pulse",size:1},{name:"pulse",size:1}],secondaryWeapons:[{name:"dart",count:2,size:1},{name:"rocket",count:2,size:1},{name:"decoy",count:4,size:1}]}),sentinel:un("sentinel",{primaryWeapons:[{name:"redLaser",size:3},{name:"redLaser",size:2},{name:"redLaser",size:1}],secondaryWeapons:[{name:"seeker",count:4,size:2},{name:"torpedo",count:2,size:2},{name:"decoy",count:4,size:1}]}),sniper:un("raider",{playstyle:"kiting",primaryWeapons:[{name:"railgun",size:2},{name:"railgun",size:2}],secondaryWeapons:[{name:"decoy",count:4,size:1}],preferredCombatRange:900,fleeDistance:400}),lancer:un("sentinel",{playstyle:"brawler",primaryWeapons:[{name:"greenLaser",size:3},{name:"greenLaser",size:2},{name:"greenLaser",size:2}],secondaryWeapons:[{name:"dart",count:4,size:1},{name:"decoy",count:4,size:1}],preferredCombatRange:400}),lancerBlue:un("sentinel",{playstyle:"brawler",primaryWeapons:[{name:"blueLaser",size:3},{name:"blueLaser",size:2},{name:"blueLaser",size:2}],secondaryWeapons:[{name:"dart",count:4,size:1},{name:"decoy",count:4,size:1}],preferredCombatRange:450}),lancerRed:un("sentinel",{playstyle:"brawler",primaryWeapons:[{name:"redLaser",size:3},{name:"redLaser",size:2},{name:"redLaser",size:2}],secondaryWeapons:[{name:"dart",count:4,size:1},{name:"decoy",count:4,size:1}],preferredCombatRange:300})};function xw(t){const e=fg[t]??dg[t];if(!e)return;const n=e.shipClassName,i=Wt[n];if(!i)throw new Error(`Archetype '${t}' references unknown ship class: ${n}`);for(let s=0;s<e.primaryWeapons.length;s++){const r=e.primaryWeapons[s];if(r&&!bt[r.name])throw new Error(`Archetype '${t}' primary bank ${s} references unknown weapon: ${r.name}`);if(s>=i.primaryBanks.length)throw new Error(`Archetype '${t}' has ${e.primaryWeapons.length} primary weapons but ship class '${n}' only has ${i.primaryBanks.length} primary banks`);const o=i.primaryBanks[s];if(r&&r.size>o)throw new Error(`Archetype '${t}' primary bank ${s} has size ${r.size} weapon but ship class '${n}' bank ${s} only supports size ${o}`)}if(e.secondaryWeapons)for(let s=0;s<e.secondaryWeapons.length;s++){const r=e.secondaryWeapons[s];if(r&&!Sn[r.name])throw new Error(`Archetype '${t}' secondary bank ${s} references unknown missile: ${r.name}`);if(s>=i.secondaryBanks.length)throw new Error(`Archetype '${t}' has ${e.secondaryWeapons.length} secondary weapons but ship class '${n}' only has ${i.secondaryBanks.length} secondary banks`);const o=i.secondaryBanks[s];if(r&&r.size>o)throw new Error(`Archetype '${t}' secondary bank ${s} has size ${r.size} missile but ship class '${n}' bank ${s} only supports size ${o}`)}}function yd(t){return fg[t]??dg[t]}function bw(t){if(t.preferredCombatRange!==void 0)return t.preferredCombatRange;let e=1/0;for(const n of t.primaryWeapons){const i=gw(n.name);i&&i.range>0&&i.range<e&&(e=i.range)}return e===1/0?600:Math.floor(e*.9)}function hg(t,e,n,i,s,r="regular",o){const a=yd(e);if(!a)throw new Error(`Unknown ship archetype: ${e}`);xw(e);const c=ai(t),l=s??new at;de(t,c,ci((i==null?void 0:i.x)??0,(i==null?void 0:i.y)??0,(i==null?void 0:i.z)??0,l)),de(t,c,dd({maxSpeed:a.maxSpeed,acceleration:a.acceleration,turnRate:a.turnRate,rollRate:a.rollRate,afterburnerHeatRate:a.afterburnerHeatRate,initialSpeed:rr}));const u=C(t,c,"physics");u&&fd(u,l,rr),de(t,c,so(a.hull)),de(t,c,pd(a.shields,a.shieldRegen,a.shieldDelay)),de(t,c,hd()),de(t,c,as(n));const d=o??(n===ze.Player?"Alpha":"Bandit"),f=pw(t,d);de(t,c,md(e,f));const h=a.playstyle??"brawler",p=Xm(r,h),v=bw(a),g=Math.floor(v*p.combatRangeMultiplier),m=a.fleeDistance?Math.floor(a.fleeDistance*p.fleeDistanceMultiplier):void 0,S=$m(p,g,m);if(de(t,c,S),de(t,c,jm(t.prng,p)),de(t,c,cd(a.maxHeat,a.coolingRate)),de(t,c,yw(a.primaryWeapons)),a.secondaryWeapons&&a.secondaryWeapons.length>0){const _=a.secondaryWeapons.map(y=>ow(y.name,y.count,y.size));de(t,c,Sw(_))}return de(t,c,ls(a.collisionRadius*1.5)),de(t,c,ud()),_d(t,c),c}function Mw(t,e,n,i,s="regular",r){return hg(t,e,ze.Enemy,n,i,s,r)}function Sd(t,e,n,i="projectile",s=!1){const r=C(t,e,"combatStats");if(r){const o=rn(r,n,i,s);o.shotsFired++}}function pg(t,e,n,i="projectile",s=!1){const r=C(t,e,"combatStats");if(r){const o=rn(r,n,i,s);o.shotsOnTarget++}}function Ew(t,e,n,i){const s=C(t,e,"combatStats");if(s){const r=rn(s,n,"beam");r.timeFired+=i}}function ww(t,e,n,i){const s=C(t,e,"combatStats");if(s){const r=rn(s,n,"beam");r.timeOnTarget+=i}}function Tw(t,e,n){const i=C(t,e,"combatStats");if(i){const s=rn(i,n,"missile");s.missilesLaunched++}}function Aw(t,e,n){const i=C(t,e,"combatStats");if(i){const s=rn(i,n,"missile");s.missilesHit++}}function Rw(t,e,n,i){const s=C(t,e,"combatStats");if(s){const o=rn(s,n,"missile");o.missilesSeduced++}const r=C(t,i,"combatStats");if(r){const o=rn(r,"Decoy","decoy");o.missilesSeducedByDecoy++}}function Cw(t,e){const n=C(t,e,"combatStats");if(n){const i=rn(n,"Decoy","decoy");i.decoysDeployed++}}function mg(t){t.systemState.matchStats={damageSources:new Map,lastDamageSource:new Map,destroyedShips:[],salvageableShips:[],missionStartTime:t.systemState.gameTime,missionEndTime:0}}function Pw(t){t.systemState.matchStats&&(t.systemState.matchStats.missionEndTime=t.systemState.gameTime)}function gg(t){t.systemState.matchStats||mg(t);const e=t.systemState.matchStats;if(!e)throw new Error("matchStats should exist after initialization");return e}function qa(t,e,n,i,s,r,o=!1){if(r<=0)return;const a=gg(t),c=C(t,e,"combatStats");if(c){c.damageDealt+=r;const u=rn(c,i,s,o);u.damageDealt+=r}const l=C(t,n,"combatStats");if(l&&(l.damageReceived+=r),Ke(t,n,"shipIdentity")){let u=a.damageSources.get(n);u||(u=new Set,a.damageSources.set(n,u)),u.add(e),a.lastDamageSource.set(n,e)}}function _d(t,e){const n=C(t,e,"combatStats");if(!n)return;const i=C(t,e,"primaryWeapons");if(i){for(const r of i.weapons)if(r&&r.ammo!==void 0){const o=rn(n,r.name,"projectile");o.ammoCarried=r.ammo}}const s=C(t,e,"secondaryWeapons");if(s){for(const r of s.weapons)if(r)if(r.isDecoy){const o=rn(n,"Decoy","decoy");o.decoysCarried+=r.count}else{const o=rn(n,r.name,"missile");o.ammoCarried+=r.count}}}function Lw(t,e){const n=gg(t),i=t.systemState.gameTime,s=C(t,e,"shipIdentity"),r=C(t,e,"health"),o=C(t,e,"faction"),a=C(t,e,"combatStats"),c=C(t,e,"primaryWeapons"),l=C(t,e,"secondaryWeapons");if(!s||!r)return;const u=n.lastDamageSource.get(e),d=n.damageSources.get(e);if(u!==void 0){const v=C(t,u,"combatStats");if(v)v.kills++;else{const g=n.destroyedShips.find(m=>m.entityId===u);g&&g.stats.kills++}}if(d){for(const v of d)if(v!==u){const g=C(t,v,"combatStats");if(g)g.assists++;else{const m=n.destroyedShips.find(S=>S.entityId===v);m&&m.stats.assists++}}}if(a&&o&&o.faction===ze.Player){const v={entityId:e,archetype:s.archetype,callsign:s.callsign,wasPlayer:Ke(t,e,"playerControlled"),isWingman:!Ke(t,e,"playerControlled")&&o.faction===ze.Player,stats:ig(a),hullMax:r.maxHull,timeOfDeath:i-n.missionStartTime};s.campaignShipId&&(v.campaignShipId=s.campaignShipId),n.destroyedShips.push(v)}const f=yd(s.archetype),p={shipClass:(f==null?void 0:f.shipClassName)??s.archetype,primaryWeapons:[],secondaryWeapons:[]};if(c)for(const v of c.weapons)v&&p.primaryWeapons.push({weaponType:v.name,...v.ammo!==void 0&&{ammoRemaining:v.ammo}});if(l)for(const v of l.weapons)v&&p.secondaryWeapons.push({weaponType:v.name,count:v.count,isDecoy:v.isDecoy??!1});n.salvageableShips.push(p),n.damageSources.delete(e),n.lastDamageSource.delete(e)}const Dw=.15,Iw={[ze.Player]:new J(65382),[ze.Enemy]:new J(16737792),[ze.Neutral]:new J(16776960)};function Nw(t,e){for(const n of Te(t,["health"])){const i=C(t,n,"health");xt(i)&&(mr(t,n)?i.deathDelay===void 0?(Lw(t,n),Uw(t,n),i.deathDelay=Dw):(i.deathDelay-=e,i.deathDelay<=0&&ss(t,n)):ss(t,n))}Hm(t)}function Uw(t,e){const n=C(t,e,"transform");if(!n)return;const i=C(t,e,"collision"),s=C(t,e,"faction"),r=(i==null?void 0:i.radius)??5,o=Iw[(s==null?void 0:s.faction)??ze.Neutral],a=ai(t);de(t,a,ci(n.position.x,n.position.y,n.position.z)),de(t,a,bu(r,o.clone(),e))}const Bc=[];function kw(t,e,n,i){const s=t.systemState.pools.collidable;s>=Bc.length&&Bc.push({entity:0,transform:null,collision:null});const r=Bc[s];return t.systemState.pools.collidable++,r.entity=e,r.transform=n,r.collision=i,r}const As=[];function Fw(t,e){for(const n of Te(t,["collision"])){const i=C(t,n,"collision");i.collidedWith.length=0}t.systemState.pools.collidable=0,As.length=0;for(const n of Te(t,["transform","collision"])){const i=C(t,n,"transform"),s=C(t,n,"collision");As.push(kw(t,n,i,s))}for(let n=0;n<As.length;n++)for(let i=n+1;i<As.length;i++){const s=As[n],r=As[i],o=s.transform.position.distanceTo(r.transform.position),a=s.collision.radius+r.collision.radius;o<a&&(s.collision.collidedWith.push(r.entity),r.collision.collidedWith.push(s.entity))}}const Ow=10;function Bw(t,e){for(const n of Te(t,["health","collision","faction"])){if(Ke(t,n,"missile")||Ke(t,n,"decoy"))continue;const i=C(t,n,"collision"),s=C(t,n,"faction");for(const r of i.collidedWith){const o=C(t,r,"faction");o&&!gr(s.faction,o.faction)||vg(t,n,Ow)}}}function vg(t,e,n,i,s=1,r=1){const o=C(t,e,"shields"),a=C(t,e,"health");let c=n,l=0;if(o&&o.current>0){const d=o.current,f=n*s;if(c=dw(o,f,t.systemState.gameTime),l=d-o.current,c>0&&(c=c/s),l>0&&i){const h=C(t,e,"shieldHit");h&&cw(h,i,l,o.max,t.systemState.gameTime)}}let u=0;if(c>0&&a){const d=c*r;u=nE(a,d)}return{shieldDamage:l,hullDamage:u}}function ao(t,e,n,i,s=1,r=1){return vg(t,e,n,i,s,r)}const yg=50,Sg=10,zw=.5,Hw=200;function Gw(t,e){return{type:"decoy",owner:t,direction:e.clone().normalize(),timeRemaining:Sg}}function Ww(t){return t.timeRemaining<=0}const bh=new T,Mh=new at;function Vw(t,e){const n=[];for(const i of Te(t,["decoy","transform"])){const s=C(t,i,"decoy"),r=C(t,i,"transform");if(s.timeRemaining-=e,Ww(s)){n.push(i);continue}const o=yg*e;r.position.addScaledVector(s.direction,o),bh.set(0,0,-1),Mh.setFromUnitVectors(bh,s.direction),r.rotation.copy(Mh);const a=C(t,i,"collision");if(a&&a.collidedWith.length>0){for(const c of a.collidedWith)if(c!==s.owner&&Ke(t,c,"missile")){ao(t,c,10,r.position),n.push(i);break}}}for(const i of n)ss(t,i)}function $w(t,e){for(const n of Te(t,["explosion","transform"])){const i=C(t,n,"explosion"),s=C(t,n,"transform");if(i.sourceEntity!==void 0&&kt(t,i.sourceEntity)){const r=C(t,i.sourceEntity,"transform");r&&s.position.copy(r.position)}i.age+=e,ew(i)&&ss(t,n)}Hm(t)}function Xw(t,e){for(const n of Te(t,["heat"])){const i=C(t,n,"heat");hE(i,e)}}const ki={pitchUp:"KeyW",pitchDown:"KeyS",yawLeft:"KeyA",yawRight:"KeyD",rollLeft:"KeyQ",rollRight:"KeyE",accelerate:"ShiftLeft",decelerate:"ControlLeft",afterburner:"KeyZ",firePrimary:"Space",fireSecondary:"KeyF",launchDecoy:"KeyC",cyclePrimary:"KeyV",cycleSecondary:"KeyX",cycleTargetNext:"BracketRight",cycleTargetPrev:"BracketLeft",targetNearest:"KeyT",toggleMatchSpeed:"KeyM",pause:"Escape"},_g={pitchUp:"Pitch Up",pitchDown:"Pitch Down",yawLeft:"Yaw Left",yawRight:"Yaw Right",rollLeft:"Roll Left",rollRight:"Roll Right",accelerate:"Accelerate",decelerate:"Decelerate",afterburner:"Afterburner",firePrimary:"Fire Primary",fireSecondary:"Fire Secondary",launchDecoy:"Launch Decoy",cyclePrimary:"Cycle Primary",cycleSecondary:"Cycle Secondary",cycleTargetNext:"Next Target",cycleTargetPrev:"Previous Target",targetNearest:"Target Nearest",toggleMatchSpeed:"Match Speed",pause:"Pause"},qw={Movement:["pitchUp","pitchDown","yawLeft","yawRight","rollLeft","rollRight"],Throttle:["accelerate","decelerate","afterburner","toggleMatchSpeed"],Combat:["firePrimary","fireSecondary","launchDecoy"],Weapons:["cyclePrimary","cycleSecondary"],Targeting:["cycleTargetNext","cycleTargetPrev","targetNearest"],System:["pause"]},xg="spaceflight_keybindings";let rs={...ki};function Yw(){const t=Jw();t?rs={...ki,...t}:rs={...ki}}function Ya(){return{...rs}}function Mu(t,e){rs[t]=e}function xd(){try{localStorage.setItem(xg,JSON.stringify(rs))}catch(t){console.error("Failed to save key bindings:",t)}}function jw(){rs={...ki},xd()}function Kw(t,e){for(const[n,i]of Object.entries(rs))if(i===t&&n!==e)return n;return null}function Zw(t){return typeof t=="string"&&t.length>0}function Jw(){try{const t=localStorage.getItem(xg);if(!t)return null;const e=JSON.parse(t);if(!e||typeof e!="object")return console.warn("Invalid key bindings format in storage"),null;const n=e,i={};for(const[s,r]of Object.entries(n))s in ki&&Zw(r)&&(i[s]=r);return Object.keys(i).length>0?i:null}catch{return console.warn("Failed to parse key bindings from storage"),null}}function Qw(t){if(t.startsWith("Key"))return t.slice(3);if(t.startsWith("Digit"))return t.slice(5);if(t.startsWith("Numpad"))return`Num ${t.slice(6)}`;const e={Space:"Space",ShiftLeft:"Left Shift",ShiftRight:"Right Shift",ControlLeft:"Left Ctrl",ControlRight:"Right Ctrl",AltLeft:"Left Alt",AltRight:"Right Alt",MetaLeft:"Left Meta",MetaRight:"Right Meta",Enter:"Enter",Escape:"Esc",Backspace:"Backspace",Tab:"Tab",ArrowUp:"↑",ArrowDown:"↓",ArrowLeft:"←",ArrowRight:"→",BracketLeft:"[",BracketRight:"]",Semicolon:";",Quote:"'",Backquote:"`",Backslash:"\\",Comma:",",Period:".",Slash:"/",Minus:"-",Equal:"=",CapsLock:"Caps",Insert:"Insert",Delete:"Delete",Home:"Home",End:"End",PageUp:"PgUp",PageDown:"PgDn"};return t.startsWith("F")&&/^F\d+$/.test(t)?t:e[t]??t}const St=new Set,Rs={keydown:null,keyup:null,blur:null};function eT(){Rs.keydown=t=>{St.add(t.code);const e=Ya();Object.values(e).includes(t.code)&&t.preventDefault()},Rs.keyup=t=>{St.delete(t.code)},Rs.blur=()=>{St.clear()},window.addEventListener("keydown",Rs.keydown),window.addEventListener("keyup",Rs.keyup),window.addEventListener("blur",Rs.blur)}function tT(t,e){const n=Ya();for(const i of Te(t,["playerControlled"])){const s=C(t,i,"playerControlled");if(!s)continue;const r=s.input;r.pitchUp=St.has(n.pitchUp),r.pitchDown=St.has(n.pitchDown),r.yawLeft=St.has(n.yawLeft),r.yawRight=St.has(n.yawRight),r.rollLeft=St.has(n.rollLeft),r.rollRight=St.has(n.rollRight),r.accelerate=St.has(n.accelerate),r.decelerate=St.has(n.decelerate),r.afterburner=St.has(n.afterburner),r.firePrimary=St.has(n.firePrimary),r.fireSecondary=St.has(n.fireSecondary),r.launchDecoy=St.has(n.launchDecoy),r.cyclePrimary=St.has(n.cyclePrimary),r.cycleSecondary=St.has(n.cycleSecondary),r.cycleTargetNext=St.has(n.cycleTargetNext),r.cycleTargetPrev=St.has(n.cycleTargetPrev),r.targetNearest=St.has(n.targetNearest),r.toggleMatchSpeed=St.has(n.toggleMatchSpeed)}}function nT(t,e){const n=t.systemState.mission;if(n.result!==Wn.InProgress)return;if(Y1(t,["playerControlled","health"])===0){n.result=Wn.Defeat;return}bg(t)===0&&(n.result=Wn.Victory)}function iT(t){return t.systemState.mission.result}function sT(t){t.systemState.mission.result=Wn.InProgress}function bg(t){let e=0;for(const n of Te(t,["faction","health","shipIdentity"])){const i=C(t,n,"health"),s=C(t,n,"faction");xt(i)||s.faction===ze.Enemy&&e++}return e}const Eh=new Dn,wh=new at,qs=new T,zc=Math.PI/180;function Xo(t,e,n){const i=e-t;return Math.abs(i)<=n?e:t+Math.sign(i)*n}function rT(t,e){for(const n of Te(t,["transform","physics"])){const i=C(t,n,"transform"),s=C(t,n,"physics");s.prevPosition.copy(i.position),s.prevRotation.copy(i.rotation),s.prevVelocity.copy(s.velocity);const r=C(t,n,"health");if(r&&xt(r)){i.position.addScaledVector(s.velocity,e);continue}const o=C(t,n,"playerControlled"),a=C(t,n,"aiControlled");let c=0,l=0,u=0,d=!1,f=!1,h=!1;if(o){o.input.pitchUp&&(c=1),o.input.pitchDown&&(c=-1),o.input.yawLeft&&(l=1),o.input.yawRight&&(l=-1),o.input.rollLeft&&(u=1),o.input.rollRight&&(u=-1),d=o.input.accelerate,f=o.input.decelerate,h=o.input.afterburner;const b=t.systemState.flightAssist;o.input.toggleMatchSpeed&&!b.prevInput.toggleMatchSpeed&&(o.matchSpeed=!o.matchSpeed,o.prevTargetDistance=0),b.prevInput.toggleMatchSpeed=o.input.toggleMatchSpeed;const x=C(t,n,"targeting"),L=(x==null?void 0:x.currentTarget)!==void 0&&kt(t,x.currentTarget);o.matchSpeed&&!L&&(o.matchSpeed=!1,o.prevTargetDistance=0)}else a&&(c=a.input.pitch,l=a.input.yaw,u=a.input.roll,d=a.input.accelerate,f=a.input.decelerate,h=a.input.afterburner);const p=c*s.turnRate,v=l*s.turnRate,g=u*s.rollRate,m=s.angularAcceleration*e;s.angularVelocity.x=Xo(s.angularVelocity.x,p,m),s.angularVelocity.y=Xo(s.angularVelocity.y,v,m),s.angularVelocity.z=Xo(s.angularVelocity.z,g,m);const S=s.angularVelocity.x*zc*e,_=s.angularVelocity.y*zc*e,y=s.angularVelocity.z*zc*e;Eh.set(S,_,y,"YXZ"),wh.setFromEuler(Eh),i.rotation.multiply(wh),i.rotation.normalize();const D=s.maxSpeed*s.afterburnerMultiplier,E=C(t,n,"heat");if(E){const b=ro(E);s.afterburnerLocked?b<=Ym&&(s.afterburnerLocked=!1):b>=cE&&(s.afterburnerLocked=!0)}const A=h&&!s.afterburnerLocked,P=d||f||h;if(A)s.currentSpeed=Math.min(s.currentSpeed+s.acceleration*1.5*e,D),s.isAfterburning=!0,E&&(E.current=Math.min(E.max,E.current+s.afterburnerHeatRate*e));else if(d)s.currentSpeed=Math.min(s.currentSpeed+s.acceleration*e,s.maxSpeed),s.isAfterburning=!1;else if(f)s.currentSpeed=Math.max(s.currentSpeed-s.acceleration*e,0),s.isAfterburning=!1;else if(o!=null&&o.matchSpeed&&!P){s.isAfterburning=!1;const b=C(t,n,"targeting");if((b==null?void 0:b.currentTarget)!==void 0){b.currentTarget!==o.prevMatchSpeedTarget&&(o.prevTargetDistance=0,o.prevMatchSpeedTarget=b.currentTarget);const x=C(t,b.currentTarget,"transform");if(x){const L=i.position.distanceTo(x.position);o.prevTargetDistance===0&&(o.prevTargetDistance=L);const B=(o.prevTargetDistance-L)/e;o.prevTargetDistance=L;const F=Math.max(0,Math.min(s.maxSpeed,s.currentSpeed-B));s.currentSpeed=Xo(s.currentSpeed,F,s.acceleration*e)}}}else s.currentSpeed>s.maxSpeed&&(s.currentSpeed=Math.max(s.currentSpeed-s.acceleration*.5*e,s.maxSpeed)),s.isAfterburning=!1;qs.set(0,0,-1),qs.applyQuaternion(i.rotation),s.velocity.copy(qs).multiplyScalar(s.currentSpeed),i.position.addScaledVector(s.velocity,e)}}function or(t){return qs.set(0,0,-1),qs.applyQuaternion(t.rotation),qs}function oT(t,e){const n=t.systemState.gameTime;for(const i of Te(t,["shields"])){const s=C(t,i,"shields");fw(s,n,e)}}const Hc=[];function aT(t,e,n){const i=t.systemState.pools.targetCollector;i>=Hc.length&&Hc.push({entity:0,distance:0});const s=Hc[i];return t.systemState.pools.targetCollector++,s.entity=e,s.distance=n,s}function cT(t,e){return t.distance-e.distance}const Cs=[];function lT(t,e){const n=t.systemState.targeting.prevInput;for(const i of Te(t,["playerControlled","targeting","transform"])){const s=C(t,i,"playerControlled"),r=C(t,i,"targeting"),o=C(t,i,"transform"),a=C(t,i,"faction"),c=(a==null?void 0:a.faction)??ze.Player;uT(t,i,r,o,c),r.currentTarget!==void 0&&(!kt(t,r.currentTarget)||!r.validTargets.includes(r.currentTarget))&&(bd(r),r.validTargets.length>0&&Gc(r)),r.currentTarget===void 0&&r.validTargets.length>0&&Gc(r);const l=s.input;l.cycleTargetNext&&!n.cycleTargetNext&&Th(r,1),l.cycleTargetPrev&&!n.cycleTargetPrev&&Th(r,-1),l.targetNearest&&!n.targetNearest&&Gc(r),n.cycleTargetNext=l.cycleTargetNext,n.cycleTargetPrev=l.cycleTargetPrev,n.targetNearest=l.targetNearest}}function uT(t,e,n,i,s){t.systemState.pools.targetCollector=0,Cs.length=0;for(const r of Te(t,["transform","faction","health"])){if(r===e)continue;const o=Ke(t,r,"shipIdentity"),a=Ke(t,r,"decoy");if(!o&&!a)continue;const c=C(t,r,"health");if(c&&xt(c))continue;const l=C(t,r,"faction");if(!l||!gr(s,l.faction))continue;const u=C(t,r,"transform"),d=i.position.distanceTo(u.position);Cs.push(aT(t,r,d))}Cs.sort(cT),n.validTargets.length=Cs.length;for(let r=0;r<Cs.length;r++)n.validTargets[r]=Cs[r].entity;if(n.currentTarget!==void 0){const r=n.validTargets.indexOf(n.currentTarget);n.targetIndex=r}}function Th(t,e){if(t.validTargets.length===0){bd(t);return}t.currentTarget===void 0?t.targetIndex=e>0?0:t.validTargets.length-1:(t.targetIndex+=e,t.targetIndex>=t.validTargets.length?t.targetIndex=0:t.targetIndex<0&&(t.targetIndex=t.validTargets.length-1)),t.currentTarget=t.validTargets[t.targetIndex]}function Gc(t){if(t.validTargets.length===0){bd(t);return}t.targetIndex=0,t.currentTarget=t.validTargets[0]}function bd(t){t.currentTarget=void 0,t.targetIndex=-1}const Mg=.25,dT=Mg*.4,Kr=12,fT={energy:{flash:new J(.4,.8,1),particles:new J(.2,.6,1)},ballistic:{flash:new J(1,.6,.2),particles:new J(1,.8,.3)}};function Eg(){return{effects:[],flashGeometry:new yn(1,12,8),hitIdCounter:0}}const Ah=new T;function hT(t){const e=new Float32Array(Kr*3),n=eo(t);for(let i=0;i<Kr;i++){const s=ft(n)*Math.PI*2,r=ft(n)*Math.PI*.5,o=i*3;e[o]=Math.sin(r)*Math.cos(s),e[o+1]=Math.sin(r)*Math.sin(s),e[o+2]=Math.cos(r)}return e}function pT(t,e,n,i,s,r){const o=r?{flash:new J(r.r,r.g,r.b),particles:new J(r.r,r.g,r.b)}:fT[i],a=new mt({color:o.flash,transparent:!0,opacity:.9,blending:ot,depthWrite:!1}),c=new Ye(t.flashGeometry.clone(),a);c.position.copy(n),c.scale.setScalar(i==="energy"?1.5:1),e.add(c);const l=new Float32Array(Kr*3);for(let p=0;p<Kr;p++){const v=p*3;l[v]=n.x,l[v+1]=n.y,l[v+2]=n.z}const u=new Tt;u.setAttribute("position",new Ut(l,3));const d=new Ga({color:o.particles,size:i==="energy"?1.5:2,transparent:!0,opacity:1,blending:ot,depthWrite:!1}),f=new Wa(u,d);e.add(f);const h=hT(t.hitIdCounter++*12345);return{flash:c,particles:f,particleVelocities:h,startTime:s,category:i,position:n.clone()}}function wg(t,e,n){var r;const i=n.systemState.gameTime,s=n.systemState.projectileHits.pending;for(const o of s){Ah.set(o.x,o.y,o.z);const a=pT(t,e,Ah,o.category,i,o.color);t.effects.push(a)}s.length=0;for(let o=t.effects.length-1;o>=0;o--){const a=t.effects[o];if(!a)continue;const c=i-a.startTime,l=c/Mg;if(l>=1){e.remove(a.flash),e.remove(a.particles),a.flash.geometry.dispose(),a.flash.material.dispose(),a.particles.geometry.dispose(),a.particles.material.dispose(),t.effects.splice(o,1);continue}const u=a.category==="energy"?1.5+l*3:1+l*2;a.flash.scale.setScalar(u),a.flash.material.opacity=.9*(1-l);const d=(r=a.particles.geometry.attributes.position)==null?void 0:r.array,f=a.category==="energy"?15:10,h=c*f;for(let v=0;v<Kr;v++){const g=v*3;d[g]=a.position.x+a.particleVelocities[g]*h,d[g+1]=a.position.y+a.particleVelocities[g+1]*h,d[g+2]=a.position.z+a.particleVelocities[g+2]*h}const p=a.particles.geometry.attributes.position;p&&(p.needsUpdate=!0),a.particles.material.opacity=1-l}}function Tg(t,e,n,i,s,r="energy",o="Plasma",a,c,l,u){const d={type:"projectile",owner:t,damage:e,speed:n,range:i,distanceTraveled:0,direction:s.clone().normalize(),category:r,weaponName:o};return a!==void 0&&(d.flakRadius=a),c!==void 0&&(d.shrapnelCount=c),l!==void 0&&(d.shieldDamageMultiplier=l),u!==void 0&&(d.ionize=u),d}function mT(t){return t.distanceTraveled>=t.range}const gT=450,vT=120,yT=8,ST=.3;function _T(t,e,n,i,s){const r=Math.PI*(3-Math.sqrt(5));for(let o=0;o<n;o++){const a=1-o/(n-1)*2,c=Math.sqrt(1-a*a),l=r*o,u=new T(c*Math.cos(l),a,c*Math.sin(l)).normalize(),d=ai(t);de(t,d,ci(e.x,e.y,e.z)),de(t,d,Tg(i,yT,gT,vT,u,"ballistic","Shrapnel")),de(t,d,ls(ST)),s&&de(t,d,as(s.faction))}}const xT=3,bT=4,MT=3,ET=1.5,wT=.5,TT=1,Qt=new T,Wc=new T,Vc=new T,$c=new T;function ja(t,e,n,i){const s=or(t);if(Qt.copy(t.position).addScaledVector(s,i),n<=1)return Qt;Wc.set(1,0,0).applyQuaternion(t.rotation);const r=Math.floor(e/2),o=e%2===1,a=ET*(r+1);return o?Qt.addScaledVector(Wc,a):Qt.addScaledVector(Wc,-a),Qt}function AT(t,e,n,i,s,r,o=0,a=1,c){const l=or(n),u=ja(n,o,a,xT);let d=r?ld(l,r):l;if(c&&c.fovDegrees>0){$c.copy(c.interceptPoint).sub(u).normalize();const p=d.dot($c);Math.acos(Math.max(-1,Math.min(1,p)))*(180/Math.PI)<=c.fovDegrees&&(d=$c)}const f=ai(t),h=i.category==="ballistic"?"ballistic":"energy";if(de(t,f,ci(u.x,u.y,u.z)),de(t,f,Tg(e,i.damage,i.projectileSpeed,i.range,d,h,i.name,i.flakRadius,i.shrapnelCount,i.shieldDamageMultiplier,i.ionize)),de(t,f,ls(wT)),s&&de(t,f,as(s.faction)),Sd(t,e,i.name),t.systemState.combatStats){const p=t.systemState.combatStats;p.shotsFired[i.name]=(p.shotsFired[i.name]||0)+1}}function Eu(t,e,n,i,s,r,o){const a=or(n);Qt.copy(n.position).addScaledVector(a,bT);const c=o??a,l=ai(t),u=ci(Qt.x,Qt.y,Qt.z);u.rotation.copy(n.rotation),de(t,l,u);const d=i.name.toLowerCase();if(de(t,l,iw(e,r,i.damage,i.speed,i.turnRate,i.range,c,i.aoeRadius??0,i.isNuke??!1,d)),de(t,l,ls(TT)),de(t,l,so(1)),s&&de(t,l,as(s.faction)),Tw(t,e,i.name),t.systemState.combatStats){const f=t.systemState.combatStats;f.missilesFired[i.name]=(f.missilesFired[i.name]||0)+1}}const RT=1.5,Xc=new T;function wu(t,e,n,i){Vc.set(0,-1,0).applyQuaternion(n.rotation),Qt.copy(n.position).addScaledVector(Vc,MT);const s=Qp(t.prng);Xc.set(s.x,s.y,s.z),Xc.addScaledVector(Vc,1.5).normalize();const r=ai(t),o=ci(Qt.x,Qt.y,Qt.z);de(t,r,o),de(t,r,Gw(e,Xc)),de(t,r,ls(RT)),de(t,r,so(1)),i&&de(t,r,as(i.faction)),Cw(t,e),t.systemState.combatStats&&t.systemState.combatStats.decoysLaunched++}const qo=new T;function Ag(t,e,n,i){qo.subVectors(t,n);const s=e.dot(e),r=2*qo.dot(e),o=qo.dot(qo)-i*i,a=r*r-4*s*o;if(a<0)return null;const c=(-r-Math.sqrt(a))/(2*s);if(c>0)return c;const l=(-r+Math.sqrt(a))/(2*s);return l>0?l:null}const Jn={entity:0,distance:0,hit:!1};function CT(t,e,n,i,s){Jn.hit=!1,Jn.distance=1/0;for(const r of Te(t,["transform","collision","health"])){if(r===e||Ke(t,r,"projectile")||Ke(t,r,"missile"))continue;const o=C(t,r,"health");if(o&&xt(o))continue;const a=C(t,r,"transform"),c=C(t,r,"collision"),l=Ag(n,i,a.position,c.radius);l!==null&&l<=s&&l<Jn.distance&&(Jn.hit=!0,Jn.entity=r,Jn.distance=l)}return{hit:Jn.hit,entity:Jn.entity,distance:Jn.distance}}function PT(t,e,n,i,s){const r=[];for(const o of Te(t,["transform","collision","health"])){if(o===e||Ke(t,o,"projectile")||Ke(t,o,"missile"))continue;const a=C(t,o,"health");if(a&&xt(a))continue;const c=C(t,o,"transform"),l=C(t,o,"collision"),u=Ag(n,i,c.position,l.radius);u!==null&&u<=s&&r.push({entity:o,distance:u})}return r.sort((o,a)=>o.distance-a.distance),r}const Md=3;function LT(t,e){const n=t.lastHitEffectTime??0;return e-n>=dT}const qc=[];function DT(t,e,n){const i=t.systemState.pools.beamWeapon;i>=qc.length&&qc.push({weapon:null,index:0});const s=qc[i];return t.systemState.pools.beamWeapon++,s.weapon=e,s.index=n,s}function IT(t){t.systemState.pools.beamWeapon=0}const Rh=100;function Tu(t,e){const n=Math.max(Rh,e);return t/(n/Rh)}const NT={"Red Laser":new J(1,0,0),"Green Laser":new J(0,1,0),"Blue Laser":new J(0,0,1),Lightning:new J(.6,.8,1),Torch:new J(1,.6,.2),"Nuclear Lance":new J(1,.95,.8)},UT=new J(1,1,1);function Ed(t){return NT[t]??UT}function Rg(t,e){var n;for(let i=0;i<t.length;i++)if(((n=t[i])==null?void 0:n.weaponIndex)===e)return t[i]}function Cg(t,e,n,i,s,r,o){const a={origin:new T,direction:new T,hitPoint:null,color:Ed(t).clone(),active:!1,weaponIndex:e,weaponName:t,fadeStartTime:null};return n!==void 0&&(a.beamWidth=n),i&&(a.isPulseBeam=!0,a.lastPulseTime=0,a.pulseActive=!1),s&&(a.isLance=!0),r&&(a.isTorch=!0),o&&(a.isInstantBeam=!0,a.lastInstantFireTime=0),a}function kT(t,e){const n=t.systemState.gameTime;for(const[i,s]of e){if(!kt(t,i))continue;const r=C(t,i,"transform");if(!r)continue;const o=C(t,i,"primaryWeapons"),a=(o==null?void 0:o.weapons.length)??1;for(const c of s){if(c.active)continue;c.fadeStartTime===null&&(c.fadeStartTime=n,c.pulseActive=!1);let l=200;if(c.hitPoint){const f=c.origin.distanceTo(c.hitPoint);f>0&&(l=f)}const u=ja(r,c.weaponIndex,a,Md),d=or(r);c.origin.copy(u),c.direction.copy(d),c.hitPoint&&c.hitPoint.copy(u).addScaledVector(d,l)}}}function Pg(t){const{world:e,owner:n,target:i,weapon:s,damage:r,hitPoint:o,beam:a,gameTime:c}=t;if(ao(e,i,r,o,s.shieldDamageMultiplier??1,s.hullDamageMultiplier??1),s.ionize){const u=C(e,i,"shields");u&&og(u,c)}if(s.heatInjection){const u=C(e,i,"heat");if(u){const d=r/s.damage;fE(u,s.heatInjection*d)}}if((s.isPulseBeam||LT(a,c))&&(e.systemState.projectileHits.pending.push({x:o.x,y:o.y,z:o.z,category:"energy",color:{r:a.color.r,g:a.color.g,b:a.color.b}}),a.lastHitEffectTime=c),qa(e,n,i,s.name,"beam",r,s.isPulseBeam),s.isPulseBeam?pg(e,n,s.name,"beam",!0):ww(e,n,s.name,r/s.damage),e.systemState.combatStats){const u=e.systemState.combatStats;u.beamDamage[s.name]=(u.beamDamage[s.name]||0)+r}}const Ps=new T,$i=new T,Yc=new T;function FT(t,e,n,i,s,r,o,a,c,l){const u=t.systemState.gameTime,d=ja(n,s,r,Md);if(Ps.copy(d),$i.copy(c),i.autoaimFov&&l!==void 0){const _=C(t,l,"transform");if(_){Yc.copy(_.position).sub(Ps).normalize();const y=$i.angleTo(Yc),D=i.autoaimFov*Math.PI/180;y<=D&&$i.copy(Yc)}}let f=a.get(e);f||(f=[],a.set(e,f));let h=Rg(f,s);const p=i.isPulseBeam===!0,v=i.name==="Nuclear Lance",g=i.name==="Torch";h||(h=Cg(i.name,s,i.beamWidth,p,v,g,!1),f.push(h)),h.origin.copy(Ps),h.direction.copy($i),h.active=!0,h.fadeStartTime=null,h.hitPoint=null,h.color.copy(Ed(i.name)),h.weaponName=i.name;let m=!0;if(i.isPulseBeam&&i.pulseInterval)if(u-(h.lastPulseTime??0)>=i.pulseInterval){h.lastPulseTime=u,h.pulseActive=!0,m=!0;const y=C(t,e,"heat");if(y){const D=us(i);Xa(y,D)?Sd(t,e,i.name,"beam",!0):(h.pulseActive=!1,m=!1)}}else h.pulseActive=!1,m=!1;const S=CT(t,e,Ps,$i,i.range);if(h.hitPoint||(h.hitPoint=new T),i.isPulseBeam||Ew(t,e,i.name,o),S.hit){if(h.hitPoint.copy($i).multiplyScalar(S.distance).add(Ps),m){let _;i.isPulseBeam?_=i.noFalloff?i.damage:Tu(i.damage,S.distance):_=Tu(i.damage,S.distance)*o,Pg({world:t,owner:e,target:S.entity,weapon:i,damage:_,hitPoint:h.hitPoint,beam:h,gameTime:u})}}else{const _=i.isPulseBeam?Math.min(i.range,150):i.range;h.hitPoint.copy($i).multiplyScalar(_).add(Ps)}}const Xi=new T,yi=new T,jc=new T;function OT(t,e,n,i,s,r,o,a,c,l){if(a.length===0||c)return!1;const u=i.weapons.length,d=t.systemState.gameTime;for(const{weapon:f,index:h}of a){if(f.ammo!==void 0&&f.ammo<=0)continue;let p=r.get(e);p||(p=[],r.set(e,p));let v=Rg(p,h);v||(v=Cg(f.name,h,f.beamWidth,!1,!0,!1,!0),p.push(v));const g=v.lastInstantFireTime??0;if(d-g<f.fireRate)continue;const m=us(f);if(Xa(s,m))return BT(t,e,n,f,h,u,v,o,d,l),f.ammo!==void 0&&(f.ammo--,f.ammo<=0&&cg(i)),!0}return!1}function BT(t,e,n,i,s,r,o,a,c,l){const u=ja(n,s,r,Md);if(Xi.copy(u),yi.copy(a),i.autoaimFov&&l!==void 0){const f=C(t,l,"transform");if(f){jc.copy(f.position).sub(Xi).normalize();const h=yi.angleTo(jc),p=i.autoaimFov*Math.PI/180;h<=p&&yi.copy(jc)}}o.origin.copy(Xi),o.direction.copy(yi),o.active=!0,o.fadeStartTime=null,o.lanceFireTime=c,o.lastInstantFireTime=c,o.color.copy(Ed(i.name)),o.weaponName=i.name,o.hitPoint||(o.hitPoint=new T);const d=PT(t,e,Xi,yi,i.range);if(Sd(t,e,i.name,"beam",!1),d.length>0){const f=d[d.length-1];f&&o.hitPoint.copy(yi).multiplyScalar(f.distance).add(Xi);for(const h of d){const p=new T().copy(yi).multiplyScalar(h.distance).add(Xi),v=i.noFalloff?i.damage:Tu(i.damage,h.distance);Pg({world:t,owner:e,target:h.entity,weapon:i,damage:v,hitPoint:p,beam:o,gameTime:c})}}else o.hitPoint.copy(yi).multiplyScalar(i.range).add(Xi);o.fadeStartTime=c,o.active=!1}const Rr=[],Kc=[];function zT(t,e){var s;const n=t.systemState.beams.activeBeams,i=t.systemState.beams.prevFireState;for(const r of n.values())for(const o of r)o.active=!1;for(const r of Te(t,["transform","primaryWeapons","heat"])){const o=C(t,r,"health");if(o&&xt(o))continue;const a=C(t,r,"transform"),c=C(t,r,"primaryWeapons"),l=C(t,r,"heat"),u=C(t,r,"playerControlled");let d=!1,f=null,h;if(u){if(d=u.input.firePrimary,d){f=or(a);const v=C(t,r,"targeting");h=v==null?void 0:v.currentTarget}}else{const v=C(t,r,"aiControlled");if(v&&v.state===Be.Engage&&v.target!==null&&kt(t,v.target)){const g=oo(c);for(const m of g)if(((s=c.weapons[m])==null?void 0:s.category)==="beam"){d=!0;break}d&&(f=or(a),h=v.target)}}const p=i.get(r)??!1;d&&f&&HT(t,r,a,c,l,e,n,f,p,h),i.set(r,d)}kT(t,n)}function HT(t,e,n,i,s,r,o,a,c,l){IT(t),Rr.length=0,Kc.length=0;const u=oo(i);for(const p of u){const v=i.weapons[p];if(v&&v.category==="beam"){const g=DT(t,v,p);v.isInstantBeam?Kc.push(g):Rr.push(g)}}if(OT(t,e,n,i,s,o,a,Kc,c,l),Rr.length===0)return;let d=0;for(const{weapon:p}of Rr)d+=us(p);const f=d*r;if(!Xa(s,f))return;const h=i.weapons.length;for(const{weapon:p,index:v}of Rr)FT(t,e,n,p,v,h,r,o,a,l)}const ar=new T;function Ch(t,e,n,i,s,r,o){for(const a of Te(t,["transform","health"])){if(a===s||a===r)continue;const c=C(t,a,"transform");if(C(t,a,"health").hull<=0)continue;ar.copy(c.position).sub(e);const u=ar.length();if(u<=n){const d=1-u/n,f=i*d;if(f>0){const h=ao(t,a,f,e);if(o){const p=h.shieldDamage+h.hullDamage;qa(t,s,a,o,"missile",p)}}}}}function GT(t,e,n,i,s){for(const r of Te(t,["transform","health"])){if(r===i||Ke(t,r,"projectile")||Ke(t,r,"missile"))continue;const o=C(t,r,"faction");if(s&&o&&!gr(s.faction,o.faction))continue;const a=C(t,r,"transform");if(C(t,r,"health").hull<=0)continue;if(ar.copy(a.position).sub(e),ar.length()<=n)return!0}return!1}function Ph(t,e,n,i){const s=[];for(const r of Te(t,["projectile","transform"])){if(C(t,r,"projectile").owner===i)continue;const a=C(t,r,"transform");ar.copy(a.position).sub(e),ar.length()<=n&&s.push(r)}for(const r of s)ss(t,r)}const WT=4,Lh=new J(1,.5,.1),VT=15,$T=100,Yo=new T,jo=new T,Dh=new T,Ta=new at,Ih=new T;function XT(t,e){const n=[];for(const i of Te(t,["missile","transform"])){const s=C(t,i,"missile"),r=C(t,i,"transform");if(s.turnRate>0&&!Ke(t,s.target??-1,"decoy")){const c=YT(t,r.position);if(c&&!s.resistedDecoys.has(c))if(ft(t.prng)<zw){const l=C(t,c,"decoy"),u=l==null?void 0:l.owner;s.target=c;const d=s.missileType.charAt(0).toUpperCase()+s.missileType.slice(1);u!==void 0&&Rw(t,s.owner,d,u),t.systemState.combatStats&&(t.systemState.combatStats.missilesSeduced++,t.systemState.combatStats.decoysSuccessful++)}else s.resistedDecoys.add(c)}if(s.target!==void 0&&s.turnRate>0)if(kt(t,s.target)){const c=C(t,s.target,"transform");c&&qT(s,r,c,e)}else s.target=void 0;const o=s.speed*e;if(r.position.addScaledVector(s.direction,o),s.distanceTraveled+=o,Dh.set(0,0,-1),Ta.setFromUnitVectors(Dh,s.direction),r.rotation.copy(Ta),sw(s)){if(t.systemState.combatStats&&t.systemState.combatStats.missilesExpired++,s.isNuke&&s.aoeRadius>0&&GT(t,r.position,s.aoeRadius,s.owner,C(t,i,"faction"))){const l=s.missileType.charAt(0).toUpperCase()+s.missileType.slice(1);Ch(t,r.position,s.aoeRadius,s.damage*.5,s.owner,-1,l),Ph(t,r.position,s.aoeRadius,s.owner),Nh(t,r.position,!0)}n.push(i);continue}const a=C(t,i,"collision");if(a&&a.collidedWith.length>0)for(const c of a.collidedWith){if(c===s.owner){if(s.distanceTraveled<$T)continue;t.systemState.combatStats&&t.systemState.combatStats.missilesHitOwner++,n.push(i);break}if(Ke(t,c,"projectile")||Ke(t,c,"missile"))continue;const l=ao(t,c,s.damage,r.position),u=s.missileType.charAt(0).toUpperCase()+s.missileType.slice(1),d=l.shieldDamage+l.hullDamage;if(Aw(t,s.owner,u),qa(t,s.owner,c,u,"missile",d),t.systemState.combatStats&&s.missileType){const f=t.systemState.combatStats;f.missilesHit[u]=(f.missilesHit[u]||0)+1,f.missileDamage[u]=(f.missileDamage[u]||0)+d}s.aoeRadius>0&&(Ch(t,r.position,s.aoeRadius,s.damage*.5,s.owner,c,u),s.isNuke&&Ph(t,r.position,s.aoeRadius,s.owner)),Nh(t,r.position,s.isNuke),n.push(i);break}}for(const i of n)ss(t,i)}function Nh(t,e,n=!1){const i=ai(t);de(t,i,ci(e.x,e.y,e.z)),n?de(t,i,bu(VT,Lh,void 0,"nuke")):de(t,i,bu(WT,Lh))}function qT(t,e,n,i){Yo.copy(n.position).sub(e.position).normalize();const s=t.direction.dot(Yo),r=Math.max(-1,Math.min(1,s)),o=Math.acos(r);if(o<.001)return;const a=t.turnRate*i;o<=a?t.direction.copy(Yo):(jo.crossVectors(t.direction,Yo).normalize(),jo.lengthSq()<1e-4&&jo.set(0,1,0),Ta.setFromAxisAngle(jo,a),t.direction.applyQuaternion(Ta).normalize())}function YT(t,e){let n,i=Hw;for(const s of Te(t,["decoy","transform"])){const r=C(t,s,"transform");Ih.copy(r.position).sub(e);const o=Ih.length();o<i&&(i=o,n=s)}return n}function Uh(t,e,n){t.systemState.projectileHits.pending.push({x:e.x,y:e.y,z:e.z,category:n})}const kh=new T;function jT(t,e){const n=[];for(const i of Te(t,["projectile","transform"])){const s=C(t,i,"projectile"),r=C(t,i,"transform"),o=s.speed*e;if(r.position.addScaledVector(s.direction,o),s.distanceTraveled+=o,mT(s)){n.push(i);continue}if(s.flakRadius!==void 0&&s.shrapnelCount){const c=C(t,i,"faction");let l=!1;for(const u of Te(t,["health","transform"])){if(u===i||Ke(t,u,"projectile")||u===s.owner)continue;const d=C(t,u,"faction");if(c&&d&&!gr(c.faction,d.faction))continue;const f=C(t,u,"transform");if(f&&(kh.copy(f.position).sub(r.position),kh.length()<=s.flakRadius)){l=!0;break}}if(l){_T(t,r.position,s.shrapnelCount,s.owner,c),Uh(t,r.position,"ballistic"),n.push(i);continue}}const a=C(t,i,"collision");if(a&&a.collidedWith.length>0)for(const c of a.collidedWith){if(c===s.owner||Ke(t,c,"projectile")||Ke(t,c,"missile"))continue;const l=ao(t,c,s.damage,r.position,s.shieldDamageMultiplier??1);if(s.ionize){const d=C(t,c,"shields");d&&og(d,t.systemState.gameTime)}const u=l.shieldDamage+l.hullDamage;if(qa(t,s.owner,c,s.weaponName,"projectile",u),pg(t,s.owner,s.weaponName),t.systemState.combatStats){const d=t.systemState.combatStats;d.damageDealt[s.weaponName]=(d.damageDealt[s.weaponName]||0)+u}l.hullDamage>0&&Uh(t,r.position,s.category),n.push(i);break}}for(const i of n)ss(t,i)}function Fh(t,e,n){return!(t.count<=0||t.range<e||t.requiresLock&&!n)}function KT(t,e,n,i){if(i)for(let s=0;s<t.weapons.length;s++){const r=t.weapons[s];if(!(!r||r.isDecoy)&&r.requiresLock&&Fh(r,e,i))return{shouldFire:!0,index:s}}for(let s=0;s<t.weapons.length;s++){const r=t.weapons[s];if(!(!r||r.isDecoy)&&!r.requiresLock&&Fh(r,e,i))return{shouldFire:!0,index:s}}return{shouldFire:!1,index:0}}var fn=(t=>(t.VeryLong="veryLong",t.Long="long",t.Medium="medium",t.Short="short",t))(fn||{});const Ys={veryLong:1500,long:800,medium:400};function Lg(t){return t>=Ys.veryLong?"veryLong":t>=Ys.long?"long":t>=Ys.medium?"medium":"short"}function Dg(t){return t.range>=Ys.veryLong?"veryLong":t.range>=Ys.long?"long":t.range>=Ys.medium?"medium":"short"}function ZT(t,e){const n=t.rotation,i={x:-2*(n.x*n.z-n.w*n.y),y:-2*(n.y*n.z+n.w*n.x),z:-(1-2*(n.x*n.x+n.y*n.y))},s={x:e.x-t.position.x,y:e.y-t.position.y,z:e.z-t.position.z},r=Math.sqrt(s.x*s.x+s.y*s.y+s.z*s.z);if(r<.001)return 0;s.x/=r,s.y/=r,s.z/=r;const o=i.x*s.x+i.y*s.y+i.z*s.z;return Math.acos(Math.max(-1,Math.min(1,o)))*(180/Math.PI)}const JT=1.3;function QT(t,e){return t===0||e===0?t===0&&e===0:(t>e?t/e:e/t)<=JT}function eA(t){let e=null;for(const n of t.weapons)if(!(!n||n.category==="beam")&&wd(n)){if(e===null)e=n.projectileSpeed;else if(!QT(e,n.projectileSpeed))return!1}return!0}function Ka(t,e){if(t.range<e)return!1;const n=Dg(t),i=Lg(e);return!(n===fn.VeryLong&&i===fn.Short)}function wd(t){return t.ammo===void 0||t.ammo>0}function tA(t,e,n,i,s){let r=0;if(!Ka(t,e)||!wd(t))return-1e3;const o=Dg(t),a=Lg(e);o===a?r+=50:(o===fn.VeryLong&&a===fn.Long||o===fn.Long&&a===fn.Medium||o===fn.Medium&&a===fn.Short)&&(r+=25);const c=us(t);return n>s.heatSwitchThreshold?r+=Math.max(0,30-c*2):r+=Math.max(0,10-c),t.ammo===void 0&&(r+=15),i&&t.name==="Ion"&&(r+=40),t.category==="beam"&&a===fn.Short?r+=30:t.category==="beam"&&a===fn.Medium&&(r+=15),a===fn.Short&&(r+=t.damage*.5),r}function nA(t,e,n,i,s,r){const o=ro(n),a=i!==void 0&&i.current>0;if(o>=qm){const f=sA(t,e);return f!==null&&us(t.weapons[f])<3?{mode:"single",index:f}:{mode:"none"}}if(s>r.minFiringAngle){const f=rA(t,e);if(f!==null)return{mode:"single",index:f};const h=oA(t,e,s,r);return h!==null?{mode:"single",index:h}:{mode:"none"}}let c=-1/0,l=-1,u=0,d=!0;for(let f=0;f<t.weapons.length;f++){const h=t.weapons[f];if(!h)continue;const p=tA(h,e,o,a,r);p>-500?u++:d=!1,p>c&&(c=p,l=f)}return u===0?{mode:"none"}:d&&u>1&&o<r.linkedFireHeatThreshold&&!(a&&iA(t))&&eA(t)?{mode:"linked"}:l>=0?{mode:"single",index:l}:{mode:"none"}}function iA(t){return t.weapons.some(e=>(e==null?void 0:e.name)==="Ion")}function sA(t,e){let n=null,i=1/0;for(let s=0;s<t.weapons.length;s++){const r=t.weapons[s];if(!r||!Ka(r,e)||!wd(r))continue;const o=us(r);o<i&&(i=o,n=s)}return n}function rA(t,e){for(let n=0;n<t.weapons.length;n++){const i=t.weapons[n];if(i&&i.ammo===void 0&&Ka(i,e))return n}return null}function oA(t,e,n,i){for(let s=0;s<t.weapons.length;s++){const r=t.weapons[s];if(!(!r||r.category==="beam")&&Ka(r,e)&&!(r.ammo!==void 0&&r.ammo<=0)&&r.autoaimFov&&r.autoaimFov>0){const o=i.minFiringAngle+r.autoaimFov;if(n<=o)return s}}return null}const Zc=new T,Oh=new T(0,0,0);function aA(t,e,n,i,s,r,o,a){if(o.state!==Be.Engage||o.target===null||!kt(t,o.target))return;const c=C(t,o.target,"transform");if(!c)return;const l=C(t,o.target,"shields"),u=n.position.distanceTo(c.position),d=ZT(n,c.position),f=nA(i,u,s,l,d,o.profile),h=C(t,e,"aimError");if(f.mode==="linked")_h(i,"all");else if(f.mode==="single"&&f.index!==void 0){const p=i.weapons[f.index];p&&_h(i,p.name)}f.mode!=="none"&&Ig(t,e,n,i,s,r,a,h,o.target)}function cA(t,e,n,i,s,r,o,a){if(dA(t,e,n,i,s,r,o),r.state!==Be.Engage||!r.target||!kt(t,r.target))return;const c=o-i.lastFireTime,l=lA(i);if(c<l)return;const u=C(t,r.target,"transform");if(!u)return;const d=C(t,r.target,"physics"),f=(d==null?void 0:d.velocity.length())??0,h=n.position.distanceTo(u.position),p=i.lockProgress>=1,v=KT(i,h,f,p);if(!v.shouldFire)return;const g=i.weapons[v.index];if(g!=null&&g.requiresLock)i.currentIndex=v.index;else{let S=!1;for(let _=0;_<i.weapons.length;_++){const y=i.weapons[_];if(y!=null&&y.requiresLock&&y.count>0&&!y.isDecoy){i.currentIndex=_,S=!0;break}}S||(i.currentIndex=v.index)}const m=i.weapons[v.index];if(!(!m||m.isDecoy||m.count<=0)&&!(m.requiresLock&&!p)&&!(c<m.fireRate)){if(i.lastFireTime=o,m.count--,m.turnRate===0){const S=C(t,e,"physics"),y=vr(n.position,(S==null?void 0:S.velocity)??Oh,u.position,(d==null?void 0:d.velocity)??Oh,m.speed)??u.position;Zc.copy(y).sub(n.position).normalize();const D=a?ld(Zc,a).clone():Zc;Eu(t,e,n,m,s,r.target,D),i.lockProgress=0;return}Eu(t,e,n,m,s,i.lockTarget),i.lockProgress=0}}function lA(t){let e=1/0;for(const n of t.weapons)!n.isDecoy&&n.fireRate<e&&(e=n.fireRate);return e===1/0?.5:e}function uA(t,e){for(const n of Te(t,["missile"])){const i=C(t,n,"missile");if((i==null?void 0:i.target)===e)return!0}return!1}function dA(t,e,n,i,s,r,o){if(o-r.lastDecoyTime<r.profile.decoyCooldown)return;const a=ug(i);!a||a.weapon.count<=0||uA(t,e)&&(r.lastDecoyTime=o,a.weapon.count--,wu(t,e,n,s))}function fA(t,e,n,i,s,r,o,a,c,l){const u=o.input,d=a.prevInput;u.cyclePrimary&&!d.cyclePrimary&&cg(i),u.firePrimary&&Ig(t,e,n,i,s,r,c,void 0,l)}function hA(t,e,n,i,s,r,o,a){const c=r.input,l=o.prevInput;if(c.cycleSecondary&&!l.cycleSecondary&&_w(i),c.launchDecoy&&!l.launchDecoy){const u=ug(i);u&&a-o.lastDecoyFireTime>=u.weapon.fireRate&&(o.lastDecoyFireTime=a,u.weapon.count--,wu(t,e,n,s))}if(c.fireSecondary&&!l.fireSecondary){const u=vd(i);if(u&&u.count>0){if(a-i.lastFireTime<u.fireRate)return;if(u.isDecoy){i.lastFireTime=a,u.count--,wu(t,e,n,s);return}if(u.requiresLock&&i.lockProgress<1)return;i.lastFireTime=a,u.count--;const f=i.lockProgress>=1?i.lockTarget:void 0;Eu(t,e,n,u,s,f),i.lockProgress=0}}}const Bh=new T,zh=new T,Hh=new T(0,0,0),pA=Math.PI/180,Cr=[];function mA(t,e){const n=t.systemState.weapons,i=t.systemState.gameTime;for(const r of Te(t,["transform","primaryWeapons","heat"])){const o=C(t,r,"health");if(o&&xt(o))continue;const a=C(t,r,"transform"),c=C(t,r,"primaryWeapons"),l=C(t,r,"heat"),u=C(t,r,"faction"),d=C(t,r,"playerControlled");if(d){const f=C(t,r,"targeting");fA(t,r,a,c,l,u,d,n,i,f==null?void 0:f.currentTarget)}else{const f=C(t,r,"aiControlled");f&&aA(t,r,a,c,l,u,f,i)}}for(const r of Te(t,["transform","secondaryWeapons"])){const o=C(t,r,"health");if(o&&xt(o))continue;const a=C(t,r,"transform"),c=C(t,r,"secondaryWeapons"),l=C(t,r,"faction"),u=C(t,r,"playerControlled");if(u){const d=C(t,r,"targeting");Gh(t,c,d==null?void 0:d.currentTarget,a,e),hA(t,r,a,c,l,u,n,i)}else{const d=C(t,r,"aiControlled");if(d){Gh(t,c,d.target,a,e);const f=C(t,r,"aimError");cA(t,r,a,c,l,d,i,f)}}}const s=gA(t);s&&(n.prevInput.cyclePrimary=s.input.cyclePrimary,n.prevInput.cycleSecondary=s.input.cycleSecondary,n.prevInput.fireSecondary=s.input.fireSecondary,n.prevInput.launchDecoy=s.input.launchDecoy)}function Gh(t,e,n,i,s){const r=vd(e);if(!r)return;if(n==null||!kt(t,n)){e.lockProgress=0,e.lockTarget=void 0;return}const o=C(t,n,"transform");if(o){if(i.position.distanceTo(o.position)>r.range){e.lockProgress=0,e.lockTarget=void 0;return}if(r.lockConeAngle!==void 0){Bh.set(0,0,-1).applyQuaternion(i.rotation),zh.copy(o.position).sub(i.position).normalize();const c=Bh.dot(zh),l=Math.acos(Math.min(1,Math.max(-1,c))),u=r.lockConeAngle*pA;if(l>u){e.lockProgress=0,e.lockTarget=void 0;return}}}if(e.lockTarget!==n&&(e.lockProgress=0,e.lockTarget=n,e.lockWeaponIndex=e.currentIndex),e.lockWeaponIndex!==e.currentIndex){const a=e.weapons[e.lockWeaponIndex],c=e.weapons[e.currentIndex],l=(a==null?void 0:a.requiresLock)??!1,u=(c==null?void 0:c.requiresLock)??!1;l&&u&&(e.lockProgress=0),e.lockWeaponIndex=e.currentIndex}e.lockProgress=r.requiresLock&&r.lockSpeed>0?Math.min(1,e.lockProgress+r.lockSpeed*s):1}function gA(t){for(const e of Te(t,["playerControlled"]))return C(t,e,"playerControlled")}function Ig(t,e,n,i,s,r,o,a,c){const l=oo(i);if(l.length===0)return;Cr.length=0;let u=1/0;for(const m of l){const S=i.weapons[m];!S||S.category==="beam"||S.ammo!==void 0&&S.ammo<=0||(Cr.push({weapon:S,index:m}),u=Math.min(u,S.fireRate))}if(Cr.length===0||o-i.lastFireTime<u)return;let f=0;for(const{weapon:m}of Cr)f+=us(m);if(!Xa(s,f))return;let h,p=Hh,v=Hh;if(c&&kt(t,c)){h=C(t,c,"transform");const m=C(t,c,"physics"),S=C(t,e,"physics");m&&(p=m.velocity),S&&(v=S.velocity)}i.lastFireTime=o;const g=i.weapons.length;for(const{weapon:m,index:S}of Cr){m.ammo!==void 0&&m.ammo--;let _;if(m.autoaimFov&&h){const y=vr(n.position,v,h.position,p,m.projectileSpeed);y&&(_={interceptPoint:y,fovDegrees:m.autoaimFov})}AT(t,e,n,m,r,a,S,g,_)}}const Ng=60,Jc=1e3/Ng,Au=1/Ng,vA=[tT,lT,$E,KE,mA,rT,zT,jT,XT,Vw,Fw,Bw,oT,Xw,Nw,$w,nT];function Ug(t=12345){return{world:X1(t),accumulator:0,lastTime:0,lastRenderTime:0,running:!1,paused:!1,lastNotifiedResult:Wn.InProgress}}function yA(t){const{world:e}=t;e.systemState.gameTime+=Au;for(const i of vA)i(e,Au);const n=iT(e);n!==t.lastNotifiedResult&&t.onMissionEnd&&(t.lastNotifiedResult=n,t.onMissionEnd(n)),t.onTick&&t.onTick(e)}function SA(t,e){if(!t.running)return;t.lastTime===0&&(t.lastTime=e,t.lastRenderTime=e);const n=e-t.lastTime;if(t.lastTime=e,!t.paused)for(t.accumulator+=n;t.accumulator>=Jc;)yA(t),t.accumulator-=Jc;const i=tE(),s=e-t.lastRenderTime;if(i===0||s>=i){t.lastRenderTime=e;const r=t.paused?1:t.accumulator/Jc;t.onRender&&t.onRender(t.world,r)}}function kg(t){t.running=!0,t.lastTime=0,t.lastRenderTime=0,t.accumulator=0;function e(n){SA(t,n),t.running&&requestAnimationFrame(e)}requestAnimationFrame(e)}function Td(t){t.running=!1}function _A(t){t.paused=!0}function Fg(t){t.paused=!1,t.lastTime=0}function xA(t){t.lastNotifiedResult=Wn.InProgress}var dt=(t=>(t.TITLE="title",t.SQUADRON="squadron",t.STORE="store",t.CONTRACTS="contracts",t.MISSION="mission",t.RESULTS="results",t.GAME_OVER="game_over",t.SETTINGS="settings",t))(dt||{});function bA(t,e){return{currentScreen:"title",container:t,campaignState:e,selectedContract:null,lastMissionVictory:!1,currentSaveSlot:null,titleElement:null,squadronElement:null,storeElement:null,contractsElement:null,resultsElement:null,gameOverElement:null,settingsElement:null,missionContainer:null,previousScreen:null}}function Og(t,e){const n=`screen-${e}`;let i=t.container.querySelector(`#${n}`);return i||(i=document.createElement("div"),i.id=n,i.className="game-screen",i.style.display="none",t.container.appendChild(i)),i}function MA(t){t.container.querySelectorAll(".game-screen").forEach(n=>{n.style.display="none"}),t.missionContainer&&(t.missionContainer.style.display="none")}function li(t,e){if(MA(t),e==="mission")t.missionContainer&&(t.missionContainer.style.display="block");else{const n=Og(t,e);n.style.display="flex"}t.currentScreen=e}function co(t){li(t,"squadron")}function Bg(t){li(t,"store")}function zg(t){li(t,"contracts")}function EA(t,e){t.selectedContract=e,li(t,"mission"),t.onStartMission&&t.onStartMission(e)}function Wh(t,e){t.lastMissionVictory=e,li(t,"results"),t.onMissionEnd&&t.onMissionEnd(e)}function wA(t){li(t,"game_over")}function on(t,e){return Og(t,e)}function TA(t,e){t.missionContainer=e}function cr(t,e){t.campaignState=e}function Hg(t){t.currentSaveSlot=null,li(t,"title")}function Gg(t){t.previousScreen=t.currentScreen,li(t,"settings")}function AA(t){const e=t.previousScreen??"title";t.previousScreen=null,li(t,e)}function Ru(t,e){t.currentSaveSlot=e}const Qc=["Vex","Nova","Rex","Kai","Zara","Hawk","Ash","Storm","Blaze","Frost","Raven","Phoenix","Viper","Ghost","Shadow","Bolt","Flint","Steel","Cinder","Drake","Sage","Echo","Jinx","Lynx","Onyx","Pyro","Quill","Razor","Siren","Talon"],Vh=[{skill:"rookie",weight:35,price:75},{skill:"regular",weight:35,price:200},{skill:"veteran",weight:20,price:400},{skill:"ace",weight:8,price:700},{skill:"elite",weight:2,price:1200}];let $h=0;function Wg(t){return $h++,`${t}-${$h}`}function RA(t){const e=Vh.reduce((i,s)=>i+s.weight,0);let n=t()*e;for(const i of Vh)if(n-=i.weight,n<=0)return{skill:i.skill,price:i.price};return{skill:"regular",price:200}}function CA(t,e){const n=Qc.filter(s=>!e.has(s));if(n.length===0){const s=Math.floor(t()*Qc.length),r=Qc[s];let o=2;for(;e.has(`${r} ${o}`);)o++;return`${r} ${o}`}const i=Math.floor(t()*n.length);return n[i]}function Vg(t,e,n,i){const s=new Set;for(const o of e)s.add(o.name);for(const o of n)s.add(o.name);const r=[];for(let o=0;o<t;o++){const a=CA(i,s);s.add(a);const{skill:c,price:l}=RA(i);r.push({id:Wg("recruit"),name:a,skill:c,price:l})}return r}function PA(t,e){return Vg(4,t,[],e)}function LA(t,e){const n=3+Math.floor(e()*3),i=Vg(n,t.pilots,[],e);return{...t,availableRecruits:i}}function DA(t,e){const n=t.availableRecruits.find(s=>s.id===e);if(!n)return console.warn(`Recruit ${e} not found`),t;if(t.credits<n.price)return console.warn(`Cannot afford recruit ${n.name} (${n.price} cr)`),t;const i={id:Wg("pilot"),name:n.name,skill:n.skill,kills:0,assists:0,missionsFlown:0,missionsWon:0,damageDealt:0,damageReceived:0};return{...t,credits:t.credits-n.price,pilots:[...t.pilots,i],availableRecruits:t.availableRecruits.filter(s=>s.id!==e)}}const IA={patrol:{buy:200,sell:100},scout:{buy:300,sell:150},fighter:{buy:400,sell:200},interceptor:{buy:500,sell:250},striker:{buy:800,sell:400},bomber:{buy:700,sell:350},defender:{buy:900,sell:450},raider:{buy:600,sell:300},sentinel:{buy:750,sell:375}},NA={plasma:{buy:100,sell:50},pulse:{buy:80,sell:40},ion:{buy:90,sell:45},autocannon:{buy:150,sell:75},railgun:{buy:300,sell:150},flak:{buy:200,sell:100},redLaser:{buy:250,sell:125},greenLaser:{buy:200,sell:100},blueLaser:{buy:180,sell:90},lightning:{buy:220,sell:110},torch:{buy:280,sell:140},nuclearLance:{buy:500,sell:250}},$g={autocannon:{buy:.1,sell:0},railgun:{buy:5,sell:2},flak:{buy:2,sell:1},nuclearLance:{buy:50,sell:25}},UA={rocket:{buy:5,sell:2},cluster:{buy:8,sell:4},seeker:{buy:15,sell:7},dart:{buy:10,sell:5},swarm:{buy:3,sell:1},torpedo:{buy:40,sell:20},nuke:{buy:100,sell:50},decoy:{buy:20,sell:10}};function ds(t,e){const n=IA[t.toLowerCase()];return n?n[e]:0}function lo(t,e){const n=NA[t];return n?n[e]:0}function pn(t,e){const n=$g[t];return n?n[e]:0}function Aa(t){return t in $g}function mn(t,e){const n=UA[t];return n?n[e]:0}function Ad(t){const e=ds(t,"buy");return e===0?0:Math.floor(e/100*.8)}const Rd=100,kA=.05;function Xg(t){const e=Wt[t.toLowerCase()],n=(e==null?void 0:e.primaryBanks.length)??0,i=(e==null?void 0:e.secondaryBanks.length)??0;return{primaryWeapons:Array(n).fill(null),secondaryWeapons:Array(i).fill(null)}}function qg(t,e,n){const i=[...t.primaryWeapons];return i[e]=n,{id:t.id,shipClass:t.shipClass,primaryWeapons:i,secondaryWeapons:t.secondaryWeapons,pilot:t.pilot,hullDamage:t.hullDamage}}function Yg(t,e,n){const i=[...t.secondaryWeapons];return i[e]=n,{id:t.id,shipClass:t.shipClass,primaryWeapons:t.primaryWeapons,secondaryWeapons:i,pilot:t.pilot,hullDamage:t.hullDamage}}function uo(t,e,n){const i=t.findIndex(s=>s.category==="secondary"&&s.weaponType===e);if(i>=0){const s=t[i];return s?t.map((r,o)=>o===i?{weaponType:r.weaponType,category:r.category,count:s.count+n}:r):t}else{const s={weaponType:e,category:"secondary",count:n};return[...t,s]}}function fo(t,e,n){if(n<=0)return t;const i=t.findIndex(s=>s.weaponType===e);if(i>=0){const s=t[i];return s?t.map((r,o)=>o===i?{weaponType:r.weaponType,count:s.count+n}:r):t}else return[...t,{weaponType:e,count:n}]}function Cd(t,e,n){const i=t.primaryWeapons.filter(o=>o!==null).map(o=>({weaponType:o.weaponType,category:"primary",count:1}));let s=[...e,...i];for(const o of t.secondaryWeapons)o!==null&&(s=uo(s,o.weaponType,o.count));let r=n;for(const o of t.primaryWeapons)o!==null&&(r=fo(r,o.weaponType,o.currentAmmo??0));return{storedWeapons:s,storedAmmo:r}}function Za(t,e){const n=Sn[t];return n?n.capacity*e:0}function Xh(t,e,n,i){const s=t.ships.findIndex(g=>g.id===e);if(s<0)return t;const r=t.ships[s];if(!r)return t;const o=r.secondaryWeapons[n];if(!o)return t;const a=o.maxCount-o.count;if(a<=0)return t;const c=t.storedWeapons.findIndex(g=>g.category==="secondary"&&g.weaponType===o.weaponType);if(c<0)return t;const l=t.storedWeapons[c];if(!l)return t;const u=Math.min(i,l.count,a);if(u<=0)return t;const d={weaponType:o.weaponType,bankSize:o.bankSize,count:o.count+u,maxCount:o.maxCount},f=Yg(r,n,d),h=[...t.ships];h[s]=f;const p=l.count-u;let v;return p<=0?v=t.storedWeapons.filter((g,m)=>m!==c):v=t.storedWeapons.map((g,m)=>m===c?{weaponType:g.weaponType,category:g.category,count:p}:g),{...t,ships:h,storedWeapons:v}}function qh(t,e,n,i){const s=t.ships.findIndex(f=>f.id===e);if(s<0)return t;const r=t.ships[s];if(!r)return t;const o=r.secondaryWeapons[n];if(!o)return t;const a=Math.min(i,o.count);if(a<=0)return t;const c={weaponType:o.weaponType,bankSize:o.bankSize,count:o.count-a,maxCount:o.maxCount},l=Yg(r,n,c),u=[...t.ships];u[s]=l;const d=uo(t.storedWeapons,o.weaponType,a);return{...t,ships:u,storedWeapons:d}}function yr(t,e){const n=bt[t];return!n||n.ammo===void 0?0:n.ammo*e}function jg(t,e,n){const i=pn(e,"buy"),s=t.storeStock.ammo[e]??0,r=Math.min(n,s);if(i===0||r<=0)return t;const o=Math.round(i*r);return t.credits<o?t:{...t,credits:t.credits-o,storedAmmo:fo(t.storedAmmo,e,r),storeStock:{...t.storeStock,ammo:{...t.storeStock.ammo,[e]:s-r}}}}function Kg(t,e,n){const i=t.storedAmmo.findIndex(d=>d.weaponType===e);if(i<0)return t;const s=t.storedAmmo[i];if(!s)return t;const r=Math.min(n,s.count);if(r<=0)return t;const o=pn(e,"sell"),a=Math.round(o*r),c=s.count-r,l=t.storeStock.ammo[e]??0,u=[...t.storedAmmo];return c<=0?u.splice(i,1):u[i]={weaponType:s.weaponType,count:c},{...t,credits:t.credits+a,storedAmmo:u,storeStock:{...t.storeStock,ammo:{...t.storeStock.ammo,[e]:l+r}}}}function Yh(t,e,n,i){const s=t.ships.findIndex(m=>m.id===e);if(s<0)return t;const r=t.ships[s];if(!r)return t;const o=r.primaryWeapons[n];if(!o||o.currentAmmo===void 0)return t;const c=yr(o.weaponType,o.bankSize)-o.currentAmmo;if(c<=0)return t;const l=t.storedAmmo.findIndex(m=>m.weaponType===o.weaponType);if(l<0)return t;const u=t.storedAmmo[l];if(!u)return t;const d=Math.min(i,u.count,c);if(d<=0)return t;const f={weaponType:o.weaponType,bankSize:o.bankSize,currentAmmo:o.currentAmmo+d},h=qg(r,n,f),p=[...t.ships];p[s]=h;const v=u.count-d,g=[...t.storedAmmo];return v<=0?g.splice(l,1):g[l]={weaponType:u.weaponType,count:v},{...t,ships:p,storedAmmo:g}}function jh(t,e,n,i){const s=t.ships.findIndex(f=>f.id===e);if(s<0)return t;const r=t.ships[s];if(!r)return t;const o=r.primaryWeapons[n];if(!o||o.currentAmmo===void 0)return t;const a=Math.min(i,o.currentAmmo);if(a<=0)return t;const c={weaponType:o.weaponType,bankSize:o.bankSize,currentAmmo:o.currentAmmo-a},l=qg(r,n,c),u=[...t.ships];u[s]=l;const d=fo(t.storedAmmo,o.weaponType,a);return{...t,ships:u,storedAmmo:d}}function Zg(){return Object.keys(Wt).map(t=>({shipClass:t,buyPrice:ds(t,"buy")})).filter(t=>t.buyPrice>0)}function Jg(){return Object.keys(bt).map(t=>({weaponType:t,buyPrice:lo(t,"buy")})).filter(t=>t.buyPrice>0)}function Qg(){return Object.keys(Sn).map(t=>({weaponType:t,buyPrice:mn(t,"buy")})).filter(t=>t.buyPrice>0)}function e0(){return Object.entries(bt).filter(([t,e])=>e.ammo!==void 0).map(([t])=>({weaponType:t,buyPrice:pn(t,"buy")})).filter(t=>t.buyPrice>0)}function FA(){return Object.keys(Wt).map(t=>({shipClass:t,sellPrice:Ad(t)})).filter(t=>t.sellPrice>0)}const Ko=1e4;function OA(){return{ships:Object.fromEntries(Zg().map(t=>[t.shipClass,Ko])),primaries:Object.fromEntries(Jg().map(t=>[t.weaponType,Ko])),secondaries:Object.fromEntries(Qg().map(t=>[t.weaponType,Ko])),ammo:Object.fromEntries(e0().map(t=>[t.weaponType,Ko]))}}let BA=0;function t0(){return`item_${++BA}`}function zA(t,e){const n=ds(e,"buy"),i=t.storeStock.ships[e]??0;if(n===0||t.credits<n||i<=0)return t;const s={id:t0(),shipClass:e,hullDamage:0};return{...t,credits:t.credits-n,storedShips:[...t.storedShips,s],storeStock:{...t.storeStock,ships:{...t.storeStock.ships,[e]:i-1}}}}function HA(t,e){const n=t.storedShips[e];if(!n)return t;const i=ds(n.shipClass,"sell"),s=t.storedShips.filter((o,a)=>a!==e),r=t.storeStock.ships[n.shipClass]??0;return{...t,credits:t.credits+i,storedShips:s,storeStock:{...t.storeStock,ships:{...t.storeStock.ships,[n.shipClass]:r+1}}}}function GA(t,e){const n=lo(e,"buy"),i=t.storeStock.primaries[e]??0;if(n===0||t.credits<n||i<=0)return t;const s={weaponType:e,category:"primary",count:1};return{...t,credits:t.credits-n,storedWeapons:[...t.storedWeapons,s],storeStock:{...t.storeStock,primaries:{...t.storeStock.primaries,[e]:i-1}}}}function WA(t,e){const n=t.storedWeapons[e];if(!n||n.category!=="primary")return t;const i=lo(n.weaponType,"sell"),s=t.storedWeapons.filter((o,a)=>a!==e),r=t.storeStock.primaries[n.weaponType]??0;return{...t,credits:t.credits+i,storedWeapons:s,storeStock:{...t.storeStock,primaries:{...t.storeStock.primaries,[n.weaponType]:r+1}}}}function n0(t,e,n){const i=mn(e,"buy"),s=t.storeStock.secondaries[e]??0,r=Math.min(n,s);if(i===0||r<=0)return t;const o=i*r;return t.credits<o?t:{...t,credits:t.credits-o,storedWeapons:uo(t.storedWeapons,e,r),storeStock:{...t.storeStock,secondaries:{...t.storeStock.secondaries,[e]:s-r}}}}function i0(t,e,n){const i=t.storedWeapons[e];if(!i||i.category!=="secondary")return t;const s=Math.min(n,i.count);if(s<=0)return t;const o=mn(i.weaponType,"sell")*s,a=i.count-s,c=t.storeStock.secondaries[i.weaponType]??0;let l;return a<=0?l=t.storedWeapons.filter((u,d)=>d!==e):l=t.storedWeapons.map((u,d)=>d===e?{...u,count:a}:u),{...t,credits:t.credits+o,storedWeapons:l,storeStock:{...t.storeStock,secondaries:{...t.storeStock.secondaries,[i.weaponType]:c+s}}}}function Pd(t,e,n){const i=t.storedScrap[e]??0,s=Math.min(n,i);if(s<=0)return t;const o=Ad(e)*s,a=i-s,c={...t.storedScrap};return a<=0?delete c[e]:c[e]=a,{...t,credits:t.credits+o,storedScrap:c}}function Ld(t){const e=ds(t,"buy");return Math.floor(e*kA)}function s0(t,e){const n=t.storedScrap[e]??0,i=Ld(e);return n>=Rd&&t.credits>=i}function VA(t,e){if(!s0(t,e))return t;const n=Ld(e),s=(t.storedScrap[e]??0)-Rd,r={...t.storedScrap};s<=0?delete r[e]:r[e]=s;const o={id:t0(),shipClass:e,hullDamage:0};return{...t,credits:t.credits-n,storedScrap:r,storedShips:[...t.storedShips,o]}}let $A=0;function r0(){return`ship_${++$A}`}function Zo(t,e=null){const n=yd(t);if(!n)throw new Error(`Unknown archetype: ${t}`);const i=n.primaryWeapons.map(r=>({weaponType:r.name,bankSize:r.size})),s=(n.secondaryWeapons??[]).map(r=>({weaponType:r.name,bankSize:r.size,count:r.count*r.size,maxCount:Za(r.name,r.size)}));return{id:r0(),shipClass:n.shipClassName,primaryWeapons:i,secondaryWeapons:s,pilot:e,hullDamage:0}}function ga(t,e){return{id:r0(),name:t,skill:e,kills:0,assists:0,missionsFlown:0,missionsWon:0,damageDealt:0,damageReceived:0}}function XA(){return ga("Commander","ace")}function qA(){return[ga("Viper","regular"),ga("Ghost","regular"),ga("Shadow","regular")]}function Dd(){const t=XA(),e=qA(),n=[t,...e],i=Zo("fighter",t),s=Zo("fighter",e[0]),r=Zo("fighter",e[1]),o=Zo("fighter",e[2]),a=eo(42),c=PA(n,()=>ft(a));return{credits:1e3,commanderId:t.id,ships:[i,s,r,o],pilots:n,storedShips:[],storedWeapons:[],storedAmmo:[],storedScrap:{},storeStock:OA(),availableRecruits:c,currentSector:1,completedContracts:[],missionCount:0}}function YA(t){return t.ships.find(e=>{var n;return((n=e.pilot)==null?void 0:n.id)===t.commanderId})}function jA(t){return t.ships.filter(e=>e.pilot!==null&&e.pilot.id!==t.commanderId)}function o0(t){return t.ships.some(e=>{var n;return((n=e.pilot)==null?void 0:n.id)===t.commanderId})}function KA(t,e,n,i,s){const r=new Set(t.ships.filter(l=>l.pilot).map(l=>{var u;return(u=l.pilot)==null?void 0:u.id})),o=new Set;for(const l of i){const u=t.ships.find(d=>d.id===l);u!=null&&u.pilot&&o.add(u.pilot.id)}const a=t.ships.filter(l=>!i.includes(l.id));for(const l of a){const u=s.get(l.id);u!==void 0&&(l.hullDamage+=u)}const c=t.pilots.filter(l=>!o.has(l.id)).map(l=>r.has(l.id)?{...l,missionsFlown:l.missionsFlown+1,missionsWon:l.missionsWon+(e?1:0)}:l);return{...t,credits:t.credits+(e?n:0),ships:a,pilots:c,missionCount:t.missionCount+1}}function ZA(t){return!o0(t)}function JA(t,e){const n=new Map(e.map(s=>[s.campaignShipId,s])),i=t.ships.map(s=>{const r=n.get(s.id);if(!r)return s;const o=s.primaryWeapons.map((c,l)=>{if(c===null)return null;const u=r.primaryAmmo.get(l);return u!==void 0?{...c,currentAmmo:u}:c}),a=s.secondaryWeapons.map((c,l)=>{if(c===null)return null;const u=r.secondaryAmmo.get(l);return u!==void 0?{...c,count:u}:c});return{...s,primaryWeapons:o,secondaryWeapons:a}});return{...t,ships:i}}function QA(t,e){return`
    <div class="nav-status" role="status" aria-label="Player status">
      <div class="nav-status-item" aria-label="Current sector: ${e}">
        <span class="nav-status-label">SECTOR</span>
        <span class="nav-status-value">${e}</span>
      </div>
      <div class="nav-status-item" aria-label="Credits: ${t.toLocaleString()}">
        <span class="nav-status-label">CREDITS</span>
        <span class="nav-status-value nav-credits">${t.toLocaleString()}</span>
      </div>
    </div>
  `}function Id(t){const{activeTab:e,credits:n,sector:i,onPause:s}=t,o=[{id:"squadron",label:"SQUADRON",icon:"◈"},{id:"store",label:"STORE",icon:"⬡"},{id:"contracts",label:"CONTRACTS",icon:"▶"}].map(l=>`
      <button
        class="nav-tab ${e===l.id?"active":""}"
        data-nav="${l.id}"
        role="tab"
        aria-selected="${e===l.id}"
        aria-label="${l.label}"
        tabindex="${e===l.id?"0":"-1"}"
      >
        <span class="nav-tab-icon" aria-hidden="true">${l.icon}</span>
        <span class="nav-tab-label">${l.label}</span>
      </button>
    `).join(""),a=QA(n,i);return`
    <nav class="global-nav" role="navigation" aria-label="Main navigation">
      <div class="nav-tabs" role="tablist" aria-label="Screen navigation">
        ${o}
      </div>
      ${a}
      ${s?`<button class="nav-pause-btn" aria-label="Pause menu" title="Menu (Esc)">
        <span aria-hidden="true">☰</span>
      </button>`:""}
      <div class="nav-scanline" aria-hidden="true"></div>
    </nav>
  `}function Nd(t,e,n){t.querySelectorAll(".nav-tab").forEach(i=>{i.addEventListener("click",()=>{const s=i.dataset.nav;s&&e(s)})})}function Fi(t,e,n,i){let s=n,r=i;const o=new Map,a=new Map,c=[],l=[],u=()=>({on(p,v,g){var m;if(!o.has(v)){o.set(v,new Map);const S=_=>{const y=_.target;if(!y)return;const D=o.get(v);if(D)for(const[E,A]of D){const P=y.closest(E);P&&e.contains(P)&&A(_,P)}};e.addEventListener(v,S),a.set(v,S)}(m=o.get(v))==null||m.set(p,g)},onRoot(p,v){e.addEventListener(p,v),c.push({event:p,handler:v})},onGlobal(p,v){document.addEventListener(p,v),l.push({event:p,handler:v})},setState(p){s={...s,...p},f()},updateState(p){s={...s,...p}},getState(){return s},getRoot(){return e}}),d=()=>{o.forEach(p=>{p.clear()});for(const{event:p,handler:v}of c)e.removeEventListener(p,v);c.length=0;for(const{event:p,handler:v}of l)document.removeEventListener(p,v);l.length=0},f=()=>{d(),e.innerHTML=t.render(s,r),t.bind(u(),r)},h=()=>{d();for(const[p,v]of a)e.removeEventListener(p,v);a.clear(),o.clear()};return f(),{setState(p){s={...s,...p},f()},updateState(p){s={...s,...p}},replaceState(p){s=p,f()},getState(){return s},setProps(p){r=p,f()},destroy:h}}function a0(t,e,n){return new Promise(i=>{const s=document.createElement("div");s.className="modal-container",document.body.appendChild(s);let r=null;const a={...n,onComplete:c=>{r==null||r.destroy(),s.remove(),i(c)}};r=Fi(t,s,e,a)})}function eR(t){return[{id:"patrol-1",name:"Patrol Duty",description:"Clear hostiles from the shipping lanes.",difficulty:"easy",waves:[{enemies:[{archetype:"dragonfly",skill:"green",count:2}],delay:[5,10]},{enemies:[{archetype:"dragonfly",skill:"green",count:2}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"green",count:1}],delay:[8,12]},{enemies:[{archetype:"firefly",skill:"green",count:1}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"green",count:1},{archetype:"firefly",skill:"green",count:1}],delay:[8,12]}],reward:2e3},{id:"escort-1",name:"Escort Mission",description:"Defend cargo ships against raider attack.",difficulty:"medium",waves:[{enemies:[{archetype:"dragonfly",skill:"rookie",count:2}],delay:[5,10]},{enemies:[{archetype:"dragonfly",skill:"rookie",count:2}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"rookie",count:1}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"rookie",count:1},{archetype:"firefly",skill:"rookie",count:1}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"rookie",count:1},{archetype:"firefly",skill:"rookie",count:1}],delay:[8,12]}],reward:3500},{id:"assault-1",name:"Strike Mission",description:"Eliminate enemy patrol. Expect heavy resistance.",difficulty:"hard",waves:[{enemies:[{archetype:"dragonfly",skill:"rookie",count:2}],delay:[5,10]},{enemies:[{archetype:"dragonfly",skill:"regular",count:2}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"rookie",count:2}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"rookie",count:1},{archetype:"firefly",skill:"regular",count:1}],delay:[8,12]},{enemies:[{archetype:"dragonfly",skill:"regular",count:1},{archetype:"firefly",skill:"regular",count:1}],delay:[8,12]}],reward:6e3}]}function tR(t){return t.waves.reduce((e,n)=>e+n.enemies.reduce((i,s)=>i+s.count,0),0)}function nR(t,e){return`
    <article
      class="contract-list-item ${e?"selected":""}"
      data-contract-id="${t.id}"
      role="option"
      aria-selected="${e}"
      tabindex="0"
      aria-label="${t.name}, ${t.difficulty} difficulty, ${t.reward} credits"
    >
      <div class="contract-list-info">
        <div class="contract-list-name">${t.name}</div>
        <span class="contract-difficulty ${t.difficulty}" aria-label="Difficulty: ${t.difficulty}">
          ${t.difficulty.toUpperCase()}
        </span>
      </div>
      <div class="contract-list-reward" aria-hidden="true">${t.reward}&nbsp;cr</div>
    </article>
  `}function iR(t,e){const n=new Map;for(const a of t.waves)for(const c of a.enemies){const l=`${c.archetype}`;n.set(l,(n.get(l)??0)+c.count)}const i=Array.from(n.entries()).map(([a,c])=>`<div class="enemy-entry">${c}× ${a}</div>`).join(""),s=tR(t),r=t.waves.length,o=e?'<button class="btn btn-large btn-success" id="btn-accept-mission">ACCEPT MISSION</button>':'<button class="btn btn-warning btn-goto-squadron">⚠ ASSIGN COMMANDER IN SQUADRON</button>';return`
    <div class="contract-detail">
      <div class="contract-detail-header">
        <span class="contract-detail-name">${t.name}</span>
        <span class="contract-difficulty ${t.difficulty}">
          ${t.difficulty.toUpperCase()}
        </span>
      </div>
      <div class="contract-detail-desc">${t.description}</div>
      <div class="contract-detail-section">
        <div class="detail-section-label">HOSTILES</div>
        <div class="contract-enemies">
          ${i}
        </div>
        <div class="contract-waves">${s} total in ${r} waves</div>
      </div>
      <div class="contract-actions">
        <div class="contract-reward-price">${t.reward.toLocaleString()}<span class="currency">cr</span></div>
        ${o}
      </div>
    </div>
  `}const sR={render(t,e){const{campaignState:n,contracts:i,onNavigate:s}=e,r=Id({activeTab:"contracts",credits:n.credits,sector:n.currentSector}),o=t.selectedContractId?i.find(c=>c.id===t.selectedContractId):null,a=o0(n);return`
      <div class="campaign-page">
        ${r}
        <main class="contracts-screen" aria-label="Contract selection">
          <div class="contracts-layout">
            <aside class="contracts-list-panel" role="listbox" aria-label="Available contracts">
              ${i.map(c=>nR(c,c.id===t.selectedContractId)).join("")}
            </aside>
            <section class="contracts-detail-panel" aria-label="Contract details">
              ${o?iR(o,a):'<div class="empty-state-panel" role="status">Select a contract to view details</div>'}
            </section>
          </div>
        </main>
      </div>
    `},bind(t,e){const{contracts:n,onNavigate:i,onAccept:s}=e;Nd(t.getRoot(),i),t.on(".contract-list-item","click",(r,o)=>{const a=o.getAttribute("data-contract-id");if(a){const c=t.getState(),l=a===c.selectedContractId?null:a;t.setState({selectedContractId:l})}}),t.on("#btn-accept-mission","click",()=>{const r=t.getState();if(r.selectedContractId){const o=n.find(a=>a.id===r.selectedContractId);o&&s(o)}}),t.on(".btn-goto-squadron","click",()=>{i("squadron")})}};let Jo=null;function rR(t,e,n,i){Jo==null||Jo.destroy();const s=eR(e.currentSector);return Jo=Fi(sR,t,{selectedContractId:null},{campaignState:e,contracts:s,onNavigate:n,onAccept:i}),{element:t,state:e,contracts:s,selectedContractId:null,onNavigate:n,onAccept:i}}const Cu=1,ho=3,oR="spaceflight_save_";function c0(t){if(!t||typeof t!="object")return!1;const e=t;return typeof e.version=="number"&&typeof e.timestamp=="number"&&e.state!==null&&typeof e.state=="object"}function l0(t){if(!t||typeof t!="object")return!1;const e=t;return typeof e.credits=="number"&&typeof e.currentSector=="number"&&Array.isArray(e.ships)&&Array.isArray(e.pilots)}function po(t){return`${oR}${t}`}function Kh(t,e){if(t<1||t>ho)return console.error(`Invalid save slot: ${t}`),!1;const n={version:Cu,timestamp:Date.now(),state:e};try{const i=JSON.stringify(n);return localStorage.setItem(po(t),i),!0}catch(i){return console.error(`Failed to save game to slot ${t}:`,i),!1}}function aR(t){if(t<1||t>ho)return console.error(`Invalid save slot: ${t}`),null;try{const e=localStorage.getItem(po(t));if(!e)return null;const n=JSON.parse(e);return c0(n)?l0(n.state)?(n.version!==Cu&&console.warn(`Save version mismatch: expected ${Cu}, got ${n.version}`),n.state):(console.error(`Invalid campaign state in slot ${t}`),null):(console.error(`Invalid save data structure in slot ${t}`),null)}catch(e){return console.error(`Failed to load game from slot ${t}:`,e),null}}function cR(t){if(t<1||t>ho){console.error(`Invalid save slot: ${t}`);return}localStorage.removeItem(po(t))}function lR(t){if(t<1||t>ho)return null;try{const e=localStorage.getItem(po(t));if(!e)return null;const n=JSON.parse(e);if(!c0(n))return console.warn(`Invalid save data structure in slot ${t}`),null;if(!l0(n.state))return console.warn(`Invalid campaign state in slot ${t}`),null;const i=n.state;return{slot:t,version:n.version,timestamp:n.timestamp,credits:i.credits,missionCount:i.missionCount??0,currentSector:i.currentSector,shipCount:i.ships.length,pilotCount:i.pilots.length}}catch{return null}}function Ud(){return[1,2,3].map(t=>lR(t))}function uR(){for(let t=1;t<=ho;t++)if(localStorage.getItem(po(t)))return!0;return!1}function u0(t){return new Date(t).toLocaleDateString(void 0,{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}function d0(t){const e={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"};return t.replace(/[&<>"']/g,n=>e[n]??n)}function dR(t,e){const n=e+1;return t?`
    <div class="pause-save-slot occupied" data-slot="${n}">
      <div class="pause-save-header">
        <span class="pause-slot-number">Slot ${n}</span>
        <span class="pause-save-date">${u0(t.timestamp)}</span>
      </div>
      <div class="pause-save-info">
        <span>Sector ${t.currentSector}</span>
        <span>${t.missionCount} missions</span>
        <span>${t.credits.toLocaleString()} credits</span>
      </div>
      <button class="btn btn-small btn-warning btn-save-to-slot" data-slot="${n}">
        Overwrite
      </button>
    </div>
  `:`
      <div class="pause-save-slot empty" data-slot="${n}">
        <div class="pause-save-header">
          <span class="pause-slot-number">Slot ${n}</span>
        </div>
        <div class="pause-save-empty">Empty Slot</div>
        <button class="btn btn-small btn-success btn-save-to-slot" data-slot="${n}">
          Save Here
        </button>
      </div>
    `}function fR(){return`
    <div class="pause-save-view">
      <div class="pause-save-title">Save Game</div>
      <div class="pause-save-list">
        ${Ud().map((e,n)=>dR(e,n)).join("")}
      </div>
      <button class="btn btn-large" id="btn-pause-back">Back</button>
    </div>
  `}function hR(){return`
    <div class="pause-confirm-view">
      <div class="pause-confirm-title">Quit to Title?</div>
      <div class="pause-confirm-message">Unsaved progress will be lost.</div>
      <div class="pause-confirm-buttons">
        <button class="btn btn-large" id="btn-confirm-cancel">Cancel</button>
        <button class="btn btn-large btn-danger" id="btn-confirm-quit">Quit</button>
      </div>
    </div>
  `}function pR(t){return`
    <div class="pause-confirm-view">
      <div class="pause-confirm-title">Overwrite Save?</div>
      <div class="pause-confirm-message">This will replace the save in Slot ${t}.</div>
      <div class="pause-confirm-buttons">
        <button class="btn btn-large" id="btn-confirm-cancel">Cancel</button>
        <button class="btn btn-large btn-warning" id="btn-confirm-overwrite" data-slot="${t}">Overwrite</button>
      </div>
    </div>
  `}function mR(t){return`
    <div class="pause-confirm-view">
      <div class="pause-confirm-title pause-error-title">Error</div>
      <div class="pause-confirm-message">${d0(t)}</div>
      <div class="pause-confirm-buttons">
        <button class="btn btn-large" id="btn-error-ok">OK</button>
      </div>
    </div>
  `}function gR(t){return`
    <div class="pause-main-view">
      <div class="pause-title">Paused</div>
      <div class="pause-menu-buttons">
        <button class="btn btn-large btn-primary" id="btn-pause-resume">
          Resume
        </button>
        <button
          class="btn btn-large"
          id="btn-pause-save"
          ${t?"":"disabled"}
          ${t?"":'title="Cannot save during mission"'}
        >
          Save Game
        </button>
        <button class="btn btn-large" id="btn-pause-settings">
          Settings
        </button>
        <button class="btn btn-large btn-danger" id="btn-pause-quit">
          Quit to Title
        </button>
      </div>
    </div>
  `}const vR={render(t,e){let n;switch(t.view){case"main":n=gR(e.canSave);break;case"save":n=fR();break;case"confirm-quit":n=hR();break;case"confirm-overwrite":n=pR(t.pendingOverwriteSlot??1);break;case"error":n=mR(t.errorMessage??"An error occurred.");break}return`
      <div class="pause-overlay" role="dialog" aria-modal="true" aria-labelledby="pause-title">
        <div class="pause-modal">
          ${n}
        </div>
      </div>
    `},bind(t,e){t.on("#btn-pause-resume","click",()=>{e.onComplete({action:"resume"})}),t.on("#btn-pause-save","click",()=>{t.setState({view:"save"})}),t.on("#btn-pause-settings","click",()=>{e.onComplete({action:"settings"})}),t.on("#btn-pause-quit","click",()=>{t.setState({view:"confirm-quit"})}),t.on("#btn-pause-back","click",()=>{t.setState({view:"main"})}),t.on(".btn-save-to-slot","click",(n,i)=>{const s=parseInt(i.dataset.slot??"0",10);s>0&&(Ud()[s-1]?t.setState({pendingOverwriteSlot:s,view:"confirm-overwrite"}):Kh(s,e.campaignState)?e.onComplete({action:"save",saveSlot:s}):t.setState({errorMessage:`Failed to save game to Slot ${s}. Storage may be full.`,view:"error"}))}),t.on("#btn-error-ok","click",()=>{t.setState({errorMessage:null,view:"save"})}),t.on("#btn-confirm-cancel","click",()=>{t.getState().view==="confirm-quit"?t.setState({view:"main"}):t.setState({pendingOverwriteSlot:null,view:"save"})}),t.on("#btn-confirm-quit","click",()=>{e.onComplete({action:"quit"})}),t.on("#btn-confirm-overwrite","click",()=>{const n=t.getState();n.pendingOverwriteSlot&&(Kh(n.pendingOverwriteSlot,e.campaignState)?e.onComplete({action:"save",saveSlot:n.pendingOverwriteSlot}):t.setState({errorMessage:`Failed to save game to Slot ${n.pendingOverwriteSlot}. Storage may be full.`,pendingOverwriteSlot:null,view:"error"}))}),t.onGlobal("keydown",n=>{if(n.code==="Escape"){n.preventDefault();const i=t.getState();i.view==="save"?t.setState({view:"main"}):i.view==="error"?t.setState({errorMessage:null,view:"save"}):i.view==="confirm-quit"?t.setState({view:"main"}):i.view==="confirm-overwrite"?t.setState({pendingOverwriteSlot:null,view:"save"}):e.onComplete({action:"resume"})}})}};function yR(t,e){return a0(vR,{view:"main",pendingOverwriteSlot:null,errorMessage:null},{campaignState:t,canSave:e})}function SR(t,e){const i=Ya()[t],s=_g[t],r=Qw(i),o=e===t,a=i===ki[t];return`
    <div class="binding-row" data-action="${t}">
      <span class="binding-label">${s}</span>
      <div class="binding-controls">
        <button
          class="btn btn-small binding-key ${o?"listening":""}"
          data-action="${t}"
          aria-label="Rebind ${s}"
        >
          ${o?"Press a key...":r}
        </button>
        ${a?"":`<button class="btn btn-small btn-reset-key" data-action="${t}" title="Reset to default">
                 <span class="reset-icon">&#8634;</span>
               </button>`}
      </div>
    </div>
  `}function _R(t,e,n){return`
    <div class="settings-category">
      <h3 class="category-header">${t}</h3>
      <div class="category-bindings">
        ${e.map(i=>SR(i,n)).join("")}
      </div>
    </div>
  `}function xR(t){return`
    <div class="settings-tab-content">
      <div class="settings-tab-header">
        <button class="btn btn-small" id="btn-reset-all">
          Reset All to Defaults
        </button>
      </div>
      <div class="bindings-list">
        ${Object.entries(qw).map(([n,i])=>_R(n,i,t)).join("")}
      </div>
    </div>
  `}function bR(t){const e=Wm.find(n=>n.value===t);return(e==null?void 0:e.label)??`${t} FPS`}function MR(t){return`
    <div class="settings-picker" id="fps-popover">
      <div class="settings-picker-content">
        ${Wm.map(n=>`
      <button class="settings-picker-item ${n.value===t?"selected":""}"
              data-fps="${n.value}">
        ${n.label}
      </button>
    `).join("")}
      </div>
    </div>
  `}function ER(t){const e=K1();return`
    <div class="settings-tab-content">
      <div class="graphics-settings">
        <div class="binding-row">
          <span class="binding-label">Frame Rate Limit</span>
          <div class="binding-controls">
            <div class="settings-picker-trigger-container">
              <button class="settings-picker-trigger" id="fps-cap-trigger">
                ${bR(e)}
              </button>
              ${t?MR(e):""}
            </div>
          </div>
        </div>
      </div>
    </div>
  `}let js=null;function wR(t){Zr(),js=e=>{const n=document.getElementById("fps-popover"),i=document.getElementById("fps-cap-trigger");n&&i&&!n.contains(e.target)&&!i.contains(e.target)&&(Zr(),t())},setTimeout(()=>{js&&document.addEventListener("click",js)},0)}function Zr(){js&&(document.removeEventListener("click",js),js=null)}function TR(){const t=document.getElementById("fps-cap-trigger"),e=document.getElementById("fps-popover");if(t&&e){const n=t.getBoundingClientRect();e.style.left=`${n.left}px`,e.style.top=`${n.bottom+4}px`}}function AR(){return`
    <div class="settings-confirm-view">
      <div class="settings-confirm-content">
        <div class="settings-confirm-title">Reset All Bindings?</div>
        <div class="settings-confirm-message">
          This will restore all key bindings to their default values.
        </div>
        <div class="settings-confirm-buttons">
          <button class="btn btn-large" id="btn-reset-cancel">Cancel</button>
          <button class="btn btn-large btn-warning" id="btn-reset-confirm">Reset All</button>
        </div>
      </div>
    </div>
  `}function RR(t){return`
    <nav class="settings-tabs" role="tablist" aria-label="Settings categories">
      <button class="btn ${t==="graphics"?"btn-primary":""}"
              data-tab="graphics" role="tab" aria-selected="${t==="graphics"}">
        Graphics
      </button>
      <button class="btn ${t==="controls"?"btn-primary":""}"
              data-tab="controls" role="tab" aria-selected="${t==="controls"}">
        Controls
      </button>
    </nav>
  `}function CR(t){const e=t.selectedTab==="graphics"?ER(t.showFpsPopover):xR(t.listeningAction);return`
    <div class="settings-container">
      <header class="panel-header">
        <h2>Settings</h2>
      </header>

      ${RR(t.selectedTab)}

      <div class="settings-content">
        ${e}
      </div>

      <footer class="settings-footer">
        <button class="btn btn-large" id="btn-settings-back">
          Back
        </button>
      </footer>
    </div>
  `}let va=null;const f0={render(t,e){let n;return t.showResetConfirm?n=AR():n=CR(t),`
      <div class="settings-screen">
        <div class="settings-background" id="settings-battle-bg"></div>
        <div class="settings-content-wrapper">
          ${n}
        </div>
      </div>
    `},bind(t,e){const n=t.getState();t.on(".settings-tabs .btn","click",(i,s)=>{const r=s.dataset.tab;r&&r!==n.selectedTab&&(Ii(),t.setState({selectedTab:r,listeningAction:null}))}),t.on("#btn-settings-back","click",()=>{Ii(),e.onBack()}),t.on("#fps-cap-trigger","click",i=>{i.stopPropagation(),Zr(),t.setState({showFpsPopover:!n.showFpsPopover})}),t.on(".settings-picker-item","click",(i,s)=>{i.stopPropagation();const r=s.dataset.fps;if(r!==void 0){const o=Number.parseInt(r,10);Z1(o),Zr(),t.setState({showFpsPopover:!1})}}),n.showFpsPopover&&(wR(()=>t.setState({showFpsPopover:!1})),TR()),t.on("#btn-reset-all","click",()=>{t.setState({showResetConfirm:!0})}),t.on("#btn-reset-cancel","click",()=>{t.setState({showResetConfirm:!1})}),t.on("#btn-reset-confirm","click",()=>{jw(),t.setState({showResetConfirm:!1})}),t.on(".binding-key","click",(i,s)=>{const r=s.dataset.action;r&&r in _g&&IR(t,r)}),t.on(".btn-reset-key","click",(i,s)=>{const r=s.dataset.action;r&&r in ki&&(Mu(r,ki[r]),xd(),t.setState({}))}),n.listeningAction&&DR(t,n.listeningAction),LR()}};let ya=null;function PR(t){ya=t}function LR(){if(ya){const t=document.getElementById("settings-battle-bg"),e=document.querySelector(".settings-screen");t&&(ya.parentElement!==t&&t.appendChild(ya),e==null||e.classList.add("with-battle-bg"))}}function DR(t,e){Ii();const n=i=>{if(i.preventDefault(),i.stopPropagation(),i.code==="Escape"){Ii(),t.setState({listeningAction:null});return}const s=Kw(i.code,e);if(s){const r=Ya()[e];Mu(s,r)}Mu(e,i.code),xd(),Ii(),t.setState({listeningAction:null})};va=n,document.addEventListener("keydown",n,!0)}function IR(t,e){Ii(),t.setState({listeningAction:e})}function Ii(){va&&(document.removeEventListener("keydown",va,!0),va=null)}let Ai=null;function NR(t){const e={selectedTab:"graphics",listeningAction:null,showResetConfirm:!1,showFpsPopover:!1};t.innerHTML=f0.render(e,{onBack:()=>{}})}function UR(t,e){Ai==null||Ai.destroy(),Ii(),Ai=Fi(f0,t,{selectedTab:"graphics",listeningAction:null,showResetConfirm:!1,showFpsPopover:!1},e)}function kR(){Ii(),Zr(),Ai==null||Ai.destroy(),Ai=null}function mo(t){return yr(t.weaponType,t.bankSize)}function kd(t){return h0(t)||p0(t)}function h0(t){for(const e of t.primaryWeapons){if(e===null)return!0;if(e.currentAmmo!==void 0){const n=mo(e);if(e.currentAmmo<n)return!0}}return!1}function p0(t){for(const e of t.secondaryWeapons)if(e===null||e.count<e.maxCount)return!0;return!1}function m0(t){for(const e of t.primaryWeapons){if(e===null||e.currentAmmo===void 0)continue;const n=mo(e);if(e.currentAmmo<n)return!0}for(const e of t.secondaryWeapons)if(e!==null&&e.count<e.maxCount)return!0;return!1}function FR(t){return kd(t)}function OR(t){const e=[],n=t.primaryWeapons.filter(o=>o===null).length;n>0&&e.push(`${n} empty primary slot${n>1?"s":""}`);const i=t.secondaryWeapons.filter(o=>o===null).length;i>0&&e.push(`${i} empty secondary slot${i>1?"s":""}`);const s=[];for(const o of t.primaryWeapons){if(o===null||o.currentAmmo===void 0)continue;const a=mo(o);if(o.currentAmmo<a){const c=Math.round(o.currentAmmo/a*100);s.push(`${gd(o.weaponType)} (${c}%)`)}}s.length>0&&e.push(`Low ammo: ${s.join(", ")}`);const r=[];for(const o of t.secondaryWeapons)o!==null&&o.count<o.maxCount&&r.push(`${Di(o.weaponType)} (${o.count}/${o.maxCount})`);return r.length>0&&e.push(`Low missiles: ${r.join(", ")}`),e}function Fd(t){const e=new Map,n=new Map;let i=0;for(const s of t.primaryWeapons){if(s===null||s.currentAmmo===void 0)continue;const r=mo(s),o=Math.max(0,r-s.currentAmmo);o>0&&(e.set(s.weaponType,(e.get(s.weaponType)??0)+o),i+=o)}for(const s of t.secondaryWeapons){if(s===null)continue;const r=Math.max(0,s.maxCount-s.count);r>0&&(n.set(s.weaponType,(n.get(s.weaponType)??0)+r),i+=r)}return{ammo:e,missiles:n,totalNeeded:i}}function BR(t,e,n){const i=t.findIndex(c=>c.weaponType===e);if(i<0||n<=0)return{newStorage:t,consumed:0};const s=t[i];if(!s)return{newStorage:t,consumed:0};const r=Math.min(n,s.count),o=s.count-r,a=[...t];return o<=0?a.splice(i,1):a[i]={weaponType:e,count:o},{newStorage:a,consumed:r}}function zR(t,e,n){const i=t.findIndex(c=>c.weaponType===e&&c.category==="secondary");if(i<0||n<=0)return{newStorage:t,consumed:0};const s=t[i];if(!s)return{newStorage:t,consumed:0};const r=Math.min(n,s.count),o=s.count-r,a=[...t];return o<=0?a.splice(i,1):a[i]={...s,count:o},{newStorage:a,consumed:r}}function Ra(t,e){return t===0&&!e?"insufficient credits and stock":t===0?"out of stock":"insufficient credits"}function el(t,e,n){return{state:t,success:e,fromStorage:{ammo:new Map,missiles:new Map},bought:{ammo:new Map,missiles:new Map},creditsSpent:0,shortages:{ammo:new Map,missiles:new Map},shortageReason:"none",messages:n}}function g0(t,e){const n=t.ships.findIndex(E=>E.id===e);if(n<0)return el(t,!1,["Ship not found"]);const i=t.ships[n];if(!i)return el(t,!1,["Ship not found"]);const s=Fd(i);if(s.totalNeeded===0)return el(t,!0,["Already fully supplied"]);const r={ammo:new Map,missiles:new Map},o={ammo:new Map,missiles:new Map},a={ammo:new Map,missiles:new Map};let c=0,l=[...t.storedAmmo],u=[...t.storedWeapons],d=t.credits;const f={...t.storeStock,ammo:{...t.storeStock.ammo},secondaries:{...t.storeStock.secondaries}},h=new Map;for(const[E,A]of s.ammo){let P=A;const b=BR(l,E,P);if(l=b.newStorage,b.consumed>0&&(r.ammo.set(E,b.consumed),P-=b.consumed),P>0){const L=f.ammo[E]??0,B=pn(E,"buy"),F=B>0?Math.floor(d/B):0,G=Math.min(P,L,F);if(G>0){const $=Math.round(G*B);o.ammo.set(E,G),d-=$,c+=$,f.ammo[E]=L-G,P-=G}}const x=(r.ammo.get(E)??0)+(o.ammo.get(E)??0);x>0&&h.set(E,x),P>0&&a.ammo.set(E,P)}const p=new Map;for(const[E,A]of s.missiles){let P=A;const b=zR(u,E,P);if(u=b.newStorage,b.consumed>0&&(r.missiles.set(E,b.consumed),P-=b.consumed),P>0){const L=f.secondaries[E]??0,B=mn(E,"buy"),F=B>0?Math.floor(d/B):0,G=Math.min(P,L,F);if(G>0){const $=G*B;o.missiles.set(E,G),d-=$,c+=$,f.secondaries[E]=L-G,P-=G}}const x=(r.missiles.get(E)??0)+(o.missiles.get(E)??0);x>0&&p.set(E,x),P>0&&a.missiles.set(E,P)}const v=i.primaryWeapons.map(E=>{if(E===null||E.currentAmmo===void 0)return E;const A=h.get(E.weaponType)??0;if(A===0)return E;const P=mo(E),b=Math.min(A,P-E.currentAmmo);return h.set(E.weaponType,A-b),{...E,currentAmmo:E.currentAmmo+b}}),g=i.secondaryWeapons.map(E=>{if(E===null)return E;const A=p.get(E.weaponType)??0;if(A===0)return E;const P=Math.min(A,E.maxCount-E.count);return p.set(E.weaponType,A-P),{...E,count:E.count+P}}),m={...i,primaryWeapons:v,secondaryWeapons:g},S=[...t.ships];S[n]=m;const _=[],y=[...a.ammo.values()].reduce((E,A)=>E+A,0)+[...a.missiles.values()].reduce((E,A)=>E+A,0);let D="none";if(y>0){const E=[...a.ammo.keys()].some(P=>(f.ammo[P]??0)===0)||[...a.missiles.keys()].some(P=>(f.secondaries[P]??0)===0),A=d<1;E&&A?D="both":A?D="credits":E?D="stock":D="both"}for(const[E,A]of r.ammo)_.push(`Loaded ${A} ${es(E)} from storage`);for(const[E,A]of r.missiles)_.push(`Loaded ${A} ${Di(E)} from storage`);for(const[E,A]of o.ammo){const P=pn(E,"buy"),b=Math.round(A*P);_.push(`Bought ${A} ${es(E)} for ${b} cr`)}for(const[E,A]of o.missiles){const P=mn(E,"buy"),b=A*P;_.push(`Bought ${A} ${Di(E)} for ${b} cr`)}for(const[E,A]of a.ammo){const P=f.ammo[E]??0,b=pn(E,"buy"),x=b>0&&d>=b,L=Ra(P,x);_.push(`Short ${A} ${es(E)} (${L})`)}for(const[E,A]of a.missiles){const P=f.secondaries[E]??0,b=mn(E,"buy"),x=b>0&&d>=b,L=Ra(P,x);_.push(`Short ${A} ${Di(E)} (${L})`)}return{state:{...t,ships:S,credits:d,storedAmmo:l,storedWeapons:u,storeStock:f},success:y===0,fromStorage:r,bought:o,creditsSpent:c,shortages:a,shortageReason:D,messages:_.length>0?_:["Resupplied"]}}function HR(t,e){const n=t.ships.find(c=>c.id===e);if(!n)return{cost:0,fromStorage:0,toBuy:0,canAfford:!0,hasStock:!0};const i=Fd(n);if(i.totalNeeded===0)return{cost:0,fromStorage:0,toBuy:0,canAfford:!0,hasStock:!0};let s=0,r=0,o=0,a=!0;for(const[c,l]of i.ammo){let u=l;const d=t.storedAmmo.find(f=>f.weaponType===c);if(d){const f=Math.min(u,d.count);r+=f,u-=f}if(u>0){const f=t.storeStock.ammo[c]??0,h=Math.min(u,f);h<u&&(a=!1),o+=h;const p=pn(c,"buy");s+=Math.round(h*p)}}for(const[c,l]of i.missiles){let u=l;const d=t.storedWeapons.find(f=>f.weaponType===c&&f.category==="secondary");if(d){const f=Math.min(u,d.count);r+=f,u-=f}if(u>0){const f=t.storeStock.secondaries[c]??0,h=Math.min(u,f);h<u&&(a=!1),o+=h;const p=mn(c,"buy");s+=h*p}}return{cost:s,fromStorage:r,toBuy:o,canAfford:t.credits>=s,hasStock:a}}function GR(t){let e=0,n=0,i=0,s=!0;const r=new Map;for(const c of t.storedAmmo)r.set(c.weaponType,c.count);const o=new Map;for(const c of t.storedWeapons)c.category==="secondary"&&o.set(c.weaponType,(o.get(c.weaponType)??0)+c.count);const a={ammo:{...t.storeStock.ammo},secondaries:{...t.storeStock.secondaries}};for(const c of t.ships){const l=Fd(c);for(const[u,d]of l.ammo){let f=d;const h=r.get(u)??0;if(h>0){const p=Math.min(f,h);n+=p,f-=p,r.set(u,h-p)}if(f>0){const p=a.ammo[u]??0,v=Math.min(f,p);v<f&&(s=!1),i+=v;const g=pn(u,"buy");e+=Math.round(v*g),a.ammo[u]=p-v}}for(const[u,d]of l.missiles){let f=d;const h=o.get(u)??0;if(h>0){const p=Math.min(f,h);n+=p,f-=p,o.set(u,h-p)}if(f>0){const p=a.secondaries[u]??0,v=Math.min(f,p);v<f&&(s=!1),i+=v;const g=mn(u,"buy");e+=v*g,a.secondaries[u]=p-v}}}return{cost:e,fromStorage:n,toBuy:i,canAfford:t.credits>=e,hasStock:s}}function WR(t,e){const n=[...t.ships].sort((f,h)=>{var g,m;const p=((g=f.pilot)==null?void 0:g.id)===e,v=((m=h.pilot)==null?void 0:m.id)===e;return p&&!v?-1:!p&&v?1:0}),i={ammo:new Map,missiles:new Map},s={ammo:new Map,missiles:new Map},r={ammo:new Map,missiles:new Map};let o=0,a=t,c=0;for(const f of n){if(!FR(f))continue;const h=g0(a,f.id);a=h.state,o+=h.creditsSpent;for(const[p,v]of h.fromStorage.ammo)i.ammo.set(p,(i.ammo.get(p)??0)+v);for(const[p,v]of h.fromStorage.missiles)i.missiles.set(p,(i.missiles.get(p)??0)+v);for(const[p,v]of h.bought.ammo)s.ammo.set(p,(s.ammo.get(p)??0)+v);for(const[p,v]of h.bought.missiles)s.missiles.set(p,(s.missiles.get(p)??0)+v);for(const[p,v]of h.shortages.ammo)r.ammo.set(p,(r.ammo.get(p)??0)+v);for(const[p,v]of h.shortages.missiles)r.missiles.set(p,(r.missiles.get(p)??0)+v);c++}if(c===0)return{state:a,success:!0,fromStorage:i,bought:s,creditsSpent:o,shortages:r,shortageReason:"none",messages:["All ships fully supplied"]};const l=[],u=[...r.ammo.values()].reduce((f,h)=>f+h,0)+[...r.missiles.values()].reduce((f,h)=>f+h,0);for(const[f,h]of i.ammo)l.push(`Loaded ${h} ${es(f)} from storage`);for(const[f,h]of i.missiles)l.push(`Loaded ${h} ${Di(f)} from storage`);for(const[f,h]of s.ammo){const p=pn(f,"buy"),v=Math.round(h*p);l.push(`Bought ${h} ${es(f)} for ${v} cr`)}for(const[f,h]of s.missiles){const p=mn(f,"buy"),v=h*p;l.push(`Bought ${h} ${Di(f)} for ${v} cr`)}let d="none";if(u>0){const f=[...r.ammo.keys()].some(p=>(a.storeStock.ammo[p]??0)===0)||[...r.missiles.keys()].some(p=>(a.storeStock.secondaries[p]??0)===0),h=a.credits<1;f&&h?d="both":h?d="credits":f?d="stock":d="both"}for(const[f,h]of r.ammo){const p=a.storeStock.ammo[f]??0,v=pn(f,"buy"),g=v>0&&a.credits>=v,m=Ra(p,g);l.push(`Short ${h} ${es(f)} (${m})`)}for(const[f,h]of r.missiles){const p=a.storeStock.secondaries[f]??0,v=mn(f,"buy"),g=v>0&&a.credits>=v,m=Ra(p,g);l.push(`Short ${h} ${Di(f)} (${m})`)}return{state:a,success:u===0,fromStorage:i,bought:s,creditsSpent:o,shortages:r,shortageReason:d,messages:l.length>0?l:[`Resupplied ${c} ${c===1?"ship":"ships"}`]}}const VR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><rect width="24" height="12" x="8" y="10" rx="2"/><path d="M32 12h56m-56 4h56m-56 4h56m0-12v16"/></svg>',$R='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="-10 0 116 32"><defs><filter id="a" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="3"/><feMerge><feMergeNode in="blur"/><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="b" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="2"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g stroke="#00f" filter="url(#a)"><path d="M27 16h67M84 6v20m8.66-5L75.34 11M89 24.66 79 7.34M75.34 21l17.32-10M79 24.66 89 7.34"/></g><rect width="24" height="12" x="2" y="10" stroke="currentColor" filter="url(#b)" rx="2"/></svg>',XR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><circle cx="48" cy="16" r="8"/><path d="M48 4v4m0 16v4M36 16h-4m32 0h-4M38 8l4 3m16-3-4 3M38 24l4-3m16 3-4-3m-38-5h12m40 0h12"/></svg>',qR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="-10 0 116 32"><defs><filter id="a" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="3"/><feMerge><feMergeNode in="blur"/><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="b" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="2"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g stroke="#0f0" filter="url(#a)"><path d="M32 16h56M78 6v20m8.66-5L69.34 11M83 24.66 73 7.34M69.34 21l17.32-10M72 24.66 83 7.34"/></g><rect width="24" height="12" x="7" y="10" stroke="currentColor" filter="url(#b)" rx="2"/></svg>',YR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 8v16l12-8Zm20 8 6-2v4l6-2m12 0 6-2v4l6-2m12 0 6-2v4l6-2"/></svg>',jR='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 32"><defs><clipPath id="a"><path d="M0 0h96v32H0z"/></clipPath></defs><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><rect width="25.6" height="8" x="6.4" y="3.2" rx="4" ry="4"/><path d="M19.2 11.2v5.92c-6.88 0-6.88 5.76 0 5.76-6.88 0-6.88 5.92 0 5.92-6.88 0-6.88 5.92 0 5.92-6.88 0-6.88 5.92 0 5.92-6.88 0-6.88 5.92 0 5.92v5.92" clip-path="url(#a)"/><path fill="currentColor" d="M40 19.2 67.2 4.8V16L88 12.8 60.8 27.2V16Z"/></g></svg>',KR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="-10 0 116 32"><defs><filter id="a" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="3"/><feMerge><feMergeNode in="blur"/><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="b" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="2"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter><path id="c" d="M0-4.5v-9.9a14.4 14.4 0 0 1 12.47 7.2L3.9-2.25A4.5 4.5 0 0 0 0-4.5"/></defs><g stroke="#fff" filter="url(#a)"><path d="M34 16h60M84 6v20m8.66-5L75.34 11M89 24.66 79 7.34M75.34 21l17.32-10M79 24.66 89 7.34"/></g><g fill="currentColor" filter="url(#b)" transform="translate(-32)"><circle cx="48" cy="16" r="2.7"/><use href="#c" transform="rotate(30 -5.856 97.57)"/><use href="#c" transform="rotate(150 21.856 14.43)"/><use href="#c" transform="rotate(-90 32 -16)"/></g></svg>',ZR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 8v16l12-8Z"/><rect width="12" height="4" x="28" y="14" rx="2"/><rect width="12" height="4" x="52" y="14" rx="2"/><rect width="12" height="4" x="76" y="14" rx="2"/></svg>',JR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 8v16l12-8Zm20 8h12m12 0h12m12 0h12"/></svg>',QR='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 16h80m-68-6h8v12h-8zm16 0h8v12h-8zm16 0h8v12h-8zm16 0h8v12h-8z"/></svg>',eC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="-10 0 116 32"><defs><filter id="a" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="3"/><feMerge><feMergeNode in="blur"/><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="b" width="300%" height="300%" x="-100%" y="-100%"><feGaussianBlur in="SourceGraphic" result="blur" stdDeviation="2"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g stroke="red" filter="url(#a)"><path d="M37 16h44M71 6v20m8.66-5L62.34 11M76 24.66 66 7.34M62.34 21l17.32-10M66 24.66 76 7.34"/></g><rect width="24" height="12" x="12" y="10" stroke="currentColor" filter="url(#b)" rx="2"/></svg>',tC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path fill="currentColor" stroke="none" d="M40.505 30.024c-2.852-1.24-3.972-3.647-4.286-9.206-.128-2.25-.136-4.09-.02-4.09.117 0 .516.162.886.36.599.32.72.148 1.085-1.546.226-1.048.508-2.61.627-3.472l.217-1.566 1.186 1.15 1.185 1.149.255-2.721c.14-1.497.14-3.246-.001-3.888-.24-1.097-.21-1.143.499-.763.415.222.928.727 1.14 1.123.713 1.334 1.086.732 1.086-1.757 0-1.564.19-2.736.515-3.182.496-.677.526-.665.773.318.141.562.964 1.851 1.828 2.864s1.638 2.27 1.719 2.795l.147.953.054-1c.07-1.277.495-1.264 1.6.049.8.95 1.216 2.098 1.928 5.315.232 1.049.253 1.06.554.273.4-1.048.824-1.037 1.399.038.56 1.048.647 2.938.277 6.053-.25 2.095-.222 2.289.245 1.706.486-.607.545-.547.768.777.307 1.813-.332 4.251-1.526 5.829-1.197 1.582-4.14 2.952-6.35 2.957q-3.233.007-.89-1.373c1.43-.844 2.884-2.649 3.692-4.582.544-1.3.54-1.363-.082-1.166-.58.184-.642.008-.535-1.516l.121-1.723-.95 1.363c-1.2 1.723-1.698 1.747-1.232.058.45-1.63.09-3.965-.85-5.512-.396-.65-.777-1.182-.847-1.182s-.121 1.35-.115 3c.012 2.942-.443 5-1.105 5-.183 0-.588-.614-.899-1.364l-.566-1.363-.055 1.273c-.03.7-.027 1.804.009 2.454s-.102 1.182-.306 1.182c-.61 0-1.506-1.544-1.74-3-.241-1.496-.822-1.844-.91-.546-.117 1.738-.173 1.907-.605 1.816-.99-.208.463 3.61 2.07 5.44.625.713 1.136 1.396 1.136 1.52 0 .397-1.964.211-3.131-.297"/></svg>',nC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 16h12"/><rect width="24" height="8" x="20" y="6" rx="2"/><rect width="24" height="8" x="20" y="18" rx="2"/><path d="M44 10h12l8 6-8 6H44m20-6h16"/></svg>',iC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="m8 16 8-4v8zm8 0h72m-64-4v8m56-10 8 6-8 6"/></svg>',sC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><circle cx="24" cy="16" r="10"/><path d="M24 10v12m-6-6h12m10-8q12 8 0 16M52 6q16 10 0 20"/><path d="M64 4q20 12 0 24"/></svg>',rC='<svg xmlns="http://www.w3.org/2000/svg" width="96" height="32" viewBox="0 0 96 32"><defs><path id="a" d="M0-4.5v-9.9a14.4 14.4 0 0 1 12.47 7.2L3.9-2.25A4.5 4.5 0 0 0 0-4.5"/></defs><circle cx="48" cy="16" r="2.7" fill="currentColor"/><g fill="currentColor"><use href="#a" transform="rotate(30 -5.856 97.57)"/><use href="#a" transform="rotate(150 21.856 14.43)"/><use href="#a" transform="rotate(-90 32 -16)"/></g></svg>',oC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 16h16m0-6v12h48l16-6-16-6zm8 0v12"/></svg>',aC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 16h12m0-6v12h40V10z"/><circle cx="76" cy="16" r="10"/><path d="m72 12 8 8m-8 0 8-8"/></svg>',cC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><path d="M8 8h20l8 4M8 16h32M8 24h20l8-4m12-4h40m-8-6 8 6-8 6"/><circle cx="44" cy="16" r="6"/></svg>',lC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 96 32"><ellipse cx="48" cy="16" rx="36" ry="12"/><path d="M12 16h8m56 0h8m0-6v12M36 10v12M48 8v16m12-14v12"/></svg>',uC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 12 6 8 20 4-2 8 2 8-20 4-2 12-4-4-4 4-2-12-20-4 2-8-2-8 20-4Z"/></svg>',dC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 6 16 8 6 18-6 18-16 8-16-8-6-18 6-18Z"/><path d="m32 16 8 4 4 12-4 12-8 4-8-4-4-12 4-12Z"/></svg>',fC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 6 4 14 20 16-8 2-4 16-12-8-12 8-4-16-8-2 20-16Z"/></svg>',hC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 4 4 14 22 26H46l-4 14-10-8-10 8-4-14H6l22-26Z"/></svg>',pC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 8 8 20 12 4-12 4-8 20-8-20-12-4 12-4Z"/></svg>',mC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 4 8 8 14 4-6 12 8 12H44l-4 16-8-12-8 12-4-16H8l8-12-6-12 14-4Z"/></svg>',gC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 4 6 20 6 4-6 4 2 20-8-4-8 4 2-20-6-4 6-4Z"/></svg>',vC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 4 4 8v12l12 4v8l-12 4v12l4 4-8 4-8-4 4-4V40l-12-4v-8l12-4V12Z"/></svg>',yC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 64 64"><path d="m32 8 8 8 2 8 14 8-14 8-2 8-8 8-8-8-2-8-14-8 14-8 2-8Z"/></svg>',SC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%2012%206%208%2020%204-2%208%202%208-20%204-2%2012-4-4-4%204-2-12-20-4%202-8-2-8%2020-4Z'/%3e%3c/svg%3e",_C="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%206%2016%208%206%2018-6%2018-16%208-16-8-6-18%206-18Z'/%3e%3cpath%20d='m32%2016%208%204%204%2012-4%2012-8%204-8-4-4-12%204-12Z'/%3e%3c/svg%3e",xC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%206%204%2014%2020%2016-8%202-4%2016-12-8-12%208-4-16-8-2%2020-16Z'/%3e%3c/svg%3e",bC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%204%204%2014%2022%2026H46l-4%2014-10-8-10%208-4-14H6l22-26Z'/%3e%3c/svg%3e",MC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%208%208%2020%2012%204-12%204-8%2020-8-20-12-4%2012-4Z'/%3e%3c/svg%3e",EC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%204%208%208%2014%204-6%2012%208%2012H44l-4%2016-8-12-8%2012-4-16H8l8-12-6-12%2014-4Z'/%3e%3c/svg%3e",wC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%204%206%2020%206%204-6%204%202%2020-8-4-8%204%202-20-6-4%206-4Z'/%3e%3c/svg%3e",TC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%204%204%208v12l12%204v8l-12%204v12l4%204-8%204-8-4%204-4V40l-12-4v-8l12-4V12Z'/%3e%3c/svg%3e",AC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2064%2064'%3e%3cpath%20d='m32%208%208%208%202%208%2014%208-14%208-2%208-8%208-8-8-2-8-14-8%2014-8%202-8Z'/%3e%3c/svg%3e",RC='<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 32 32"><path d="m8 8 16 16m0-16L8 24"/></svg>',CC="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20stroke='currentColor'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='2'%20viewBox='0%200%2032%2032'%3e%3cpath%20d='m8%208%2016%2016m0-16L8%2024'/%3e%3c/svg%3e",PC=Object.assign({"/src/assets/icons/weapons/autocannon.svg":VR,"/src/assets/icons/weapons/bluelaser.svg":$R,"/src/assets/icons/weapons/flak.svg":XR,"/src/assets/icons/weapons/greenlaser.svg":qR,"/src/assets/icons/weapons/ion.svg":YR,"/src/assets/icons/weapons/lightning.svg":jR,"/src/assets/icons/weapons/nuclearlance.svg":KR,"/src/assets/icons/weapons/plasma.svg":ZR,"/src/assets/icons/weapons/pulse.svg":JR,"/src/assets/icons/weapons/railgun.svg":QR,"/src/assets/icons/weapons/redlaser.svg":eC,"/src/assets/icons/weapons/torch.svg":tC}),LC=Object.assign({"/src/assets/icons/missiles/cluster.svg":nC,"/src/assets/icons/missiles/dart.svg":iC,"/src/assets/icons/missiles/decoy.svg":sC,"/src/assets/icons/missiles/nuke.svg":rC,"/src/assets/icons/missiles/rocket.svg":oC,"/src/assets/icons/missiles/seeker.svg":aC,"/src/assets/icons/missiles/swarm.svg":cC,"/src/assets/icons/missiles/torpedo.svg":lC}),DC=Object.assign({"/src/assets/icons/ships/bomber.svg":uC,"/src/assets/icons/ships/defender.svg":dC,"/src/assets/icons/ships/fighter.svg":fC,"/src/assets/icons/ships/interceptor.svg":hC,"/src/assets/icons/ships/patrol.svg":pC,"/src/assets/icons/ships/raider.svg":mC,"/src/assets/icons/ships/scout.svg":gC,"/src/assets/icons/ships/sentinel.svg":vC,"/src/assets/icons/ships/striker.svg":yC}),IC=Object.assign({"/src/assets/icons/ships/bomber.svg":SC,"/src/assets/icons/ships/defender.svg":_C,"/src/assets/icons/ships/fighter.svg":xC,"/src/assets/icons/ships/interceptor.svg":bC,"/src/assets/icons/ships/patrol.svg":MC,"/src/assets/icons/ships/raider.svg":EC,"/src/assets/icons/ships/scout.svg":wC,"/src/assets/icons/ships/sentinel.svg":TC,"/src/assets/icons/ships/striker.svg":AC}),NC=Object.assign({"/src/assets/icons/fallback.svg":RC}),UC=Object.assign({"/src/assets/icons/fallback.svg":CC}),v0="/src/assets/icons/fallback.svg";function Od(){return NC[v0]??""}function Bd(){return UC[v0]??""}function kC(t){const e=`/src/assets/icons/weapons/${t.toLowerCase()}.svg`;return PC[e]??Od()}function FC(t){const e=`/src/assets/icons/missiles/${t.toLowerCase()}.svg`;return LC[e]??Od()}function OC(t){const e=`/src/assets/icons/ships/${t.toLowerCase()}.svg`;return DC[e]??Od()}function BC(t){const e=`/src/assets/icons/ships/${t.toLowerCase()}.svg`;return IC[e]??Bd()}const zC=new Set(["redlaser","bluelaser","greenlaser","nuclearlance"]);function HC(t){return zC.has(t.toLowerCase())}function Jr(t,e={}){const{className:n="",size:i="md",color:s="var(--color-primary)",glowColor:r="var(--color-primary-glow)"}=e,o=kC(t),a=HC(t),c=a?"has-svg-glow":"",l=["weapon-icon",`weapon-icon-${i}`,c,n].filter(Boolean).join(" "),u=a?"":`--glow-color: ${r};`;return`<span class="${l}" style="color: ${s}; ${u}">${o}</span>`}function Ja(t,e={}){const{className:n="",size:i="md",color:s="var(--color-danger)",glowColor:r="var(--color-danger-glow)"}=e,o=FC(t);return`<span class="${["missile-icon",`missile-icon-${i}`,n].filter(Boolean).join(" ")}" style="color: ${s}; --glow-color: ${r};">${o}</span>`}function GC(t,e={}){const{className:n="",size:i="md",color:s="var(--color-secondary)",glowColor:r="var(--color-secondary-glow)"}=e,o=OC(t);return`<span class="${["ship-icon",`ship-icon-${i}`,n].filter(Boolean).join(" ")}" style="color: ${s}; --glow-color: ${r};">${o}</span>`}function WC(t,e){return""}const Zh=[88,132,176],VC=5;function y0(t,e){if(e==="primary"){const i=t;return Aa(i.weaponType)?{current:i.currentAmmo??0,max:yr(i.weaponType,i.bankSize)}:{current:0,max:0}}const n=t;return{current:n.count,max:n.maxCount}}function $C(t,e){const n=Zh[e-1]??Zh[0];return t<=Math.floor(n/VC)}function XC(t){return"var(--color-primary)"}function qC(t){return"var(--color-danger)"}function Qa(t){return BC(t)}function ec(){return`onerror="this.onerror=null; this.src='${Bd()}'"`}function S0(t){return`
    <div class="ship-icon-large">
      ${GC(t,{className:"ship-icon-svg"})}
    </div>
  `}function YC(t){const e=new Map;for(const n of t){const i=e.get(n.row)??[];i.push(n),e.set(n.row,i)}return e}function Ca(t,e,n,i,s,r="interactive"){const o=YC(t);return[...o.keys()].sort((c,l)=>c-l).map(c=>{const u=(o.get(c)??[]).map(d=>{const f=t.indexOf(d),h=e[f]??1,p=n[f]??null;return ZC(p,f,h,i,s,d,r)}).join("");return`<div class="row-slots" data-row="${c}">${u}</div>`}).join("")}function jC(t){const e=Wt[t.shipClass.toLowerCase()];if(!e)return"";const n=Ca(e.primaryHardpoints,e.primaryBanks,t.primaryWeapons,t.id,"primary"),i=Ca(e.secondaryHardpoints,e.secondaryBanks,t.secondaryWeapons,t.id,"secondary");return`
    <div class="schematic-diagram vertical">
      <div class="hardpoint-row primary-row">
        ${n}
      </div>

      <div class="schematic-center">
        ${S0(t.shipClass)}
      </div>

      <div class="hardpoint-row secondary-row">
        ${i}
      </div>
    </div>
  `}function KC(t,e){var o,a;if(!Wt[t.shipClass.toLowerCase()])return'<div class="ship-viewer-error">Unknown ship class</div>';const i=((o=t.pilot)==null?void 0:o.id)===e.commanderId,s=((a=t.pilot)==null?void 0:a.name.toUpperCase())??"NO PILOT",r=i||!t.pilot?"":` • ${t.pilot.skill.toUpperCase()}`;return`
    <div class="ship-viewer schematic">
      <div class="schematic-header">
        <div class="schematic-header-left">
          <span class="schematic-class">${t.shipClass.toUpperCase()}</span>
          <span class="schematic-pilot">${s}${r}</span>
        </div>
        <div class="schematic-header-right"></div>
      </div>

      ${jC(t)}

      ${WC()}
    </div>
  `}function ZC(t,e,n,i,s,r,o="interactive"){const a=s==="primary",c=`bank-${n}`,l=r.x*100,u=r.svgX/64*100,d=r.svgY/64*100;if(o==="hull-preview")return`
      <div class="schematic-slot ${s} hull-preview ${c}"
           data-type="${s}"
           style="--slot-x: ${l}%; --svg-x: ${u}%; --svg-y: ${d}%; --bank-size: ${n}; --slot-color: ${a?"var(--color-primary)":"var(--color-danger)"}">
      </div>
    `;const f=!t,h=t?t.weaponType:"",p=t?a?XC():qC():"";let v="";if(t){const{current:m,max:S}=y0(t,s);S>0&&($C(S,n)?v=`<div class="slot-ammo-bar segmented">${Array.from({length:S},(y,D)=>`<div class="slot-ammo-segment ${D<m?"filled":""}"></div>`).join("")}</div>`:v=`<div class="slot-ammo-bar"><div class="slot-ammo-fill" style="width: ${Math.round(m/S*100)}%"></div></div>`)}let g="";if(f)g=Array(n).fill('<span class="slot-empty-icon">+</span>').join("");else if(a){const m=Jr(h,{size:"lg",color:p,className:"slot-weapon-icon"});g=Array(n).fill(m).join("")}else{const m=Ja(h,{size:"lg",color:p,className:"slot-missile-icon"});g=Array(n).fill(m).join("")}return`
    <div class="schematic-slot ${s} ${f?"empty":"filled"} ${c}"
         data-ship="${i}"
         data-type="${s}"
         data-index="${e}"
         data-weapon="${h}"
         style="--slot-x: ${l}%; --svg-x: ${u}%; --svg-y: ${d}%; --bank-size: ${n}; ${t?`--slot-color: ${p}`:""}">
      <div class="slot-connector"></div>
      <div class="slot-content">
        <div class="slot-icons">${g}</div>
      </div>
      ${v}
    </div>
  `}function Jh(t){const e=Wt[t.toLowerCase()];if(!e)return"";const n=e.primaryBanks.map(()=>null),i=e.secondaryBanks.map(()=>null),s=Ca(e.primaryHardpoints,e.primaryBanks,n,"","primary","hull-preview"),r=Ca(e.secondaryHardpoints,e.secondaryBanks,i,"","secondary","hull-preview");return`
    <div class="schematic-diagram vertical hull-schematic-preview">
      <div class="hardpoint-row primary-row">
        ${s}
      </div>

      <div class="schematic-center">
        ${S0(t)}
      </div>

      <div class="hardpoint-row secondary-row">
        ${r}
      </div>
    </div>
  `}function _0(t){return t.charAt(0).toUpperCase()+t.slice(1)}function x0(t,e){const i=(e==="secondary"?"◆":"●").repeat(t);return`<span class="bank-indicator ${e}">${i}</span>`}function b0(t){const e=[];for(const n of t.primaryWeapons)if(n){const i=x0(n.bankSize,"primary"),s=_0(n.weaponType);if(n.currentAmmo!==void 0){const r=yr(n.weaponType,n.bankSize);e.push(`${i} ${s} (${n.currentAmmo}/${r})`)}else e.push(`${i} ${s}`)}return e.length>0?e.join(", "):"No primary"}function M0(t){const e=[];for(const n of t.secondaryWeapons)if(n&&n.count>0){const i=x0(n.bankSize,"secondary"),s=_0(n.weaponType);e.push(`${i} ${s} (${n.count}/${n.maxCount})`)}return e.length>0?e.join(", "):"No secondary"}function E0(t){const{ship:e,isCommander:n,isSelected:i,extraClasses:s="",dataAttrs:r={},beforeContent:o="",iconContent:a="",afterContent:c=""}=t,l=e.pilot;if(!l)return"";const u=Qa(e.shipClass),d=["ship-item",n?"commander":"",i?"selected":"",s].filter(Boolean).join(" "),f=Object.entries(r).map(([p,v])=>`data-${p}="${v}"`).join(" "),h=[l.name,e.shipClass,n?"your ship":""].filter(Boolean).join(", ");return`
    <article
      class="${d}"
      ${f}
      role="option"
      aria-selected="${i}"
      tabindex="0"
      aria-label="${h}"
    >
      ${o}

      <div class="ship-item-icon">
        <img
          src="${u}"
          alt="${e.shipClass}"
          class="ship-item-img"
          ${ec()}
        />
        ${a}
      </div>

      <div class="ship-item-info">
        <div class="ship-item-name-row">
          <span class="ship-item-pilot">${l.name}</span>
          ${n?'<span class="ship-item-badge commander-badge">You</span>':""}
        </div>
        <span class="ship-item-class">${e.shipClass}</span>
      </div>

      ${c}
    </article>
  `}function JC(t){const{primary:e,secondary:n,primaryUnarmed:i,secondaryUnarmed:s}=QC(t),r=b0(t),o=M0(t);return`
    <div class="ship-item-weapons">
      <span class="weapon-badge primary ${i?"unarmed":""}">
        ● ${e}
        <span class="weapon-tooltip">${r}</span>
      </span>
      <span class="weapon-badge secondary ${s?"unarmed":""}">
        ◆ ${n}
        <span class="weapon-tooltip">${o}</span>
      </span>
    </div>
  `}function QC(t){const e=Wt[t.shipClass],n=(e==null?void 0:e.primaryBanks.length)??0,i=(e==null?void 0:e.secondaryBanks.length)??0,s=t.primaryWeapons.filter(o=>o!==null).length,r=t.secondaryWeapons.filter(o=>o!==null).length;return{primary:`${s}/${n}`,secondary:`${r}/${i}`,primaryUnarmed:s===0&&n>0,secondaryUnarmed:r===0&&i>0}}const Hs=4;function e2(t,e){const n=t?"commander":e?"selected":"";return`<div class="ship-item-toggle${n?` ${n}`:""}" aria-hidden="true"></div>`}function t2(t,e,n){const i=b0(t),s=M0(t),r=kd(t),o=h0(t),a=p0(t),c=r?'<span class="ship-item-warning" aria-label="Needs attention">!</span>':"",d=`
    <div class="ship-item-loadout-stack">
      <span class="ship-item-loadout primary ${o?"warning":""}">${i}</span>
      <span class="ship-item-loadout secondary ${a?"warning":""}">${s}</span>
    </div>
  `;return E0({ship:t,isCommander:e,isSelected:n,extraClasses:"squad-card",dataAttrs:{"ship-id":t.id},beforeContent:e2(e,n),iconContent:c,afterContent:d})}const n2={render(t,e){const{campaignState:n,contract:i,commanderShipId:s}=e,r=new Set(t.selectedIds),o=r.size,c=n.ships.filter(u=>u.pilot!==null).sort((u,d)=>u.id===s?-1:d.id===s?1:0).map(u=>{const d=u.id===s,f=r.has(u.id);return t2(u,d,f)}).join(""),l=Array.from({length:Hs},(u,d)=>`<div class="capacity-segment${d<o?" filled":""}"></div>`).join("");return`
      <div class="squad-selection-overlay" role="dialog" aria-modal="true" aria-labelledby="squad-title">
        <div class="squad-selection-modal">
          <header class="squad-header panel-header">
            <h2 class="squad-title" id="squad-title">${i.name}</h2>
          </header>

          <div class="squad-content">
            <div class="squad-ship-list" role="group" aria-label="Available ships">
              ${c}
            </div>
          </div>

          <footer class="squad-footer">
            <div class="squad-capacity">
              <div class="capacity-bar" role="meter" aria-valuenow="${o}" aria-valuemin="0" aria-valuemax="${Hs}">
                ${l}
              </div>
              <div class="capacity-label"><span class="capacity-current">${o}</span>/${Hs} ships</div>
            </div>
            <div class="squad-footer-actions">
              <button class="btn btn-large" id="btn-squad-cancel">Cancel</button>
              <button
                class="btn btn-large btn-success"
                id="btn-squad-launch"
                ${o===0?"disabled":""}
              >
                <span class="launch-icon">&#9654;</span>
                Launch Mission
              </button>
            </div>
          </footer>
        </div>
      </div>
    `},bind(t,e){const{commanderShipId:n,onComplete:i}=e,s=t.getRoot();t.on(".squad-card","click",(r,o)=>{const a=o.dataset.shipId;if(!a||a===n)return;const c=t.getState(),l=new Set(c.selectedIds),u=l.has(a);if(!u&&l.size>=Hs)return;u?l.delete(a):l.add(a);const d=!u,f=l.size;t.updateState({selectedIds:Array.from(l)}),o.classList.toggle("selected",d),o.setAttribute("aria-selected",String(d));const h=o.querySelector(".ship-item-toggle");h&&h.classList.toggle("selected",d),s.querySelectorAll(".capacity-segment").forEach((S,_)=>{S.classList.toggle("filled",_<f)});const v=s.querySelector(".capacity-current");v&&(v.textContent=String(f));const g=s.querySelector(".capacity-bar");g&&g.setAttribute("aria-valuenow",String(f));const m=s.querySelector("#btn-squad-launch");m&&(m.disabled=f===0)}),t.on("#btn-squad-cancel","click",()=>{i({confirmed:!1,deployedShipIds:[]})}),t.on("#btn-squad-launch","click",()=>{const r=t.getState();i({confirmed:!0,deployedShipIds:r.selectedIds})}),t.onGlobal("keydown",r=>{r.key==="Escape"&&i({confirmed:!1,deployedShipIds:[]})})}};function i2(t,e){const n=t.ships.find(r=>{var o;return((o=r.pilot)==null?void 0:o.id)===t.commanderId});if(!n)return Promise.resolve({confirmed:!1,deployedShipIds:[]});const i=t.ships.filter(r=>r.pilot!==null).slice(0,Hs).map(r=>r.id);return i.includes(n.id)||(i.unshift(n.id),i.length>Hs&&i.pop()),a0(n2,{selectedIds:i},{campaignState:t,contract:e,commanderShipId:n.id})}const s2={name:"Title Screen",teamA:{archetype:"firefly",count:4,profile:"regular",callsignPrefix:"Alpha"},teamB:{archetype:"dragonfly",count:4,profile:"regular",callsignPrefix:"Bandit"},spawnRadius:800},Qh=new oi,Qo=new T;class w0 extends W1{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry";const e=[-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],n=[-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],i=[0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5];this.setIndex(i),this.setAttribute("position",new vt(e,3)),this.setAttribute("uv",new vt(n,2))}applyMatrix4(e){const n=this.attributes.instanceStart,i=this.attributes.instanceEnd;return n!==void 0&&(n.applyMatrix4(e),i.applyMatrix4(e),n.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}setPositions(e){let n;e instanceof Float32Array?n=e:Array.isArray(e)&&(n=new Float32Array(e));const i=new _u(n,6,1);return this.setAttribute("instanceStart",new Ti(i,3,0)),this.setAttribute("instanceEnd",new Ti(i,3,3)),this.instanceCount=this.attributes.instanceStart.count,this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e){let n;e instanceof Float32Array?n=e:Array.isArray(e)&&(n=new Float32Array(e));const i=new _u(n,6,1);return this.setAttribute("instanceColorStart",new Ti(i,3,0)),this.setAttribute("instanceColorEnd",new Ti(i,3,3)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new O1(e.geometry)),this}fromLineSegments(e){const n=e.geometry;return this.setPositions(n.attributes.position.array),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new oi);const e=this.attributes.instanceStart,n=this.attributes.instanceEnd;e!==void 0&&n!==void 0&&(this.boundingBox.setFromBufferAttribute(e),Qh.setFromBufferAttribute(n),this.boundingBox.union(Qh))}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new fr),this.boundingBox===null&&this.computeBoundingBox();const e=this.attributes.instanceStart,n=this.attributes.instanceEnd;if(e!==void 0&&n!==void 0){const i=this.boundingSphere.center;this.boundingBox.getCenter(i);let s=0;for(let r=0,o=e.count;r<o;r++)Qo.fromBufferAttribute(e,r),s=Math.max(s,i.distanceToSquared(Qo)),Qo.fromBufferAttribute(n,r),s=Math.max(s,i.distanceToSquared(Qo));this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}ie.line={worldUnits:{value:1},linewidth:{value:1},resolution:{value:new fe(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}};Xt.line={uniforms:ed.merge([ie.common,ie.fog,ie.line]),vertexShader:`
		#include <common>
		#include <color_pars_vertex>
		#include <fog_pars_vertex>
		#include <logdepthbuf_pars_vertex>
		#include <clipping_planes_pars_vertex>

		uniform float linewidth;
		uniform vec2 resolution;

		attribute vec3 instanceStart;
		attribute vec3 instanceEnd;

		attribute vec3 instanceColorStart;
		attribute vec3 instanceColorEnd;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#ifdef USE_DASH

			uniform float dashScale;
			attribute float instanceDistanceStart;
			attribute float instanceDistanceEnd;
			varying float vLineDistance;

		#endif

		void trimSegment( const in vec4 start, inout vec4 end ) {

			// trim end segment so it terminates between the camera plane and the near plane

			// conservative estimate of the near plane
			float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
			float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
			float nearEstimate = - 0.5 * b / a;

			float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

			end.xyz = mix( start.xyz, end.xyz, alpha );

		}

		void main() {

			#ifdef USE_COLOR

				vColor.xyz = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

			#endif

			#ifdef USE_DASH

				vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
				vUv = uv;

			#endif

			float aspect = resolution.x / resolution.y;

			// camera space
			vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
			vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

			#ifdef WORLD_UNITS

				worldStart = start.xyz;
				worldEnd = end.xyz;

			#else

				vUv = uv;

			#endif

			// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
			// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
			// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
			// perhaps there is a more elegant solution -- WestLangley

			bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

			if ( perspective ) {

				if ( start.z < 0.0 && end.z >= 0.0 ) {

					trimSegment( start, end );

				} else if ( end.z < 0.0 && start.z >= 0.0 ) {

					trimSegment( end, start );

				}

			}

			// clip space
			vec4 clipStart = projectionMatrix * start;
			vec4 clipEnd = projectionMatrix * end;

			// ndc space
			vec3 ndcStart = clipStart.xyz / clipStart.w;
			vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

			// direction
			vec2 dir = ndcEnd.xy - ndcStart.xy;

			// account for clip-space aspect ratio
			dir.x *= aspect;
			dir = normalize( dir );

			#ifdef WORLD_UNITS

				vec3 worldDir = normalize( end.xyz - start.xyz );
				vec3 tmpFwd = normalize( mix( start.xyz, end.xyz, 0.5 ) );
				vec3 worldUp = normalize( cross( worldDir, tmpFwd ) );
				vec3 worldFwd = cross( worldDir, worldUp );
				worldPos = position.y < 0.5 ? start: end;

				// height offset
				float hw = linewidth * 0.5;
				worldPos.xyz += position.x < 0.0 ? hw * worldUp : - hw * worldUp;

				// don't extend the line if we're rendering dashes because we
				// won't be rendering the endcaps
				#ifndef USE_DASH

					// cap extension
					worldPos.xyz += position.y < 0.5 ? - hw * worldDir : hw * worldDir;

					// add width to the box
					worldPos.xyz += worldFwd * hw;

					// endcaps
					if ( position.y > 1.0 || position.y < 0.0 ) {

						worldPos.xyz -= worldFwd * 2.0 * hw;

					}

				#endif

				// project the worldpos
				vec4 clip = projectionMatrix * worldPos;

				// shift the depth of the projected points so the line
				// segments overlap neatly
				vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
				clip.z = clipPose.z * clip.w;

			#else

				vec2 offset = vec2( dir.y, - dir.x );
				// undo aspect ratio adjustment
				dir.x /= aspect;
				offset.x /= aspect;

				// sign flip
				if ( position.x < 0.0 ) offset *= - 1.0;

				// endcaps
				if ( position.y < 0.0 ) {

					offset += - dir;

				} else if ( position.y > 1.0 ) {

					offset += dir;

				}

				// adjust for linewidth
				offset *= linewidth;

				// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
				offset /= resolution.y;

				// select end
				vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

				// back to clip space
				offset *= clip.w;

				clip.xy += offset;

			#endif

			gl_Position = clip;

			vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

			#include <logdepthbuf_vertex>
			#include <clipping_planes_vertex>
			#include <fog_vertex>

		}
		`,fragmentShader:`
		uniform vec3 diffuse;
		uniform float opacity;
		uniform float linewidth;

		#ifdef USE_DASH

			uniform float dashOffset;
			uniform float dashSize;
			uniform float gapSize;

		#endif

		varying float vLineDistance;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#include <common>
		#include <color_pars_fragment>
		#include <fog_pars_fragment>
		#include <logdepthbuf_pars_fragment>
		#include <clipping_planes_pars_fragment>

		vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

			float mua;
			float mub;

			vec3 p13 = p1 - p3;
			vec3 p43 = p4 - p3;

			vec3 p21 = p2 - p1;

			float d1343 = dot( p13, p43 );
			float d4321 = dot( p43, p21 );
			float d1321 = dot( p13, p21 );
			float d4343 = dot( p43, p43 );
			float d2121 = dot( p21, p21 );

			float denom = d2121 * d4343 - d4321 * d4321;

			float numer = d1343 * d4321 - d1321 * d4343;

			mua = numer / denom;
			mua = clamp( mua, 0.0, 1.0 );
			mub = ( d1343 + d4321 * ( mua ) ) / d4343;
			mub = clamp( mub, 0.0, 1.0 );

			return vec2( mua, mub );

		}

		void main() {

			#include <clipping_planes_fragment>

			#ifdef USE_DASH

				if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

				if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

			#endif

			float alpha = opacity;

			#ifdef WORLD_UNITS

				// Find the closest points on the view ray and the line segment
				vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
				vec3 lineDir = worldEnd - worldStart;
				vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

				vec3 p1 = worldStart + lineDir * params.x;
				vec3 p2 = rayEnd * params.y;
				vec3 delta = p1 - p2;
				float len = length( delta );
				float norm = len / linewidth;

				#ifndef USE_DASH

					#ifdef USE_ALPHA_TO_COVERAGE

						float dnorm = fwidth( norm );
						alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

					#else

						if ( norm > 0.5 ) {

							discard;

						}

					#endif

				#endif

			#else

				#ifdef USE_ALPHA_TO_COVERAGE

					// artifacts appear on some hardware if a derivative is taken within a conditional
					float a = vUv.x;
					float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
					float len2 = a * a + b * b;
					float dlen = fwidth( len2 );

					if ( abs( vUv.y ) > 1.0 ) {

						alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

					}

				#else

					if ( abs( vUv.y ) > 1.0 ) {

						float a = vUv.x;
						float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
						float len2 = a * a + b * b;

						if ( len2 > 1.0 ) discard;

					}

				#endif

			#endif

			vec4 diffuseColor = vec4( diffuse, alpha );

			#include <logdepthbuf_fragment>
			#include <color_fragment>

			gl_FragColor = vec4( diffuseColor.rgb, alpha );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>
			#include <fog_fragment>
			#include <premultiplied_alpha_fragment>

		}
		`};class Qr extends vn{static get type(){return"LineMaterial"}constructor(e){super({uniforms:ed.clone(Xt.line.uniforms),vertexShader:Xt.line.vertexShader,fragmentShader:Xt.line.fragmentShader,clipping:!0}),this.isLineMaterial=!0,this.setValues(e)}get color(){return this.uniforms.diffuse.value}set color(e){this.uniforms.diffuse.value=e}get worldUnits(){return"WORLD_UNITS"in this.defines}set worldUnits(e){e===!0?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}get linewidth(){return this.uniforms.linewidth.value}set linewidth(e){this.uniforms.linewidth&&(this.uniforms.linewidth.value=e)}get dashed(){return"USE_DASH"in this.defines}set dashed(e){e===!0!==this.dashed&&(this.needsUpdate=!0),e===!0?this.defines.USE_DASH="":delete this.defines.USE_DASH}get dashScale(){return this.uniforms.dashScale.value}set dashScale(e){this.uniforms.dashScale.value=e}get dashSize(){return this.uniforms.dashSize.value}set dashSize(e){this.uniforms.dashSize.value=e}get dashOffset(){return this.uniforms.dashOffset.value}set dashOffset(e){this.uniforms.dashOffset.value=e}get gapSize(){return this.uniforms.gapSize.value}set gapSize(e){this.uniforms.gapSize.value=e}get opacity(){return this.uniforms.opacity.value}set opacity(e){this.uniforms&&(this.uniforms.opacity.value=e)}get resolution(){return this.uniforms.resolution.value}set resolution(e){this.uniforms.resolution.value.copy(e)}get alphaToCoverage(){return"USE_ALPHA_TO_COVERAGE"in this.defines}set alphaToCoverage(e){this.defines&&(e===!0!==this.alphaToCoverage&&(this.needsUpdate=!0),e===!0?this.defines.USE_ALPHA_TO_COVERAGE="":delete this.defines.USE_ALPHA_TO_COVERAGE)}}const tl=new qe,ep=new T,tp=new T,Rt=new qe,Ct=new qe,Nn=new qe,nl=new T,il=new Qe,Pt=new V1,np=new T,ea=new oi,ta=new fr,Un=new qe;let Bn,ts;function ip(t,e,n){return Un.set(0,0,-e,1).applyMatrix4(t.projectionMatrix),Un.multiplyScalar(1/Un.w),Un.x=ts/n.width,Un.y=ts/n.height,Un.applyMatrix4(t.projectionMatrixInverse),Un.multiplyScalar(1/Un.w),Math.abs(Math.max(Un.x,Un.y))}function r2(t,e){const n=t.matrixWorld,i=t.geometry,s=i.attributes.instanceStart,r=i.attributes.instanceEnd,o=Math.min(i.instanceCount,s.count);for(let a=0,c=o;a<c;a++){Pt.start.fromBufferAttribute(s,a),Pt.end.fromBufferAttribute(r,a),Pt.applyMatrix4(n);const l=new T,u=new T;Bn.distanceSqToSegment(Pt.start,Pt.end,u,l),u.distanceTo(l)<ts*.5&&e.push({point:u,pointOnLine:l,distance:Bn.origin.distanceTo(u),object:t,face:null,faceIndex:a,uv:null,uv1:null})}}function o2(t,e,n){const i=e.projectionMatrix,r=t.material.resolution,o=t.matrixWorld,a=t.geometry,c=a.attributes.instanceStart,l=a.attributes.instanceEnd,u=Math.min(a.instanceCount,c.count),d=-e.near;Bn.at(1,Nn),Nn.w=1,Nn.applyMatrix4(e.matrixWorldInverse),Nn.applyMatrix4(i),Nn.multiplyScalar(1/Nn.w),Nn.x*=r.x/2,Nn.y*=r.y/2,Nn.z=0,nl.copy(Nn),il.multiplyMatrices(e.matrixWorldInverse,o);for(let f=0,h=u;f<h;f++){if(Rt.fromBufferAttribute(c,f),Ct.fromBufferAttribute(l,f),Rt.w=1,Ct.w=1,Rt.applyMatrix4(il),Ct.applyMatrix4(il),Rt.z>d&&Ct.z>d)continue;if(Rt.z>d){const _=Rt.z-Ct.z,y=(Rt.z-d)/_;Rt.lerp(Ct,y)}else if(Ct.z>d){const _=Ct.z-Rt.z,y=(Ct.z-d)/_;Ct.lerp(Rt,y)}Rt.applyMatrix4(i),Ct.applyMatrix4(i),Rt.multiplyScalar(1/Rt.w),Ct.multiplyScalar(1/Ct.w),Rt.x*=r.x/2,Rt.y*=r.y/2,Ct.x*=r.x/2,Ct.y*=r.y/2,Pt.start.copy(Rt),Pt.start.z=0,Pt.end.copy(Ct),Pt.end.z=0;const v=Pt.closestPointToPointParameter(nl,!0);Pt.at(v,np);const g=fS.lerp(Rt.z,Ct.z,v),m=g>=-1&&g<=1,S=nl.distanceTo(np)<ts*.5;if(m&&S){Pt.start.fromBufferAttribute(c,f),Pt.end.fromBufferAttribute(l,f),Pt.start.applyMatrix4(o),Pt.end.applyMatrix4(o);const _=new T,y=new T;Bn.distanceSqToSegment(Pt.start,Pt.end,y,_),n.push({point:y,pointOnLine:_,distance:Bn.origin.distanceTo(y),object:t,face:null,faceIndex:f,uv:null,uv1:null})}}}class a2 extends Ye{constructor(e=new w0,n=new Qr({color:Math.random()*16777215})){super(e,n),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){const e=this.geometry,n=e.attributes.instanceStart,i=e.attributes.instanceEnd,s=new Float32Array(2*n.count);for(let o=0,a=0,c=n.count;o<c;o++,a+=2)ep.fromBufferAttribute(n,o),tp.fromBufferAttribute(i,o),s[a]=a===0?0:s[a-1],s[a+1]=s[a]+ep.distanceTo(tp);const r=new _u(s,2,1);return e.setAttribute("instanceDistanceStart",new Ti(r,1,0)),e.setAttribute("instanceDistanceEnd",new Ti(r,1,1)),this}raycast(e,n){const i=this.material.worldUnits,s=e.camera;s===null&&!i&&console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');const r=e.params.Line2!==void 0&&e.params.Line2.threshold||0;Bn=e.ray;const o=this.matrixWorld,a=this.geometry,c=this.material;ts=c.linewidth+r,a.boundingSphere===null&&a.computeBoundingSphere(),ta.copy(a.boundingSphere).applyMatrix4(o);let l;if(i)l=ts*.5;else{const d=Math.max(s.near,ta.distanceToPoint(Bn.origin));l=ip(s,d,c.resolution)}if(ta.radius+=l,Bn.intersectsSphere(ta)===!1)return;a.boundingBox===null&&a.computeBoundingBox(),ea.copy(a.boundingBox).applyMatrix4(o);let u;if(i)u=ts*.5;else{const d=Math.max(s.near,ea.distanceToPoint(Bn.origin));u=ip(s,d,c.resolution)}ea.expandByScalar(u),Bn.intersectsBox(ea)!==!1&&(i?r2(this,n):o2(this,s,n))}onBeforeRender(e){const n=this.material.uniforms;n&&n.resolution&&(e.getViewport(tl),this.material.uniforms.resolution.value.set(tl.z,tl.w))}}class Pa extends w0{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){const n=e.length-3,i=new Float32Array(2*n);for(let s=0;s<n;s+=3)i[2*s]=e[s],i[2*s+1]=e[s+1],i[2*s+2]=e[s+2],i[2*s+3]=e[s+3],i[2*s+4]=e[s+4],i[2*s+5]=e[s+5];return super.setPositions(i),this}setColors(e){const n=e.length-3,i=new Float32Array(2*n);for(let s=0;s<n;s+=3)i[2*s]=e[s],i[2*s+1]=e[s+1],i[2*s+2]=e[s+2],i[2*s+3]=e[s+3],i[2*s+4]=e[s+4],i[2*s+5]=e[s+5];return super.setColors(i),this}fromLine(e){const n=e.geometry;return this.setPositions(n.attributes.position.array),this}}class Pu extends a2{constructor(e=new Pa,n=new Qr({color:Math.random()*16777215})){super(e,n),this.isLine2=!0,this.type="Line2"}}const Fs=new T,en=new T,na=new T,c2=.4,l2=3;function T0(t,e,n,i,s){let r=[t.clone(),e.clone()];for(let o=0;o<n;o++){const a=[];for(let c=0;c<r.length-1;c++){const l=r[c],u=r[c+1];a.push(l),na.copy(l).add(u).multiplyScalar(.5),Fs.copy(u).sub(l);const d=Fs.length();Math.abs(Fs.x)<.9?en.set(1,0,0):en.set(0,1,0),en.cross(Fs).normalize();const f=(ft(s)-.5)*d*i;na.addScaledVector(en,f);const h=Fs.clone().cross(en).normalize(),p=(ft(s)-.5)*d*i;na.addScaledVector(h,p),a.push(na.clone())}a.push(r[r.length-1]),r=a}return r}function u2(t,e,n,i){const s=[],r=Math.floor(t.length*.2),o=Math.floor(t.length*.8);for(let a=r;a<o;a++){if(ft(i)>e)continue;const c=t[a],l=t[t.length-1],u=Fs.copy(l).sub(c),d=u.length();Math.abs(u.x)<.9?en.set(1,0,0):en.set(0,1,0),en.cross(u).normalize();const f=ft(i)*Math.PI*2,h=u.clone().normalize();en.applyAxisAngle(h,f);const p=d*c2*(.5+ft(i)*.5),v=c.clone().addScaledVector(en,p*.8).addScaledVector(u.normalize(),p*.3),g=T0(c,v,l2,n*1.2,i);s.push(g)}return s}function d2(t,e,n,i){const s=t.clone(),r=e.clone(),o=(ft(i)-.5)*Math.PI/3,a=(ft(i)-.5)*Math.PI/3;Math.abs(r.x)<.9?en.set(1,0,0):en.set(0,1,0);const c=en.clone().cross(r).normalize(),l=r.clone().cross(c).normalize();r.applyAxisAngle(c,o),r.applyAxisAngle(l,a);const u=n*(.4+ft(i)*.4);return s.addScaledVector(r,u),s}const Lu=new fe(1,1);function sp(t,e){Lu.set(t,e)}const f2=6719743,h2=16777215,p2=5601245,m2=8,g2=2.5,v2=5,y2=1.5,S2=.35,_2=1,rp=.7,x2=5,op=.15,b2=.25,A0=.05,ap=120,M2=.35;function R0(t){return{bolts:new Map,mainLines:[],branchLines:[]}}function cp(t,e,n){const i=[];for(const u of t)i.push(u.x,u.y,u.z);const s=new Pa;s.setPositions(i);const r=new Qr({color:e?f2:p2,linewidth:e?m2:v2,opacity:S2*n*(e?1:rp),transparent:!0,resolution:Lu,depthWrite:!1});r.blending=ot;const o=new Pu(s,r),a=new Pa;a.setPositions(i);const c=new Qr({color:h2,linewidth:e?g2:y2,opacity:_2*n*(e?1:rp),transparent:!0,resolution:Lu,depthWrite:!1});c.blending=ot;const l=new Pu(a,c);return{glow:o,core:l,glowGeometry:s,coreGeometry:a}}function lp(t){t.glowGeometry.dispose(),t.coreGeometry.dispose(),t.glow.material.dispose(),t.core.material.dispose()}function C0(t,e,n){const i=n.systemState.gameTime,s=n.systemState.beams.activeBeams,r=new Set;for(const[o,a]of s)for(const c of a){if(c.weaponName!=="Lightning"||!c.hitPoint)continue;const l=`${o}-${c.weaponIndex}`;r.add(l);let u=t.bolts.get(l);if(c.pulseActive){const f=c.origin.distanceTo(c.hitPoint)<ap*.9,h=f?M2:op,p=f?d2(c.origin,c.direction,ap,n.prng):c.hitPoint.clone(),v=T0(c.origin,p,x2,h,n.prng),g=f?[]:u2(v,b2,op,n.prng);u={segments:v,branches:g,startTime:i,active:!0},t.bolts.set(l,u)}else u&&i-u.startTime>A0&&(u.active=!1)}for(const[o,a]of t.bolts)(!r.has(o)||!a.active)&&t.bolts.delete(o);E2(t,e,i)}function E2(t,e,n){for(const i of t.mainLines)e.remove(i.glow),e.remove(i.core),lp(i);t.mainLines=[];for(const i of t.branchLines)e.remove(i.glow),e.remove(i.core),lp(i);t.branchLines=[];for(const i of t.bolts.values()){if(!i.active)continue;const s=n-i.startTime,r=Math.max(0,1-s/A0);if(i.segments.length>1){const o=cp(i.segments,!0,r);e.add(o.glow),e.add(o.core),t.mainLines.push(o)}for(const o of i.branches){if(o.length<2)continue;const a=cp(o,!1,r);e.add(a.glow),e.add(a.core),t.branchLines.push(a)}}}const P0=1.5,L0=1.5,D0=1,I0=1.2,w2=1.2,T2=10,A2=5,R2=8,up=.8,dp=2.5,fp=8,N0=5,C2=200,Du=8,P2=150,kr=24,L2=6,Iu=new J(1,.95,.8),D2=new J(.4,.5,1),U0=new J(1,1,1),k0=new J(.6,.7,1),hp=new J(.3,.4,.8),pp=new J(1,.9,.7),I2=new J(1,1,.7),N2=new J(1,.8,.4),Zi=new T,$r=new at,Tn=new J;function U2(t,e,n,i){Zi.copy(i.hitPoint).sub(i.origin);const s=Zi.length();Zi.normalize();const r=new T().copy(i.origin).addScaledVector(Zi,s/2);$r.setFromUnitVectors(new T(0,1,0),Zi);const o=new is(up,up,s,fp,1,!0),a=new mt({color:U0,transparent:!0,opacity:1,blending:ot,depthWrite:!1,side:Dt}),c=new Ye(o,a);c.position.copy(r),c.quaternion.copy($r),e.add(c),t.beamCores.set(n,c);const l=new is(dp,dp,s,fp,1,!0),u=new mt({color:k0,transparent:!0,opacity:.5,blending:ot,depthWrite:!1,side:Dt}),d=new Ye(l,u);d.position.copy(r),d.quaternion.copy($r),e.add(d),t.beamGlows.set(n,d)}function k2(t,e,n,i){const s=t.beamCores.get(n),r=t.beamGlows.get(n);if(!s||!r)return;const o=i/L0;if(o>=1){e.remove(s),s.geometry.dispose(),s.material.dispose(),t.beamCores.delete(n),e.remove(r),r.geometry.dispose(),r.material.dispose(),t.beamGlows.delete(n);return}const a=1-(1-o)**2,c=s.material;c.opacity=1-a*.8,Tn.copy(U0),Tn.lerp(hp,o*.5),c.color.copy(Tn);const l=r.material;l.opacity=.5*(1-a),Tn.copy(k0),Tn.lerp(hp,o*.6),l.color.copy(Tn);const u=1-a*.5;s.scale.set(u,1,u),r.scale.set(u,1,u)}function F2(t,e,n,i){const s=new mt({color:pp,transparent:!0,opacity:1,blending:ot,depthWrite:!1}),r=new Ye(t.sphereGeometry.clone(),s);r.position.copy(i.hitPoint),r.scale.setScalar(1),e.add(r),t.impactFlashMeshes.set(n,r);const o=new mt({color:I2,transparent:!0,opacity:.8,blending:ot,depthWrite:!1,side:Dt}),a=new Ye(t.ringGeometry.clone(),o);a.position.copy(i.hitPoint),Zi.copy(i.hitPoint).sub(i.origin).normalize(),$r.setFromUnitVectors(new T(0,0,1),Zi),a.quaternion.copy($r),a.scale.setScalar(1),e.add(a),t.impactRings.set(n,a);const c=new io(pp,Du,P2);c.position.copy(i.hitPoint),e.add(c),t.impactLights.set(n,c),O2(t,e,n,i)}function O2(t,e,n,i){const s=new Float32Array(kr*3),r=eo(i.entitySeed);for(let u=0;u<kr;u++){const d=ft(r)*Math.PI*2,f=Math.acos(2*ft(r)-1),h=u*3;s[h]=Math.sin(f)*Math.cos(d),s[h+1]=Math.sin(f)*Math.sin(d),s[h+2]=Math.cos(f)}t.particleVelocities.set(n,s);const o=new Float32Array(kr*3);for(let u=0;u<kr;u++){const d=u*3;o[d]=i.hitPoint.x,o[d+1]=i.hitPoint.y,o[d+2]=i.hitPoint.z}const a=new Tt;a.setAttribute("position",new Ut(o,3));const c=new Ga({color:N2,size:2.5,transparent:!0,opacity:1,blending:ot,depthWrite:!1}),l=new Wa(a,c);e.add(l),t.impactParticles.set(n,l)}function B2(t,e,n,i,s){z2(t,e,n,s),H2(t,e,n,s),G2(t,e,n,s),W2(t,e,n,i,s)}function z2(t,e,n,i){const s=t.impactFlashMeshes.get(n);if(!s)return;const r=i/D0;if(r>=1){e.remove(s),s.geometry.dispose(),s.material.dispose(),t.impactFlashMeshes.delete(n);return}const o=1-(1-r)**2,a=1+o*(A2-1);s.scale.setScalar(a);const c=s.material;c.opacity=1-o,Tn.setRGB(1,.9-r*.3,.7-r*.4),c.color.copy(Tn)}function H2(t,e,n,i){const s=t.impactRings.get(n);if(!s)return;const r=i/I0;if(r>=1){e.remove(s),s.geometry.dispose(),s.material.dispose(),t.impactRings.delete(n);return}const o=1-(1-r)**2,a=1+o*(R2-1);s.scale.setScalar(a);const c=s.material;c.opacity=.8*(1-o)}function G2(t,e,n,i){const s=t.impactLights.get(n);if(!s)return;const r=i/D0;if(r>=1){e.remove(s),t.impactLights.delete(n);return}const o=.2;let a;r<o?a=Du*(r/o)*1.5:a=Du*1.5*(1-(r-o)/(1-o)),s.intensity=Math.max(0,a)}function W2(t,e,n,i,s){var f;const r=t.impactParticles.get(n),o=t.particleVelocities.get(n);if(!r||!o)return;const a=s/w2;if(a>=1){e.remove(r),r.geometry.dispose(),r.material.dispose(),t.impactParticles.delete(n),t.particleVelocities.delete(n);return}const c=1-(1-a)**2,l=c*L2,u=(f=r.geometry.attributes.position)==null?void 0:f.array;for(let h=0;h<kr;h++){const p=h*3;u[p]=i.hitPoint.x+o[p]*l,u[p+1]=i.hitPoint.y+o[p+1]*l,u[p+2]=i.hitPoint.z+o[p+2]*l}const d=r.geometry.attributes.position;d&&(d.needsUpdate=!0),r.material.opacity=1-c}function V2(t,e,n,i){const s=new mt({color:Iu,transparent:!0,opacity:1,blending:ot,depthWrite:!1}),r=new Ye(t.sphereGeometry.clone(),s);r.position.copy(i.origin),r.scale.setScalar(1),e.add(r),t.originFlashMeshes.set(n,r);const o=new io(Iu,N0,C2);o.position.copy(i.origin),e.add(o),t.originLights.set(n,o)}function $2(t,e,n,i){const s=t.originFlashMeshes.get(n),r=t.originLights.get(n);if(!s||!r)return;const o=i/P0;if(o>=1){e.remove(s),s.geometry.dispose(),s.material.dispose(),t.originFlashMeshes.delete(n),e.remove(r),t.originLights.delete(n);return}const a=1-(1-o)**2,c=1+a*(T2-1);s.scale.setScalar(c);const l=s.material;Tn.copy(Iu),Tn.lerp(D2,o*.7),l.color.copy(Tn),l.opacity=1-a,r.intensity=N0*(1-a)}function F0(t){return{shots:new Map,originFlashMeshes:new Map,originLights:new Map,beamCores:new Map,beamGlows:new Map,impactFlashMeshes:new Map,impactRings:new Map,impactLights:new Map,impactParticles:new Map,particleVelocities:new Map,sphereGeometry:new yn(1,16,12),ringGeometry:new Va(1,.15,8,32)}}function O0(t,e,n){const i=n.systemState.gameTime,s=n.systemState.beams.activeBeams;for(const[r,o]of s)for(const a of o){if(a.weaponName!=="Nuclear Lance"||!a.hitPoint||a.lanceFireTime===void 0)continue;const c=`${r}-${a.weaponIndex}`;let l=t.shots.get(c);(!l||l.startTime!==a.lanceFireTime)&&(l={origin:a.origin.clone(),hitPoint:a.hitPoint.clone(),startTime:a.lanceFireTime,active:!0,entitySeed:r*31337+Math.floor(a.lanceFireTime*1e3)},t.shots.set(c,l),V2(t,e,c,l),U2(t,e,c,l),F2(t,e,c,l))}for(const[r,o]of t.shots){const a=i-o.startTime;$2(t,e,r,a),k2(t,e,r,a),B2(t,e,r,o,a);const c=Math.max(P0,L0,I0);a>=c&&(o.active=!1,t.shots.delete(r))}}const X2=1.5,q2=.3,Y2=8,sl=15,j2=.15,K2=new J(1,.95,.85),Z2=new J(1,.5,.1);function B0(){const t=new mt({color:K2,transparent:!0,opacity:.9,blending:ot,depthWrite:!1,side:Dt}),e=new mt({color:Z2,transparent:!0,opacity:.6,blending:ot,depthWrite:!1,side:Dt});return{cones:new Map,coreMaterial:t,outerMaterial:e}}const Pr=new T,mp=new at;function z0(t,e,n){const i=n.systemState.gameTime,s=n.systemState.beams.activeBeams,r=new Set;for(const[o,a]of s)for(const c of a){if(!c.isTorch||!c.hitPoint||c.fadeStartTime!==null||!c.active)continue;const l=`${o}-${c.weaponIndex}`;r.add(l);let u=t.cones.get(l);u||(u=J2(t),e.add(u),t.cones.set(l,u)),Q2(u,c,i)}for(const[o,a]of t.cones)r.has(o)||(e.remove(a),a.geometry.dispose(),t.cones.delete(o))}function J2(t){const e=new is(q2,X2,1,Y2,1,!0);return e.rotateX(Math.PI/2),new Ye(e,t.outerMaterial.clone())}function Q2(t,e,n){Pr.copy(e.hitPoint).sub(e.origin);const i=Pr.length();Pr.normalize(),t.position.copy(e.origin).addScaledVector(Pr,i/2),mp.setFromUnitVectors(new T(0,0,1),Pr),t.quaternion.copy(mp),t.scale.set(1,1,i);const s=1-j2*Math.sin(n*sl),r=t.material;r.opacity=.6*s,r.color.setRGB(1,.5+.1*Math.sin(n*sl*.7),.1+.05*Math.sin(n*sl*1.3))}const wn=100,H0=4,Sa=600,eP=8,tP=new J(16777215),G0=1,nP=50,iP=150,sP=500,rP=600;function oP(t,e,n){let i=t*374761393+e*668265263+n*1274126177;return i=(i^i>>13)*1274126177>>>0,i}function rl(t){return t=t*1103515245+12345&2147483647,[t,t/2147483647]}const aP=`
  uniform float uSize;
  varying float vDistance;

  void main() {
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    vDistance = -mvPosition.z;
    gl_PointSize = uSize * (150.0 / vDistance);
    gl_Position = projectionMatrix * mvPosition;
  }
`,cP=`
  uniform vec3 uColor;
  uniform float uFadeNear;
  uniform float uFadeMid;
  uniform float uFadeFar;
  uniform float uFadeEnd;

  varying float vDistance;

  void main() {
    // Near fade: 0 at uFadeNear, 1 at uFadeMid
    float nearFade = smoothstep(uFadeNear, uFadeMid, vDistance);

    // Far fade: 1 at uFadeFar, 0 at uFadeEnd
    float farFade = 1.0 - smoothstep(uFadeFar, uFadeEnd, vDistance);

    float alpha = nearFade * farFade * 0.7;

    gl_FragColor = vec4(uColor, alpha);
  }
`;function W0(t){const e=Math.ceil(Sa*2/wn)+1,n=e*e*e*H0,i=new Tt,s=new Float32Array(n*3);i.setAttribute("position",new Ut(s,3));const r=new vn({uniforms:{uSize:{value:eP},uColor:{value:tP},uFadeNear:{value:nP},uFadeMid:{value:iP},uFadeFar:{value:sP},uFadeEnd:{value:rP}},vertexShader:aP,fragmentShader:cP,transparent:!0,depthWrite:!1}),o=new Wa(i,r);return o.layers.set(G0),o.frustumCulled=!1,t.add(o),{points:o,positions:s,geometry:i,material:r,maxParticles:n}}function V0(t,e){const{positions:n,geometry:i}=t,s=Math.floor(e.x/wn),r=Math.floor(e.y/wn),o=Math.floor(e.z/wn),a=Math.ceil(Sa/wn);let c=0;const l=Sa*Sa;for(let d=s-a;d<=s+a;d++)for(let f=r-a;f<=r+a;f++)for(let h=o-a;h<=o+a;h++){const p=d*wn,v=f*wn,g=h*wn;let m=oP(d,f,h);for(let S=0;S<H0;S++){let _,y,D;[m,_]=rl(m),[m,y]=rl(m),[m,D]=rl(m);const E=p+_*wn,A=v+y*wn,P=g+D*wn,b=E-e.x,x=A-e.y,L=P-e.z;if(b*b+x*x+L*L<=l&&c<t.maxParticles){const F=c*3;n[F]=E,n[F+1]=A,n[F+2]=P,c++}}}const u=i.attributes.position;u&&(u.needsUpdate=!0),i.setDrawRange(0,c)}const Ls=[new J(1,1,1),new J(1,1,.5),new J(1,.7,.2),new J(1,.3,.1),new J(.5,.1,.05)];function gp(t){const n=Math.min(1,Math.max(0,t))*(Ls.length-1),i=Math.floor(n),s=n-i;if(i>=Ls.length-1)return Ls[Ls.length-1];const r=Ls[i],o=Ls[i+1];return new J().lerpColors(r,o,s)}const tc=24,zd=64,lP=3,uP=5,dP=4,fP=8,hP=.1;function pP(t){return new mt({color:t,transparent:!0,opacity:.6,blending:ot,depthWrite:!1,side:Dt})}function mP(t){return new Ga({color:t,size:2,transparent:!0,opacity:1,blending:ot,depthWrite:!1})}function gP(t,e=tc){const n=new Float32Array(e*3);return $0(n,t,e),n}function $0(t,e,n){const i=eo(e*31337);for(let s=0;s<n;s++){const r=ft(i)*Math.PI*2,o=Math.acos(2*ft(i)-1),a=s*3;t[a]=Math.sin(o)*Math.cos(r),t[a+1]=Math.sin(o)*Math.sin(r),t[a+2]=Math.cos(o)}}function vP(t,e,n,i,s,r){const o=s.variant==="nuke",a=o?zd:tc,c=o?new J(1,1,1):s.color,l=pP(c),u=new Ye(t.clone(),l);u.position.copy(r),u.scale.setScalar(.1),n.add(u);const d=new Float32Array(a*3),f=new Tt;f.setAttribute("position",new Ut(d,3));const h=mP(s.color);o&&(h.size=3);const p=new Wa(f,h);n.add(p);const v=gP(i,a),g={sphere:u,particles:p,particleVelocities:v,isNuke:o};if(o){const m=new mt({color:16777215,transparent:!0,opacity:1,blending:ot,depthWrite:!1}),S=new Ye(t.clone(),m);S.position.copy(r),S.scale.setScalar(s.size*.5),n.add(S),g.flash=S;const _=new mt({color:16777130,transparent:!0,opacity:.8,blending:ot,depthWrite:!1,side:Dt}),y=new Ye(e.clone(),_);y.position.copy(r),y.rotation.x=Math.PI/2,y.scale.setScalar(s.size*.5),n.add(y),g.ring=y;const D=new io(16777164,50,s.size*30);D.position.copy(r),n.add(D),g.light=D}return g}function yP(t,e,n,i){var S;const{sphere:s,particles:r,particleVelocities:o,isNuke:a}=t,c=1-(1-i)**2,l=a?uP:lP,u=a?fP:dP,d=a?zd:tc,f=n.size*(.5+c*l);s.position.copy(e),s.scale.setScalar(f);const h=s.material;a?(h.color.copy(gp(i)),h.opacity=Math.max(0,.8*(1-c*1.2))):h.opacity=Math.max(0,.6*(1-c*1.5));const p=(S=r.geometry.attributes.position)==null?void 0:S.array,v=n.size*c*u;for(let _=0;_<d;_++){const y=_*3;p[y]=e.x+o[y]*v,p[y+1]=e.y+o[y+1]*v,p[y+2]=e.z+o[y+2]*v}const g=r.geometry.attributes.position;g&&(g.needsUpdate=!0);const m=Math.max(0,1-c);if(r.material.opacity=m,a&&r.material.color.copy(gp(i*.8)),a){if(t.flash){t.flash.position.copy(e);const _=i/hP;if(_<1){t.flash.visible=!0;const y=n.size*(1+_*2);t.flash.scale.setScalar(y);const D=1-_;t.flash.material.opacity=D}else t.flash.visible=!1}if(t.ring){t.ring.position.copy(e);const _=n.size*(1+c*10);t.ring.scale.setScalar(_);const y=Math.max(0,.8*(1-c));t.ring.material.opacity=y}if(t.light){t.light.position.copy(e);const _=Math.min(1,i*3),y=_<.3?80:80*(1-_);t.light.intensity=Math.max(0,y)}}}function SP(t,e,n,i){var l;const s=n.variant==="nuke",r=s?zd:tc,o=s?new J(1,1,1):n.color;t.sphere.material.color.copy(o),t.sphere.material.opacity=.6,t.sphere.position.copy(i),t.sphere.scale.setScalar(.1),t.sphere.visible=!0;const a=(l=t.particles.geometry.attributes.position)==null?void 0:l.array;for(let u=0;u<r*3;u++)a[u]=0;const c=t.particles.geometry.attributes.position;c&&(c.needsUpdate=!0),t.particles.material.color.copy(n.color),t.particles.material.opacity=1,t.particles.visible=!0,$0(t.particleVelocities,e,r),s&&(t.flash&&(t.flash.material.opacity=1,t.flash.position.copy(i),t.flash.scale.setScalar(n.size*.5),t.flash.visible=!0),t.ring&&(t.ring.material.opacity=.8,t.ring.position.copy(i),t.ring.scale.setScalar(n.size*.5),t.ring.visible=!0),t.light&&(t.light.intensity=50,t.light.position.copy(i)))}function _P(t){t.sphere.visible=!1,t.particles.visible=!1,t.flash&&(t.flash.visible=!1),t.ring&&(t.ring.visible=!1),t.light&&(t.light.intensity=0)}const ol=new Set;function X0(){const t=new yn(1,16,12),e=new Va(1,.1,8,32);return{visuals:new Map,sphereGeometry:t,nukeRingGeometry:e,standardPool:[],nukePool:[],scene:null}}function xP(t,e,n,i,s){t.scene=e;const a=(i.variant==="nuke"?t.nukePool:t.standardPool).pop();return a?(SP(a,n,i,s),a):vP(t.sphereGeometry,t.nukeRingGeometry,e,n,i,s)}function bP(t,e){_P(e),(e.isNuke?t.nukePool:t.standardPool).push(e)}function q0(t,e,n){ol.clear();for(const i of Te(n,["explosion","transform"])){ol.add(i);const s=C(n,i,"explosion"),r=C(n,i,"transform"),o=QE(s);let a=t.visuals.get(i);a||(a=xP(t,e,i,s,r.position),t.visuals.set(i,a)),yP(a,r.position,s,o)}for(const[i,s]of t.visuals)ol.has(i)||(bP(t,s),t.visuals.delete(i))}const MP=.08,EP={Plasma:new J(0,1,0),Pulse:new J(.3,.9,1),Ion:new J(.4,.5,1),Autocannon:new J(1,.6,.2),Railgun:new J(1,1,1),Flak:new J(1,.5,.2),Shrapnel:new J(1,.6,.2)},wP=new J(1,.5,.2),al={Red:new J(1,0,0),Green:new J(0,1,0),Blue:new J(0,0,1),Lightning:new J(.6,.8,1),Torch:new J(1,.6,.2)},TP=new J(1,1,1),cl=new Set,Nu=[];function Y0(){return{flashes:[],beamGlows:new Map,flashGeometry:new yn(1.5,12,8),glowGeometry:new yn(.8,8,6)}}function AP(t,e,n,i){const s=EP[i]??wP,r=new mt({color:s,transparent:!0,opacity:1,blending:ot,depthWrite:!1}),o=new Ye(t.flashGeometry.clone(),r);return o.position.copy(n),e.add(o),o}function RP(t,e,n){const i=new mt({color:n,transparent:!0,opacity:.9,blending:ot,depthWrite:!1}),s=new Ye(t.glowGeometry.clone(),i);e.add(s);const r=new io(n,.3,8);return e.add(r),{mesh:s,light:r}}function j0(t,e,n){const i=n.systemState.gameTime;CP(n);for(const s of Nu){const r={mesh:AP(t,e,s.position,s.weaponName),startTime:i};t.flashes.push(r)}Nu.length=0;for(let s=t.flashes.length-1;s>=0;s--){const r=t.flashes[s];if(!r)continue;const a=(i-r.startTime)/MP;if(a>=1)e.remove(r.mesh),r.mesh.geometry.dispose(),r.mesh.material.dispose(),t.flashes.splice(s,1);else{const c=1+a*2;r.mesh.scale.setScalar(c),r.mesh.material.opacity=1-a}}PP(t,e,n)}function CP(t){const e=new Set;for(const n of Te(t,["projectile","transform"]))if(e.add(n),!cl.has(n)){const i=C(t,n,"transform"),s=C(t,n,"projectile");Nu.push({position:i.position.clone(),weaponName:(s==null?void 0:s.weaponName)??"Plasma"})}cl.clear();for(const n of e)cl.add(n)}function PP(t,e,n){const i=n.systemState.beams.activeBeams,s=new Set;for(const[r,o]of i)for(const a of o){if(a.weaponName==="Nuclear Lance"||a.isInstantBeam&&a.lanceFireTime!==void 0||!a.active)continue;const c=`${r}-${a.weaponIndex}`;s.add(c);let l=t.beamGlows.get(c);if(!l){let d=TP;if(a.weaponName==="Lightning")d=al.Lightning;else if(a.weaponName==="Torch")d=al.Torch;else for(const[f,h]of Object.entries(al))a.color.r>.5&&f==="Red"&&(d=h),a.color.g>.5&&f==="Green"&&(d=h),a.color.b>.5&&f==="Blue"&&(d=h);l=RP(t,e,d),t.beamGlows.set(c,l)}l.mesh.position.copy(a.origin),l.light.position.copy(a.origin),l.mesh.visible=!0;const u=.8+.2*Math.sin(n.systemState.gameTime*20);l.mesh.scale.setScalar(u),l.light.intensity=.2+.2*u}for(const[r,o]of t.beamGlows)s.has(r)||(o.mesh.visible=!1,o.light.intensity=0)}const LP=new J(.3,.7,1),DP=3,ll=new Set;function K0(){const t=new yn(DP,16,12);return{effects:new Map,geometry:t}}function IP(t,e,n){const i=new mt({color:LP,transparent:!0,opacity:.8,blending:ot,depthWrite:!1,side:Dt}),s=new Ye(t.geometry.clone(),i);return s.position.copy(n),e.add(s),s}function Z0(t,e,n){const i=n.systemState.gameTime;ll.clear();for(const s of Te(n,["shieldHit"])){const r=C(n,s,"shieldHit"),o=lw(r,i);for(let a=0;a<o.length;a++){const c=o[a];if(!c)continue;const l=`${s}-${c.time.toFixed(3)}`;ll.add(l);let u=t.effects.get(l);u||(u={mesh:IP(t,e,c.position),startTime:c.time},t.effects.set(l,u));const f=(i-c.time)/sg,h=1+f*2;u.mesh.scale.setScalar(h*c.intensity);const p=Math.max(0,.8*(1-f));u.mesh.material.opacity=p,u.mesh.position.copy(c.position)}}for(const[s,r]of t.effects)ll.has(s)||(e.remove(r.mesh),r.mesh.geometry.dispose(),r.mesh.material.dispose(),t.effects.delete(s))}const NP={sphere:{radius:.5},cylinder:{radius:.15,length:1.2},capsule:{radius:.12,length:5}},UP={Plasma:{color:new J(0,1,0),radius:.5,length:25,boltShape:"capsule"},Pulse:{color:new J(.3,.9,1),radius:.5,length:20,boltShape:"capsule"},Ion:{color:new J(.4,.5,1),radius:1,length:20,boltShape:"capsule"},Autocannon:{color:new J(1,.85,.3),radius:.25,length:15,boltShape:"cylinder"},Railgun:{color:new J(1,1,1),radius:.5,length:100,boltShape:"cylinder"},Flak:{color:new J(1,.2,.2),radius:.4,boltShape:"sphere"},Shrapnel:{color:new J(1,.9,.3),radius:.25,length:15,boltShape:"cylinder"}},kP={color:new J(1,.5,.2),radius:.072,length:3,boltShape:"capsule"};function Hd(t,e,n){const i=NP[t.boltShape],s=t.radius/i.radius;if(t.boltShape==="sphere"||!i.length)e.set(s,s,s);else{const o=(n??t.length??i.length)/i.length;e.set(s,o,s)}}function Gd(t){return UP[t]??kP}const ul=new Set;function J0(t,e){return e.boltShape==="sphere"?t.energyBoltGeometry:e.boltShape==="capsule"?t.capsuleBoltGeometry:t.ballisticBoltGeometry}function Q0(){return{bolts:new Map,energyBoltGeometry:new yn(.5,8,6),ballisticBoltGeometry:new is(.15,.15,1.2,6),capsuleBoltGeometry:new od(.12,5,4,8),pool:[],scene:null}}function FP(t,e,n,i){t.scene=e;const s=t.pool.pop();return s?(OP(t,s,n,i),s.bolt.visible=!0,s):BP(t,e,n,i)}function OP(t,e,n,i){const s=Gd(n);e.weaponName=n;const r=J0(t,s);e.bolt.geometry!==r&&(e.bolt.geometry=r),e.bolt.material.color.copy(s.color),Hd(s,e.bolt.scale),e.bolt.position.copy(i)}function BP(t,e,n,i){const s=Gd(n),r=J0(t,s),o=new mt({color:s.color,transparent:!0,opacity:1,blending:ot,depthWrite:!1}),a=new Ye(r,o);return a.position.copy(i),Hd(s,a.scale),e.add(a),{bolt:a,weaponName:n}}function zP(t,e){e.bolt.visible=!1,t.pool.push(e)}function ev(t,e,n){ul.clear();for(const i of Te(n,["projectile","transform"])){ul.add(i);const s=C(n,i,"projectile"),r=C(n,i,"transform");let o=t.bolts.get(i);o||(o=FP(t,e,s.weaponName,r.position),t.bolts.set(i,o)),GP(o,r.position,s.direction,s.distanceTraveled)}for(const[i,s]of t.bolts)ul.has(i)||(zP(t,s),t.bolts.delete(i))}const vp=new at,HP=new T(0,1,0);function GP(t,e,n,i){const s=Gd(t.weaponName);let r,o=0;s.boltShape!=="sphere"&&s.length&&(r=Math.min(i,s.length),o=-r/2),Hd(s,t.bolt.scale,r),t.bolt.position.copy(e),o!==0&&t.bolt.position.addScaledVector(n,o),vp.setFromUnitVectors(HP,n),t.bolt.quaternion.copy(vp)}function yp(t,e){e.remove(t.bolt),t.bolt.material.dispose()}function WP(t,e){for(const n of t.bolts.values())yp(n,e);t.bolts.clear();for(const n of t.pool)yp(n,e);t.pool.length=0,t.energyBoltGeometry.dispose(),t.ballisticBoltGeometry.dispose(),t.capsuleBoltGeometry.dispose(),t.scene=null}const VP=new J(1,.6,.1),$P=new J(1,.3,0),Sp=2.5,XP=.4,dl=new Set,_p=new T;function tv(){const t=new no(XP,Sp,8);return t.rotateX(-Math.PI/2),t.translate(0,0,Sp/2),{exhausts:new Map,coneGeometry:t}}function qP(t,e,n){const i=new mt({color:VP,transparent:!0,opacity:.8,blending:ot,depthWrite:!1}),s=new Ye(t.coneGeometry.clone(),i);e.add(s);const r=new io($P,.5,10);return e.add(r),{cone:s,glow:r,flickerPhase:ft(n.prng)*Math.PI*2}}function nv(t,e,n,i){dl.clear();for(const s of Te(n,["missile","transform"])){dl.add(s);const r=C(n,s,"missile"),o=C(n,s,"transform");let a=t.exhausts.get(s);a||(a=qP(t,e,n),t.exhausts.set(s,a)),_p.copy(r.direction).multiplyScalar(-1.5),a.cone.position.copy(o.position).add(_p),a.cone.quaternion.copy(o.rotation),a.glow.position.copy(a.cone.position);const c=.7+.3*Math.sin(i*30+a.flickerPhase)*Math.sin(i*47+a.flickerPhase*1.3);a.cone.material.opacity=.6+.4*c,a.glow.intensity=.3+.4*c;const l=.9+.2*c;a.cone.scale.set(l,l,l)}for(const[s,r]of t.exhausts)dl.has(s)||(e.remove(r.cone),e.remove(r.glow),r.cone.geometry.dispose(),r.cone.material.dispose(),t.exhausts.delete(s))}const iv=.15,sv=3,Wd=new fe(1,1);function xp(t,e){Wd.set(t,e)}function YP(t,e,n,i){const s=new Pa;s.setPositions([0,0,0,0,0,1]);const r=new Qr({color:n.getHex(),linewidth:sv*i,opacity:1,transparent:!0,resolution:Wd}),o=new Pu(s,r);return t.add(o),{line:o,material:r,geometry:s,entityId:e}}function jP(t,e,n){if(!e.hitPoint)return;t.geometry.setPositions([e.origin.x,e.origin.y,e.origin.z,e.hitPoint.x,e.hitPoint.y,e.hitPoint.z]);let i=1;e.fadeStartTime!==null&&(i=1-(n-e.fadeStartTime)/iv),t.material.color.setHex(e.color.getHex()),t.material.opacity=i,t.material.linewidth=sv*(e.beamWidth??1),t.material.resolution=Wd,t.line.visible=!0}function rv(t,e){t.remove(e.line),e.material.dispose(),e.geometry.dispose()}const fl=new Set;function KP(t,e,n,i){const s=t.systemState.beams.activeBeams;fl.clear();for(const[r,o]of s)for(const a of o){if(!a.hitPoint||a.weaponName==="Nuclear Lance"||a.weaponName==="Lightning"||a.fadeStartTime!==null&&i-a.fadeStartTime>=iv)continue;const c=`${r}-${a.weaponIndex}`;fl.add(c);let l=n.get(c);l||(l=YP(e,r,a.color,a.beamWidth??1),n.set(c,l)),jP(l,a,i)}for(const[r,o]of n)fl.has(r)||(rv(e,o),n.delete(r))}const ov={[ze.Player]:65280,[ze.Enemy]:16711680,[ze.Neutral]:16776960},ZP={rocket:{radius:.6,length:2.5,color:16729088},seeker:{radius:.4,length:3,color:65484},dart:{radius:.25,length:3.5,color:11197951,emissive:4491519},cluster:{radius:.35,length:2,color:16755200},swarm:{radius:.2,length:1.5,color:16746496,emissive:16729088},torpedo:{radius:.7,length:4,color:6719658},nuke:{radius:.9,length:5,color:16720384,emissive:16711680}};function JP(t){const e=new no(2,8,4);e.rotateX(Math.PI/2);const n=ov[t]??16777215,i=new B1({color:n});return new Ye(e,i)}function QP(t){const e=ZP[t],n=new zs,i=new no(e.radius,e.length,8);i.rotateX(Math.PI/2);const s=new mt({color:e.color,transparent:!0,opacity:.9});e.emissive&&s.color.lerp(new J(e.emissive),.3);const r=new Ye(i,s);if(n.add(r),t==="torpedo"||t==="nuke"){const o=new os(e.radius*2.5,.1,.8),a=new mt({color:4473924});for(let c=0;c<4;c++){const l=new Ye(o,a);l.position.z=e.length*.35,l.rotation.z=c*Math.PI/2,n.add(l)}}if(e.emissive){const o=new yn(e.radius*1.3,8,6),a=new mt({color:e.emissive,transparent:!0,opacity:.4,blending:ot}),c=new Ye(o,a);c.position.z=-e.length*.3,n.add(c)}return n}function eL(t){const e=new zs,n=ov[t]??16776960,i=new Ye(new yn(.8,12,8),new mt({color:n,transparent:!0,opacity:.9})),s=new Ye(new yn(1.2,12,8),new mt({color:n,transparent:!0,opacity:.3,blending:ot}));return e.add(i,s),e}class tL{constructor(e){sc(this,"_state");sc(this,"_index",0);this._state=new Array(624),this._state[0]=e|0;for(let n=1;n<624;n++){const i=this._state[n-1];this._state[n]=i^i>>>30,this._state[n]=1812433253*this._state[n]+n;const s=this._state[n];this._state[n]=s&(s<<32)-1}}_generateNumbers(){const e=this._state;for(let n=0;n<624;n++){let i=e[n]&2147483648;i=i+(e[(n+1)%624]&2147483647),e[n]=e[(n+397)%624]^i>>>1,i%2!==0&&(e[n]=e[n]^2567483615)}}random(){this._index===0&&this._generateNumbers();let e=this._state[this._index];return e=e^e>>>11,e=e^e<<7&2636928640,e=e^e<<15&4022730752,e=e^e>>>18,this._index=(this._index+1)%624,(e>>>0)*(1/4294967296)}}function nL(t){let e=0;for(let n=0;n<t.length;n++)e+=(n+1)*t.charCodeAt(n);return e}function Gs(t,e){return new tL(nL(t)+e)}const iL=`
vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 permute(vec4 x) { return mod289(((x*34.0)+1.0)*x); }
vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }
vec4 fade(vec4 t) { return t*t*t*(t*(t*6.0-15.0)+10.0); }

float cnoise(vec4 P) {
  vec4 Pi0 = floor(P); vec4 Pi1 = Pi0 + 1.0;
  Pi0 = mod289(Pi0); Pi1 = mod289(Pi1);
  vec4 Pf0 = fract(P); vec4 Pf1 = Pf0 - 1.0;
  vec4 ix = vec4(Pi0.x, Pi1.x, Pi0.x, Pi1.x);
  vec4 iy = vec4(Pi0.yy, Pi1.yy);
  vec4 iz0 = vec4(Pi0.zzzz); vec4 iz1 = vec4(Pi1.zzzz);
  vec4 iw0 = vec4(Pi0.wwww); vec4 iw1 = vec4(Pi1.wwww);
  vec4 ixy = permute(permute(ix) + iy);
  vec4 ixy0 = permute(ixy + iz0); vec4 ixy1 = permute(ixy + iz1);
  vec4 ixy00 = permute(ixy0 + iw0); vec4 ixy01 = permute(ixy0 + iw1);
  vec4 ixy10 = permute(ixy1 + iw0); vec4 ixy11 = permute(ixy1 + iw1);
  vec4 gx00 = ixy00 * (1.0 / 7.0); vec4 gy00 = floor(gx00) * (1.0 / 7.0);
  vec4 gz00 = floor(gy00) * (1.0 / 6.0);
  gx00 = fract(gx00) - 0.5; gy00 = fract(gy00) - 0.5; gz00 = fract(gz00) - 0.5;
  vec4 gw00 = vec4(0.75) - abs(gx00) - abs(gy00) - abs(gz00);
  vec4 sw00 = step(gw00, vec4(0.0));
  gx00 -= sw00 * (step(0.0, gx00) - 0.5); gy00 -= sw00 * (step(0.0, gy00) - 0.5);
  vec4 gx01 = ixy01 * (1.0 / 7.0); vec4 gy01 = floor(gx01) * (1.0 / 7.0);
  vec4 gz01 = floor(gy01) * (1.0 / 6.0);
  gx01 = fract(gx01) - 0.5; gy01 = fract(gy01) - 0.5; gz01 = fract(gz01) - 0.5;
  vec4 gw01 = vec4(0.75) - abs(gx01) - abs(gy01) - abs(gz01);
  vec4 sw01 = step(gw01, vec4(0.0));
  gx01 -= sw01 * (step(0.0, gx01) - 0.5); gy01 -= sw01 * (step(0.0, gy01) - 0.5);
  vec4 gx10 = ixy10 * (1.0 / 7.0); vec4 gy10 = floor(gx10) * (1.0 / 7.0);
  vec4 gz10 = floor(gy10) * (1.0 / 6.0);
  gx10 = fract(gx10) - 0.5; gy10 = fract(gy10) - 0.5; gz10 = fract(gz10) - 0.5;
  vec4 gw10 = vec4(0.75) - abs(gx10) - abs(gy10) - abs(gz10);
  vec4 sw10 = step(gw10, vec4(0.0));
  gx10 -= sw10 * (step(0.0, gx10) - 0.5); gy10 -= sw10 * (step(0.0, gy10) - 0.5);
  vec4 gx11 = ixy11 * (1.0 / 7.0); vec4 gy11 = floor(gx11) * (1.0 / 7.0);
  vec4 gz11 = floor(gy11) * (1.0 / 6.0);
  gx11 = fract(gx11) - 0.5; gy11 = fract(gy11) - 0.5; gz11 = fract(gz11) - 0.5;
  vec4 gw11 = vec4(0.75) - abs(gx11) - abs(gy11) - abs(gz11);
  vec4 sw11 = step(gw11, vec4(0.0));
  gx11 -= sw11 * (step(0.0, gx11) - 0.5); gy11 -= sw11 * (step(0.0, gy11) - 0.5);
  vec4 g0000 = vec4(gx00.x,gy00.x,gz00.x,gw00.x); vec4 g1000 = vec4(gx00.y,gy00.y,gz00.y,gw00.y);
  vec4 g0100 = vec4(gx00.z,gy00.z,gz00.z,gw00.z); vec4 g1100 = vec4(gx00.w,gy00.w,gz00.w,gw00.w);
  vec4 g0010 = vec4(gx10.x,gy10.x,gz10.x,gw10.x); vec4 g1010 = vec4(gx10.y,gy10.y,gz10.y,gw10.y);
  vec4 g0110 = vec4(gx10.z,gy10.z,gz10.z,gw10.z); vec4 g1110 = vec4(gx10.w,gy10.w,gz10.w,gw10.w);
  vec4 g0001 = vec4(gx01.x,gy01.x,gz01.x,gw01.x); vec4 g1001 = vec4(gx01.y,gy01.y,gz01.y,gw01.y);
  vec4 g0101 = vec4(gx01.z,gy01.z,gz01.z,gw01.z); vec4 g1101 = vec4(gx01.w,gy01.w,gz01.w,gw01.w);
  vec4 g0011 = vec4(gx11.x,gy11.x,gz11.x,gw11.x); vec4 g1011 = vec4(gx11.y,gy11.y,gz11.y,gw11.y);
  vec4 g0111 = vec4(gx11.z,gy11.z,gz11.z,gw11.z); vec4 g1111 = vec4(gx11.w,gy11.w,gz11.w,gw11.w);
  vec4 norm00 = taylorInvSqrt(vec4(dot(g0000,g0000), dot(g0100,g0100), dot(g1000,g1000), dot(g1100,g1100)));
  g0000 *= norm00.x; g0100 *= norm00.y; g1000 *= norm00.z; g1100 *= norm00.w;
  vec4 norm01 = taylorInvSqrt(vec4(dot(g0001,g0001), dot(g0101,g0101), dot(g1001,g1001), dot(g1101,g1101)));
  g0001 *= norm01.x; g0101 *= norm01.y; g1001 *= norm01.z; g1101 *= norm01.w;
  vec4 norm10 = taylorInvSqrt(vec4(dot(g0010,g0010), dot(g0110,g0110), dot(g1010,g1010), dot(g1110,g1110)));
  g0010 *= norm10.x; g0110 *= norm10.y; g1010 *= norm10.z; g1110 *= norm10.w;
  vec4 norm11 = taylorInvSqrt(vec4(dot(g0011,g0011), dot(g0111,g0111), dot(g1011,g1011), dot(g1111,g1111)));
  g0011 *= norm11.x; g0111 *= norm11.y; g1011 *= norm11.z; g1111 *= norm11.w;
  float n0000 = dot(g0000, Pf0); float n1000 = dot(g1000, vec4(Pf1.x, Pf0.yzw));
  float n0100 = dot(g0100, vec4(Pf0.x, Pf1.y, Pf0.zw)); float n1100 = dot(g1100, vec4(Pf1.xy, Pf0.zw));
  float n0010 = dot(g0010, vec4(Pf0.xy, Pf1.z, Pf0.w)); float n1010 = dot(g1010, vec4(Pf1.x, Pf0.y, Pf1.z, Pf0.w));
  float n0110 = dot(g0110, vec4(Pf0.x, Pf1.yz, Pf0.w)); float n1110 = dot(g1110, vec4(Pf1.xyz, Pf0.w));
  float n0001 = dot(g0001, vec4(Pf0.xyz, Pf1.w)); float n1001 = dot(g1001, vec4(Pf1.x, Pf0.yz, Pf1.w));
  float n0101 = dot(g0101, vec4(Pf0.x, Pf1.y, Pf0.z, Pf1.w)); float n1101 = dot(g1101, vec4(Pf1.xy, Pf0.z, Pf1.w));
  float n0011 = dot(g0011, vec4(Pf0.xy, Pf1.zw)); float n1011 = dot(g1011, vec4(Pf1.x, Pf0.y, Pf1.zw));
  float n0111 = dot(g0111, vec4(Pf0.x, Pf1.yzw)); float n1111 = dot(g1111, Pf1);
  vec4 fade_xyzw = fade(Pf0);
  vec4 n_0w = mix(vec4(n0000, n1000, n0100, n1100), vec4(n0001, n1001, n0101, n1101), fade_xyzw.w);
  vec4 n_1w = mix(vec4(n0010, n1010, n0110, n1110), vec4(n0011, n1011, n0111, n1111), fade_xyzw.w);
  vec4 n_zw = mix(n_0w, n_1w, fade_xyzw.z);
  vec2 n_yzw = mix(n_zw.xy, n_zw.zw, fade_xyzw.y);
  return 2.2 * mix(n_yzw.x, n_yzw.y, fade_xyzw.x);
}
`,sL=`
varying vec3 vPosition;
void main() {
  vPosition = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,rL=`
precision highp float;
varying vec3 vPosition;
uniform vec3 uNebulaColors[5], uNebulaOffsets[5];
uniform float uNebulaScales[5], uNebulaIntensities[5], uNebulaFalloffs[5];
uniform int uNebulaCount;
uniform vec3 uHaloDirections[9], uHaloColors[9];
uniform float uHaloSizes[9], uHaloFalloffs[9];
uniform int uHaloCount;
uniform vec3 uSunDirection, uSunColor;
uniform float uSunSize, uSunFalloff;

${iL}

float noise(vec3 p) {
  return 0.5 * cnoise(vec4(p, 0.0)) + 0.5;
}

float nebula(vec3 p) {
  float scale = 64.0; vec3 displace = vec3(0.0);
  for (int i = 0; i < 6; i++) {
    displace = vec3(noise(p.xyz * scale + displace), noise(p.yzx * scale + displace), noise(p.zxy * scale + displace));
    scale *= 0.5;
  }
  return noise(p * scale + displace);
}

void main() {
  vec3 dir = normalize(vPosition);
  vec3 color = vec3(0.0);

  for (int i = 0; i < 5; i++) { // Nebulae
    if (i >= uNebulaCount) break;
    vec3 posn = dir * uNebulaScales[i];
    float c = min(1.0, nebula(posn + uNebulaOffsets[i]) * uNebulaIntensities[i]);
    color += uNebulaColors[i] * pow(c, uNebulaFalloffs[i]);
  }
  for (int i = 0; i < 9; i++) { // Star halos
    if (i >= uHaloCount) break;
    float d = 1.0 - clamp(dot(dir, uHaloDirections[i]), 0.0, 1.0);
    color += uHaloColors[i] * exp(-(d - uHaloSizes[i]) * uHaloFalloffs[i]);
  }
  // Sun: sharp disc with anti-aliased edge + tight halo
  float sunDot = clamp(dot(dir, uSunDirection), 0.0, 1.0);
  float edge = 1.0 - uSunSize;
  float sunDisc = smoothstep(edge - 0.0003, edge, sunDot); // Tight AA edge
  float sunHalo = pow(sunDot, uSunFalloff) * 0.25; // Small glow
  float sunC = max(sunDisc, sunHalo);
  vec3 sunColor = mix(uSunColor, vec3(1.0), sunDisc); // White core
  color += sunColor * sunC;

  gl_FragColor = vec4(color, 1.0);
}
`,oL=`
attribute vec3 color;
varying vec3 vColor;
void main() {
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  vColor = color;
}
`,aL=`
precision highp float;
varying vec3 vColor;
void main() {
  gl_FragColor = vec4(vColor, 1.0);
}
`,cL=1e3,lL=2e3,uL=3e3,av=4e3,Os=5,bp=.25,dL=.75,Mp=.6,fL=1,Ep=4,hL=9,Ds=1e3,pL=.45,Fr=9,Uu=2**20,mL=.01,wp=4e-4,gL=6e-4,Tp=1024,vL=2048,yL=5,SL=.2;function cv(t){const e=new Qe;e.makeRotationX(t.random()*Math.PI*2);const n=new Qe().makeRotationY(t.random()*Math.PI*2),i=new Qe().makeRotationZ(t.random()*Math.PI*2);return e.multiply(n).multiply(i),e}function ku(t){const e=cv(t),n=new T(0,0,1);return n.applyMatrix4(e),n.normalize()}function _L(t){const e=Gs(t,cL),n=[];for(;n.push(cv(e)),!(e.random()<SL||n.length>=yL););const i=Gs(t,lL),s=[];for(;;){const d=dL-bp,f=fL-Mp,h=hL-Ep,p=2.5;if(s.push({scale:i.random()*d+bp,color:new T(i.random()**p,i.random()**p,i.random()**p),intensity:i.random()*f+Mp,falloff:i.random()*h+Ep,offset:new T(i.random()*Ds*2-Ds,i.random()*Ds*2-Ds,i.random()*Ds*2-Ds)}),i.random()<pL||s.length>=Os)break}const r=Gs(t,uL),o=[];for(;o.push({direction:ku(r),color:new T(1,1,1),size:0,falloff:r.random()*Uu+Uu}),!(r.random()<mL||o.length>=Fr););const a=Gs(t,av),c=gL-wp,l=vL-Tp,u={direction:ku(a),color:new T(a.random(),a.random(),a.random()),size:a.random()*c+wp,falloff:a.random()*l+Tp};return{nebulae:s,starHalos:o,sun:u,starRotations:n}}const hl=1e5,pl=128,dn=.02,xL=4,bL=5e3;function ML(t){const e=t.random()*Math.PI*2,n=2*t.random()-1,i=Math.sqrt(1-n*n);return[Math.cos(e)*i,Math.sin(e)*i,n]}function EL(t,e){const n=t[0]*e[0]+t[1]*e[1]+t[2]*e[2],i=new at;if(n<-.9999){let l=0,u=1,d=0;Math.abs(t[0])<.9?(l=0,u=-t[2],d=t[1]):(l=t[2],u=0,d=-0);const f=Math.sqrt(l*l+u*u+d*d);return i.setFromAxisAngle(new T(l/f,u/f,d/f),Math.PI),i}const s=Math.acos(Math.max(-1,Math.min(1,n)));let r=t[1]*e[2]-t[2]*e[1],o=t[2]*e[0]-t[0]*e[2],a=t[0]*e[1]-t[1]*e[0];const c=Math.sqrt(r*r+o*o+a*a);return c>1e-4&&(r/=c,o/=c,a/=c),i.setFromAxisAngle(new T(r,o,a),s),i}function wL(t){const e=Gs(t,bL),n=new Float32Array(hl*6*3),i=new Float32Array(hl*6*3),s=[[-dn,-dn,0],[dn,-dn,0],[dn,dn,0],[-dn,-dn,0],[dn,dn,0],[-dn,dn,0]],r=new T;for(let a=0;a<hl;a++){const c=ML(e),l=e.random()**xL,u=EL([0,0,-1],c),d=a*6*3;for(let f=0;f<6;f++){const h=s[f];r.set(h[0],h[1],h[2]),r.applyQuaternion(u),r.x+=c[0]*pl,r.y+=c[1]*pl,r.z+=c[2]*pl,n[d+f*3+0]=r.x,n[d+f*3+1]=r.y,n[d+f*3+2]=r.z,i[d+f*3+0]=l,i[d+f*3+1]=l,i[d+f*3+2]=l}}const o=new Tt;return o.setAttribute("position",new Ut(n,3)),o.setAttribute("color",new Ut(i,3)),o}const TL={seed:"7alzyiphy3k0",resolution:2048};function Qn(t,e,n){return[...t,...Array(e-t.length).fill(n)]}function AL(t,e={}){const n={...TL,...e},i=n.resolution??1024,s=_L(n.seed),r=new Tm(i,{format:nn,generateMipmaps:!1,minFilter:qt,magFilter:qt}),o=new Em(.1,256,r),a=new Nm,c=wL(n.seed),l=new vn({vertexShader:oL,fragmentShader:aL});let u=0;const d=new Qe;for(const m of s.starRotations){d.premultiply(m);const S=new Ye(c,l);S.applyMatrix4(d.clone()),S.renderOrder=u++,a.add(S)}const f=new os(2,2,2),h={uNebulaColors:{value:Qn(s.nebulae.map(m=>m.color),Os,new T)},uNebulaOffsets:{value:Qn(s.nebulae.map(m=>m.offset),Os,new T)},uNebulaScales:{value:Qn(s.nebulae.map(m=>m.scale),Os,.5)},uNebulaIntensities:{value:Qn(s.nebulae.map(m=>m.intensity),Os,1)},uNebulaFalloffs:{value:Qn(s.nebulae.map(m=>m.falloff),Os,4)},uNebulaCount:{value:s.nebulae.length},uHaloDirections:{value:Qn(s.starHalos.map(m=>m.direction),Fr,new T)},uHaloColors:{value:Qn(s.starHalos.map(m=>m.color),Fr,new T)},uHaloSizes:{value:Qn(s.starHalos.map(m=>m.size),Fr,0)},uHaloFalloffs:{value:Qn(s.starHalos.map(m=>m.falloff),Fr,Uu)},uHaloCount:{value:s.starHalos.length},uSunDirection:{value:s.sun.direction},uSunColor:{value:s.sun.color},uSunSize:{value:s.sun.size},uSunFalloff:{value:s.sun.falloff}},p=new vn({vertexShader:sL,fragmentShader:rL,uniforms:h,side:Gt,transparent:!0,blending:ot,depthWrite:!1,depthTest:!1}),v=new Ye(f,p);v.renderOrder=u,a.add(v),o.update(t,a);const g=r.texture;return p.dispose(),f.dispose(),c.dispose(),l.dispose(),g}function RL(t){const e=Gs(t,av);return ku(e)}const ml=new T,gl=new Set,vl=new T,yl=new at,_a=new Map,xa=new Map;function CL(t,e,n,i,s,r,o){const a=s*s,c=a*s,l=2*c-3*a+1,u=c-2*a+s,d=-2*c+3*a,f=c-a;o.set(0,0,0),o.addScaledVector(t,l),o.addScaledVector(e,u*r),o.addScaledVector(n,d),o.addScaledVector(i,f*r)}function lv(t,e){const n=new Nm,i=new $t(60,t.clientWidth/t.clientHeight,.1,1e4);i.layers.enable(G0);const s=new b1({antialias:!0});s.setSize(t.clientWidth,t.clientHeight),s.setPixelRatio(Math.min(window.devicePixelRatio,2)),t.appendChild(s.domElement);const r=e.toString(),o=new G1(5263440,.6);n.add(o);const a=RL(r),c=new zm(16777215,1.4);c.position.copy(a),n.add(c),n.background=AL(s,{seed:r}),xp(t.clientWidth,t.clientHeight),sp(t.clientWidth,t.clientHeight);const l=()=>{i.aspect=t.clientWidth/t.clientHeight,i.updateProjectionMatrix(),s.setSize(t.clientWidth,t.clientHeight),xp(t.clientWidth,t.clientHeight),sp(t.clientWidth,t.clientHeight)};return window.addEventListener("resize",l),{scene:n,camera:i,webglRenderer:s,entityMeshes:new Map,beamLines:new Map,resizeHandler:l}}function uv(t,e,n=1){const{scene:i,entityMeshes:s,beamLines:r}=t;gl.clear();for(const o of Te(e,["transform"])){const a=Ke(e,o,"missile"),c=Ke(e,o,"decoy"),l=mr(e,o);if(!a&&!c&&!l)continue;gl.add(o);const u=C(e,o,"transform"),d=C(e,o,"faction");let f=s.get(o);if(!f){if(a){const p=C(e,o,"missile");f=QP((p==null?void 0:p.missileType)??"seeker")}else c?f=eL((d==null?void 0:d.faction)??ze.Neutral):f=JP((d==null?void 0:d.faction)??ze.Neutral);i.add(f),s.set(o,f)}const h=C(e,o,"physics");if(h){if(CL(h.prevPosition,h.prevVelocity,u.position,h.velocity,n,Au,vl),yl.slerpQuaternions(h.prevRotation,u.rotation,n),f.position.copy(vl),f.quaternion.copy(yl),l){let p=_a.get(o);p||(p=new T,_a.set(o,p)),p.copy(vl);let v=xa.get(o);v||(v=new at,xa.set(o,v)),v.copy(yl)}}else f.position.copy(u.position),f.quaternion.copy(u.rotation)}for(const[o,a]of s)gl.has(o)||(i.remove(a),s.delete(o),_a.delete(o),xa.delete(o));KP(e,i,r,e.systemState.gameTime)}function dv(t){t.webglRenderer.render(t.scene,t.camera)}function PL(t,e,n){const i=C(e,n,"transform");if(!i)return;const{camera:s}=t,r=fv(n)??i.position,o=hv(n)??i.rotation;ml.set(0,5,20),ml.applyQuaternion(o),s.position.copy(r).add(ml),s.quaternion.copy(o)}function go(t){return t.scene}function fv(t){return _a.get(t)??null}function hv(t){return xa.get(t)??null}function pv(t){window.removeEventListener("resize",t.resizeHandler);for(const e of t.beamLines.values())rv(t.scene,e);t.beamLines.clear(),t.webglRenderer.dispose(),t.entityMeshes.clear()}function LL(t=8){return{followedEntity:null,timeSinceSwitch:0,switchInterval:t}}function DL(t,e){const n=[];for(const i of Te(t,["faction","health"])){if(!mr(t,i))continue;const s=C(t,i,"faction"),r=C(t,i,"health");(s==null?void 0:s.faction)===e&&r&&!xt(r)&&n.push(i)}return n}function IL(t){const e=[];for(const n of Te(t,["health"])){if(!mr(t,n))continue;const i=C(t,n,"health");i&&!xt(i)&&e.push(n)}return e}function NL(t,e){if(t.followedEntity===null)return!1;const n=C(e,t.followedEntity,"health");return n!==void 0&&!xt(n)}function UL(t,e,n){if(t.timeSinceSwitch+=n,!NL(t,e)||t.timeSinceSwitch>=t.switchInterval){const r=Math.random()<.5?ze.Player:ze.Enemy;let o=DL(e,r);if(o.length===0&&(o=IL(e)),o.length>0){let a;if(o.length>1&&t.followedEntity!==null){const c=o.filter(l=>l!==t.followedEntity);a=c[Math.floor(Math.random()*c.length)]}else a=o[Math.floor(Math.random()*o.length)];t.followedEntity=a,t.timeSinceSwitch=0}}return t.followedEntity}const kL={offset:new T(0,5,20)};function La(t,e,n,i){const s=Math.random()*Math.PI*2,r=Math.acos(2*Math.random()-1),o=new T(i*Math.sin(r)*Math.cos(s),i*Math.sin(r)*Math.sin(s),i*Math.cos(r)),a=o.clone().negate().normalize(),c=new at().setFromUnitVectors(new T(0,0,-1),a);return hg(t,e.archetype,n,o,c,e.profile,e.callsignPrefix)}function FL(t){const{game:e,config:n}=t,i=e.world;for(let s=0;s<n.teamA.count;s++)La(i,n.teamA,ze.Player,n.spawnRadius);for(let s=0;s<n.teamB.count;s++)La(i,n.teamB,ze.Enemy,n.spawnRadius)}function Ap(t,e){let n=0;for(const i of Te(t,["faction","health"])){if(!mr(t,i))continue;const s=C(t,i,"faction"),r=C(t,i,"health");(s==null?void 0:s.faction)===e&&r&&!xt(r)&&n++}return n}function OL(t){const{game:e,config:n}=t,i=e.world,s=Ap(i,ze.Player),r=Ap(i,ze.Enemy);for(let o=s;o<n.teamA.count;o++)La(i,n.teamA,ze.Player,n.spawnRadius);for(let o=r;o<n.teamB.count;o++)La(i,n.teamB,ze.Enemy,n.spawnRadius)}function BL(t,e){const n=e.seed??Math.floor(Math.random()*1e5),i=Ug(n),s=lv(t,n),r=go(s),o={game:i,config:e,container:t,renderer:s,camera:LL(8),smoothedCamera:{position:new T,rotation:new at,initialized:!1,lastFollowed:null},lastRenderTime:0,dustSystem:W0(r),explosionRenderer:X0(),boltRenderer:Q0(),exhaustRenderer:tv(),shieldEffectRenderer:K0(),muzzleFlashRenderer:Y0(),lightningRenderer:R0(),nuclearLanceRenderer:F0(),torchRenderer:B0(),projectileHitRenderer:Eg()};return FL(o),i.onTick=()=>{OL(o)},i.onRender=(a,c)=>{zL(o,c)},o}function zL(t,e){const{game:n,renderer:i,camera:s}=t,r=n.world,o=go(i),a=performance.now(),c=t.lastRenderTime===0?1/60:(a-t.lastRenderTime)/1e3;t.lastRenderTime=a,uv(i,r,e),q0(t.explosionRenderer,o,r),ev(t.boltRenderer,o,r),nv(t.exhaustRenderer,o,r,r.systemState.gameTime),Z0(t.shieldEffectRenderer,o,r),j0(t.muzzleFlashRenderer,o,r),C0(t.lightningRenderer,o,r),O0(t.nuclearLanceRenderer,o,r),z0(t.torchRenderer,o,r),wg(t.projectileHitRenderer,o,r);const l=UL(s,r,1/60);if(l!==null){const u=C(r,l,"transform");if(u){const d=fv(l),f=hv(l);HL(t,l,u,d,f,c),d&&V0(t.dustSystem,d)}}dv(i)}const Sl=new T;function HL(t,e,n,i,s,r){const{renderer:o,smoothedCamera:a}=t,c=o.camera,l=i??n.position,u=s??n.rotation,d=a.lastFollowed!==e;if(!a.initialized||d)a.rotation.copy(u),a.initialized=!0,a.lastFollowed=e;else{const f=1-Math.exp(-4*r);a.rotation.slerp(u,f)}Sl.copy(kL.offset),Sl.applyQuaternion(a.rotation),a.position.copy(l).add(Sl),c.position.copy(a.position),c.quaternion.copy(a.rotation)}function GL(t){kg(t.game)}function mv(t){Td(t.game),pv(t.renderer)}function WL(t,e){const n=e+1;return t?`
    <div class="save-slot occupied" data-slot="${n}">
      <div class="save-slot-header">
        <span class="save-slot-number">Slot ${n}</span>
        <span class="save-slot-date">${u0(t.timestamp)}</span>
      </div>
      <div class="save-slot-info">
        <div class="save-slot-stat">
          <span class="save-stat-label">Sector</span>
          <span class="save-stat-value">${t.currentSector}</span>
        </div>
        <div class="save-slot-stat">
          <span class="save-stat-label">Missions</span>
          <span class="save-stat-value">${t.missionCount}</span>
        </div>
        <div class="save-slot-stat">
          <span class="save-stat-label">Credits</span>
          <span class="save-stat-value">${t.credits.toLocaleString()}</span>
        </div>
        <div class="save-slot-stat">
          <span class="save-stat-label">Ships</span>
          <span class="save-stat-value">${t.shipCount}</span>
        </div>
      </div>
      <div class="save-slot-actions">
        <button class="btn btn-small btn-load" data-slot="${n}">Load</button>
        <button class="btn btn-small btn-danger btn-delete" data-slot="${n}">Delete</button>
      </div>
    </div>
  `:`
      <div class="save-slot empty" data-slot="${n}">
        <div class="save-slot-header">
          <span class="save-slot-number">Slot ${n}</span>
        </div>
        <div class="save-slot-empty">Empty</div>
      </div>
    `}function VL(){return`
    <div class="title-saves-view">
      <div class="panel-header">
        <h2>Load Game</h2>
      </div>
      <div class="saves-list">
        ${Ud().map((e,n)=>WL(e,n)).join("")}
      </div>
      <div class="saves-footer">
        <button class="btn btn-large" id="btn-back-to-title">Back</button>
      </div>
    </div>
  `}function $L(t){return`
    <div class="title-confirm-view">
      <div class="title-confirm-content">
        <div class="title-confirm-title">Delete Save?</div>
        <div class="title-confirm-message">
          This will permanently delete the save in Slot ${t}.
        </div>
        <div class="title-confirm-buttons">
          <button class="btn btn-large" id="btn-confirm-cancel">Cancel</button>
          <button class="btn btn-large btn-danger" id="btn-confirm-delete" data-slot="${t}">Delete</button>
        </div>
      </div>
    </div>
  `}function XL(t){return`
    <div class="title-confirm-view">
      <div class="title-confirm-content">
        <div class="title-confirm-title title-error-title">Error</div>
        <div class="title-confirm-message">${d0(t)}</div>
        <div class="title-confirm-buttons">
          <button class="btn btn-large" id="btn-error-ok">OK</button>
        </div>
      </div>
    </div>
  `}function qL(){return`
    <div class="title-main-view">
      <div class="title-left-column">
        <div class="title-logo">
          <h1 class="title-name">Spaceflight</h1>
          <div class="title-subtitle">Squadron Commander</div>
        </div>
        <div class="title-menu">
          <button class="btn btn-title btn-primary" id="btn-new-game">
            New Game
          </button>
          <button
            class="btn btn-title"
            id="btn-continue"
            ${uR()?"":"disabled"}
          >
            Continue
          </button>
          <button class="btn btn-title" id="btn-settings">
            Settings
          </button>
        </div>
      </div>
      <div class="title-footer">
        <span class="title-version">v0.1.0</span>
      </div>
    </div>
  `}const gv={render(t,e){let n;switch(t.view){case"main":n=qL();break;case"saves":n=VL();break;case"confirm-delete":n=$L(t.deleteSlot??1);break;case"error":n=XL(t.errorMessage??"An error occurred.");break}return`
      <div class="title-screen">
        <div class="title-background" id="title-battle-bg"></div>
        <div class="title-content">
          ${n}
        </div>
      </div>
    `},bind(t,e){if(t.on("#btn-new-game","click",()=>{e.onNewGame()}),t.on("#btn-continue","click",()=>{t.setState({view:"saves"})}),t.on("#btn-settings","click",()=>{e.onSettings()}),t.on("#btn-back-to-title","click",()=>{t.setState({view:"main"})}),t.on(".btn-load","click",(n,i)=>{const s=parseInt(i.dataset.slot??"0",10);if(s>0){const r=aR(s);r?(t.setState({view:"main"}),e.onContinue(r,s)):t.setState({errorMessage:`Failed to load save from Slot ${s}. The save data may be corrupted.`,view:"error"})}}),t.on("#btn-error-ok","click",()=>{t.setState({errorMessage:null,view:"saves"})}),t.on(".btn-delete","click",(n,i)=>{const s=parseInt(i.dataset.slot??"0",10);s>0&&t.setState({deleteSlot:s,view:"confirm-delete"})}),t.on("#btn-confirm-cancel","click",()=>{t.setState({view:"saves",deleteSlot:null})}),t.on("#btn-confirm-delete","click",()=>{const n=t.getState();n.deleteSlot&&(cR(n.deleteSlot),t.setState({deleteSlot:null,view:"saves"}))}),t.onGlobal("keydown",n=>{if(n.code==="Escape"){n.preventDefault();const i=t.getState();i.view==="saves"?t.setState({view:"main"}):i.view==="confirm-delete"?t.setState({view:"saves",deleteSlot:null}):i.view==="error"&&t.setState({errorMessage:null,view:"saves"})}}),tn){const n=document.getElementById("title-battle-bg");if(n){const i=tn.renderer.webglRenderer.domElement;i.parentElement!==n&&n.appendChild(i)}}}};let Pn=null,tn=null;function YL(t){const e={view:"main",deleteSlot:null,errorMessage:null};t.innerHTML=gv.render(e,{onNewGame:()=>{},onContinue:()=>{},onSettings:()=>{}})}function jL(t,e){Pn==null||Pn.destroy(),tn&&(mv(tn),tn=null),Pn=Fi(gv,t,{view:"main",deleteSlot:null,errorMessage:null},e),requestAnimationFrame(()=>{const i=document.getElementById("title-battle-bg");i&&i.clientWidth>0&&(tn=BL(i,s2),GL(tn))})}function KL(){Pn==null||Pn.replaceState({view:"main",deleteSlot:null,errorMessage:null})}function vv(){Pn==null||Pn.destroy(),Pn=null,tn&&(mv(tn),tn=null)}function Rp(){return tn?tn.renderer.webglRenderer.domElement:null}function Cp(){return tn!==null}function ZL(t){const e=bt[t.weaponType];if(!e)throw new Error(`Unknown weapon type: ${t.weaponType}`);const n={name:e.name,category:e.category,heatPerShot:e.heatPerShot/t.bankSize,projectileSpeed:e.projectileSpeed,fireRate:e.fireRate,range:e.range,damage:e.damage,bankSize:t.bankSize};return e.ammo!==void 0&&(n.maxAmmo=e.ammo*t.bankSize,n.ammo=t.currentAmmo??n.maxAmmo),e.flakRadius&&(n.flakRadius=e.flakRadius),e.shrapnelCount&&(n.shrapnelCount=e.shrapnelCount),e.isPulseBeam&&(n.isPulseBeam=e.isPulseBeam),e.pulseInterval&&(n.pulseInterval=e.pulseInterval),e.noFalloff&&(n.noFalloff=e.noFalloff),e.autoaimFov&&(n.autoaimFov=e.autoaimFov),e.beamWidth&&(n.beamWidth=e.beamWidth),e.shieldDamageMultiplier&&(n.shieldDamageMultiplier=e.shieldDamageMultiplier),e.hullDamageMultiplier&&(n.hullDamageMultiplier=e.hullDamageMultiplier),e.ionize&&(n.ionize=e.ionize),e.heatInjection&&(n.heatInjection=e.heatInjection),e.isInstantBeam&&(n.isInstantBeam=e.isInstantBeam),n}function JL(t){const e=Sn[t.weaponType];if(!e)throw new Error(`Unknown secondary type: ${t.weaponType}`);const n={name:e.name,requiresLock:e.requiresLock,speed:e.speed,turnRate:e.turnRate,range:e.range,damage:e.damage,count:t.count,maxCount:t.maxCount,fireRate:e.fireRate,lockSpeed:e.lockSpeed,lockConeAngle:e.lockConeAngle??30,bankSize:t.bankSize};return e.aoeRadius!==void 0&&(n.aoeRadius=e.aoeRadius),e.isNuke&&(n.isNuke=e.isNuke),e.isDecoy&&(n.isDecoy=e.isDecoy),n}function yv(t){const e=t.map(ZL);let n=0;for(const r of e)r.category==="beam"&&n++;const{linkModes:i,defaultLinkMode:s}=ag(e);return{type:"primaryWeapons",weapons:e,currentIndex:0,lastFireTime:0,linkMode:s,linkModes:i,hasBeams:n>0,hasOnlyBeams:n===e.length}}function Sv(t){return{type:"secondaryWeapons",weapons:t.map(JL),currentIndex:0,lastFireTime:0,lockTarget:void 0,lockProgress:0,lockWeaponIndex:-1}}function Da(t){return t.filter(e=>e!==null)}function QL(t,e,n,i){const s=Wt[e.shipClass];if(!s)throw new Error(`Unknown ship class: ${e.shipClass}`);const r=ai(t),o=new at;de(t,r,ci((n==null?void 0:n.x)??0,(n==null?void 0:n.y)??0,(n==null?void 0:n.z)??0,o)),de(t,r,dd({maxSpeed:s.maxSpeed,acceleration:s.acceleration,turnRate:s.turnRate,rollRate:s.rollRate,afterburnerHeatRate:s.afterburnerHeatRate,initialSpeed:rr}));const a=C(t,r,"physics");a&&fd(a,o,rr);const c=s.hull,l=c-e.hullDamage;de(t,r,so(c,l)),de(t,r,pd(s.shields,s.shieldRegen,s.shieldDelay)),de(t,r,hd()),de(t,r,as(ze.Player)),de(t,r,aw()),de(t,r,md(e.shipClass,"Commander",e.id)),de(t,r,mw()),de(t,r,cd(s.maxHeat,s.coolingRate));const u=Da(e.primaryWeapons),d=Da(e.secondaryWeapons);return de(t,r,yv(u)),d.length>0&&de(t,r,Sv(d)),de(t,r,ls(s.collisionRadius)),de(t,r,ud()),_d(t,r),r}function eD(t,e,n,i){var S,_;const s=Wt[e.shipClass];if(!s)throw new Error(`Unknown ship class: ${e.shipClass}`);const r=ai(t),o=new at;de(t,r,ci((n==null?void 0:n.x)??0,(n==null?void 0:n.y)??0,(n==null?void 0:n.z)??0,o)),de(t,r,dd({maxSpeed:s.maxSpeed,acceleration:s.acceleration,turnRate:s.turnRate,rollRate:s.rollRate,afterburnerHeatRate:s.afterburnerHeatRate,initialSpeed:rr}));const a=C(t,r,"physics");a&&fd(a,o,rr);const c=s.hull,l=c-e.hullDamage;de(t,r,so(c,l)),de(t,r,pd(s.shields,s.shieldRegen,s.shieldDelay)),de(t,r,hd()),de(t,r,as(ze.Player));const u=((S=e.pilot)==null?void 0:S.name)??"Wingman";de(t,r,md(e.shipClass,u,e.id));const d=((_=e.pilot)==null?void 0:_.skill)??"regular",f=Xm(d,"brawler"),p=Math.floor(600*f.combatRangeMultiplier);de(t,r,$m(f,p,void 0)),de(t,r,jm(t.prng,f)),de(t,r,cd(s.maxHeat,s.coolingRate));const g=Da(e.primaryWeapons),m=Da(e.secondaryWeapons);return de(t,r,yv(g)),m.length>0&&de(t,r,Sv(m)),de(t,r,ls(s.collisionRadius*1.5)),de(t,r,ud()),_d(t,r),r}function tD(t){const e=[];for(const n of Te(t,["shipIdentity"])){const i=C(t,n,"shipIdentity");if(!(i!=null&&i.campaignShipId))continue;const s={campaignShipId:i.campaignShipId,primaryAmmo:new Map,secondaryAmmo:new Map},r=C(t,n,"primaryWeapons");if(r)for(let a=0;a<r.weapons.length;a++){const c=r.weapons[a];(c==null?void 0:c.ammo)!==void 0&&s.primaryAmmo.set(a,c.ammo)}const o=C(t,n,"secondaryWeapons");if(o)for(let a=0;a<o.weapons.length;a++){const c=o.weapons[a];c&&s.secondaryAmmo.set(a,c.count)}e.push(s)}return e}function nD(){const e=new URLSearchParams(window.location.search).get("seed");if(e===null||e==="random")return performance.now()|0;const n=Number.parseInt(e,10);return Number.isNaN(n)?12345:n}function iD(t){const e=document.createElement("div"),n=t?"#ff0000":"#00ff00";return e.style.cssText=`
    position: absolute;
    top: 35%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 72px;
    font-weight: bold;
    font-family: sans-serif;
    text-shadow: 0 0 20px ${n}, 0 0 40px ${n};
    color: ${n};
    pointer-events: none;
    z-index: 1000;
  `,e.textContent=t?"DEFEAT":"VICTORY",e}function sD(){return{scrap:{},weapons:[],ammo:[],totalValue:0}}function rD(t,e){const n=sD();for(const i of t){const s=e()*.1,r=Math.floor(100*s);if(r>0){n.scrap[i.shipClass]=(n.scrap[i.shipClass]??0)+r;const o=ds(i.shipClass,"buy");n.totalValue+=r*(o/100)}for(const o of i.primaryWeapons)if(e()<s&&(n.weapons.push({weaponType:o.weaponType,category:"primary",count:1}),n.totalValue+=lo(o.weaponType,"buy")),o.ammoRemaining!==void 0&&o.ammoRemaining>0){const a=Math.floor(o.ammoRemaining*s);if(a>0){const c=n.ammo.find(l=>l.weaponType===o.weaponType);c?c.count+=a:n.ammo.push({weaponType:o.weaponType,count:a}),n.totalValue+=a*pn(o.weaponType,"buy")}}for(const o of i.secondaryWeapons)if(o.count>0){const a=Math.floor(o.count*s);if(a>0){const c=n.weapons.find(l=>l.category==="secondary"&&l.weaponType===o.weaponType);c?c.count+=a:n.weapons.push({weaponType:o.weaponType,category:"secondary",count:a}),n.totalValue+=a*mn(o.weaponType,"buy")}}}return n}function oD(t,e){const n={...t.storedScrap};for(const[r,o]of Object.entries(e.scrap))n[r]=(n[r]??0)+o;let i=[...t.storedWeapons];for(const r of e.weapons)r.category==="primary"?i.push({...r}):i=uo(i,r.weaponType,r.count);let s=t.storedAmmo;for(const r of e.ammo)s=fo(s,r.weaponType,r.count);return{...t,storedScrap:n,storedWeapons:i,storedAmmo:s}}function aD(t){const e=t.systemState.matchStats,n=e?e.missionEndTime-e.missionStartTime:0,i=[];if(e)for(const s of e.destroyedShips)i.push({callsign:s.callsign,archetype:s.archetype,isPlayer:s.wasPlayer,isKIA:!0,kills:s.stats.kills,assists:s.stats.assists,damageDealt:s.stats.damageDealt,damageReceived:s.stats.damageReceived,hullRemaining:0,hullMax:s.hullMax,timeOfDeath:s.timeOfDeath,weaponStats:s.stats.weaponStats});for(const s of Te(t,["shipIdentity","combatStats"])){const r=C(t,s,"faction");if(!r||r.faction!==ze.Player)continue;const o=C(t,s,"shipIdentity"),a=C(t,s,"combatStats"),c=C(t,s,"health");if(!o||!a||!c)continue;const l=Ke(t,s,"playerControlled"),u=ig(a);i.push({callsign:o.callsign,archetype:o.archetype,isPlayer:l,isKIA:!1,kills:u.kills,assists:u.assists,damageDealt:u.damageDealt,damageReceived:u.damageReceived,hullRemaining:c.hull,hullMax:c.maxHull,timeOfDeath:null,weaponStats:u.weaponStats})}return i.sort((s,r)=>s.isPlayer!==r.isPlayer?s.isPlayer?-1:1:s.kills!==r.kills?r.kills-s.kills:r.damageDealt-s.damageDealt),{missionDuration:n,pilots:i}}function _v(t){const e=Math.floor(t/60),n=Math.floor(t%60);return`${e}:${n.toString().padStart(2,"0")}`}function cD(t){const e=t.weaponName,n=Math.round(t.damageDealt);switch(t.category){case"beam":{if(t.isPulseBeam){const o=t.shotsFired,a=t.shotsOnTarget,c=o>0?Math.round(a/o*100):0;return`
          <tr>
            <td>${e}</td>
            <td>${o} pulses</td>
            <td>${a} hit (${c}%)</td>
            <td class="damage">${n}</td>
          </tr>
        `}const i=t.timeFired.toFixed(1),s=t.timeOnTarget.toFixed(1),r=t.timeFired>0?Math.round(t.timeOnTarget/t.timeFired*100):0;return`
        <tr>
          <td>${e}</td>
          <td>${i}s fired</td>
          <td>${s}s on target (${r}%)</td>
          <td class="damage">${n}</td>
        </tr>
      `}case"missile":{const i=t.missilesLaunched,s=t.missilesHit,r=t.missilesSeduced,o=t.ammoCarried,a=i>0?Math.round(s/i*100):0;return`
        <tr>
          <td>${e}</td>
          <td>${i}/${o} launched</td>
          <td>${s} hit (${a}%), ${r} seduced</td>
          <td class="damage">${n}</td>
        </tr>
      `}case"decoy":{const i=t.decoysDeployed,s=t.decoysCarried,r=t.missilesSeducedByDecoy;return`
        <tr>
          <td>${e}</td>
          <td>${i}/${s} deployed</td>
          <td>${r} missiles seduced</td>
          <td>-</td>
        </tr>
      `}default:{const i=t.shotsFired,s=t.shotsOnTarget,r=i>0?Math.round(s/i*100):0,o=t.ammoCarried>0?`/${t.ammoCarried}`:"";return`
        <tr>
          <td>${e}</td>
          <td>${i}${o} fired</td>
          <td>${s} hit (${r}%)</td>
          <td class="damage">${n}</td>
        </tr>
      `}}}function lD(t){const e=t.isKIA?"kia":"survived",n=t.isKIA?"KIA":"Survived",i=t.hullMax>0?Math.round(t.hullRemaining/t.hullMax*100):0,s=t.weaponStats.filter(h=>h.category==="beam"),r=t.weaponStats.filter(h=>h.category==="projectile"),o=t.weaponStats.filter(h=>h.category==="missile"),a=t.weaponStats.filter(h=>h.category==="decoy"),c=[...r,...s,...o,...a],l=c.length>0?c.map(h=>cD(h)).join(""):'<tr><td colspan="4" class="no-weapons">No weapons used</td></tr>',u=t.timeOfDeath!==null?`<span class="time-of-death">@ ${_v(t.timeOfDeath)}</span>`:"",d=t.isKIA?"kia":"",f=Qa(t.archetype);return`
    <div class="pilot-card ${t.isPlayer?"player":"wingman"} ${d}">
      <div class="pilot-header">
        <div class="pilot-info">
          <span class="callsign">${t.callsign}</span>
          <span class="archetype">
            <img src="${f}" alt="${t.archetype}" class="debrief-ship-icon" ${ec()} />
            ${t.archetype}
          </span>
        </div>
        <div class="pilot-status ${e}">
          ${n} ${u}
        </div>
      </div>

      <div class="stat-grid pilot-stats">
        <div class="stat">
          <span class="stat-value">${t.kills}</span>
          <span class="stat-label">Kills</span>
        </div>
        <div class="stat">
          <span class="stat-value">${t.assists}</span>
          <span class="stat-label">Assists</span>
        </div>
        <div class="stat">
          <span class="stat-value">${Math.round(t.damageDealt)}</span>
          <span class="stat-label">Damage</span>
        </div>
        <div class="stat">
          <span class="stat-value ${t.isKIA?"destroyed":""}">${t.isKIA?"0":i}%</span>
          <span class="stat-label">Hull</span>
        </div>
      </div>

      <div class="weapon-breakdown">
        <table>
          <thead>
            <tr>
              <th>Weapon</th>
              <th>Usage</th>
              <th>Accuracy</th>
              <th>Damage</th>
            </tr>
          </thead>
          <tbody>
            ${l}
          </tbody>
        </table>
      </div>
    </div>
  `}function uD(t){const e=t.pilots.map(n=>lD(n)).join("");return`
    <div class="debrief-section">
      <div class="debrief-header">
        <h2>Combat Debrief</h2>
        <div class="mission-time">Mission Duration: ${_v(t.missionDuration)}</div>
      </div>
      <div class="pilot-cards">
        ${e}
      </div>
    </div>
  `}function dD(t){if(!t)return`
      <div class="rewards-salvage">
        <div class="rewards-section-header">
          <span class="rewards-section-icon" aria-hidden="true">◈</span>
          <span class="rewards-section-title">SALVAGE</span>
        </div>
        <div class="salvage-empty">No salvage collected</div>
      </div>
    `;const e=Object.entries(t.scrap),n=e.length>0,i=t.weapons.length>0,s=t.ammo.length>0;if(!n&&!i&&!s)return`
      <div class="rewards-salvage">
        <div class="rewards-section-header">
          <span class="rewards-section-icon" aria-hidden="true">◈</span>
          <span class="rewards-section-title">SALVAGE</span>
        </div>
        <div class="salvage-empty">No salvage collected</div>
      </div>
    `;const r=n?`
      <div class="salvage-category">
        <h3>Scrap</h3>
        ${e.map(([l,u])=>`
          <div class="salvage-item">
            <span class="item-name">${l.charAt(0).toUpperCase()+l.slice(1)} Scrap</span>
            <span class="item-count">×${u}</span>
          </div>
        `).join("")}
      </div>
    `:"",o=i?`
      <div class="salvage-category">
        <h3>Weapons</h3>
        ${t.weapons.map(l=>`
          <div class="salvage-item">
            <span class="item-name">${gd(l.weaponType)}</span>
            <span class="item-category">${l.category}</span>
            ${l.count>1?`<span class="item-count">×${l.count}</span>`:""}
          </div>
        `).join("")}
      </div>
    `:"",a=s?`
      <div class="salvage-category">
        <h3>Ammo</h3>
        ${t.ammo.map(l=>`
          <div class="salvage-item">
            <span class="item-name">${es(l.weaponType)}</span>
            <span class="item-count">×${l.count}</span>
          </div>
        `).join("")}
      </div>
    `:"";return`
    <div class="rewards-salvage">
      <div class="rewards-section-header">
        <span class="rewards-section-icon" aria-hidden="true">◈</span>
        <span class="rewards-section-title">SALVAGE</span>
        <span class="rewards-section-value">Est. Value: ~${Math.floor(t.totalValue).toLocaleString()} cr</span>
      </div>
      <div class="salvage-items">
        ${r}
        ${o}
        ${a}
      </div>
    </div>
  `}function fD(t,e,n){return`
    <nav class="results-tab-bar" role="navigation" aria-label="Results navigation">
      <div class="results-tabs-group" role="tablist" aria-label="Results sections">
        ${[{id:"debrief",label:"DEBRIEF",icon:"◆"},{id:"rewards",label:"REWARDS",icon:"★"}].map(r=>`
      <button
        class="results-tab ${t===r.id?"active":""}"
        data-tab="${r.id}"
        role="tab"
        aria-selected="${t===r.id}"
        tabindex="${t===r.id?"0":"-1"}"
      >
        <span class="results-tab-icon" aria-hidden="true">${r.icon}</span>
        <span class="results-tab-label">${r.label}</span>
      </button>
    `).join("")}
      </div>
      <div class="results-status" role="status" aria-label="Player status">
        <div class="results-status-item">
          <span class="results-status-label">SECTOR</span>
          <span class="results-status-value">${n}</span>
        </div>
        <div class="results-status-item">
          <span class="results-status-label">CREDITS</span>
          <span class="results-status-value results-credits">${e.toLocaleString()}</span>
        </div>
      </div>
    </nav>
  `}function hD(t,e,n){const i=t?"victory":"defeat",s=t?"VICTORY":"DEFEAT",r=t&&e?e.reward:0,o=e?`
      <div class="rewards-contract">
        <div class="rewards-section-header">
          <span class="rewards-section-icon" aria-hidden="true">▶</span>
          <span class="rewards-section-title">CONTRACT REWARD</span>
        </div>
        <div class="rewards-contract-details">
          <div class="rewards-contract-name">${e.name}</div>
          <div class="rewards-contract-amount ${t?"earned":"failed"}">
            ${t?`+${r.toLocaleString()} cr`:"Mission Failed"}
          </div>
        </div>
      </div>
    `:"",a=dD(n);return`
    <div class="rewards-content">
      <div class="rewards-title ${i}">${s}</div>
      ${o}
      ${a}
    </div>
  `}const pD={render(t,e){const{victory:n,contract:i,campaignState:s,debriefData:r,salvage:o}=e,a=fD(t.selectedTab,s.credits,s.currentSector),c=t.selectedTab==="debrief"?r?uD(r):'<div class="empty-state-panel">No debrief data available</div>':hD(n,i,o);return`
      <div class="results-screen">
        ${a}
        <main class="results-main" aria-label="Mission results">
          <div class="results-content-scroll">
            ${c}
          </div>
        </main>
        <footer class="results-footer">
          <button class="btn btn-xl btn-primary" id="btn-continue">
            ${n?"Return to Hangar":"Continue"}
          </button>
        </footer>
      </div>
    `},bind(t,e){t.on("#btn-continue","click",()=>{e.onContinue()}),t.on(".results-tab","click",(n,i)=>{const s=i.dataset.tab;if(s){const r=t.getState();s!==r.selectedTab&&t.setState({selectedTab:s})}})}};let ia=null;function mD(t,e,n,i,s,r,o){ia==null||ia.destroy();const a=r?aD(r):null;return ia=Fi(pD,t,{selectedTab:"debrief"},{victory:e,contract:n,campaignState:i,debriefData:a,salvage:o??null,onContinue:s}),{element:t,onContinue:s,selectedTab:"debrief"}}const gD={render(t,e){const{campaignState:n}=e;return`
      <div class="results-screen game-over-screen">
        <div class="game-over-content">
          <h1 class="game-over-title">GAME OVER</h1>
          <div class="game-over-stats">
            <div class="game-over-message">Your ship was destroyed.</div>
            <div class="game-over-stat">
              <span class="stat-label">Final Credits</span>
              <span class="stat-value">${n.credits.toLocaleString()}</span>
            </div>
            <div class="game-over-stat">
              <span class="stat-label">Missions Completed</span>
              <span class="stat-value">${n.missionCount}</span>
            </div>
            <div class="game-over-stat">
              <span class="stat-label">Sector Reached</span>
              <span class="stat-value">${n.currentSector}</span>
            </div>
          </div>
          <button class="btn btn-xl btn-danger" id="btn-restart">
            Start New Campaign
          </button>
        </div>
      </div>
    `},bind(t,e){t.on("#btn-restart","click",()=>{e.onRestart()})}};let sa=null;function vD(t,e,n){sa==null||sa.destroy(),sa=Fi(gD,t,{_placeholder:!0},{campaignState:e,onRestart:n})}function yD(t,e){const n=e.x-t.x,i=e.y-t.y,s=Math.abs(n),r=Math.abs(i);if(s<2&&r<2)return[t,e];if(s<2)return[t,e];if(r<2)return[t,e];const o=[t];if(r>=s){const a=r-s;if(a>2){const c=t.y+Math.sign(i)*a;o.push({x:t.x,y:c})}o.push(e)}else{const a=r,c=t.x+Math.sign(n)*a;o.push({x:c,y:e.y}),o.push(e)}return o}function SD(t){return t.map((e,n)=>`${n===0?"M":"L"} ${e.x.toFixed(1)} ${e.y.toFixed(1)}`).join(" ")}function _D(t,e,n){const i=t.getBoundingClientRect(),s=e.getBoundingClientRect(),r=i.left+i.width/2-s.left,o=n==="primary"?i.bottom-s.top:i.top-s.top;return{x:r,y:o}}function xD(t,e,n,i){const s=t.getBoundingClientRect(),r=e.getBoundingClientRect(),o=1,a=s.width/s.height;let c,l,u,d;a>o?(l=s.height,c=s.height*o,u=(s.width-c)/2,d=0):(c=s.width,l=s.width/o,u=0,d=(s.height-l)/2);const f=s.left+u+c*(n/100)-r.left,h=s.top+d+l*(i/100)-r.top;return{x:f,y:h}}function bD(t){const e=[],n=t.getBoundingClientRect(),i=t.querySelectorAll(".schematic-slot");for(const s of i){const r=s.getBoundingClientRect();e.push({x:r.left-n.left,y:r.top-n.top,width:r.width,height:r.height})}return e}function MD(t){var s,r;const e=[],n=t.querySelector(".ship-icon-svg");if(!n)return e;const i=t.querySelectorAll(".schematic-slot");for(const o of i){const a=o.getAttribute("data-type"),c=(s=o.getAttribute("style"))==null?void 0:s.match(/--svg-x:\s*([\d.]+)%/),l=(r=o.getAttribute("style"))==null?void 0:r.match(/--svg-y:\s*([\d.]+)%/);if(!a||!(c!=null&&c[1])||!(l!=null&&l[1]))continue;const u=parseFloat(c[1]),d=parseFloat(l[1]),f=_D(o,t,a),h=xD(n,t,u,d),p=o.classList.contains("filled"),v=yD(f,h);e.push({points:v,slotType:a,filled:p})}return e}let Pp=0;function xv(t,e,n,i){const s=t.map(r=>`<rect x="${r.x}" y="${r.y}" width="${r.width}" height="${r.height}" fill="black" />`).join(`
`);return`
    <mask id="${i}">
      <rect x="0" y="0" width="${e}" height="${n}" fill="white" />
      ${s}
    </mask>
  `}function bv(t){return t.map(e=>{const n=SD(e.points),i=e.slotType==="primary"?"connector-primary":"connector-secondary",s=e.filled?"filled":"";return`<path d="${n}" class="connector-line ${i} ${s}" />`}).join(`
`)}function ED(t,e,n,i,s){const r=bv(t),o=xv(e,n,i,s);return`
    <svg class="connector-overlay" viewBox="0 0 ${n} ${i}" preserveAspectRatio="none" data-mask-id="${s}">
      <defs>${o}</defs>
      <g mask="url(#${s})">
        ${r}
      </g>
    </svg>
  `}function Lp(t){const e=t.querySelector(".schematic-diagram");if(!e)return;const n=e.getBoundingClientRect();if(n.width===0||n.height===0)return;const i=MD(e),s=bD(e);let r=e.querySelector(".connector-overlay");if(r){const o=r.dataset.maskId??`slot-mask-${++Pp}`;r.setAttribute("viewBox",`0 0 ${n.width} ${n.height}`);const a=bv(i),c=xv(s,n.width,n.height,o);r.innerHTML=`<defs>${c}</defs><g mask="url(#${o})">${a}</g>`}else{const o=`slot-mask-${++Pp}`,a=document.createElement("div");a.innerHTML=ED(i,s,n.width,n.height,o),r=a.firstElementChild,r&&e.appendChild(r)}}const Fu=new WeakMap;function Mv(t){Ev(t);const e=t.querySelector(".schematic-diagram");if(!e)return;Lp(t);const n=new ResizeObserver(()=>{Lp(t)});n.observe(e),Fu.set(t,n)}function Ev(t){const e=Fu.get(t);e&&(e.disconnect(),Fu.delete(t));const n=t.querySelector(".connector-overlay");n&&n.remove()}function wD(t){return t.ships.filter(e=>e.pilot===null)}function TD(t){const e=new Map;for(let n=0;n<t.length;n++){const i=t[n];if(!i)continue;const s=e.get(i.shipClass);s?s.count++:e.set(i.shipClass,{firstIndex:n,count:1})}return[...e.entries()].map(([n,i])=>({shipClass:n,...i}))}function Dp(t,e){const n=t.id===e.commanderId,i=e.ships.some(f=>{var h;return((h=f.pilot)==null?void 0:h.id)===t.id}),s=e.ships.find(f=>{var h;return((h=f.pilot)==null?void 0:h.id)===t.id}),r=wD(e),o=n?"PLAYER":t.skill.toUpperCase(),a=i&&s?`
        <div class="pilot-unassign-section">
          <button class="btn btn-large btn-danger btn-unassign-pilot"
                  data-pilot="${t.id}"
                  data-ship="${s.id}">
            Unassign Pilot
          </button>
        </div>
      `:"",c=!i&&r.length>0?`
        <div class="pilot-assignment">
          <div class="assignment-label">Assign to ship</div>
          <div class="assignment-options">
            ${r.map(f=>`
              <button class="btn btn-assign-pilot"
                      data-pilot="${t.id}"
                      data-ship="${f.id}">
                ${f.shipClass}
              </button>
            `).join("")}
          </div>
        </div>
      `:"",l=TD(e.storedShips),u=!i&&e.storedShips.length>0?`
        <div class="pilot-assignment">
          <div class="assignment-label">Assign to stored ship</div>
          <div class="stored-ship-options">
            ${l.map(f=>{const h=Qa(f.shipClass),p=f.count>1?`<span class="stored-ship-card-count">×${f.count}</span>`:"";return`
              <button class="stored-ship-card-btn"
                      data-pilot="${t.id}"
                      data-stored-ship-index="${f.firstIndex}">
                <div class="stored-ship-card-icon">
                  <img src="${h}" alt="${f.shipClass}" class="stored-ship-icon-svg" ${ec()} />
                </div>
                <div class="stored-ship-card-name">${f.shipClass}${p}</div>
              </button>
            `}).join("")}
          </div>
        </div>
      `:"",d=!i&&r.length===0&&e.storedShips.length===0?`
        <div class="no-ships-section">
          <div class="no-ships-message">No available ships for this pilot</div>
          <button class="btn btn-go-to-store" data-section="ships">Buy Ship in Store</button>
        </div>
      `:"";return`
    <div class="pilot-viewer">
      <div class="pilot-viewer-header">
        <div class="pilot-header-info">
          <div class="pilot-viewer-name">${t.name}</div>
          <div class="pilot-rank">${o}</div>
        </div>
      </div>

      <div class="stat-grid pilot-viewer-stats">
        <div class="stat">
          <span class="stat-value">${t.missionsFlown}</span>
          <span class="stat-label">Missions</span>
        </div>
        <div class="stat">
          <span class="stat-value">${t.missionsWon}</span>
          <span class="stat-label">Victories</span>
        </div>
        <div class="stat">
          <span class="stat-value">${t.kills}</span>
          <span class="stat-label">Kills</span>
        </div>
        <div class="stat">
          <span class="stat-value">${t.assists}</span>
          <span class="stat-label">Assists</span>
        </div>
        <div class="stat">
          <span class="stat-value">${t.damageDealt.toLocaleString()}</span>
          <span class="stat-label">Dmg Dealt</span>
        </div>
        <div class="stat">
          <span class="stat-value">${t.damageReceived.toLocaleString()}</span>
          <span class="stat-label">Dmg Recv</span>
        </div>
      </div>

      ${a}
      ${c}
      ${u}
      ${d}
    </div>
  `}function AD(t){switch(t){case"rookie":return"New to combat. Lower accuracy and slower reactions, but eager to prove themselves.";case"regular":return"Competent pilot with solid fundamentals. Reliable in standard engagements.";case"veteran":return"Battle-hardened with excellent situational awareness. Rarely misses a shot.";case"ace":return"Elite combatant with exceptional skills. Deadly accurate with lightning reflexes.";case"elite":return"Legendary pilot. Masters of evasion and precision. Worth every credit.";default:return"Standard combat training."}}function RD(t,e){const n=e.credits>=t.price;return`
    <div class="recruit-viewer">
      <div class="recruit-viewer-header">
        <div class="recruit-header-info">
          <div class="recruit-viewer-name">${t.name}</div>
          <div class="recruit-rank">${t.skill.toUpperCase()}</div>
        </div>
      </div>

      <div class="recruit-description">
        <div class="recruit-description-title">Profile</div>
        <div class="recruit-description-text">${AD(t.skill)}</div>
      </div>

      <div class="recruit-hire-section">
        <div class="recruit-price-large${n?"":" expensive"}">
          ${t.price.toLocaleString()}<span class="currency">cr</span>
        </div>
        <button
          class="btn btn-large btn-success btn-hire-pilot"
          id="btn-hire-recruit"
          data-recruit-id="${t.id}"
          ${n?"":"disabled"}
        >
          Hire Pilot
        </button>
      </div>
    </div>
  `}function CD(t,e,n){const i=t.ships.find(d=>d.id===e),s=t.storedShips[n];if(!i||!s||!i.pilot)return t;const{primaryWeapons:r,secondaryWeapons:o}=Xg(s.shipClass),a={id:s.id,shipClass:s.shipClass,primaryWeapons:r,secondaryWeapons:o,pilot:i.pilot,hullDamage:s.hullDamage},c={id:i.id,shipClass:i.shipClass,hullDamage:i.hullDamage},{storedWeapons:l,storedAmmo:u}=Cd(i,t.storedWeapons,t.storedAmmo);return{...t,ships:t.ships.map(d=>d.id===e?a:d),storedShips:[...t.storedShips.filter((d,f)=>f!==n),c],storedWeapons:l,storedAmmo:u}}function PD(t,e,n){const i=t.pilots.find(l=>l.id===e),s=t.storedShips[n];if(!i||!s||t.ships.find(l=>{var u;return((u=l.pilot)==null?void 0:u.id)===e}))return t;const{primaryWeapons:o,secondaryWeapons:a}=Xg(s.shipClass),c={id:s.id,shipClass:s.shipClass,primaryWeapons:o,secondaryWeapons:a,pilot:i,hullDamage:s.hullDamage};return{...t,ships:[...t.ships,c],storedShips:t.storedShips.filter((l,u)=>u!==n)}}function LD(t,e,n){const i=t.pilots.find(o=>o.id===e),s=t.ships.find(o=>o.id===n);return!i||!s||t.ships.find(o=>{var a;return((a=o.pilot)==null?void 0:a.id)===e})||s.pilot?t:{...t,ships:t.ships.map(o=>o.id===n?{...o,pilot:i}:o)}}function DD(t,e,n){const i=t.pilots.find(u=>u.id===e),s=t.ships.find(u=>{var d;return((d=u.pilot)==null?void 0:d.id)===e}),r=t.ships.find(u=>u.id===n);if(!i||!s||!r||r.pilot!==null)return t;const o={id:s.id,shipClass:s.shipClass,hullDamage:s.hullDamage},{storedWeapons:a,storedAmmo:c}=Cd(s,t.storedWeapons,t.storedAmmo),l=t.ships.filter(u=>u.id!==s.id).map(u=>u.id===n?{...u,pilot:i}:u);return{...t,ships:l,storedShips:[...t.storedShips,o],storedWeapons:a,storedAmmo:c}}function wv(t,e){const n=t.ships.find(o=>o.id===e);if(!n||!n.pilot)return t;const i={id:n.id,shipClass:n.shipClass,hullDamage:n.hullDamage},{storedWeapons:s,storedAmmo:r}=Cd(n,t.storedWeapons,t.storedAmmo);return{...t,ships:t.ships.filter(o=>o.id!==e),storedShips:[...t.storedShips,i],storedWeapons:s,storedAmmo:r}}function Tv(t,e,n){const i=t.ships.find(c=>c.id===e);if(!i||n<0||n>=i.primaryWeapons.length)return t;const s=i.primaryWeapons[n];if(!s)return t;const r={weaponType:s.weaponType,category:"primary",count:1},o=i.primaryWeapons.map((c,l)=>l===n?null:c),a=fo(t.storedAmmo,s.weaponType,s.currentAmmo??0);return{...t,ships:t.ships.map(c=>c.id===e?{...c,primaryWeapons:o}:c),storedWeapons:[...t.storedWeapons,r],storedAmmo:a}}function Ou(t,e,n){const i=t.ships.find(a=>a.id===e);if(!i||n<0||n>=i.secondaryWeapons.length)return t;const s=i.secondaryWeapons[n];if(!s)return t;const r=i.secondaryWeapons.map((a,c)=>c===n?null:a),o=uo(t.storedWeapons,s.weaponType,s.count);return{...t,ships:t.ships.map(a=>a.id===e?{...a,secondaryWeapons:r}:a),storedWeapons:o}}function Av(t,e,n,i,s){const r=t.ships.find(f=>f.id===e),o=t.storedWeapons[n];if(!r||!o||o.category!=="primary"||i<0||i>=r.primaryWeapons.length||r.primaryWeapons[i]!==null)return t;let a=t.storedAmmo,c=0;if(Aa(o.weaponType)){const f=yr(o.weaponType,s),h=t.storedAmmo.findIndex(p=>p.weaponType===o.weaponType);if(h>=0&&f>0){const p=t.storedAmmo[h];if(p){const v=Math.min(p.count,f);c=v;const g=p.count-v;a=[...t.storedAmmo],g<=0?a.splice(h,1):a[h]={weaponType:p.weaponType,count:g}}}}const l=Aa(o.weaponType)?{weaponType:o.weaponType,bankSize:s,currentAmmo:c}:{weaponType:o.weaponType,bankSize:s},u=r.primaryWeapons.map((f,h)=>h===i?l:f),d=t.storedWeapons.filter((f,h)=>h!==n);return{...t,ships:t.ships.map(f=>f.id===e?{...f,primaryWeapons:u}:f),storedWeapons:d,storedAmmo:a}}function Rv(t,e,n,i,s,r){const o=t.ships.find(v=>v.id===e),a=t.storedWeapons[n];if(!o||!a||a.category!=="secondary"||i<0||i>=o.secondaryWeapons.length||o.secondaryWeapons[i]!==null)return t;const c=Za(a.weaponType,s),l=Math.min(a.count,c),u=r!==void 0?Math.min(Math.max(1,r),l):l,d=a.count-u,f={weaponType:a.weaponType,bankSize:s,count:u,maxCount:c},h=o.secondaryWeapons.map((v,g)=>g===i?f:v);let p;return d<=0?p=t.storedWeapons.filter((v,g)=>g!==n):p=t.storedWeapons.map((v,g)=>g===n?{weaponType:v.weaponType,category:v.category,count:d}:v),{...t,ships:t.ships.map(v=>v.id===e?{...v,secondaryWeapons:h}:v),storedWeapons:p}}let Ks=null;function ba(){Ks&&(Ks.remove(),Ks=null)}function Ip(t,e,n=1){const i=Qa(t),s=n>1?`<span class="ship-picker-count">×${n}</span>`:"";return`
    <button class="ship-picker-card" ${e}>
      <div class="ship-picker-icon">
        <img src="${i}" alt="${t}" class="ship-picker-svg"
             ${ec()} />
      </div>
      <div class="ship-picker-name">${t}${s}</div>
    </button>
  `}function ID(t){const e=new Map;for(let n=0;n<t.length;n++){const i=t[n];if(!i)continue;const s=e.get(i.shipClass);s?s.count++:e.set(i.shipClass,{firstIndex:n,count:1})}return[...e.entries()].map(([n,i])=>({shipClass:n,...i}))}function ND(t,e){const n=e.ships.filter(r=>r.pilot===null&&r.id!==t),i=e.storedShips,s=[];if(n.length>0){const r=n.map(o=>Ip(o.shipClass,`data-action="swap-to-ship" data-ship-id="${o.id}"`)).join("");s.push(`
      <div class="ship-picker-section">
        <div class="ship-picker-section-label">Available Ships</div>
        <div class="ship-picker-grid">${r}</div>
      </div>
    `)}if(i.length>0){const o=ID(i).map(a=>Ip(a.shipClass,`data-action="swap-to-stored-ship" data-stored-ship-index="${a.firstIndex}"`,a.count)).join("");s.push(`
      <div class="ship-picker-section">
        <div class="ship-picker-section-label">Stored Ships</div>
        <div class="ship-picker-grid">${o}</div>
      </div>
    `)}return n.length===0&&i.length===0&&s.push(`
      <div class="ship-picker-empty">
        No other ships available
      </div>
    `),`
    <div class="ship-picker-content">
      ${s.join("")}
    </div>
    <div class="ship-picker-footer">
      <button class="btn btn-danger ship-picker-unassign" data-action="unassign">
        Unassign Pilot
      </button>
    </div>
  `}function UD(t,e,n,i,s,r){ba();const o=document.createElement("div");o.className="ship-picker",o.innerHTML=ND(n,i);const a=t.getBoundingClientRect();o.style.position="fixed",o.style.zIndex="1000",document.body.appendChild(o),Ks=o;const c=o.getBoundingClientRect(),l=12;let u=a.left+a.width/2-c.width/2,d=a.bottom+8;u+c.width>window.innerWidth-l&&(u=window.innerWidth-c.width-l),u<l&&(u=l),d+c.height>window.innerHeight-l&&(d=a.top-c.height-8),d<l&&(d=l),o.style.left=`${u}px`,o.style.top=`${d}px`,o.querySelectorAll("[data-action]").forEach(h=>{h.addEventListener("click",p=>{p.stopPropagation();const v=p.currentTarget.dataset.action;let g=i;switch(v){case"swap-to-ship":{const m=p.currentTarget.dataset.shipId;m&&(g=DD(i,e,m));break}case"swap-to-stored-ship":{const m=parseInt(p.currentTarget.dataset.storedShipIndex??"-1",10);m>=0&&(g=CD(i,n,m));break}case"unassign":{g=wv(i,n);break}}g!==i&&s(g),ba(),r()})});const f=h=>{Ks&&!Ks.contains(h.target)&&(ba(),document.removeEventListener("click",f))};setTimeout(()=>{document.addEventListener("click",f)},0)}const kD={success:"✓",warning:"!",error:"✕",info:"●"};let kn=null;function FD(){return kn&&document.body.contains(kn)||(kn=document.createElement("div"),kn.className="notification-container",kn.setAttribute("role","alert"),kn.setAttribute("aria-live","polite"),document.body.appendChild(kn)),kn}function Np(t,e={}){const{type:n="info",duration:i=3e3}=e,s=FD(),r=document.createElement("div");r.className=`notification notification-${n}`,r.innerHTML=`
    <span class="notification-icon" aria-hidden="true">${kD[n]}</span>
    <span class="notification-message">${t}</span>
  `,s.appendChild(r),setTimeout(()=>{r.classList.add("exiting"),setTimeout(()=>{r.remove(),s.children.length===0&&(s.remove(),kn=null)},300)},i)}let Is=null;function OD(){return Is||(Is=document.createElement("div"),Is.className="stat-tooltip",Is.style.display="none",document.body.appendChild(Is)),Is}function Cv(){const t=OD();t.style.display="none"}const Up=100;function BD(t){if(t.noFalloff)return`${t.damage}`;const e=Math.round(t.damage/(t.range/Up));return`${t.damage}&nbsp;at&nbsp;${Up}&nbsp;m,<br>${e}&nbsp;at&nbsp;${t.range}&nbsp;m`}function zD(t,e){const n=t.storedAmmo.find(i=>i.weaponType===e);return(n==null?void 0:n.count)??0}function HD(t,e){const n=t.storedWeapons.find(i=>i.category==="secondary"&&i.weaponType===e);return(n==null?void 0:n.count)??0}function GD(t,e,n){for(const i of t.storedWeapons)if(i.category==="primary"&&(i.weaponType!==e||i.count>n))return!0;return!1}function WD(t,e,n){for(const i of t.storedWeapons)if(i.category==="secondary"&&(i.weaponType!==e||i.count>n))return!0;return!1}function Lt(t,e,n=""){return`<div class="popover-stat"><span class="popover-stat-label">${t}</span><span class="popover-stat-value">${e}${n}</span></div>`}const VD=16;function Pv(t,e){return e<=VD?`<div class="ammo-bar segmented">${Array.from({length:e},(s,r)=>`<div class="ammo-segment${r<t?" filled":""}"></div>`).join("")}</div>`:`<div class="ammo-bar"><div class="ammo-bar-fill" style="width: ${e>0?Math.round(t/e*100):0}%"></div></div>`}function Lv(t,e,n,i){const s=bt[t.weaponType];if(!s)return`<div class="popover-header"><div class="popover-title"><span class="manager-name">${gd(t.weaponType)}</span></div></div>`;const r=s.category??"unknown",o=r==="beam",a=s.isPulseBeam===!0,c=s.isInstantBeam===!0,l=o&&!a&&!c,u=a?Math.round(s.damage/(s.pulseInterval??.1)):l?s.damage:Math.round(s.damage/s.fireRate),d=a?"Dmg/pulse":l?"DPS":c?"Dmg/shot":"Damage",f=o?BD(s):`${s.damage}`;let h="";if(Aa(t.weaponType)){const p=t.currentAmmo??0,v=yr(t.weaponType,t.bankSize),m=zD(i,t.weaponType)>0&&p<v,S=p>0;h=`
    <div class="popover-ammo">
      ${Pv(p,v)}
      <div class="ammo-count">${p}<span class="ammo-max">/${v}</span></div>
      <div class="popover-controls">
        <button class="manager-btn" data-action="unload-all" data-label="All" ${S?"":"disabled"}>▼</button>
        <button class="manager-btn" data-action="unload" data-label="−10" ${S?"":"disabled"}>−</button>
        <button class="manager-btn" data-action="load" data-label="+10" ${m?"":"disabled"}>+</button>
        <button class="manager-btn" data-action="load-all" data-label="All" ${m?"":"disabled"}>▲</button>
      </div>
    </div>
    `}return`
    <div class="popover-header popover-header-primary">
      <div class="popover-title">
        <span class="manager-size">${"●".repeat(t.bankSize)}</span>
        <span class="manager-name">${s.name}</span>
      </div>
    </div>
    <div class="popover-stats">
      ${Lt(d,f)}
      ${s.shieldDamageMultiplier&&s.shieldDamageMultiplier!==1?Lt("Shield Dmg",`${Math.round(s.damage*s.shieldDamageMultiplier)} (${s.shieldDamageMultiplier}×)`):""}
      ${s.hullDamageMultiplier&&s.hullDamageMultiplier!==1?Lt("Hull Dmg",`${Math.round(s.damage*s.hullDamageMultiplier)} (${s.hullDamageMultiplier}×)`):""}
      ${Lt("Range",s.range,"m")}
      ${r!=="beam"?Lt("Speed",s.projectileSpeed," m/s"):""}
      ${a?Lt("Pulse rate",`${Math.round(1/(s.pulseInterval??.1))}/s`):""}
      ${c?Lt("Cooldown",`${s.fireRate}s`):""}
      ${r!=="beam"?Lt("Fire rate",`${Math.round(1/s.fireRate)}/s`):""}
      ${Lt("Heat",s.heatPerShot,a?"/pulse":l?"/s":"/shot")}
      ${s.flakRadius?Lt("Blast Radius",s.flakRadius,"m"):""}
      ${!l&&!c?Lt("DPS",`~${u}`):""}
    </div>
    ${h}
    <div class="manager-actions">
      <button class="btn btn-small btn-change-weapon" data-ship="${e}" data-type="primary" data-index="${n}" ${GD(i,t.weaponType,t.bankSize)?"":"disabled"}>
        Change
      </button>
      <button class="btn btn-small btn-unequip" data-ship="${e}" data-type="primary" data-index="${n}">
        Unequip
      </button>
    </div>
  `}function Dv(t,e,n,i){const s=Sn[t.weaponType],o=HD(i,t.weaponType)>0&&t.count<t.maxCount,a=t.count>0;if(!s)return`<div class="popover-header"><div class="popover-title"><span class="manager-name">${Di(t.weaponType)}</span></div></div>`;const c=s.requiresLock?`${(1/s.lockSpeed).toFixed(1)}s`:"None";return`
    <div class="popover-header popover-header-secondary">
      <div class="popover-title">
        <span class="manager-size">${"◆".repeat(t.bankSize)}</span>
        <span class="manager-name">${s.name}</span>
      </div>
    </div>
    <div class="popover-stats">
      ${s.isDecoy?"":Lt("Damage",s.damage)}
      ${Lt("Speed",s.speed," m/s")}
      ${s.turnRate>0?Lt("Tracking",s.turnRate,"°/s"):""}
      ${s.isDecoy?"":Lt("Range",s.range,"m")}
      ${Lt("Lock Time",c)}
      ${s.aoeRadius?Lt("Blast Radius",s.aoeRadius,"m"):""}
    </div>
    <div class="popover-ammo">
      ${Pv(t.count,t.maxCount)}
      <div class="ammo-count">${t.count}<span class="ammo-max">/${t.maxCount}</span></div>
      <div class="popover-controls">
        <button class="manager-btn" data-action="unload-all" data-label="All" ${a?"":"disabled"}>▼</button>
        <button class="manager-btn" data-action="unload" data-label="−1" ${a?"":"disabled"}>−</button>
        <button class="manager-btn" data-action="load" data-label="+1" ${o?"":"disabled"}>+</button>
        <button class="manager-btn" data-action="load-all" data-label="All" ${o?"":"disabled"}>▲</button>
      </div>
    </div>
    <div class="manager-actions">
      <button class="btn btn-small btn-change-weapon" data-ship="${e}" data-type="secondary" data-index="${n}" ${WD(i,t.weaponType,t.count)?"":"disabled"}>
        Change
      </button>
      <button class="btn btn-small btn-unequip" data-ship="${e}" data-type="secondary" data-index="${n}">
        Unequip
      </button>
    </div>
  `}let It=null,lr=!1,nc=!1,sn=null,Vd=null,Ma=null,wi=null;function Iv(t){It=t}function $d(){return Vd}function $D(t){Vd=t}function XD(t){Ma=t}function Bu(){Ma&&(Ma.remove(),Ma=null)}function Nv(){lr=!1,nc=!1,sn&&(clearTimeout(sn),sn=null)}function Ia(t){nc=t,t&&sn&&(clearTimeout(sn),sn=null)}function gn(){sn&&(clearTimeout(sn),sn=null),wi&&(document.removeEventListener("click",wi),wi=null),Bu(),It&&(It.remove(),It=null),lr=!1,nc=!1,Vd=null}function zu(){!It||lr||(lr=!0,It.classList.add("pinned"),wi&&document.removeEventListener("click",wi),wi=t=>{It&&!It.contains(t.target)&&gn()},setTimeout(()=>{wi&&document.addEventListener("click",wi)},0))}function Na(){lr||(sn&&clearTimeout(sn),sn=setTimeout(()=>{!lr&&!nc&&gn(),sn=null},50))}function qD(t,e){const n=$d();if(!n)return;const i=n.querySelector(".slot-ammo-bar");if(!i)return;const{current:s,max:r}=y0(e,t);if(i.classList.contains("segmented"))i.querySelectorAll(".slot-ammo-segment").forEach((a,c)=>{a.classList.toggle("filled",c<s)});else{const o=i.querySelector(".slot-ammo-fill");if(o){const a=r>0?Math.round(s/r*100):0;o.style.width=`${a}%`}}}let Hu=null;function YD(t){Hu=t}function Uv(t,e,n,i,s,r,o){var c;t.querySelectorAll(".manager-btn").forEach(l=>{l.addEventListener("click",u=>{u.stopPropagation();const d=u.currentTarget.dataset.action;if(!d)return;let f=e;if(i==="primary")switch(d){case"load":f=Yh(e,n,s,10);break;case"unload":f=jh(e,n,s,10);break;case"load-all":f=Yh(e,n,s,1/0);break;case"unload-all":f=jh(e,n,s,1/0);break}else switch(d){case"load":f=Xh(e,n,s,1);break;case"unload":f=qh(e,n,s,1);break;case"load-all":f=Xh(e,n,s,1/0);break;case"unload-all":f=qh(e,n,s,1/0);break}if(f!==e){if(i==="secondary"){const p=f.ships.find(g=>g.id===n),v=p==null?void 0:p.secondaryWeapons[s];if(v&&v.count===0){f=Ou(f,n,s),r(f),gn(),o();return}}r(f);const h=f.ships.find(p=>p.id===n);if(h&&It){const p=i==="primary"?h.primaryWeapons[s]:h.secondaryWeapons[s];if(p){const v=i==="primary"?Lv(p,n,s,f):Dv(p,n,s,f),g=It.querySelector(".popover-content");g&&(g.innerHTML=v,Uv(It,f,n,i,s,r,o)),qD(i,p)}}}})});const a=t.querySelector(".btn-change-weapon");a&&a.addEventListener("click",l=>{l.stopPropagation(),zu();const u=$d();Hu&&u&&Hu(l.currentTarget,u,e,n,i,s,r,o)}),(c=t.querySelector(".btn-unequip"))==null||c.addEventListener("click",l=>{l.stopPropagation();const u=i==="primary"?Tv(e,n,s):Ou(e,n,s);u!==e&&r(u),gn(),o()})}function jD(t,e,n,i,s,r,o,a){if($d()===t&&It)return;gn();const c=document.createElement("div");c.className=`weapon-popover weapon-popover-${i}`;const l=i==="primary"?Lv(r,n,s,e):Dv(r,n,s,e);c.innerHTML=`<div class="popover-content">${l}</div>`;const u=t.getBoundingClientRect();c.style.position="fixed",c.style.left=`${u.left}px`,c.style.top=`${u.bottom+4}px`,c.style.zIndex="1000",document.body.appendChild(c),Iv(c),$D(t),Nv(),c.addEventListener("mouseenter",()=>{Ia(!0)}),c.addEventListener("mouseleave",()=>{Ia(!1),Na()});const d=c.getBoundingClientRect(),f=8;if(d.bottom>window.innerHeight-f){const h=u.top-d.height-4;h>=f?c.style.top=`${h}px`:c.style.top=`${f}px`}if(d.right>window.innerWidth-f){const h=window.innerWidth-d.width-f;c.style.left=`${Math.max(f,h)}px`}Uv(c,e,n,i,s,o,a)}function KD(t,e,n){return t.map(i=>{if(i.weaponType===e){const s=i.totalCount-n;return s<=0?null:{...i,totalCount:s}}return i}).filter(i=>i!==null)}function ZD(t){return t.length===0?'<div class="picker-empty">No other weapons available</div>':t.map(e=>{var i;const n=((i=bt[e.weaponType])==null?void 0:i.name)??e.weaponType;return`
        <button class="picker-item" data-weapon-type="${e.weaponType}">
          ${Jr(e.weaponType,{size:"sm",className:"picker-icon"})}
          <span class="picker-name">${n}</span>
          <span class="picker-stock">×${e.totalCount}</span>
        </button>
      `}).join("")}function JD(t,e){return t.length===0?'<div class="picker-empty">No other missiles available</div>':t.map(n=>{var o;const i=((o=Sn[n.weaponType])==null?void 0:o.name)??n.weaponType,s=Za(n.weaponType,e),r=Math.min(n.totalCount,s);return`
        <div class="picker-missile-row" data-weapon-type="${n.weaponType}">
          <div class="picker-missile-info">
            ${Ja(n.weaponType,{size:"sm",className:"picker-icon"})}
            <span class="picker-name">${i}</span>
            <span class="picker-storage">×${n.totalCount}</span>
          </div>
          <div class="picker-quantity">
            <button class="picker-qty-btn" data-action="dec">−</button>
            <span class="picker-qty-value" data-max="${r}">${r}</span>
            <button class="picker-qty-btn" data-action="inc">+</button>
            <button class="picker-equip-btn">Equip</button>
          </div>
        </div>
      `}).join("")}function kp(t,e){return t.storedWeapons.findIndex(n=>n.weaponType===e)}function QD(t,e,n,i,s,r,o,a){Bu(),Cv();const c=n.ships.find(E=>E.id===i);if(!c)return;const l=s==="primary"?c.primaryWeapons[r]:c.secondaryWeapons[r];if(!l)return;const u=l.weaponType,d=s==="primary"?l.bankSize:l.count,f=Fv(n,s),h=KD(f,u,d),p=kv(n,i,s,r),v=document.createElement("div");v.className=`weapon-popover weapon-submenu weapon-popover-${s}`;const g=s==="primary"?ZD(h):JD(h,p);v.innerHTML=`<div class="popover-content picker-content">${g}</div>`;const m=t.getBoundingClientRect(),S=8,_=4;v.style.position="fixed",v.style.left=`${m.left}px`,v.style.top=`${m.bottom+_}px`,v.style.zIndex="1001",document.body.appendChild(v),XD(v);const y=v.getBoundingClientRect();if(y.bottom>window.innerHeight-S){const E=m.top-y.height-_;E>=S?v.style.top=`${E}px`:v.style.top=`${S}px`}if(y.right>window.innerWidth-S){const E=window.innerWidth-y.width-S;v.style.left=`${Math.max(S,E)}px`}s==="primary"?v.querySelectorAll(".picker-item").forEach(E=>{E.addEventListener("click",A=>{A.stopPropagation();const b=A.currentTarget.dataset.weaponType;if(!b)return;const x=kp(n,b);if(x<0)return;let L=Tv(n,i,r);L=Av(L,i,x,r,p),L!==n&&o(L),gn(),a()})}):(v.querySelectorAll(".picker-qty-btn").forEach(E=>{E.addEventListener("click",A=>{A.stopPropagation();const P=A.currentTarget,b=P.dataset.action,x=P.closest(".picker-missile-row"),L=x==null?void 0:x.querySelector(".picker-qty-value");if(!L)return;const B=Number.parseInt(L.dataset.max??"1",10);let F=Number.parseInt(L.textContent??"1",10);b==="inc"&&F<B?F++:b==="dec"&&F>1&&F--,L.textContent=String(F)})}),v.querySelectorAll(".picker-equip-btn").forEach(E=>{E.addEventListener("click",A=>{A.stopPropagation();const P=A.currentTarget.closest(".picker-missile-row");if(!P)return;const b=P.dataset.weaponType,x=P.querySelector(".picker-qty-value"),L=Number.parseInt((x==null?void 0:x.textContent)??"1",10);if(!b)return;const B=kp(n,b);if(B<0)return;let F=Ou(n,i,r);F=Rv(F,i,B,r,p,L),F!==n&&o(F),gn(),a()})}));const D=E=>{const A=E.target;if(!v.contains(A)){if(It!=null&&It.contains(A)){Bu(),document.removeEventListener("click",D);return}gn(),a(),document.removeEventListener("click",D)}};setTimeout(()=>{document.addEventListener("click",D)},0)}function kv(t,e,n,i){const s=t.ships.find(a=>a.id===e);if(!s)return 1;const r=Wt[s.shipClass];return r?(n==="primary"?r.primaryBanks:r.secondaryBanks)[i]??1:1}function Fv(t,e){const n=new Map;return t.storedWeapons.forEach((i,s)=>{if(i.category!==e)return;const r=n.get(i.weaponType);r?r.totalCount+=i.count:n.set(i.weaponType,{weaponType:i.weaponType,category:e,totalCount:i.count,firstIndex:s})}),Array.from(n.values())}function eI(t){return t.length===0?'<div class="picker-empty">No primary weapons in storage</div>':t.map(e=>{var i;const n=((i=bt[e.weaponType])==null?void 0:i.name)??e.weaponType;return`
        <button class="picker-item" data-weapon-type="${e.weaponType}">
          ${Jr(e.weaponType,{size:"sm",className:"picker-icon"})}
          <span class="picker-name">${n}</span>
          <span class="picker-stock">×${e.totalCount}</span>
        </button>
      `}).join("")}function tI(t,e){return t.length===0?'<div class="picker-empty">No missiles in storage</div>':t.map(n=>{var o;const i=((o=Sn[n.weaponType])==null?void 0:o.name)??n.weaponType,s=Za(n.weaponType,e),r=Math.min(n.totalCount,s);return`
        <div class="picker-missile-row" data-weapon-type="${n.weaponType}">
          <div class="picker-missile-info">
            ${Ja(n.weaponType,{size:"sm",className:"picker-icon"})}
            <span class="picker-name">${i}</span>
            <span class="picker-storage">×${n.totalCount}</span>
          </div>
          <div class="picker-quantity">
            <button class="picker-qty-btn" data-action="dec">−</button>
            <span class="picker-qty-value" data-max="${r}">${r}</span>
            <button class="picker-qty-btn" data-action="inc">+</button>
            <button class="picker-equip-btn">Equip</button>
          </div>
        </div>
      `}).join("")}function Ov(t,e){return t.storedWeapons.findIndex(n=>n.weaponType===e)}function nI(t,e,n,i,s,r,o){if(It&&t.contains(It))return;gn(),Cv();const a=Fv(e,i),c=kv(e,n,i,s),l=document.createElement("div");l.className=`weapon-popover weapon-popover-${i}`;const u=i==="primary"?eI(a):tI(a,c);l.innerHTML=`<div class="popover-content picker-content">${u}</div>`;const d=t.getBoundingClientRect();l.style.position="fixed",l.style.left=`${d.left}px`,l.style.top=`${d.bottom+4}px`,l.style.zIndex="1000",document.body.appendChild(l),Iv(l),Nv(),l.addEventListener("mouseenter",()=>{Ia(!0)}),l.addEventListener("mouseleave",()=>{Ia(!1),Na()});const f=l.getBoundingClientRect(),h=8;if(f.bottom>window.innerHeight-h){const p=d.top-f.height-4;p>=h?l.style.top=`${p}px`:l.style.top=`${h}px`}if(f.right>window.innerWidth-h){const p=window.innerWidth-f.width-h;l.style.left=`${Math.max(h,p)}px`}i==="primary"?iI(l,e,n,s,c,r,o):sI(l,e,n,s,c,r,o)}function iI(t,e,n,i,s,r,o){t.querySelectorAll(".picker-item").forEach(a=>{a.addEventListener("click",c=>{c.stopPropagation();const u=c.currentTarget.dataset.weaponType;if(!u)return;const d=Ov(e,u);if(d<0)return;const f=Av(e,n,d,i,s);f!==e&&r(f),gn(),o()})})}function sI(t,e,n,i,s,r,o){t.querySelectorAll(".picker-qty-btn").forEach(a=>{a.addEventListener("click",c=>{c.stopPropagation();const l=c.currentTarget,u=l.dataset.action,d=l.closest(".picker-missile-row"),f=d==null?void 0:d.querySelector(".picker-qty-value");if(!f)return;const h=Number.parseInt(f.dataset.max??"1",10);let p=Number.parseInt(f.textContent??"1",10);u==="inc"&&p<h?p++:u==="dec"&&p>1&&p--,f.textContent=String(p)})}),t.querySelectorAll(".picker-equip-btn").forEach(a=>{a.addEventListener("click",c=>{c.stopPropagation();const l=c.currentTarget.closest(".picker-missile-row");if(!l)return;const u=l.dataset.weaponType,d=l.querySelector(".picker-qty-value"),f=Number.parseInt((d==null?void 0:d.textContent)??"1",10);if(!u)return;const h=Ov(e,u);if(h<0)return;const p=Rv(e,n,h,i,s,f);p!==e&&r(p),gn(),o()})})}let Ri=null;function Fp(){Ri==null||Ri(),Ri=null}function rI(t,e,n){Ri==null||Ri();const i=[],s=(a,c,l)=>{a.addEventListener(c,l),i.push({el:a,event:c,handler:l})};Ri=()=>{for(const{el:a,event:c,handler:l}of i)a.removeEventListener(c,l);i.length=0},YD(QD);const r=a=>{n.onStateUpdate&&n.onStateUpdate(a)},o=()=>e.setState({});t.querySelectorAll(".schematic-slot").forEach(a=>{const c=a,l=c.dataset.type,u=c.dataset.ship,d=Number.parseInt(c.dataset.index??"0",10),f=c.classList.contains("filled");if(!u||!l)return;const h=n.campaignState.ships.find(p=>p.id===u);if(h)if(f){const p=l==="primary"?h.primaryWeapons[d]:h.secondaryWeapons[d];if(!p)return;s(c,"mouseenter",()=>{jD(c,n.campaignState,u,l,d,p,r,o)}),s(c,"click",v=>{v.stopPropagation(),zu()}),s(c,"mouseleave",()=>{Na()})}else s(c,"mouseenter",()=>{nI(c,n.campaignState,u,l,d,r,o)}),s(c,"click",p=>{p.stopPropagation(),zu()}),s(c,"mouseleave",()=>{Na()})})}function Si(t,e,n,i,s){e.onStateUpdate&&e.onStateUpdate(n),(i!==void 0||s!==void 0)&&t.setState({...i!==void 0&&{selection:i},...s!==void 0&&{activeTab:s}})}function oI(t,e,n){const{onNavigate:i}=e;t.on(".ship-item[data-deployed-id]","click",(r,o)=>{const a=o.dataset.deployedId;if(a){const c=t.getState(),u=c.selection.type==="deployed"&&c.selection.id===a?{type:"none",id:null}:{type:"deployed",id:a};gn(),t.setState({selection:u,activeTab:"loadout"})}}),t.on(".ship-item[data-pilot-id]","click",(r,o)=>{const a=o.dataset.pilotId;if(a){const c=t.getState(),u=c.selection.type==="available"&&c.selection.id===a?{type:"none",id:null}:{type:"available",id:a};t.setState({selection:u})}}),t.on(".ship-item[data-recruit-id]","click",(r,o)=>{const a=o.dataset.recruitId;if(a){const c=t.getState(),u=c.selection.type==="recruit"&&c.selection.id===a?{type:"none",id:null}:{type:"recruit",id:a};t.setState({selection:u})}}),t.on(".btn-change-ship","click",(r,o)=>{r.stopPropagation();const a=o.dataset.pilot,c=o.dataset.ship;!a||!c||UD(o,a,c,e.campaignState,l=>{const u=l.ships.find(f=>{var h;return((h=f.pilot)==null?void 0:h.id)===a}),d=u?{type:"deployed",id:u.id}:{type:"available",id:a};Si(t,e,l,d)},()=>t.setState({}))}),t.on(".btn-resupply-ship","click",(r,o)=>{r.stopPropagation();const a=o.dataset.ship;if(!a)return;const c=g0(e.campaignState,a);if(c.state!==e.campaignState){Si(t,e,c.state);const l=c.success?"success":"warning";for(const u of c.messages)Np(u,{type:l})}}),t.on(".btn-resupply-all","click",(r,o)=>{r.stopPropagation();const a=o.dataset.commander;if(!a)return;const c=WR(e.campaignState,a);if(c.state!==e.campaignState){Si(t,e,c.state);const l=c.success?"success":"warning";for(const u of c.messages)Np(u,{type:l})}}),t.on(".btn-assign-pilot","click",(r,o)=>{r.stopPropagation();const a=o.dataset.pilot,c=o.dataset.ship;if(!a||!c)return;const l=LD(e.campaignState,a,c);l!==e.campaignState&&Si(t,e,l,{type:"deployed",id:c},"loadout")}),t.on(".stored-ship-card-btn","click",(r,o)=>{r.stopPropagation();const a=o.dataset.pilot,c=Number.parseInt(o.dataset.storedShipIndex??"0",10);if(!a)return;const l=PD(e.campaignState,a,c);if(l!==e.campaignState){const u=l.ships.find(d=>{var f;return((f=d.pilot)==null?void 0:f.id)===a});u?Si(t,e,l,{type:"deployed",id:u.id},"loadout"):Si(t,e,l)}}),t.on("#btn-hire-recruit","click",(r,o)=>{const a=o.dataset.recruitId;if(!a)return;const c=e.campaignState.availableRecruits.find(d=>d.id===a);if(!c)return;const l=c.name,u=DA(e.campaignState,a);if(u!==e.campaignState){const d=u.pilots.find(h=>h.name===l),f=d?{type:"available",id:d.id}:{type:"none",id:null};Si(t,e,u,f)}}),t.on(".btn-go-to-store","click",()=>{i("store")}),t.on(".btn-unassign-pilot","click",(r,o)=>{r.stopPropagation();const a=o.dataset.pilot,c=o.dataset.ship;if(!a||!c)return;const l=wv(e.campaignState,c);l!==e.campaignState&&Si(t,e,l,{type:"available",id:a})}),rI(n,t,e);const s=12;t.on(".weapon-badge","mouseenter",(r,o)=>{const a=o.querySelector(".weapon-tooltip");if(!a)return;const c=o.getBoundingClientRect();a.style.top=`${c.top+c.height/2}px`,a.style.left=`${c.right+s}px`,a.style.transform="translateY(-50%)"})}function aI(t){const e=OR(t);return e.length===0?"":`
    <span class="ship-item-warning" aria-label="Needs attention">!</span>
    <div class="warning-tooltip">${e.map(i=>`<div class="warning-tooltip-line">${i}</div>`).join("")}</div>
  `}function cI(t,e,n){const i=kd(t);return E0({ship:t,isCommander:n,isSelected:e,extraClasses:`deployed ${i?"has-warning":""}`,dataAttrs:{"deployed-id":t.id},iconContent:i?aI(t):"",afterContent:JC(t)})}function lI(t,e,n){return`
    <article
      class="ship-item available ${e?"selected":""} ${n?"commander":""}"
      data-pilot-id="${t.id}"
      role="option"
      aria-selected="${e}"
      tabindex="0"
      aria-label="${t.name}, available"
    >
      <div class="ship-item-icon">
        <img src="${Bd()}" alt="No ship" class="ship-item-img ship-item-img-empty" />
      </div>
      <div class="ship-item-info">
        <div class="ship-item-name-row">
          <span class="ship-item-pilot">${n?'<span class="commander-star" aria-label="Commander">★</span>':""}${t.name}</span>
        </div>
        <span class="ship-item-status">Available</span>
      </div>
    </article>
  `}function uI(t,e,n){const i=e?"selected":"",s=n?"":"unaffordable",r=t.skill.toLowerCase();return`
    <article
      class="ship-item recruit ${i} ${s}"
      data-recruit-id="${t.id}"
      role="option"
      aria-selected="${e}"
      tabindex="0"
      aria-label="${t.name}, ${t.skill} pilot, ${t.price} credits${n?"":", cannot afford"}"
    >
      <div class="ship-item-info recruit-info">
        <div class="ship-item-name-row">
          <span class="ship-item-pilot">${t.name}</span>
        </div>
        <span class="ship-item-status ${r}">${t.skill}</span>
      </div>
      <div class="ship-item-price">${t.price} cr</div>
    </article>
  `}function dI(t,e,n,i,s,r,o){const a=t.filter(m=>m.pilot!==null),c=a.map(m=>{var y;const S=r.type==="deployed"&&r.id===m.id,_=((y=m.pilot)==null?void 0:y.id)===i;return cI(m,S,_)}).join(""),l=new Set;for(const m of t)m.pilot&&l.add(m.pilot.id);const u=e.filter(m=>!l.has(m.id)),d=u.map(m=>{const S=r.type==="available"&&r.id===m.id,_=m.id===i;return lI(m,S,_)}).join(""),f=n.map(m=>{const S=r.type==="recruit"&&r.id===m.id,_=s>=m.price;return uI(m,S,_)}).join("");let h="";if(o!=null&&o.showResupplyAll&&o.commanderId){const m=o.resupplyAllCost&&o.resupplyAllCost>0?` (${o.resupplyAllCost} cr)`:"";h=`<div class="squadron-resupply-toolbar">
        <button class="btn btn-small btn-resupply-all" data-commander="${o.commanderId}">
          Resupply All${m}
        </button>
      </div>`}const p=a.length>0?`
        <div class="squadron-section">
          <header class="panel-header">
            <span class="panel-icon" aria-hidden="true">◈</span>
            <span class="panel-title">Deployed</span>
            <span class="panel-count" aria-label="${a.length} deployed">${a.length}</span>
          </header>
          ${h}
          <div class="squadron-items" role="listbox" aria-label="Deployed pilots">
            ${c}
          </div>
        </div>
      `:"",v=u.length>0?`
        <div class="squadron-section">
          <header class="panel-header available-header">
            <span class="panel-icon" aria-hidden="true">★</span>
            <span class="panel-title">Available</span>
            <span class="panel-count" aria-label="${u.length} available">${u.length}</span>
          </header>
          <div class="squadron-items" role="listbox" aria-label="Available pilots">
            ${d}
          </div>
        </div>
      `:"",g=n.length>0?`
        <div class="squadron-section">
          <header class="panel-header recruits-header">
            <span class="panel-icon" aria-hidden="true">+</span>
            <span class="panel-title">Recruits</span>
            <span class="panel-count" aria-label="${n.length} recruits">${n.length}</span>
          </header>
          <div class="squadron-items" role="listbox" aria-label="Available recruits">
            ${f||'<div class="no-recruits">No recruits available</div>'}
          </div>
        </div>
      `:"";return`
    <aside class="squadron-list" aria-label="Squadron list">
      ${p}
      ${v}
      ${g}
    </aside>
  `}function Ua(t,e,n="●"){const i=new Map;for(const r of t)i.set(r,(i.get(r)??0)+1);return[...i.entries()].sort((r,o)=>o[0]-r[0]).map(([r,o])=>`${`<span class="${e}">${n.repeat(r)}</span>`} ×${o}`).join(", ")}function Bv(t,e={}){const n=Wt[t.toLowerCase()];if(!n)return"";const{classPrefix:i="stat"}=e,s=Ua(n.primaryBanks,"bank-dots-primary","●"),r=Ua(n.secondaryBanks,"bank-dots-secondary","◆"),o=`${i}-row`,a=i==="detail"?"detail-label":"",c=i==="detail"?"detail-value":"",l=(u,d)=>i==="detail"?`
        <div class="${o}">
          <span class="${a}">${u}</span>
          <span class="${c}">${d}</span>
        </div>`:`<div class="${o}"><span>${u}</span><span>${d}</span></div>`;return`
    ${l("Hull",`${n.hull}`)}
    ${l("Shields",`${n.shields} (+${n.shieldRegen}/s)`)}
    ${l("Speed",`${n.maxSpeed} m/s`)}
    ${l("Turn rate",`${n.turnRate}°/s`)}
    ${l("Acceleration",`${n.acceleration} m/s²`)}
    ${l("Primary banks",s)}
    ${l("Secondary banks",r)}
    ${l("Heat capacity",`${n.maxHeat}`)}
    ${l("Cooling rate",`${n.coolingRate}/s`)}
  `}function fI(t,e){return[...t].sort((n,i)=>{var o,a;const s=((o=n.pilot)==null?void 0:o.id)===e,r=((a=i.pilot)==null?void 0:a.id)===e;return s&&!r?-1:!s&&r?1:0})}function hI(t){return t.some(e=>m0(e))}function pI(t){const e=Bv(t.shipClass,{classPrefix:"detail"});return e?`
    <div class="ship-details">
      <div class="ship-details-header">
        <span class="panel-icon">▦</span> Ship Stats
      </div>
      <div class="ship-details-stats">
        ${e}
      </div>
    </div>
  `:'<div class="ship-details">Unknown ship class</div>'}function mI(t,e){let n=KC(t,e);const i=m0(t);let s="";if(i){const o=HR(e,t.id),a=o.cost>0?` (${o.cost} cr)`:"";s=`<button class="btn btn-small btn-resupply-ship" data-ship="${t.id}">Resupply${a}</button>`}const r=t.pilot?`<div class="schematic-header-right">
        ${s}
        <button class="btn btn-small btn-change-ship" data-pilot="${t.pilot.id}" data-ship="${t.id}">Change Ship</button>
       </div>`:"";return n=n.replace('<div class="schematic-header-right"></div>',r),n}function gI(t){return`
    <div class="viewer-tabs" role="tablist" aria-label="View mode">
      <button
        class="viewer-tab ${t==="loadout"?"active":""}"
        data-tab="loadout"
        role="tab"
        aria-selected="${t==="loadout"}"
        aria-controls="viewer-content"
        tabindex="${t==="loadout"?"0":"-1"}"
      >
        <span class="viewer-tab-icon" aria-hidden="true">◈</span>
        <span class="viewer-tab-label">Loadout</span>
      </button>
      <button
        class="viewer-tab ${t==="pilot"?"active":""}"
        data-tab="pilot"
        role="tab"
        aria-selected="${t==="pilot"}"
        aria-controls="viewer-content"
        tabindex="${t==="pilot"?"0":"-1"}"
      >
        <span class="viewer-tab-icon" aria-hidden="true">★</span>
        <span class="viewer-tab-label">Pilot</span>
      </button>
    </div>
  `}function vI(t,e,n,i,s){const r=t.pilot;if(!r)return`
      <div class="empty-state-panel" role="status">
        No pilot assigned to this ship
      </div>
    `;const o=gI(n),a=n==="loadout"?i(t,e):s(r,e);return`
    <section class="squadron-viewer tabbed" aria-label="Ship and pilot details">
      ${o}
      <div class="viewer-content" id="viewer-content" role="tabpanel">
        ${a}
      </div>
    </section>
  `}let Ci=null;function Op(){Ci==null||Ci(),Ci=null}function yI(t,e){Ci==null||Ci();const n=[];t.querySelectorAll(".viewer-tab").forEach(i=>{const s=()=>{const r=i.dataset.tab;r&&e(r)};i.addEventListener("click",s),n.push({el:i,event:"click",handler:s})}),Ci=()=>{for(const{el:i,event:s,handler:r}of n)i.removeEventListener(s,r);n.length=0}}function SI(t,e,n,i){const s=fI(n.ships,n.commanderId),r=t.type==="deployed"||t.type==="ship"?n.ships.find(v=>v.id===t.id):null,o=t.type==="available"?n.pilots.find(v=>v.id===t.id):null,a=t.type==="recruit"?n.availableRecruits.find(v=>v.id===t.id):null,c=Id({activeTab:"squadron",credits:n.credits,sector:n.currentSector}),l=hI(n.ships),u=l?GR(n):null,d=dI(s,n.pilots,n.availableRecruits,n.commanderId,n.credits,t,{showResupplyAll:l,...(u==null?void 0:u.cost)!==void 0&&{resupplyAllCost:u.cost},commanderId:n.commanderId});let f;t.type==="deployed"&&r?f=vI(r,n,e,mI,Dp):t.type==="available"&&o?f=`
      <section class="squadron-viewer" aria-label="Pilot details">
        ${Dp(o,n)}
      </section>
    `:t.type==="recruit"&&a?f=`
      <section class="squadron-viewer" aria-label="Recruit details">
        ${RD(a,n)}
      </section>
    `:f=`
      <div class="empty-state-panel" role="status" aria-label="No selection">
        Select a pilot or ship to view details
      </div>
    `;const p=t.type==="deployed"&&r?`<aside class="squadron-details" aria-label="Ship statistics">${pI(r)}</aside>`:'<div class="squadron-details-placeholder" aria-hidden="true"></div>';return`
    <div class="campaign-page">
      ${c}
      <main class="squadron-screen" aria-label="Squadron - Pilot and ship management">
        <div class="squadron-layout">
          <!-- Left Column: Unified List -->
          ${d}

          <!-- Center Column: Viewer -->
          ${f}

          <!-- Right Column: Ship Details -->
          ${p}
        </div>
      </main>
    </div>
  `}const _I={render(t,e){return ba(),SI(t.selection,t.activeTab,e.campaignState,e.onNavigate)},bind(t,e){const n=t.getRoot(),{onNavigate:i}=e,s=n.querySelector(".ship-viewer");s&&Ev(s);const r=n.querySelector(".ship-viewer");r&&Mv(r),Nd(n,i),yI(n,o=>{t.setState({activeTab:o})}),oI(t,e,n)}};let Jt=null;function xI(t,e,n,i,s){Fp(),Op(),Jt==null||Jt.destroy();const r={selection:{type:"none",id:null},activeTab:"loadout"};let o;o={campaignState:e,onNavigate:n,onStateUpdate:i?l=>{i(l),o={...o,campaignState:l},Jt==null||Jt.setProps(o)}:void 0},Jt=Fi(_I,t,r,o);const c={element:t,state:e,onNavigate:n,onStateUpdate:i,update(l){c.state=l,o={...o,campaignState:l},Jt==null||Jt.setProps(o)},destroy(){Fp(),Op(),Jt==null||Jt.destroy()}};return c}const Bp=100;function bI(t){if(t.noFalloff)return`${t.damage}`;const e=Math.round(t.damage/(t.range/Bp));return`${t.damage}&nbsp;at&nbsp;${Bp}&nbsp;m, ${e}&nbsp;at&nbsp;${t.range}&nbsp;m`}function zv(t,e){const n={ships:"var(--color-secondary)",primaries:"var(--color-primary)",secondaries:"var(--color-danger)",ammo:"var(--color-success)",scrap:"var(--color-text-dim)"};return t==="ships"?`
      <div class="item-preview ship-preview-container" style="--preview-color: ${n[t]}">
        ${Jh(e)}
      </div>
    `:t==="scrap"?`
      <div class="item-preview scrap-preview-container" style="--preview-color: ${n[t]}">
        ${Jh(e)}
      </div>
    `:t==="primaries"?`
      <div class="item-preview" style="--preview-color: ${n[t]}">
        ${Jr(e,{size:"xl"})}
      </div>
    `:t==="secondaries"?`
      <div class="item-preview" style="--preview-color: ${n[t]}">
        ${Ja(e,{size:"xl"})}
      </div>
    `:`
    <div class="item-preview" style="--preview-color: ${n[t]}">
      ${Jr(e,{size:"xl",color:"var(--color-success)",glowColor:"var(--color-success-glow)"})}
    </div>
  `}function MI(t){const e=Bv(t,{classPrefix:"stat"});return e?`
    <div class="item-stats">
      ${e}
    </div>
  `:""}function EI(t){const e=bt[t];if(!e)return"";const n=e.ammo!==void 0?`${e.ammo} ${e.ammo===1?"round":"rounds"}`:"Unlimited",i=e.category.charAt(0).toUpperCase()+e.category.slice(1),s=e.category==="beam",r=e.isPulseBeam===!0,o=e.isInstantBeam===!0,a=s&&!r&&!o,c=r?`${Math.round(1/(e.pulseInterval??.1))} pulses/s`:a?"Continuous":o?`${e.fireRate}s cooldown`:`${(1/e.fireRate).toFixed(1)}/s`,l=r?"Damage per pulse":a?"Damage per second":o?"Damage per shot":"Damage",u=s?bI(e):`${e.damage}`,d=r?"Heat per pulse":a?"Heat per second":"Heat per shot",f=e.flakRadius?`
      <div class="stat-row"><span>Burst radius</span><span>${e.flakRadius} m</span></div>
      <div class="stat-row"><span>Shrapnel count</span><span>${e.shrapnelCount}</span></div>
    `:"",h=e.shieldDamageMultiplier??1,p=h!==1?`${Math.round(e.damage*h)} (${h}×)`:"",v=e.hullDamageMultiplier??1,g=v!==1?`${Math.round(e.damage*v)} (${v}×)`:"",m=e.projectileSpeed>0?`${e.projectileSpeed} m/s`:"";return`
    <div class="item-stats">
      <div class="stat-row"><span>Category</span><span>${i}</span></div>
      <div class="stat-row"><span>${l}</span><span>${u}</span></div>
      ${p?`<div class="stat-row"><span>Shield damage</span><span>${p}</span></div>`:""}
      ${g?`<div class="stat-row"><span>Hull damage</span><span>${g}</span></div>`:""}
      <div class="stat-row"><span>Range</span><span>${e.range} m</span></div>
      ${m?`<div class="stat-row"><span>Speed</span><span>${m}</span></div>`:""}
      <div class="stat-row"><span>Fire rate</span><span>${c}</span></div>
      <div class="stat-row"><span>${d}</span><span>${e.heatPerShot}</span></div>
      ${f}
      <div class="stat-row"><span>Ammo</span><span>${n}</span></div>
    </div>
  `}function wI(t){const e=Sn[t];if(!e)return"";const n=e.turnRate>0?`${e.turnRate}°/s`:"None",i=e.requiresLock?`${(1/e.lockSpeed).toFixed(1)}s`:"N/A";return`
    <div class="item-stats">
      <div class="stat-row"><span>Size</span><span>${e.capacity} per bank</span></div>
      <div class="stat-row"><span>Damage</span><span>${e.damage}</span></div>
      <div class="stat-row"><span>Speed</span><span>${e.speed} m/s</span></div>
      <div class="stat-row"><span>Range</span><span>${e.range} m</span></div>
      <div class="stat-row"><span>Tracking</span><span>${n}</span></div>
      <div class="stat-row"><span>Lock time</span><span>${i}</span></div>
      ${e.aoeRadius?`<div class="stat-row"><span>AoE radius</span><span>${e.aoeRadius} m</span></div>`:""}
    </div>
  `}function TI(t){const e=bt[t];if(!e||e.ammo===void 0)return"";const n=e.ammo===1?"round":"rounds";return`
    <div class="item-stats">
      <div class="stat-row"><span>Weapon</span><span>${e.name}</span></div>
      <div class="stat-row"><span>Capacity per bank size</span><span>${e.ammo} ${n}</span></div>
    </div>
  `}function AI(t){const e=Wt[t];if(!e)return"";const n=t.charAt(0).toUpperCase()+t.slice(1),i=Ua(e.primaryBanks,"bank-dots-primary"),s=Ua(e.secondaryBanks,"bank-dots-secondary");return`
    <div class="item-stats">
      <div class="stat-row"><span>Hull</span><span>${n}</span></div>
      <div class="stat-row"><span>Primary banks</span><span>${i}</span></div>
      <div class="stat-row"><span>Secondary banks</span><span>${s}</span></div>
    </div>
  `}function RI(t,e,n){switch(t){case"ships":return Zg().filter(({shipClass:i})=>(e.ships[i]??0)>0).map(({shipClass:i})=>({id:i,name:i.charAt(0).toUpperCase()+i.slice(1),stock:e.ships[i]??0}));case"primaries":return Jg().filter(({weaponType:i})=>(e.primaries[i]??0)>0).map(({weaponType:i})=>{const s=bt[i];return{id:i,name:(s==null?void 0:s.listName)??(s==null?void 0:s.name)??i,stock:e.primaries[i]??0}});case"secondaries":return Qg().filter(({weaponType:i})=>(e.secondaries[i]??0)>0).map(({weaponType:i})=>{var s;return{id:i,name:((s=Sn[i])==null?void 0:s.name)??i,stock:e.secondaries[i]??0}});case"ammo":return e0().filter(({weaponType:i})=>(e.ammo[i]??0)>0).map(({weaponType:i})=>{const s=bt[i];return{id:i,name:(s==null?void 0:s.listName)??(s==null?void 0:s.name)??i,stock:e.ammo[i]??0}});case"scrap":return FA().filter(({shipClass:i})=>((n==null?void 0:n[i])??0)>0).map(({shipClass:i})=>({id:i,name:`${i.charAt(0).toUpperCase()+i.slice(1)} Scrap`,stock:(n==null?void 0:n[i])??0}))}}function ka(t,e,n){switch(t){case"ships":return ds(e,n);case"primaries":return lo(e,n);case"secondaries":return mn(e,n);case"ammo":return pn(e,n);case"scrap":return n==="sell"?Ad(e):0}}function CI(t,e){switch(e){case"ships":return Object.values(t.storeStock.ships).some(n=>n>0);case"primaries":return Object.values(t.storeStock.primaries).some(n=>n>0);case"secondaries":return Object.values(t.storeStock.secondaries).some(n=>n>0);case"ammo":return Object.values(t.storeStock.ammo).some(n=>n>0);case"scrap":return!1}}function PI(t,e){switch(e){case"ships":return t.storedShips.length>0;case"primaries":return t.storedWeapons.some(n=>n.category==="primary");case"secondaries":return t.storedWeapons.some(n=>n.category==="secondary");case"ammo":return t.storedAmmo.length>0;case"scrap":return Object.values(t.storedScrap).some(n=>n>0)}}function Xd(t,e){return CI(t,e)||PI(t,e)}function Hv(t){return["ships","primaries","secondaries","ammo","scrap"].find(n=>Xd(t,n))??null}function LI(t,e,n){switch(e){case"ships":return t.storedShips.filter(i=>i.shipClass===n).length;case"primaries":return t.storedWeapons.filter(i=>i.category==="primary"&&i.weaponType===n).length;case"secondaries":return t.storedWeapons.filter(i=>i.category==="secondary"&&i.weaponType===n).reduce((i,s)=>i+s.count,0);case"ammo":return t.storedAmmo.filter(i=>i.weaponType===n).reduce((i,s)=>i+s.count,0);case"scrap":return t.storedScrap[n]??0}}function Gv(t,e,n){switch(e){case"ships":return t.storedShips.findIndex(i=>i.shipClass===n);case"primaries":return t.storedWeapons.findIndex(i=>i.category==="primary"&&i.weaponType===n);case"secondaries":return t.storedWeapons.findIndex(i=>i.category==="secondary"&&i.weaponType===n);case"ammo":return t.storedAmmo.findIndex(i=>i.weaponType===n);case"scrap":return(t.storedScrap[n]??0)>0?0:-1}}function Wv(t){return t==="autocannon"?10:1}function Vv(t){return t==="autocannon"?100:10}function DI(t,e,n){switch(e){case"ships":return zA(t,n);case"primaries":return GA(t,n);case"secondaries":return n0(t,n,1);case"ammo":return jg(t,n,Wv(n));default:return t}}function II(t,e,n){return e==="secondaries"?n0(t,n,10):e==="ammo"?jg(t,n,Vv(n)):t}function NI(t,e,n){const i=Gv(t,e,n);if(i<0)return t;switch(e){case"ships":return HA(t,i);case"primaries":return WA(t,i);case"secondaries":return i0(t,i,1);case"ammo":return Kg(t,n,Wv(n));case"scrap":return Pd(t,n,1);default:return t}}function UI(t,e,n){const i=Gv(t,e,n);return i<0?t:e==="secondaries"?i0(t,i,10):e==="ammo"?Kg(t,n,Vv(n)):e==="scrap"?Pd(t,n,10):t}function kI(t,e,n){return e!=="scrap"?t:Pd(t,n,100)}function FI(t,e){switch(t){case"ships":return MI(e);case"primaries":return EI(e);case"secondaries":return wI(e);case"ammo":return TI(e);case"scrap":return AI(e)}}function OI(t,e,n,i,s,r){const o=i>0,a=i>=10,c=i>=100,l=Ld(n),u=s0(t,n),d=i>0?`In storage: ${i}`:"",f=n.charAt(0).toUpperCase()+n.slice(1),h=zv(e,n);return`
    <div class="store-detail">
      <div class="detail-fixed-top">
        <div class="detail-header">${f} Scrap</div>
        ${h}
      </div>
      <div class="detail-scrollable">
        ${r}
      </div>
      <div class="detail-fixed-bottom">
        ${d?`<div class="detail-storage">${d}</div>`:""}
        <div class="detail-actions">
          <button class="btn btn-convert" id="btn-convert" ${u?"":"disabled"}>
            Convert&nbsp;to&nbsp;Ship (${Rd}&nbsp;scrap,&nbsp;${l}&nbsp;cr)
          </button>
          <button class="btn btn-sell" id="btn-sell" ${o?"":"disabled"}>
            Sell&nbsp;×1<br>(${s}&nbsp;cr)
          </button>
          <button class="btn btn-sell" id="btn-sell-bulk" ${a?"":"disabled"}>
            Sell&nbsp;×10<br>(${s*10}&nbsp;cr)
          </button>
          <button class="btn btn-sell" id="btn-sell-bulk-100" ${c?"":"disabled"}>
            Sell&nbsp;×100<br>(${s*100}&nbsp;cr)
          </button>
        </div>
      </div>
    </div>
  `}function BI(t,e,n,i,s,r,o,a){var G,$;const c=t.credits>=r&&i>0,l=s>0,u=s>0?`In storage: ${s}`:"",d=zv(e,n),f=e==="secondaries",h=e==="ammo",p=h&&n==="autocannon",v=p?10:1,g=p?10:1,m=p?100:10,S=f||h,_=Math.round(r*v),y=Math.round(o*g),D=Math.round(r*m),E=Math.round(o*m),A=t.credits>=D&&i>=m,P=s>=m,b=e==="primaries";let x=n;h?x=((G=bt[n])==null?void 0:G.ammoName)??n:b&&(x=(($=bt[n])==null?void 0:$.name)??n);const L=S,B=L?`&nbsp;×${v}<br>`:" ",F=L?`&nbsp;×${g}<br>`:" ";return`
    <div class="store-detail">
      <div class="detail-fixed-top">
        <div class="detail-header">${x}</div>
        ${d}
      </div>
      <div class="detail-scrollable">
        ${a}
      </div>
      <div class="detail-fixed-bottom">
        ${u?`<div class="detail-storage">${u}</div>`:""}
        <div class="detail-actions">
          <button class="btn btn-sell" id="btn-sell" ${l?"":"disabled"}>
            Sell${F}(${y}&nbsp;cr)
          </button>
          ${S?`<button class="btn btn-sell" id="btn-sell-bulk" ${P?"":"disabled"}>Sell&nbsp;×${m}<br>(${E}&nbsp;cr)</button>`:""}
          <button class="btn btn-buy" id="btn-buy" ${c?"":"disabled"}>
            Buy${B}(${_}&nbsp;cr)
          </button>
          ${S?`<button class="btn btn-buy" id="btn-buy-bulk" ${A?"":"disabled"}>Buy&nbsp;×${m}<br>(${D}&nbsp;cr)</button>`:""}
        </div>
      </div>
    </div>
  `}function zI(t,e,n,i){if(!n)return"";const s=ka(e,n,"buy"),r=ka(e,n,"sell"),o=i.find(u=>u.id===n),a=(o==null?void 0:o.stock)??0,c=LI(t,e,n),l=FI(e,n);return e==="scrap"?OI(t,e,n,c,r,l):BI(t,e,n,a,c,s,r,l)}function zp(t){return t.charAt(0).toUpperCase()+t.slice(1)}function ra(t,e,n,i,s){return`
    <div class="storage-item ${s?"selected":""}"
         data-category="${t}" data-item="${e}">
      <span class="item-name">${n}</span>
      <span class="item-count">×${i}</span>
    </div>
  `}function HI(t){const e=new Map;for(const n of t){const i=e.get(n.shipClass)??0;e.set(n.shipClass,i+1)}return e}function GI(t){const e=new Map;for(const n of t){const i=e.get(n.weaponType);i?i.count+=n.category==="secondary"?n.count??1:1:e.set(n.weaponType,{category:n.category,count:n.category==="secondary"?n.count??1:1})}return e}function WI(t,e,n){const i=t.storedShips.length>0,s=t.storedWeapons.length>0,r=t.storedAmmo.length>0,o=Object.values(t.storedScrap).some(g=>g>0);if(!i&&!s&&!r&&!o)return`
      <div class="store-storage">
        <div class="storage-header">Storage</div>
        <div class="empty-state-panel storage-empty">No items in storage</div>
      </div>
    `;const c=(g,m)=>e===g&&n===m,l=HI(t.storedShips),u=i?`
      <div class="storage-section">
        <div class="storage-label">Stored Ships</div>
        ${Array.from(l.entries()).map(([g,m])=>ra("ships",g,zp(g),m,c("ships",g))).join("")}
      </div>
    `:"",d=GI(t.storedWeapons),f=s?`
      <div class="storage-section">
        <div class="storage-label">Weapons</div>
        ${Array.from(d.entries()).map(([g,m])=>{var y,D;const S=m.category==="primary"?"primaries":"secondaries",_=m.category==="primary"?((y=bt[g])==null?void 0:y.name)??g:((D=Sn[g])==null?void 0:D.name)??g;return ra(S,g,_,m.count,c(S,g))}).join("")}
      </div>
    `:"",h=r?`
      <div class="storage-section">
        <div class="storage-label">Ammo</div>
        ${t.storedAmmo.map(g=>{var S;const m=((S=bt[g.weaponType])==null?void 0:S.name)??g.weaponType;return ra("ammo",g.weaponType,m,g.count,c("ammo",g.weaponType))}).join("")}
      </div>
    `:"",p=Object.entries(t.storedScrap).filter(([,g])=>g>0),v=o?`
      <div class="storage-section">
        <div class="storage-label">Scrap</div>
        ${p.map(([g,m])=>ra("scrap",g,`${zp(g)} Scrap`,m,c("scrap",g))).join("")}
      </div>
    `:"";return`
    <div class="store-storage">
      <div class="storage-header">Storage</div>
      <div class="storage-content">
        ${u}
        ${f}
        ${h}
        ${v}
      </div>
    </div>
  `}function Lr(t,e,n,i){if(!Xd(t,n))return"";const s=e===n;return`<button class="btn ${s?"btn-primary":""}" data-cat="${n}" role="tab" aria-selected="${s}">${i}</button>`}function VI(t,e,n,i){const s=RI(t,n.storeStock,n.storedScrap),r=t==="scrap",o=s.map(l=>{const u=l.id===e;if(r){const h=ka(t,l.id,"sell");return`
          <div class="store-item ${u?"selected":""}" data-item="${l.id}" role="option" aria-selected="${u}" tabindex="0">
            <span class="item-name">${l.name}</span>
            <span class="item-price sell-price" aria-label="Sell price: ${h} credits">${h} cr</span>
          </div>
        `}const d=ka(t,l.id,"buy"),f=n.credits>=d;return`
        <div class="store-item ${u?"selected":""}" data-item="${l.id}" role="option" aria-selected="${u}" tabindex="0">
          <span class="item-name">${l.name}</span>
          <span class="item-stock" aria-label="${l.stock} in stock">×${l.stock}</span>
          <span class="item-price ${f?"":"expensive"}" aria-label="Price: ${d} credits${f?"":", cannot afford"}">${d}&nbsp;cr</span>
        </div>
      `}).join(""),a=zI(n,t,e,s);return`
    <div class="campaign-page">
      ${Id({activeTab:"store",credits:n.credits,sector:n.currentSector})}
      <main class="store-screen" aria-label="Equipment Store">
        <nav class="store-categories" aria-label="Store categories">
          <div class="category-tabs" role="tablist" aria-label="Item categories">
            ${Lr(n,t,"ships","Ships")}
            ${Lr(n,t,"primaries","Primaries")}
            ${Lr(n,t,"secondaries","Missiles")}
            ${Lr(n,t,"ammo","Ammo")}
            ${Lr(n,t,"scrap","Scrap")}
          </div>
        </nav>
        <div class="store-layout">
          <aside class="store-list" role="listbox" aria-label="Available items">
            ${o}
          </aside>
          <section class="store-details" aria-label="Item details">
            ${a||'<div class="empty-state-panel" role="status">Select an item to view details</div>'}
          </section>
          ${WI(n,t,e)}
        </div>
      </main>
    </div>
  `}const $I={render(t,e){let n=t.selectedCategory;return Xd(e.campaignState,n)||(n=Hv(e.campaignState)??"ships"),VI(n,t.selectedItem,e.campaignState,e.onNavigate)},bind(t,e){const n=t.getState(),{onNavigate:i,onStateUpdate:s}=e,r=document.querySelector("#screen-store");if(r&&Nd(r,i),t.on("[data-cat]","click",(o,a)=>{const c=a.dataset.cat;t.setState({selectedCategory:c,selectedItem:null})}),t.on(".store-item","click",(o,a)=>{const c=a.dataset.item;if(c){const l=t.getState();t.setState({selectedItem:c===l.selectedItem?null:c})}}),t.on(".storage-item","click",(o,a)=>{const c=a.dataset.category,l=a.dataset.item;c&&l&&t.setState({selectedCategory:c,selectedItem:l})}),t.on("#btn-buy","click",()=>{const o=t.getState();if(o.selectedItem){const a=DI(e.campaignState,o.selectedCategory,o.selectedItem);a!==e.campaignState&&s(a)}}),t.on("#btn-sell","click",()=>{const o=t.getState();if(o.selectedItem){const a=NI(e.campaignState,o.selectedCategory,o.selectedItem);a!==e.campaignState&&s(a)}}),t.on("#btn-buy-bulk","click",()=>{const o=t.getState();if(o.selectedItem){const a=II(e.campaignState,o.selectedCategory,o.selectedItem);a!==e.campaignState&&s(a)}}),t.on("#btn-sell-bulk","click",()=>{const o=t.getState();if(o.selectedItem){const a=UI(e.campaignState,o.selectedCategory,o.selectedItem);a!==e.campaignState&&s(a)}}),t.on("#btn-sell-bulk-100","click",()=>{const o=t.getState();if(o.selectedItem){const a=kI(e.campaignState,o.selectedCategory,o.selectedItem);a!==e.campaignState&&s(a)}}),t.on("#btn-convert","click",()=>{const o=t.getState();if(o.selectedItem&&o.selectedCategory==="scrap"){const a=VA(e.campaignState,o.selectedItem);a!==e.campaignState&&s(a)}}),n.selectedCategory==="ships"||n.selectedCategory==="scrap"){const o=document.querySelector(".ship-preview-container, .scrap-preview-container");o&&Mv(o)}}};let Ns=null,Us=null;function XI(t,e,n,i){Ns==null||Ns.destroy();const s=Hv(e)??"ships",r={selectedCategory:s,selectedItem:null};return Us={campaignState:e,onNavigate:n,onStateUpdate:a=>{i(a),Ns&&Us&&(Us={...Us,campaignState:a},Ns.setProps(Us))}},Ns=Fi($I,t,r,Us),{element:t,state:e,selectedCategory:s,selectedItem:null,onNavigate:n,onStateUpdate:i}}function Sr(t,e,n,i){const{screenManager:s}=t,r=a=>{switch(a){case"squadron":break;case"store":{Bg(s);const c=on(s,dt.STORE);$v(t,c,n);break}case"contracts":zg(s),n(t);break}},o=a=>{cr(s,a)};xI(e,s.campaignState,r,o)}function $v(t,e,n){const{screenManager:i}=t,s=o=>{switch(o){case"squadron":{co(i);const a=on(i,dt.SQUADRON);Sr(t,a,n);break}case"store":break;case"contracts":zg(i),n(t);break}},r=o=>{cr(i,o)};XI(e,i.campaignState,s,r)}function qI(t,e,n,i,s,r){const{screenManager:o}=t,a=on(o,dt.RESULTS);mD(a,e,n,o.campaignState,()=>{co(o);const c=on(o,dt.SQUADRON);Sr(t,c,i)},s,r)}function YI(t,e){const{screenManager:n}=t,i=on(n,dt.GAME_OVER);vD(i,n.campaignState,()=>{const s=Dd();cr(n,s),co(n);const r=on(n,dt.SQUADRON);Sr(t,r,e)}),wA(n)}const jI=5;function KI(t){return{currentWave:0,totalWaves:t,waveCleared:!1,delayRemaining:0}}function ZI(){return{pending:!1,delayRemaining:0,victory:!1}}function Xv(t,e){return t===void 0?0:typeof t=="number"?t:zr(e,t[0],t[1])}const Hp=2e3;function JI(t){const e=[];for(const n of Te(t,["faction","transform"])){if(!mr(t,n))continue;const i=C(t,n,"faction");if((i==null?void 0:i.faction)!==ze.Player)continue;const s=C(t,n,"transform");s&&e.push(s.position.clone())}return e}function QI(t,e){if(e.length===0)return new T(0,0,-Hp);const n=Qp(t.prng),i=new T(n.x,n.y,n.z);let s=-1/0,r=e[0];for(const o of e){const a=o.dot(i);a>s&&(s=a,r=o)}return r.clone().addScaledVector(i,Hp)}function e3(t,e){const n=new T;for(const r of e)n.add(r);n.divideScalar(e.length);const i=n.clone().sub(t).normalize(),s=new T(0,0,-1);return new at().setFromUnitVectors(s,i)}function qv(t,e,n){const i=hw(n),s=JI(t),r=QI(t,s),o=s.length>0?e3(r,s):void 0,a=t3(e);let c=0;const l=new T(1,0,0),u=new T(0,1,0);o&&(l.applyQuaternion(o),u.applyQuaternion(o)),e.enemies.forEach(d=>{for(let f=0;f<d.count;f++){const h=(c-(a-1)/2)*20,p=(c%2===0?1:-1)*5,v=r.clone().addScaledVector(l,h).addScaledVector(u,p);Mw(t,d.archetype,v,o,d.skill,i),c++}})}function t3(t){return t.enemies.reduce((e,n)=>e+n.count,0)}function n3(t,e,n,i,s){const{screenManager:r}=t;return()=>{t.missionEnded=!0,Pw(e.world);const o=tD(e.world);Td(e);const a=e.world.systemState.matchStats,c=[];if(a)for(const p of a.destroyedShips)(p.wasPlayer||p.isWingman)&&p.campaignShipId&&c.push(p.campaignShipId);const l=new Map,u=i.victory?n.reward:0;let d=KA(r.campaignState,i.victory,u,c,l);d=JA(d,o);let f=null;if(a&&a.salvageableShips.length>0){const p=()=>ft(e.world.prng);f=rD(a.salvageableShips,p),d=oD(d,f)}d=LA(d,()=>ft(e.world.prng)),cr(r,d),ZA(d)?(Wh(r,i.victory),YI(t,s)):(Wh(r,i.victory),qI(t,i.victory,n,s,e.world,f))}}function i3(t,e,n,i,s,r){const o=.016666666666666666;return a=>{if(t.missionEnded)return;if(s.pending){s.delayRemaining-=o,s.delayRemaining<=0&&r();return}if(bg(a)===0&&!i.waveCleared){i.waveCleared=!0;const l=i.currentWave+1;if(l<i.totalWaves){const u=n.waves[l];u&&(i.delayRemaining=Xv(u.delay,a.prng))}}if(i.waveCleared&&i.currentWave+1<i.totalWaves)if(i.delayRemaining>0)i.delayRemaining-=o;else{i.currentWave++,i.waveCleared=!1;const l=n.waves[i.currentWave];l&&(sT(e.world),xA(e),qv(a,l,i.currentWave))}}}function s3(t,e,n){return i=>{var a;const s=e.currentWave>=e.totalWaves-1,r=i===Wn.Defeat;if(!r&&!s||t.missionEnded||n.pending)return;n.pending=!0,n.delayRemaining=jI,n.victory=i===Wn.Victory;const o=iD(r);(a=t.missionContainer)==null||a.appendChild(o)}}const _i=12,r3=2,Ws=8,Mi=40,ks=12,o3=18,Yv='"Lucida Console", "Consolas", monospace',Gp=12,xi=6,a3=8,c3=3;function Or(t,e,n,i,s){const r=e.toUpperCase();t.font=`bold ${o3}px ${Yv}`,t.strokeStyle="#000",t.lineWidth=3,t.lineJoin="round",t.strokeText(r,n,i),t.fillStyle=s,t.fillText(r,n,i)}function l3(t,e,n){const i=e/2,s=n/2,r=a3,o=c3;t.strokeStyle="#00ff00",t.lineWidth=1.5,t.beginPath(),t.moveTo(i-r,s),t.lineTo(i-o,s),t.moveTo(i+o,s),t.lineTo(i+r,s),t.moveTo(i,s-r),t.lineTo(i,s-o),t.moveTo(i,s+o),t.lineTo(i,s+r),t.stroke()}function u3(t,e,n,i){let s=e.maxX-e.minX+Ws*2,r=e.maxY-e.minY+Ws*2,o=e.minX-Ws,a=e.minY-Ws;if(s<Mi){const u=Mi-s;o-=u/2,s=Mi}if(r<Mi){const u=Mi-r;a-=u/2,r=Mi}const c=o+s,l=a+r;t.strokeStyle=i,t.lineWidth=r3,t.beginPath(),t.moveTo(o,a+_i),t.lineTo(o,a),t.lineTo(o+_i,a),t.moveTo(c-_i,a),t.lineTo(c,a),t.lineTo(c,a+_i),t.moveTo(o,l-_i),t.lineTo(o,l),t.lineTo(o+_i,l),t.moveTo(c-_i,l),t.lineTo(c,l),t.lineTo(c,l-_i),t.stroke(),t.textAlign="center",t.textBaseline="top",Or(t,`${Math.round(n)}`,o+s/2,l+4,i)}function d3(t,e,n,i){const s=(e.minX+e.maxX)/2,r=(e.minY+e.maxY)/2,o=e.maxX-e.minX+Ws*2,a=e.maxY-e.minY+Ws*2,c=Math.max(o,Mi),l=Math.max(a,Mi),u=Math.max(c,l)/2+4,d=-Math.PI/2,f=d+n*Math.PI*2;t.strokeStyle=i,t.lineWidth=3,t.beginPath(),t.arc(s,r,u,d,f),t.stroke(),n>=1&&(t.strokeStyle=i,t.lineWidth=2,t.beginPath(),t.arc(s,r,u+3,0,Math.PI*2),t.stroke())}function f3(t,e,n,i,s=!1,r){s?(t.strokeStyle=Wp(i),t.setLineDash([3,3])):(t.strokeStyle=i,t.setLineDash([])),t.lineWidth=2,t.beginPath(),t.arc(e,n,xi,0,Math.PI*2),t.stroke();const o=xi+3;t.beginPath(),t.moveTo(e-o,n),t.lineTo(e-xi-1,n),t.moveTo(e+xi+1,n),t.lineTo(e+o,n),t.moveTo(e,n-o),t.lineTo(e,n-xi-1),t.moveTo(e,n+xi+1),t.lineTo(e,n+o),t.stroke(),t.setLineDash([]),r&&(t.font=`bold 9px ${Yv}`,t.textAlign="center",t.textBaseline="top",t.fillStyle=s?Wp(i):i,t.strokeStyle="#000",t.lineWidth=2,t.strokeText(r,e,n+xi+4),t.fillText(r,e,n+xi+4))}function Wp(t){return t==="#ff0000"||t==="#f00"?"#660000":t==="#00ff00"||t==="#0f0"?"#006600":t==="#ffff00"||t==="#ff0"?"#666600":`${t}80`}function h3(t,e,n,i,s,r){const a=s?.5:1;t.save(),t.globalAlpha=a,t.strokeStyle=i,t.lineWidth=2,t.beginPath(),t.moveTo(e,n-8),t.lineTo(e+8,n),t.lineTo(e,n+8),t.lineTo(e-8,n),t.closePath(),t.stroke(),t.fillStyle=i,t.beginPath(),t.arc(e,n,2,0,Math.PI*2),t.fill(),t.font="10px monospace",t.textAlign="center",t.fillText(r,e,n+8+12),t.restore()}function p3(t,e,n,i,s,r,o,a){const c=o/2,l=a/2;let u=e-c,d=n-l;r&&(u=-u,d=-d);const f=Math.sqrt(u*u+d*d);f>.001?(u/=f,d/=f):(u=0,d=-1);const h=o/2-Gp,p=a/2-Gp;let v=p;Math.abs(u)>.001&&(v=Math.min(v,h/Math.abs(u))),Math.abs(d)>.001&&(v=Math.min(v,p/Math.abs(d)));const g=c+u*v,m=l+d*v,S=Math.atan2(d,u);t.fillStyle=s,t.save(),t.translate(g,m),t.rotate(S),t.beginPath(),t.moveTo(ks,0),t.lineTo(-ks/2,-ks/2),t.lineTo(-ks/2,ks/2),t.closePath(),t.fill(),t.restore();const _=`${Math.round(i)}`,y=g,D=o-g,E=m,A=a-m,P=Math.min(y,D,E,A),b=ks+8;P===y?(t.textAlign="left",t.textBaseline="middle",Or(t,_,g+b,m,s)):P===D?(t.textAlign="right",t.textBaseline="middle",Or(t,_,g-b,m,s)):P===E?(t.textAlign="center",t.textBaseline="top",Or(t,_,g,m+b,s)):(t.textAlign="center",t.textBaseline="bottom",Or(t,_,g,m-b,s))}const zn=new T,Br=new Map,Fn={x:0,y:0,initialized:!1};let _l=0,xl=.016;const m3=.001;function jv(){const t=performance.now()/1e3,e=t-_l;return e<m3||(xl=_l>0?Math.min(e,.1):.016,_l=t),xl}function Kv(t,e,n,i){if(!t.initialized)t.x=e,t.y=n,t.initialized=!0;else{const s=1-Math.exp(-20*i);t.x+=(e-t.x)*s,t.y+=(n-t.y)*s}}function g3(){for(const t of Br.values())t.initialized=!1;Fn.initialized=!1}const bl=[];let Gu=0;function v3(t,e){Gu>=bl.length&&bl.push({name:"",range:0});const n=bl[Gu++];return n.name=t,n.range=e,n}const Dr=new Map;function y3(t,e,n,i,s,r,o,a,c,l,u){S3(t,e,n,i,s,r,o,a,c,l,u)}function S3(t,e,n,i,s,r,o,a,c,l,u){const d=oo(c);if(d.length===0)return;const f=jv();Gu=0,Dr.clear();for(const h of d){const p=c.weapons[h];if(!p||p.projectileSpeed<=0)continue;const v=p.projectileSpeed;Dr.has(v)||Dr.set(v,v3(p.name,p.range))}for(const[h,p]of Dr){const v=vr(s.position,r,o,a,h);if(!v){const D=Br.get(h);D&&(D.initialized=!1);continue}const m=s.position.distanceTo(o)<=p.range;if(zn.copy(v).sub(e.position),zn.dot(u)<=0){const D=Br.get(h);D&&(D.initialized=!1);continue}zn.copy(v).project(e);const S=(zn.x+1)*.5*n,_=(1-zn.y)*.5*i;let y=Br.get(h);if(y||(y={x:0,y:0,initialized:!1},Br.set(h,y)),Kv(y,S,_,f),y.x>=0&&y.x<=n&&y.y>=0&&y.y<=i){const D=Dr.size>1?p.name:void 0;f3(t,y.x,y.y,l,!m,D)}}}function _3(t,e,n,i,s,r,o,a,c,l,u){const d=vd(c);d&&d.turnRate===0&&(d.isDecoy||x3(t,e,n,i,s,r,o,a,d,l,u))}function x3(t,e,n,i,s,r,o,a,c,l,u){const d=jv(),f=vr(s.position,r,o,a,c.speed);if(!f){Fn.initialized=!1;return}const p=s.position.distanceTo(f)>c.range;if(zn.copy(f).sub(e.position),zn.dot(u)<0){Fn.initialized=!1;return}zn.copy(f).project(e);const g=(zn.x+1)*.5*n,m=(1-zn.y)*.5*i;Kv(Fn,g,m,d),Fn.x>=0&&Fn.x<=n&&Fn.y>=0&&Fn.y<=i&&h3(t,Fn.x,Fn.y,l,p,c.name)}const oa=new T,Ml=new oi,On=[];for(let t=0;t<8;t++)On.push(new T);const Fa=new T,El=[];let Wu=0;function b3(){return Wu>=El.length&&El.push({entity:0,transform:null,velocity:Fa,mesh:void 0,distance:0,isSelected:!1,isEnemy:!1,isNeutral:!1,isLockTarget:!1,lockProgress:0,isMissile:!1}),El[Wu++]}function M3(){Wu=0}function E3(t,e){return t.isSelected!==e.isSelected?t.isSelected?1:-1:e.distance-t.distance}function w3(t,e,n,i){var u,d,f,h,p,v,g,m;if(Ml.setFromObject(t),Ml.isEmpty())return null;const{min:s,max:r}=Ml;(u=On[0])==null||u.set(s.x,s.y,s.z),(d=On[1])==null||d.set(s.x,s.y,r.z),(f=On[2])==null||f.set(s.x,r.y,s.z),(h=On[3])==null||h.set(s.x,r.y,r.z),(p=On[4])==null||p.set(r.x,s.y,s.z),(v=On[5])==null||v.set(r.x,s.y,r.z),(g=On[6])==null||g.set(r.x,r.y,s.z),(m=On[7])==null||m.set(r.x,r.y,r.z);let o=1/0,a=-1/0,c=1/0,l=-1/0;for(const S of On){oa.copy(S),oa.project(e);const _=(oa.x+1)*.5*n,y=(1-oa.y)*.5*i;o=Math.min(o,_),a=Math.max(a,_),c=Math.min(c,y),l=Math.max(l,y)}return{minX:o,maxX:a,minY:c,maxY:l}}const wl=new T,Vp=new T,aa=new T;let $p;const ca=[];function T3(t){const e=document.createElement("canvas");e.style.position="absolute",e.style.top="0",e.style.left="0",e.style.width="100%",e.style.height="100%",e.style.pointerEvents="none",t.appendChild(e);const n=e.getContext("2d"),i=window.devicePixelRatio||1;return Zv({canvas:e,ctx:n,dpr:i},t.clientWidth,t.clientHeight),{canvas:e,ctx:n,dpr:i}}function Zv(t,e,n){t.dpr=window.devicePixelRatio||1,t.canvas.width=e*t.dpr,t.canvas.height=n*t.dpr,t.ctx.scale(t.dpr,t.dpr)}function A3(t,e,n,i,s,r,o,a,c){const{ctx:l,dpr:u}=t;l.setTransform(1,0,0,1,0,0),l.clearRect(0,0,t.canvas.width,t.canvas.height),l.scale(u,u),l3(l,a,c);const d=C(e,n,"targeting"),f=d==null?void 0:d.currentTarget;f!==$p&&(g3(),$p=f);const h=C(e,n,"primaryWeapons"),p=C(e,n,"secondaryWeapons"),v=(p==null?void 0:p.lockProgress)??0,g=p==null?void 0:p.lockTarget;M3(),ca.length=0;for(const m of Te(e,["transform","health","faction"])){if(m===n||Ke(e,m,"projectile"))continue;const S=C(e,m,"health");if(S&&xt(S))continue;const _=C(e,m,"transform"),y=C(e,m,"faction"),D=C(e,m,"physics"),E=o.get(m),A=(i==null?void 0:i.position.distanceTo(_.position))??0,P=m===g,b=Ke(e,m,"missile"),x=b3();x.entity=m,x.transform=_,x.velocity=(D==null?void 0:D.velocity)??Fa,x.mesh=E,x.distance=A,x.isSelected=m===f,x.isEnemy=y.faction===ze.Enemy,x.isNeutral=y.faction===ze.Neutral,x.isLockTarget=P,x.lockProgress=P?v:0,x.isMissile=b,ca.push(x)}ca.sort(E3);for(const m of ca)R3(l,m,r,a,c,i,s,h,p)}function R3(t,e,n,i,s,r,o,a,c){let l;e.isMissile?l="#888888":e.isNeutral?l=e.isSelected?"#ffff00":"#888800":e.isEnemy?l=e.isSelected?"#ff0000":"#880000":l=e.isSelected?"#00ff00":"#008800",Vp.copy(e.transform.position).sub(n.position),aa.set(0,0,-1).applyQuaternion(n.quaternion);const u=Vp.dot(aa)<0;wl.copy(e.transform.position).project(n);const d=(wl.x+1)*.5*i,f=(1-wl.y)*.5*s;let h=null;e.mesh&&!u&&(h=w3(e.mesh,n,i,s));const p=50;!u&&d>=-p&&d<=i+p&&f>=-p&&f<=s+p&&h?(u3(t,h,e.distance,l),e.isLockTarget&&e.lockProgress>0&&d3(t,h,e.lockProgress,l),e.isSelected&&!e.isMissile&&r&&a&&y3(t,n,i,s,r,o??Fa,e.transform.position,e.velocity,a,l,aa),e.isSelected&&!e.isMissile&&r&&c&&_3(t,n,i,s,r,o??Fa,e.transform.position,e.velocity,c,l,aa)):p3(t,d,f,e.distance,l,u,i,s)}function Jv(t,e){const n=document.createElement("div");n.className="weapon-bank";const i=document.createElement("div");i.className="weapon-name";const s=document.createElement("div");s.className="weapon-info";const r=document.createElement("span");r.className="ammo",s.appendChild(r);let o=null,a=null,c=null;return t?(a=document.createElement("span"),a.className="lock-status",s.appendChild(a)):(o=document.createElement("span"),o.className="heat-mini",s.appendChild(o),e&&(c=document.createElement("div"),c.className="weapon-type beam",c.textContent="BEAM")),n.appendChild(i),n.appendChild(s),c&&n.appendChild(c),{element:n,nameEl:i,ammoEl:r,heatEl:o,lockEl:a,typeEl:c,lastSelected:!1,lastAmmo:"",lastHeat:"",lastLock:"",lastEmpty:!1,lastOnCooldown:!1}}function Qv(t){let e="";for(let n=0;n<t.length;n++){const i=t[n];n>0&&(e+=","),e+=i.name,e+=":",e+=i.category}return e}function ey(t){let e="";for(let n=0;n<t.length;n++){const i=t[n];n>0&&(e+=","),e+=i.name,e+=":",e+=i.requiresLock}return e}function C3(t,e){for(const n of t.secondaryBanks)n.element.remove();t.secondaryNoneEl&&(t.secondaryNoneEl.remove(),t.secondaryNoneEl=null),t.secondaryBanks=[];for(const n of e){const i=Jv(!0,!1);i.nameEl.textContent=n.name,t.secondarySection.appendChild(i.element),t.secondaryBanks.push(i)}t.lastSecondarySignature=ey(e)}function P3(t,e,n,i,s,r,o){for(let a=0;a<e.length;a++){const c=e[a],l=t.secondaryBanks[a],u=a===n,d=`${c.count}/${c.maxCount}`,f=c.count<=0,h=o-i,p=u&&h<c.fireRate;if(l.lastOnCooldown!==p&&(l.element.classList.toggle("cooldown",p),l.lastOnCooldown=p),l.lastSelected!==u&&(l.element.classList.toggle("selected",u),l.lastSelected=u),l.lastEmpty!==f&&(l.element.classList.toggle("empty",f),l.ammoEl.classList.toggle("depleted",f),l.lastEmpty=f),l.lastAmmo!==d&&(l.ammoEl.textContent=d,l.lastAmmo=d),l.lockEl){let v="",g="";c.requiresLock?u?r?s>=1?(v="LOCKED",g="locked"):(v=`LOCK ${Math.round(s*100)}%`,g="locking"):(v="NO TGT",g="no-target"):(v="LOCK REQ",g="lock-req"):(v="DUMBFIRE",g=u?"dumbfire":"dumbfire-dim");const m=`${v}:${g}`;l.lastLock!==m&&(l.lockEl.textContent=v,l.lockEl.className=`lock-status${g?` ${g}`:""}`,l.lastLock=m)}}}function L3(t){if(t.secondaryBanks.length>0){for(const e of t.secondaryBanks)e.element.remove();t.secondaryBanks=[],t.lastSecondarySignature=""}t.secondaryNoneEl||(t.secondaryNoneEl=document.createElement("div"),t.secondaryNoneEl.className="no-weapon",t.secondaryNoneEl.textContent="NONE",t.secondarySection.appendChild(t.secondaryNoneEl))}function D3(){return`
    .weapon-display {
      position: absolute;
      bottom: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-size: 12px;
    }
    .weapon-section {
      background: rgba(0, 0, 0, 0.6);
      border: 1px solid #0a0;
      padding: 6px 8px;
      min-width: 140px;
    }
    .section-label {
      font-size: 10px;
      color: #0a0;
      margin-bottom: 4px;
      letter-spacing: 1px;
    }
    .key-hint {
      color: #050;
      font-size: 8px;
      margin-left: 4px;
    }
    .link-indicator {
      font-size: 9px;
      padding: 2px 4px;
      margin-bottom: 4px;
      text-align: center;
      letter-spacing: 1px;
    }
    .link-indicator::after {
      content: ' [V]';
      color: #050;
      font-size: 8px;
    }
    .link-indicator.linked {
      color: #4f4;
      background: rgba(0, 100, 0, 0.4);
      border: 1px solid #0a0;
    }
    .link-indicator.single {
      color: #666;
      background: rgba(0, 30, 0, 0.3);
      border: 1px solid #333;
    }
    .weapon-bank {
      padding: 3px 6px;
      background: rgba(0, 30, 0, 0.4);
      border-left: 2px solid transparent;
      margin-top: 3px;
    }
    .section-label + .weapon-bank {
      margin-top: 0;
    }
    .weapon-bank.selected {
      background: rgba(0, 60, 0, 0.6);
      border-left-color: #0f0;
    }
    .weapon-bank.selected.cooldown {
      border-left-color: #860;
    }
    .weapon-bank.selected.cooldown .weapon-name {
      color: #a80;
    }
    .weapon-bank.empty {
      opacity: 0.5;
    }
    .weapon-name {
      color: #0f0;
      font-size: 11px;
    }
    .weapon-bank.selected .weapon-name {
      color: #4f4;
    }
    .weapon-info {
      display: flex;
      gap: 8px;
      font-size: 10px;
      margin-top: 2px;
    }
    .ammo {
      color: #0a0;
    }
    .ammo.depleted {
      color: #f00;
    }
    .heat-mini {
      color: #f80;
    }
    .heat-mini.hot {
      color: #f00;
      animation: pulse 0.3s ease-in-out infinite alternate;
    }
    .weapon-type {
      font-size: 9px;
      padding: 1px 3px;
      margin-top: 2px;
      display: inline-block;
    }
    .weapon-type.beam {
      background: #306;
      color: #c6f;
    }
    .lock-status {
      font-size: 9px;
      padding: 1px 4px;
    }
    .lock-status.no-target {
      color: #666;
    }
    .lock-status.locking {
      color: #ff0;
      animation: blink 0.5s ease-in-out infinite;
    }
    .lock-status.locked {
      color: #0f0;
      background: rgba(0, 255, 0, 0.2);
    }
    .lock-status.dumbfire {
      color: #f80;
    }
    .lock-status.dumbfire-dim {
      color: #864;
    }
    .lock-status.lock-req {
      color: #555;
    }
    .no-weapon {
      color: #444;
      font-size: 10px;
      padding: 2px;
    }
    @keyframes blink {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
    @keyframes pulse {
      from { opacity: 0.7; }
      to { opacity: 1; }
    }
  `}function I3(t){const e=document.createElement("div");e.className="weapon-display";const n=document.createElement("div");n.className="weapon-section primary-section";const i=document.createElement("div");i.className="section-label",i.textContent="PRIMARY ";const s=document.createElement("span");s.className="key-hint",s.textContent="[V]",i.appendChild(s),n.appendChild(i);const r=document.createElement("div");r.className="link-indicator",n.appendChild(r);const o=document.createElement("div");o.className="weapon-section secondary-section";const a=document.createElement("div");a.className="section-label",a.textContent="SECONDARY ";const c=document.createElement("span");return c.className="key-hint",c.textContent="[X]",a.appendChild(c),o.appendChild(a),e.appendChild(n),e.appendChild(o),t.appendChild(e),{container:e,primarySection:n,secondarySection:o,primaryBanks:[],secondaryBanks:[],primaryNoneEl:null,secondaryNoneEl:null,linkIndicator:r,lastLinkMode:null,lastPrimarySignature:"",lastSecondarySignature:""}}function N3(t,e){for(const n of t.primaryBanks)n.element.remove();t.primaryNoneEl&&(t.primaryNoneEl.remove(),t.primaryNoneEl=null),t.primaryBanks=[];for(const n of e){const i=n.category==="beam",s=Jv(!1,i);s.nameEl.textContent=n.name,t.primarySection.appendChild(s.element),t.primaryBanks.push(s)}t.lastPrimarySignature=Qv(e)}function U3(t,e,n){const i=C(e,n,"primaryWeapons"),s=C(e,n,"secondaryWeapons"),r=C(e,n,"heat"),o=C(e,n,"targeting");if(i&&i.weapons.length>0){Qv(i.weapons)!==t.lastPrimarySignature&&N3(t,i.weapons);const c=lg(i);if(t.lastLinkMode!==c){t.lastLinkMode=c;let g,m;if(c==="all")g="ALL",m=!0;else{const S=Number.parseInt(c,10);!Number.isNaN(S)&&i.weapons[S]?g=`${i.weapons[S].name.toUpperCase()} ${S+1}`:g=c.toUpperCase(),m=!1}t.linkIndicator.textContent=g,t.linkIndicator.className=m?"link-indicator linked":"link-indicator single"}const l=r?Math.round(r.current/r.max*100):0,u=`${l}%`,d=l>80,h=e.systemState.gameTime-i.lastFireTime,p=oo(i);let v=0;for(const g of p){const m=i.weapons[g];m&&m.category!=="beam"&&m.fireRate>v&&(v=m.fireRate)}for(let g=0;g<i.weapons.length;g++){const m=i.weapons[g],S=t.primaryBanks[g],_=p.includes(g),y=m.ammo!==void 0?`${m.ammo}/${m.maxAmmo}`:"∞",D=p.includes(g),E=m.category!=="beam"&&D&&h<v;if(S.lastOnCooldown!==E&&(S.element.classList.toggle("cooldown",E),S.lastOnCooldown=E),S.lastSelected!==_&&(S.element.classList.toggle("selected",_),S.lastSelected=_),S.lastAmmo!==y&&(S.ammoEl.textContent=y,S.lastAmmo=y),S.heatEl){const A=_?u:"";S.lastHeat!==A&&(S.heatEl.textContent=A,S.heatEl.classList.toggle("hot",_&&d),S.lastHeat=A)}}}else{if(t.primaryBanks.length>0){for(const a of t.primaryBanks)a.element.remove();t.primaryBanks=[],t.lastPrimarySignature=""}t.primaryNoneEl||(t.primaryNoneEl=document.createElement("div"),t.primaryNoneEl.className="no-weapon",t.primaryNoneEl.textContent="NONE",t.primarySection.appendChild(t.primaryNoneEl))}if(s&&s.weapons.length>0){ey(s.weapons)!==t.lastSecondarySignature&&C3(t,s.weapons);const c=s.lockProgress??0,l=(o==null?void 0:o.currentTarget)!==void 0,u=e.systemState.gameTime;P3(t,s.weapons,s.currentIndex,s.lastFireTime,c,l,u)}else L3(t)}const k3=5;function F3(t){const e=document.createElement("div");e.className="allied-display",e.innerHTML='<div class="allied-header">WINGMEN</div>';const n=[];for(let i=0;i<k3;i++){const s=document.createElement("div");s.className="ally-row",s.innerHTML=`
      <span class="ally-callsign">---</span>
      <div class="ally-bars">
        <div class="ally-bar hull"><div class="ally-bar-fill"></div></div>
        <div class="ally-bar shield"><div class="ally-bar-fill"></div></div>
      </div>
      <span class="ally-distance">---</span>
    `,e.appendChild(s),n.push({row:s,callsign:s.querySelector(".ally-callsign"),hullBar:s.querySelector(".ally-bar.hull .ally-bar-fill"),shieldBar:s.querySelector(".ally-bar.shield .ally-bar-fill"),distance:s.querySelector(".ally-distance")})}return t.appendChild(e),{container:e,allyElements:n}}const Ir=[];function O3(t,e,n){const i=C(e,n,"transform");Ir.length=0;for(const r of Te(e,["faction","health","transform","shipIdentity"])){if(r===n||Ke(e,r,"playerControlled"))continue;const o=C(e,r,"faction");if(!o||o.faction!==ze.Player)continue;const a=C(e,r,"health");if(!a||xt(a))continue;const c=C(e,r,"shipIdentity"),l=C(e,r,"shields"),u=C(e,r,"transform"),d=a.hull/a.maxHull*100,f=l?l.current/l.max*100:0,h=i&&u?i.position.distanceTo(u.position):0;Ir.push({entity:r,callsign:(c==null?void 0:c.callsign)??"???",hullPct:d,shieldPct:f,distance:h,critical:d<30})}Ir.sort((r,o)=>r.callsign.localeCompare(o.callsign));const s=Ir.length>0;t.container.classList.toggle("has-allies",s);for(let r=0;r<t.allyElements.length;r++){const o=t.allyElements[r],a=Ir[r];a?(o.row.style.display="flex",o.row.classList.toggle("critical",a.critical),o.callsign.textContent=a.callsign,o.hullBar.style.width=`${a.hullPct}%`,o.shieldBar.style.width=`${a.shieldPct}%`,o.distance.textContent=B3(a.distance),a.hullPct<25?o.hullBar.style.background="#f00":a.hullPct<50?o.hullBar.style.background="#f80":o.hullBar.style.background="#0f0"):o.row.style.display="none"}}function B3(t){return t>=1e3?`${(t/1e3).toFixed(1)}k`:`${Math.round(t)}m`}function z3(){return`
    .allied-display {
      position: absolute;
      top: 20px;
      left: 20px;
      background: rgba(0, 0, 0, 0.6);
      border: 1px solid #080;
      padding: 8px 10px;
      min-width: 140px;
      opacity: 0.6;
      transition: opacity 0.2s;
    }
    .allied-display.has-allies {
      opacity: 1;
      border-color: #0a0;
    }
    .allied-header {
      font-size: 10px;
      color: #0a0;
      letter-spacing: 1px;
      margin-bottom: 6px;
    }
    .ally-row {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 4px;
    }
    .ally-row.critical {
      animation: pulse 0.5s ease-in-out infinite alternate;
    }
    .ally-callsign {
      width: 52px;
      font-size: 10px;
      color: #0f0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ally-bars {
      display: flex;
      flex-direction: column;
      gap: 2px;
      flex: 1;
    }
    .ally-bar {
      height: 4px;
      background: rgba(0, 20, 0, 0.5);
      border: 1px solid #040;
    }
    .ally-bar-fill {
      height: 100%;
      width: 0%;
      transition: width 0.1s;
    }
    .ally-bar.hull .ally-bar-fill {
      background: #0f0;
    }
    .ally-bar.shield .ally-bar-fill {
      background: #0af;
    }
    .ally-distance {
      width: 32px;
      font-size: 9px;
      color: #080;
      text-align: right;
    }
  `}const Xp="hud-styles";function H3(){return`
    #hud {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      font-family: "Lucida Console", "Consolas", monospace;
      font-weight: bold;
      color: #0f0;
      overflow: hidden;
      text-transform: uppercase;
    }
    .status-panel {
      position: absolute;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      flex-direction: column;
      gap: 4px;
      background: rgba(0, 0, 0, 0.6);
      padding: 10px 12px;
      border: 1px solid #0f0;
    }
    .match-speed-indicator {
      position: absolute;
      bottom: 145px;
      left: 50%;
      transform: translateX(-50%);
      font-size: 14px;
      color: #0af;
      background: rgba(0, 0, 0, 0.6);
      padding: 4px 10px;
      border: 1px solid #0af;
    }
    /* Common row styling */
    .bar-row,
    .bar-container {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .bar-label {
      width: 40px;
      font-size: 13px;
    }
    .bar-value {
      width: 48px;
      font-size: 15px;
      text-align: right;
    }
    /* Speed bar with throttle marker */
    .speed-row {
      margin-bottom: 8px;
    }
    .speed-row .bar-value {
      font-size: 20px;
    }
    .speed-bar {
      position: relative;
      width: 180px;
      height: 14px;
      background: rgba(0, 20, 0, 0.5);
      border: 1px solid #0a0;
    }
    .speed-fill {
      position: absolute;
      left: 0;
      top: 0;
      height: 100%;
      width: 0%;
      background: #0f0;
      transition: width 0.05s linear;
    }
    .afterburner-fill {
      position: absolute;
      top: 0;
      height: 100%;
      width: 0%;
      background: #f80;
      transition: width 0.05s linear;
    }
    .max-speed-tick {
      position: absolute;
      top: -2px;
      bottom: -2px;
      width: 2px;
      background: #0a0;
      transform: translateX(-50%);
    }
    .throttle-marker {
      position: absolute;
      bottom: -12px;
      left: 0%;
      transform: translateX(-50%);
      font-size: 10px;
      color: #0f0;
      line-height: 1;
      transition: left 0.05s linear;
    }
    /* Status bars */
    .bar {
      width: 180px;
      height: 12px;
      background: rgba(0, 20, 0, 0.5);
      border: 1px solid #0a0;
      padding: 1px;
    }
    .bar-segments {
      display: flex;
      gap: 2px;
      height: 100%;
    }
    .segment {
      flex: 1;
      background: rgba(0, 40, 0, 0.5);
    }
    /* Shield bar colors */
    .shield-bar .segment.filled { background: #0af; }
    .bar-container.warning .shield-bar .segment.filled { background: #066; }
    .bar-container.warning .bar-label,
    .bar-container.warning .bar-value { color: #066; }
    /* Ionized state - purple/magenta glow indicates suppressed regen */
    .bar-container.ionized .shield-bar .segment.filled { background: #c0f; }
    .bar-container.ionized .bar-label,
    .bar-container.ionized .bar-value { color: #c0f; }
    .bar-container.ionized {
      animation: pulse 0.8s ease-in-out infinite alternate;
    }
    /* Hull bar colors */
    .hull-bar .segment.filled { background: #0f0; }
    .bar-container.critical .hull-bar .segment.filled { background: #f00; }
    .bar-container.critical .bar-label,
    .bar-container.critical .bar-value { color: #f00; }
    .bar-container.critical {
      animation: pulse 0.5s ease-in-out infinite alternate;
    }
    /* Heat bar colors */
    .heat-bar .segment.filled { background: #f80; }
    .bar-container.danger .heat-bar .segment.filled { background: #f00; }
    .bar-container.danger .bar-label,
    .bar-container.danger .bar-value { color: #f00; }
    .bar-container.danger {
      animation: pulse 0.3s ease-in-out infinite alternate;
    }
    @keyframes pulse {
      from { opacity: 1; }
      to { opacity: 0.5; }
    }
  `}const qp=150,qd=3e3,G3=3,W3=4,V3=[500,1e3,2e3],$3=Math.log(1+qd/500),bi={enemyDim:"#a00",enemyBright:"#f00",allyDim:"#0a0",allyBright:"#0f0",neutralDim:"#aa0",neutralBright:"#ff0",player:"#0f0",missile:"#888"},pt=new T,Tl=new at;function X3(t){const e=document.createElement("div");e.className="radar-container";const n=document.createElement("canvas");n.className="radar-canvas",n.width=qp,n.height=qp;const i=document.createElement("div");i.className="radar-label",i.textContent="RADAR",e.appendChild(i),e.appendChild(n),t.appendChild(e);const s=n.getContext("2d");return{canvas:n,ctx:s}}function Vu(t,e){if(t<=0)return 0;const n=Math.log(1+t/500)/$3;return Math.min(n*e,e)}function q3(t,e,n){const{ctx:i,canvas:s}=t,r=s.width/2,o=s.height/2,a=r-4;i.clearRect(0,0,s.width,s.height),i.fillStyle="rgba(0, 20, 0, 0.7)",i.beginPath(),i.arc(r,o,a,0,Math.PI*2),i.fill(),i.strokeStyle="#0a0",i.lineWidth=1,i.beginPath(),i.arc(r,o,a,0,Math.PI*2),i.stroke(),i.font='8px "Lucida Console", monospace',i.fillStyle="rgba(0, 100, 0, 0.6)",i.textAlign="center",i.textBaseline="middle";for(const d of V3){const f=Vu(d,a);i.strokeStyle="rgba(0, 100, 0, 0.3)",i.beginPath(),i.arc(r,o,f,0,Math.PI*2),i.stroke();const h=d>=1e3?`${d/1e3}k`:`${d}`;i.fillText(h,r+f-10,o-3)}i.strokeStyle="rgba(0, 100, 0, 0.4)",i.beginPath(),i.moveTo(r,o-a),i.lineTo(r,o+a),i.moveTo(r-a,o),i.lineTo(r+a,o),i.stroke();const c=C(e,n,"transform"),l=C(e,n,"faction"),u=C(e,n,"targeting");if(!(!c||!l)){Tl.copy(c.rotation).invert(),i.fillStyle=bi.player,i.beginPath(),i.moveTo(r,o-5),i.lineTo(r-4,o+4),i.lineTo(r+4,o+4),i.closePath(),i.fill();for(const d of Te(e,["transform","faction","health"])){if(d===n||Ke(e,d,"projectile")||Ke(e,d,"missile"))continue;const f=C(e,d,"health");if(!f||xt(f))continue;const h=C(e,d,"transform"),p=C(e,d,"faction");if(!h||!p||(pt.copy(h.position).sub(c.position),pt.applyQuaternion(Tl),Math.sqrt(pt.x*pt.x+pt.y*pt.y+pt.z*pt.z)>qd))continue;const g=Math.sqrt(pt.x*pt.x+pt.z*pt.z),m=Vu(g,a),S=Math.atan2(pt.x,-pt.z),_=r+Math.sin(S)*m,y=o-Math.cos(S)*m,D=p.faction!==l.faction&&p.faction!==ze.Neutral,E=p.faction===ze.Neutral,A=(u==null?void 0:u.currentTarget)===d;let P;E?P=A?bi.neutralBright:bi.neutralDim:D?P=A?bi.enemyBright:bi.enemyDim:P=A?bi.allyBright:bi.allyDim,i.fillStyle=P;const b=A?W3:G3;A?(i.beginPath(),i.moveTo(_,y-b),i.lineTo(_+b,y),i.lineTo(_,y+b),i.lineTo(_-b,y),i.closePath(),i.fill()):(i.beginPath(),i.arc(_,y,b,0,Math.PI*2),i.fill())}Y3(i,e,c,Tl,r,o,a)}}function Y3(t,e,n,i,s,r,o){t.strokeStyle=bi.missile,t.lineWidth=1.5,t.beginPath();for(const a of Te(e,["transform","missile","health"])){const c=C(e,a,"health");if(!c||xt(c))continue;const l=C(e,a,"transform");if(!l||(pt.copy(l.position).sub(n.position),pt.applyQuaternion(i),pt.length()>qd))continue;const d=Math.sqrt(pt.x*pt.x+pt.z*pt.z),f=Vu(d,o),h=Math.atan2(pt.x,-pt.z),p=s+Math.sin(h)*f,v=r-Math.cos(h)*f,g=2;t.moveTo(p-g,v-g),t.lineTo(p+g,v+g),t.moveTo(p+g,v-g),t.lineTo(p-g,v+g)}t.stroke()}function j3(){return`
    .radar-container {
      position: absolute;
      bottom: 20px;
      left: 20px;
      background: rgba(0, 0, 0, 0.6);
      border: 1px solid #0a0;
      padding: 6px;
    }
    .radar-label {
      font-size: 10px;
      color: #0a0;
      letter-spacing: 1px;
      margin-bottom: 4px;
    }
    .radar-canvas {
      display: block;
    }
  `}const Cn=160,Gn=120,K3=12,Z3=3,Al=new T,la=new T,Rl=new T;function J3(){const t=new $t(40,Cn/Gn,1,1e4),e=new Ui(Cn,Gn,{minFilter:qt,magFilter:qt,format:nn}),n=document.createElement("canvas");n.width=Cn,n.height=Gn,n.className="target-camera-canvas";const i=n.getContext("2d");if(!i)throw new Error("Failed to get 2D context for target camera canvas");const s=new Uint8Array(Cn*Gn*4);return{camera:t,renderTarget:e,canvas:n,ctx:i,pixelBuffer:s,dirLight:null,scene:null}}function Q3(t,e,n,i,s){if(s===void 0){Cl(t);return}const r=C(i,s,"targeting"),o=r==null?void 0:r.currentTarget;if(o===void 0){Cl(t);return}const a=C(i,o,"transform");if(!a){Cl(t);return}la.copy(a.position),Rl.set(0,Z3,K3),Rl.applyQuaternion(a.rotation),Al.copy(la).add(Rl),t.camera.position.copy(Al),t.camera.lookAt(la),t.dirLight||(t.dirLight=new zm(16777215,0),t.scene=n,n.add(t.dirLight)),t.dirLight.position.copy(Al),t.dirLight.target.position.copy(la),t.dirLight.target.updateMatrixWorld();const c=[];n.traverse(h=>{h!==t.dirLight&&h instanceof $a&&(c.push({light:h,intensity:h.intensity}),h.intensity=0)}),t.dirLight.intensity=3;const l=e.getRenderTarget();e.setRenderTarget(t.renderTarget),e.clear(),e.render(n,t.camera),e.setRenderTarget(l);for(const{light:h,intensity:p}of c)h.intensity=p;t.dirLight.intensity=0,e.readRenderTargetPixels(t.renderTarget,0,0,Cn,Gn,t.pixelBuffer);const u=t.ctx.createImageData(Cn,Gn),d=t.pixelBuffer,f=u.data;for(let h=0;h<Gn;h++){const p=(Gn-1-h)*Cn*4,v=h*Cn*4;for(let g=0;g<Cn*4;g++)f[v+g]=d[p+g]}t.ctx.putImageData(u,0,0)}function Cl(t){t.ctx.fillStyle="#111",t.ctx.fillRect(0,0,Cn,Gn),t.ctx.fillStyle="#333",t.ctx.font="12px monospace",t.ctx.textAlign="center",t.ctx.fillText("NO TARGET",Cn/2,Gn/2+4)}function eN(){return`
    .target-camera-canvas {
      width: 160px;
      height: 120px;
      border: 1px solid #600;
      margin-bottom: 8px;
      image-rendering: pixelated;
    }
    .target-stats.has-target .target-camera-canvas {
      border-color: #f00;
    }
  `}function tN(t){t.renderTarget.dispose(),t.dirLight&&t.scene&&(t.scene.remove(t.dirLight),t.dirLight.dispose())}const Yp=new T,jp=new T,Kp=new T;function nN(t){const e=document.createElement("div");return e.className="target-stats",e.innerHTML=`
    <div class="target-camera-container"></div>
    <div class="target-callsign">---</div>
    <div class="target-type">NO TARGET</div>
    <div class="target-row">
      <span class="target-label">DIST</span>
      <span class="target-distance">---</span>
    </div>
    <div class="target-row">
      <span class="target-label hull-label">HULL</span>
      <div class="target-bar hull"><div class="target-bar-fill"></div></div>
      <span class="target-bar-value">---</span>
    </div>
    <div class="target-row shield-row">
      <span class="target-label">SHLD</span>
      <div class="target-bar shield"><div class="target-bar-fill"></div></div>
      <span class="target-bar-value">---</span>
    </div>
    <div class="target-aspect">---</div>
  `,t.appendChild(e),{container:e,cameraContainer:e.querySelector(".target-camera-container"),callsignEl:e.querySelector(".target-callsign"),typeEl:e.querySelector(".target-type"),distanceEl:e.querySelector(".target-distance"),hullLabel:e.querySelector(".hull-label"),hullBar:e.querySelector(".target-bar.hull .target-bar-fill"),hullValue:e.querySelector(".target-bar.hull + .target-bar-value"),shieldRow:e.querySelector(".shield-row"),shieldBar:e.querySelector(".target-bar.shield .target-bar-fill"),shieldValue:e.querySelector(".target-bar.shield + .target-bar-value"),aspectEl:e.querySelector(".target-aspect")}}function iN(t,e,n){const i=C(e,n,"targeting"),s=i==null?void 0:i.currentTarget;if(s===void 0){t.callsignEl.textContent="---",t.typeEl.textContent="NO TARGET",t.distanceEl.textContent="---",t.hullLabel.textContent="HULL",t.hullBar.style.width="0%",t.hullValue.textContent="---",t.shieldBar.style.width="0%",t.shieldValue.textContent="---",t.aspectEl.textContent="---",t.container.classList.remove("has-target");return}t.container.classList.add("has-target");const r=C(e,s,"shipIdentity"),o=C(e,s,"health"),a=C(e,s,"shields"),c=C(e,s,"transform"),l=C(e,s,"physics"),u=C(e,n,"transform"),d=C(e,n,"physics"),f=Ke(e,s,"decoy"),h=f?C(e,s,"decoy"):void 0;if(f?(t.callsignEl.textContent="DECOY",t.typeEl.textContent="COUNTERMEASURE"):r?(t.callsignEl.textContent=r.callsign,t.typeEl.textContent=r.archetype.toUpperCase()):(t.callsignEl.textContent="???",t.typeEl.textContent="UNKNOWN"),c&&u){const p=u.position.distanceTo(c.position);t.distanceEl.textContent=rN(p)}else t.distanceEl.textContent="---";if(f&&h){t.hullLabel.textContent="TIME";const p=h.timeRemaining/Sg*100;t.hullBar.style.width=`${p}%`,t.hullValue.textContent=`${h.timeRemaining.toFixed(1)}s`,t.hullBar.style.background=p<30?"#f80":"#0af"}else if(o){t.hullLabel.textContent="HULL";const p=o.hull/o.maxHull*100;t.hullBar.style.width=`${p}%`,t.hullValue.textContent=`${Math.round(p)}%`,p<25?t.hullBar.style.background="#f00":p<50?t.hullBar.style.background="#f80":t.hullBar.style.background="#0f0"}else t.hullBar.style.width="0%",t.hullValue.textContent="---";if(f)t.shieldRow.style.display="none";else if(t.shieldRow.style.display="",a){const p=a.current/a.max*100;t.shieldBar.style.width=`${p}%`,t.shieldValue.textContent=`${Math.round(p)}%`}else t.shieldBar.style.width="0%",t.shieldValue.textContent="---";if(c&&u&&d){let p;if(f&&h)Kp.copy(h.direction).multiplyScalar(yg),p=Kp;else if(l)p=l.velocity;else{t.aspectEl.textContent="---",t.aspectEl.className="target-aspect";return}const v=sN(u.position,d.velocity,c.position,p);t.aspectEl.textContent=oN(v),t.aspectEl.className=`target-aspect ${v>10?"closing":v<-10?"separating":""}`}else t.aspectEl.textContent="---",t.aspectEl.className="target-aspect"}function sN(t,e,n,i){return Yp.copy(i).sub(e),jp.copy(n).sub(t).normalize(),-Yp.dot(jp)}function rN(t){return t>=1e3?`${(t/1e3).toFixed(1)}km`:`${Math.round(t)}m`}function oN(t){const e=Math.abs(t),n=e>=1e3?`${(e/1e3).toFixed(1)}k`:`${Math.round(e)}`;return t>10?`CLOSING +${n}`:t<-10?`SEPARATING -${n}`:"MATCHED"}function aN(){return`
    .target-stats {
      position: absolute;
      top: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.7);
      border: 1px solid #a00;
      padding: 8px 12px;
      min-width: 160px;
      opacity: 0.6;
      transition: opacity 0.2s;
    }
    .target-stats.has-target {
      opacity: 1;
      border-color: #f00;
    }
    .target-callsign {
      font-size: 14px;
      color: #f00;
      margin-bottom: 2px;
    }
    .target-type {
      font-size: 11px;
      color: #f88;
      margin-bottom: 8px;
    }
    .target-row {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 4px;
    }
    .target-label {
      width: 32px;
      font-size: 10px;
      color: #888;
    }
    .target-bar {
      flex: 1;
      height: 8px;
      background: rgba(40, 0, 0, 0.5);
      border: 1px solid #600;
    }
    .target-bar-fill {
      height: 100%;
      width: 0%;
      transition: width 0.1s;
    }
    .target-bar.hull .target-bar-fill {
      background: #0f0;
    }
    .target-bar.shield .target-bar-fill {
      background: #0af;
    }
    .target-bar-value {
      width: 36px;
      font-size: 10px;
      text-align: right;
      color: #f88;
    }
    .target-distance {
      font-size: 12px;
      color: #f88;
    }
    .target-aspect {
      margin-top: 6px;
      font-size: 11px;
      color: #888;
      text-align: center;
    }
    .target-aspect.closing {
      color: #f80;
    }
    .target-aspect.separating {
      color: #0af;
    }
  `}const ty=10;function Pl(){return Array(ty).fill('<div class="segment"></div>').join("")}function cN(t){const e=document.createElement("div");if(e.id="hud",e.innerHTML=`
    <div class="match-speed-indicator" style="display: none;">[MATCH SPEED]</div>
    <div class="status-panel">
      <div class="bar-row speed-row">
        <div class="bar-label">SPD</div>
        <div class="speed-bar">
          <div class="speed-fill"></div>
          <div class="afterburner-fill"></div>
          <div class="max-speed-tick"></div>
          <div class="throttle-marker">▲</div>
        </div>
        <div class="bar-value speed-value">0</div>
      </div>
      <div class="bar-container shield-container">
        <div class="bar-label">SHLD</div>
        <div class="bar shield-bar"><div class="bar-segments">${Pl()}</div></div>
        <div class="bar-value shield-value">100</div>
      </div>
      <div class="bar-container hull-container">
        <div class="bar-label">HULL</div>
        <div class="bar hull-bar"><div class="bar-segments">${Pl()}</div></div>
        <div class="bar-value hull-value">100</div>
      </div>
      <div class="bar-container heat-container">
        <div class="bar-label">HEAT</div>
        <div class="bar heat-bar"><div class="bar-segments">${Pl()}</div></div>
        <div class="bar-value heat-value">0</div>
      </div>
    </div>
  `,!document.getElementById(Xp)){const h=document.createElement("style");h.id=Xp,h.textContent=H3()+D3()+j3()+aN()+eN()+z3(),document.head.appendChild(h)}t.appendChild(e);const n=T3(e),i=I3(e),s=X3(e),r=nN(e),o=J3();r.cameraContainer.appendChild(o.canvas);const a=F3(e),c=()=>{Zv(n,t.clientWidth,t.clientHeight)};window.addEventListener("resize",c);const l=Array.from(e.querySelectorAll(".shield-bar .segment")),u=Array.from(e.querySelectorAll(".hull-bar .segment")),d=Array.from(e.querySelectorAll(".heat-bar .segment")),f=()=>{window.removeEventListener("resize",c),tN(o),e.remove()};return{container:e,speedFill:e.querySelector(".speed-fill"),afterburnerFill:e.querySelector(".afterburner-fill"),maxSpeedTick:e.querySelector(".max-speed-tick"),speedValue:e.querySelector(".speed-value"),throttleMarker:e.querySelector(".throttle-marker"),shieldSegments:l,hullSegments:u,heatSegments:d,shieldContainer:e.querySelector(".shield-container"),hullContainer:e.querySelector(".hull-container"),heatContainer:e.querySelector(".heat-container"),hullValue:e.querySelector(".hull-value"),shieldValue:e.querySelector(".shield-value"),heatValue:e.querySelector(".heat-value"),reticleCanvas:n,weaponDisplay:i,radarDisplay:s,targetStats:r,targetCamera:o,alliedDisplay:a,matchSpeedIndicator:e.querySelector(".match-speed-indicator"),dispose:f}}function lN(t,e,n,i,s,r){const o=Gm(e,["playerControlled","transform"]);if(o===void 0)return;uN(t,e,o),U3(t.weaponDisplay,e,o),q3(t.radarDisplay,e,o),iN(t.targetStats,e,o),O3(t.alliedDisplay,e,o);const a=C(e,o,"transform"),c=C(e,o,"physics");A3(t.reticleCanvas,e,o,a,c==null?void 0:c.velocity,n,i,s,r)}function uN(t,e,n){const i=C(e,n,"playerControlled");i&&(t.matchSpeedIndicator.style.display=i.matchSpeed?"block":"none");const s=C(e,n,"physics");if(s){const c=s.velocity.length(),l=s.maxSpeed*s.afterburnerMultiplier,u=s.maxSpeed/l*100;t.maxSpeedTick.style.left=`${u}%`;const d=Math.min(c/l*100,u);if(t.speedFill.style.width=`${d}%`,c>s.maxSpeed){const h=(c-s.maxSpeed)/(l-s.maxSpeed)*(100-u);t.afterburnerFill.style.width=`${h}%`,t.afterburnerFill.style.left=`${u}%`}else t.afterburnerFill.style.width="0%";t.speedValue.textContent=Math.round(c).toString();const f=s.currentSpeed/l*100;t.throttleMarker.style.left=`${Math.min(f,100)}%`}const r=C(e,n,"health");if(r){const c=r.hull/r.maxHull*100;Ll(t.hullSegments,c),t.hullValue.textContent=Math.round(r.hull).toString(),t.hullContainer.classList.toggle("critical",c<25)}const o=C(e,n,"shields");if(o){const c=o.current/o.max*100;Ll(t.shieldSegments,c),t.shieldValue.textContent=Math.round(o.current).toString(),t.shieldContainer.classList.toggle("warning",o.current<=0);const l=rg(o,e.systemState.gameTime);t.shieldContainer.classList.toggle("ionized",l)}const a=C(e,n,"heat");if(a){const c=uE(a)*100;Ll(t.heatSegments,c),t.heatValue.textContent=Math.round(a.current).toString(),t.heatContainer.classList.toggle("danger",c>80)}}function Ll(t,e){const n=Math.round(e/ty);for(let i=0;i<t.length;i++)t[i].classList.toggle("filled",i<n)}function dN(t,e){const n=lv(t,e),i=go(n);return{renderer:n,dustSystem:W0(i),explosionRenderer:X0(),boltRenderer:Q0(),exhaustRenderer:tv(),shieldEffectRenderer:K0(),muzzleFlashRenderer:Y0(),lightningRenderer:R0(),nuclearLanceRenderer:F0(),torchRenderer:B0(),projectileHitRenderer:Eg(),hud:cN(t)}}function fN(t,e,n,i,s=1){const{renderer:r}=t,o=go(r);uv(r,e,s),q0(t.explosionRenderer,o,e),ev(t.boltRenderer,o,e),nv(t.exhaustRenderer,o,e,e.systemState.gameTime),Z0(t.shieldEffectRenderer,o,e),j0(t.muzzleFlashRenderer,o,e),C0(t.lightningRenderer,o,e),O0(t.nuclearLanceRenderer,o,e),z0(t.torchRenderer,o,e),wg(t.projectileHitRenderer,o,e);const a=Gm(e,["playerControlled","transform"]);if(a!==void 0){PL(r,e,a);const c=C(e,a,"transform");c&&V0(t.dustSystem,c.position)}Q3(t.hud.targetCamera,r.webglRenderer,o,e,a),dv(r),lN(t.hud,e,r.camera,r.entityMeshes,n,i)}function hN(t){const e=go(t.renderer);WP(t.boltRenderer,e),pv(t.renderer),t.hud.container.parentNode&&t.hud.container.parentNode.removeChild(t.hud.container)}function pN(t,e,n,i){const{container:s,screenManager:r}=t;t.missionEnded=!1,t.missionContainer||(t.missionContainer=document.createElement("div"),t.missionContainer.id="mission-container",t.missionContainer.style.cssText="position: absolute; top: 0; left: 0; width: 100%; height: 100%;",s.appendChild(t.missionContainer),TA(r,t.missionContainer)),t.missionContainer.innerHTML="";const o=nD(),a=Ug(o);t.game=a;const c=dN(t.missionContainer,o);t.missionRenderers=c;const{campaignState:l}=r,u=YA(l),d=jA(l),f=new Set(n),h=d.filter(_=>f.has(_.id));u&&QL(a.world,u,new T(0,0,0)),h.forEach((_,y)=>{const E=20*(y%2===0?1:-1),A=-10-Math.floor(y/2)*15;eD(a.world,_,new T(E,0,A))}),mg(a.world);const p=KI(e.waves.length),v=ZI(),g=e.waves[0];if(g){const _=Xv(g.delay,a.world.prng);_>0?(p.currentWave=-1,p.waveCleared=!0,p.delayRemaining=_,console.log(`[WAVE ${performance.now().toFixed(0)}ms] First wave in ${_.toFixed(1)}s`)):(qv(a.world,g,0),console.log(`[WAVE ${performance.now().toFixed(0)}ms] Wave 1/${p.totalWaves} spawned`))}a.onRender=(_,y)=>{var D,E;fN(c,_,((D=t.missionContainer)==null?void 0:D.clientWidth)??800,((E=t.missionContainer)==null?void 0:E.clientHeight)??600,y)};const m=n3(t,a,e,v,i);a.onTick=i3(t,a,e,p,v,m),a.onMissionEnd=s3(t,p,v),kg(a);const S=e.waves.reduce((_,y)=>_+y.enemies.reduce((D,E)=>D+E.count,0),0);console.log(`[MISSION ${performance.now().toFixed(0)}ms] Mission started: ${e.name}`),console.log(`[MISSION ${performance.now().toFixed(0)}ms] ${S} enemies across ${e.waves.length} waves`)}function mN(t){Yw(),j1(),eT();const e=Dd(),n=bA(t,e),i={container:t,screenManager:n,missionContainer:null,game:null,missionRenderers:null,missionEnded:!1,pausedMissionForSettings:!1};return Yd(i),Hg(n),console.log("Campaign initialized - showing title screen"),i}function Yd(t){const{screenManager:e}=t,n=on(e,dt.TITLE);YL(n),jL(n,{onNewGame:()=>{const i=Dd();cr(e,i),Ru(e,null),Zp(t)},onContinue:(i,s)=>{cr(e,i),Ru(e,s),Zp(t)},onSettings:()=>{Gg(e),ny(t)}})}function ny(t){const{screenManager:e}=t,n=on(e,dt.SETTINGS),i=e.previousScreen===dt.TITLE;if(NR(n),UR(n,{onBack:()=>{if(i&&Cp()){const r=Rp(),o=document.getElementById("title-battle-bg");r&&o&&o.appendChild(r)}if(kR(),AA(e),t.pausedMissionForSettings&&t.game){t.pausedMissionForSettings=!1,Fg(t.game);return}const s=e.currentScreen;if(s===dt.TITLE)Yd(t);else if(s===dt.SQUADRON){const r=on(e,dt.SQUADRON);Sr(t,r,()=>jd(t))}}}),i&&Cp()){const s=Rp(),r=n.querySelector(".settings-screen"),o=n.querySelector("#settings-battle-bg");s&&r&&o&&(o.appendChild(s),r.classList.add("with-battle-bg"),PR(s))}}let Xr=null;function Zp(t){const{screenManager:e}=t;vv();const n=on(e,dt.SQUADRON);Sr(t,n,()=>jd(t)),co(e),gN(t);const{campaignState:i}=e;console.log("Campaign gameplay started"),console.log(`Credits: ${i.credits}`),console.log(`Ships: ${i.ships.length}`)}function gN(t){iy(),Xr=async e=>{const{screenManager:n}=t,i=[dt.SQUADRON,dt.STORE,dt.CONTRACTS,dt.RESULTS,dt.MISSION];if(e.code==="Escape"&&i.includes(n.currentScreen)){e.preventDefault();const s=n.currentScreen===dt.MISSION;s&&t.game&&_A(t.game);const r=!s&&n.currentScreen!==dt.RESULTS;await vN(t,r,s),s&&t.game&&n.currentScreen===dt.MISSION&&Fg(t.game)}},document.addEventListener("keydown",Xr)}function iy(){Xr&&(document.removeEventListener("keydown",Xr),Xr=null)}async function vN(t,e,n=!1){const{screenManager:i}=t,s=await yR(i.campaignState,e);switch(s.action){case"resume":break;case"save":s.saveSlot&&(Ru(i,s.saveSlot),console.log(`Game saved to slot ${s.saveSlot}`));break;case"settings":n&&(t.pausedMissionForSettings=!0),Gg(i),ny(t);break;case"quit":t.pausedMissionForSettings=!1,n&&t.game&&(Td(t.game),t.game=null,t.missionRenderers&&(hN(t.missionRenderers),t.missionRenderers=null),t.missionContainer&&(t.missionContainer.innerHTML="")),iy(),vv(),KL(),Hg(i),Yd(t);break}}function jd(t){const{screenManager:e}=t,n=on(e,dt.CONTRACTS),i=s=>jd(s);rR(n,e.campaignState,s=>{switch(s){case"squadron":{co(e);const r=on(e,dt.SQUADRON);Sr(t,r,i);break}case"store":{Bg(e);const r=on(e,dt.STORE);$v(t,r,i);break}}},async s=>{const r=await i2(e.campaignState,s);r.confirmed&&(EA(e,s),pN(t,s,r.deployedShipIds,i))})}function Jp(){const t=document.getElementById("game");if(!t)throw new Error("Game container not found");mN(t)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Jp):Jp();
